import { deflateSync } from 'zlib';
import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const assetsDir = join(root, 'public', 'assets');
const brandDir = join(assetsDir, 'brand');

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const typeBuf = Buffer.from(type);
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(width, height, pixels) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    const rowStart = y * (width * 4 + 1);
    raw[rowStart] = 0;
    pixels.copy(raw, rowStart + 1, y * width * 4, (y + 1) * width * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

function fillRect(pixels, width, x0, y0, x1, y1, r, g, b, a = 255) {
  const minX = Math.max(0, Math.floor(x0));
  const minY = Math.max(0, Math.floor(y0));
  const maxX = Math.min(width, Math.ceil(x1));
  const maxY = Math.min(pixels.length / (width * 4), Math.ceil(y1));
  for (let y = minY; y < maxY; y++) {
    for (let x = minX; x < maxX; x++) {
      const i = (y * width + x) * 4;
      pixels[i] = r;
      pixels[i + 1] = g;
      pixels[i + 2] = b;
      pixels[i + 3] = a;
    }
  }
}

function fillRoundRect(pixels, width, size, x, y, w, h, radius, r, g, b) {
  const rr = Math.max(0, radius);
  for (let py = Math.floor(y); py < y + h; py++) {
    for (let px = Math.floor(x); px < x + w; px++) {
      const dx = px < x + rr ? x + rr - px : px > x + w - rr ? px - (x + w - rr) : 0;
      const dy = py < y + rr ? y + rr - py : py > y + h - rr ? py - (y + h - rr) : 0;
      if (dx * dx + dy * dy > rr * rr && (dx !== 0 && dy !== 0)) continue;
      if (px < 0 || py < 0 || px >= width || py >= size) continue;
      const i = (py * width + px) * 4;
      pixels[i] = r;
      pixels[i + 1] = g;
      pixels[i + 2] = b;
      pixels[i + 3] = 255;
    }
  }
}

function drawUG(pixels, width, size, insetRatio) {
  const pad = size * insetRatio;
  const box = size - pad * 2;
  fillRoundRect(pixels, width, size, pad, pad, box, box, box * 0.22, 220, 38, 38);

  const unit = box / 11;
  const ox = pad + unit * 1.4;
  const oy = pad + unit * 2.2;
  const bar = unit * 1.35;
  const white = [255, 255, 255];

  // U
  fillRect(pixels, width, ox, oy, ox + bar, oy + unit * 5.4, ...white);
  fillRect(pixels, width, ox + unit * 3.1, oy, ox + unit * 3.1 + bar, oy + unit * 5.4, ...white);
  fillRect(pixels, width, ox, oy + unit * 4.4, ox + unit * 3.1 + bar, oy + unit * 6.6, ...white);

  // G
  const gx = ox + unit * 4.7;
  fillRect(pixels, width, gx, oy, gx + unit * 4.4, oy + bar, ...white);
  fillRect(pixels, width, gx, oy, gx + bar, oy + unit * 6.6, ...white);
  fillRect(pixels, width, gx, oy + unit * 5.25, gx + unit * 4.4, oy + unit * 6.6, ...white);
  fillRect(pixels, width, gx + unit * 3.05, oy + unit * 3.2, gx + unit * 4.4, oy + unit * 6.6, ...white);
  fillRect(pixels, width, gx + unit * 2.1, oy + unit * 3.2, gx + unit * 4.4, oy + unit * 3.2 + bar, ...white);
}

function makeIcon(size, insetRatio) {
  const pixels = Buffer.alloc(size * size * 4);
  for (let i = 0; i < pixels.length; i += 4) {
    pixels[i] = 255;
    pixels[i + 1] = 255;
    pixels[i + 2] = 255;
    pixels[i + 3] = 255;
  }
  drawUG(pixels, size, size, insetRatio);
  return encodePNG(size, size, pixels);
}

mkdirSync(brandDir, { recursive: true });
writeFileSync(join(assetsDir, 'icon-192.png'), makeIcon(192, 0.08));
writeFileSync(join(assetsDir, 'icon-512.png'), makeIcon(512, 0.08));
writeFileSync(join(assetsDir, 'icon-maskable-512.png'), makeIcon(512, 0.18));
writeFileSync(join(assetsDir, 'favicon.png'), makeIcon(64, 0.08));
writeFileSync(join(brandDir, 'ug-gaming-mark.png'), makeIcon(256, 0.08));
console.log('PWA icons written to public/assets');
