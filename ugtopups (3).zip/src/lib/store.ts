import { supabase } from './supabase';
import { 
  Game, GamePackage, BannerItem, UserProfile, Order, 
  GameCategory, ProductItem, SocialLinks, Review, CustomInputField, Announcement 
} from '../types';
import { 
  GAMES_DATA, INITIAL_BANNERS, INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_REVIEWS 
} from '../data/initialData';

// Collection / Table Names
export const CATEGORIES_COLLECTION = 'categories';
export const BANNERS_COLLECTION = 'banners';
export const GAMES_COLLECTION = 'games';
export const PRODUCTS_COLLECTION = 'products';
export const USERS_COLLECTION = 'users';
export const ORDERS_COLLECTION = 'orders';
export const ADMINS_COLLECTION = 'admins';
export const WALLET_REQUESTS_COLLECTION = 'walletRequests';
export const TRANSACTIONS_COLLECTION = 'transactions';
export const SETTINGS_COLLECTION = 'settings';
export const ANNOUNCEMENTS_COLLECTION = 'announcements';

// ── UG Coins Reward System ──────────────────────────────────────────────────
// Every successfully completed order (any payment method) rewards the user
// with UG Coins. Coins can be exchanged for UG Wallet credit at a fixed rate.
export const COINS_PER_SUCCESSFUL_ORDER = 3;
export const MIN_COIN_EXCHANGE = 30;         // Minimum 30 coins to exchange
export const COIN_EXCHANGE_RATE_COINS = 100; // 100 coins
export const COIN_EXCHANGE_RATE_NPR = 10;    // = NPR 10
export const coinsToNpr = (coins: number): number =>
  Math.round(((coins * COIN_EXCHANGE_RATE_NPR) / COIN_EXCHANGE_RATE_COINS) * 100) / 100;

// Helper: Generate unique channel name to prevent "cannot add callbacks after subscribe()" errors
export function getUniqueChannelName(base: string): string {
  return `${base}:${Math.random().toString(36).substring(2, 9)}_${Date.now()}`;
}

// Helper: Safely stringify objects for logging or storage
export function safeJsonStringify(data: any): string {
  try {
    return JSON.stringify(data);
  } catch (err) {
    return String(data);
  }
}

// Clean objects before saving
export function sanitizePayload<T extends Record<string, any>>(data: T): T {
  const clean: Record<string, any> = {};
  for (const [key, val] of Object.entries(data)) {
    if (val !== undefined) {
      clean[key] = val;
    }
  }
  return clean as T;
}

// Validation helpers
export function validateProduct(product: Partial<ProductItem>): string | null {
  if (!product.id || !product.id.trim()) return 'Missing product id';
  if ((!product.name || !product.name.trim()) && (!product.title || !(product as any).title.trim())) return 'Missing product name';
  return null;
}

export function sanitizeProduct(product: ProductItem): ProductItem {
  let embeddedCfg: any = null;
  const rawDescString = (product as any).rawDescription || product.description || '';
  let cleanDescription = rawDescString ? String(rawDescString).trim() : undefined;

  if (cleanDescription && cleanDescription.includes('<!--INPUT_CFG:')) {
    try {
      const match = cleanDescription.match(/<!--INPUT_CFG:(.*?)-->/s);
      if (match && match[1]) {
        embeddedCfg = JSON.parse(match[1]);
        cleanDescription = cleanDescription.replace(/<!--INPUT_CFG:.*?-->/s, '').trim() || undefined;
      }
    } catch (e) {
      console.warn('[INPUT_CFG PARSE ERROR]', e);
    }
  }

  const productName = String(product.name || (product as any).title || '').trim();
  const isMlbbName = /mobile\s*legends|mlbb/i.test(productName);

  const rawProdType = product.productType || (product as any).product_type || (embeddedCfg ? embeddedCfg.productType : undefined);
  const inferredProductType: 'voucher' | 'topup' = rawProdType === 'voucher' ? 'voucher' : (rawProdType === 'topup' ? 'topup' : (product.category === 'Voucher' ? 'voucher' : 'topup'));

  const reqZone = typeof product.requireZoneId === 'boolean' 
    ? product.requireZoneId 
    : (typeof (product as any).require_zone_id === 'boolean' 
        ? (product as any).require_zone_id 
        : (typeof (product as any).requiresZoneId === 'boolean'
            ? (product as any).requiresZoneId
            : (typeof (product as any).requires_zone_id === 'boolean'
                ? (product as any).requires_zone_id
                : (embeddedCfg && typeof embeddedCfg.requireZoneId === 'boolean' 
                    ? embeddedCfg.requireZoneId 
                    : (isMlbbName && inferredProductType !== 'voucher')))));

  const reqUid = typeof product.requireUid === 'boolean' 
    ? product.requireUid 
    : (typeof (product as any).require_uid === 'boolean' 
        ? (product as any).require_uid 
        : (embeddedCfg && typeof embeddedCfg.requireUid === 'boolean' 
            ? embeddedCfg.requireUid 
            : false));

  const reqEmail = typeof product.requireEmail === 'boolean' 
    ? product.requireEmail 
    : (typeof (product as any).require_email === 'boolean' 
        ? (product as any).require_email 
        : (embeddedCfg && typeof embeddedCfg.requireEmail === 'boolean' ? embeddedCfg.requireEmail : false));

  const reqPass = typeof product.requirePassword === 'boolean' 
    ? product.requirePassword 
    : (typeof (product as any).require_password === 'boolean' 
        ? (product as any).require_password 
        : (embeddedCfg && typeof embeddedCfg.requirePassword === 'boolean' ? embeddedCfg.requirePassword : false));

  const reqWa = typeof product.requireWhatsapp === 'boolean' 
    ? product.requireWhatsapp 
    : (typeof (product as any).require_whatsapp === 'boolean' 
        ? (product as any).require_whatsapp 
        : (embeddedCfg && typeof embeddedCfg.requireWhatsapp === 'boolean' ? embeddedCfg.requireWhatsapp : false));

  const uField1 = product.userField1 
    || (product as any).user_field1 
    || (embeddedCfg ? embeddedCfg.userField1 : undefined);

  const uField2 = product.userField2 
    || (product as any).user_field2 
    || (embeddedCfg ? embeddedCfg.userField2 : undefined);

  const descTitle = product.descriptionTitle 
    || (product as any).description_title 
    || (embeddedCfg ? embeddedCfg.descriptionTitle : undefined);

  const rawCustomFields = Array.isArray(product.customFields)
    ? product.customFields
    : (Array.isArray((product as any).custom_fields)
        ? (product as any).custom_fields
        : (embeddedCfg && Array.isArray(embeddedCfg.customFields) ? embeddedCfg.customFields : []));
  const cFields: CustomInputField[] = rawCustomFields
    .filter((f: any) => f && String(f.label || '').trim())
    .map((f: any) => ({ id: String(f.id || `cf_${Math.random().toString(36).slice(2, 9)}`), label: String(f.label).trim() }));

  const incomingPackages = Array.isArray((product as any).packages) ? (product as any).packages : [];

  return {
    id: String(product.id || '').trim(),
    name: productName,
    code: String(product.code || '').trim(),
    category: String(product.category || (inferredProductType === 'voucher' ? 'Voucher' : 'Games')).trim(),
    productType: inferredProductType,
    status: (product.status === 'Active' || product.status === 'Inactive') ? product.status : 'Active',
    availability: (['In Stock', 'Out Of Stock', 'Pre-Order'].includes(product.availability as string)) ? product.availability : 'In Stock',
    priceNpr: typeof product.priceNpr === 'number' ? product.priceNpr : (typeof (product as any).price_npr === 'number' ? (product as any).price_npr : 0),
    stockCount: typeof product.stockCount === 'number' ? product.stockCount : (typeof (product as any).stock_count === 'number' ? (product as any).stock_count : 0),
    imageUrl: String(product.imageUrl || (product as any).image_url || (product as any).image || '').trim(),
    description: cleanDescription,
    rawDescription: rawDescString,
    descriptionTitle: descTitle ? String(descTitle).trim() : undefined,
    requireUid: reqUid,
    requireZoneId: reqZone,
    requireEmail: reqEmail,
    requirePassword: reqPass,
    requireWhatsapp: reqWa,
    userField1: uField1 ? String(uField1).trim() : undefined,
    userField2: uField2 ? String(uField2).trim() : undefined,
    customFields: cFields,
    gameId: product.gameId ? String(product.gameId).trim() : ((product as any).game_id ? String((product as any).game_id).trim() : undefined),
    packages: incomingPackages,
    createdAt: product.createdAt || (product as any).created_at || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  } as ProductItem;
}

export function validateGame(game: Partial<Game>): string | null {
  if (!game.id || !game.id.trim()) return 'Missing game id';
  if (!game.name || !game.name.trim()) return 'Missing game name';
  return null;
}

export function sanitizeGame(game: Game): Game {
  return {
    id: String(game.id || '').trim(),
    name: String(game.name || '').trim(),
    category: String(game.category || 'Direct Topup').trim(),
    iconUrl: String((game as any).iconUrl || (game as any).imageUrl || '').trim(),
    bannerUrl: String(game.bannerUrl || '').trim(),
    requireUid: typeof game.requireUid === 'boolean' ? game.requireUid : false,
    requiresZoneId: typeof game.requiresZoneId === 'boolean' ? game.requiresZoneId : (typeof game.requireZoneId === 'boolean' ? game.requireZoneId : false),
    requireZoneId: typeof game.requireZoneId === 'boolean' ? game.requireZoneId : (typeof game.requiresZoneId === 'boolean' ? game.requiresZoneId : false),
    requireEmail: typeof game.requireEmail === 'boolean' ? game.requireEmail : false,
    requirePassword: typeof game.requirePassword === 'boolean' ? game.requirePassword : false,
    requireWhatsapp: typeof game.requireWhatsapp === 'boolean' ? game.requireWhatsapp : false,
    userField1: game.userField1 ? String(game.userField1).trim() : undefined,
    userField2: game.userField2 ? String(game.userField2).trim() : undefined,
    customFields: Array.isArray(game.customFields) ? game.customFields : [],
    uidPlaceholder: String(game.uidPlaceholder || 'Enter Player UID').trim(),
    description: String(game.description || '').trim(),
    packages: Array.isArray(game.packages) ? game.packages.map((pkg) => ({
      id: String(pkg.id || '').trim(),
      name: String(pkg.name || '').trim(),
      diamonds: typeof pkg.diamonds === 'number' ? pkg.diamonds : 0,
      priceNpr: typeof pkg.priceNpr === 'number' ? pkg.priceNpr : 0,
      originalPriceNpr: typeof pkg.originalPriceNpr === 'number' ? pkg.originalPriceNpr : undefined,
      popular: typeof pkg.popular === 'boolean' ? pkg.popular : false,
      badge: pkg.badge ? String(pkg.badge).trim() : undefined,
      inStock: typeof pkg.inStock === 'boolean' ? pkg.inStock : true,
      requiresRedeemCode: pkg.requiresRedeemCode === true,
      product_id: (pkg as any).product_id && !isNaN(Number((pkg as any).product_id)) ? Number((pkg as any).product_id) : undefined,
      variation_id: (pkg as any).variation_id && !isNaN(Number((pkg as any).variation_id)) ? Number((pkg as any).variation_id) : undefined,
    })) : [],
  };
}

export function validateUser(user: Partial<UserProfile>): string | null {
  if (!user.id || !user.id.trim()) return 'Missing user id';
  return null;
}

export function sanitizeUser(user: UserProfile): UserProfile {
  return {
    id: String(user.id || '').trim(),
    userCode: user.userCode ? String(user.userCode).trim() : undefined,
    username: String(user.username || 'User').trim(),
    email: String(user.email || '').trim(),
    gameUid: user.gameUid ? String(user.gameUid).trim() : '',
    avatarUrl: user.avatarUrl ? String(user.avatarUrl).trim() : '',
    walletBalanceNpr: typeof user.walletBalanceNpr === 'number' ? user.walletBalanceNpr : 0,
    level: user.level ? String(user.level).trim() : 'Regular Member',
    totalTopupsNpr: typeof user.totalTopupsNpr === 'number' ? user.totalTopupsNpr : 0,
    completedOrdersCount: typeof user.completedOrdersCount === 'number' ? user.completedOrdersCount : 0,
    coinBalance: typeof user.coinBalance === 'number' ? user.coinBalance : 0,
    registrationDate: user.registrationDate ? String(user.registrationDate) : new Date().toISOString(),
    disabled: typeof user.disabled === 'boolean' ? user.disabled : false,
  };
}

export function validateOrder(order: Partial<Order>): string | null {
  if (!order.orderId || !order.orderId.trim()) return 'Missing orderId';
  if (!order.userId || !order.userId.trim()) return 'Missing userId';
  return null;
}

export function sanitizeOrder(order: Order): Order {
  return {
    orderId: String(order.orderId || '').trim(),
    userId: String(order.userId || '').trim(),
    gameId: String(order.gameId || '').trim(),
    gameName: String(order.gameName || '').trim(),
    playerUid: String(order.playerUid || '').trim(),
    playerName: String(order.playerName || '').trim(),
    uidVerified: order.uidVerified === true,
    uidVerifiedAt: order.uidVerifiedAt || '',
    zoneId: order.zoneId ? String(order.zoneId).trim() : '',
    userEmail: order.userEmail ? String(order.userEmail).trim() : undefined,
    userPassword: order.userPassword ? String(order.userPassword).trim() : undefined,
    userWhatsapp: order.userWhatsapp ? String(order.userWhatsapp).trim() : undefined,
    userField1Val: order.userField1Val ? String(order.userField1Val).trim() : undefined,
    userField2Val: order.userField2Val ? String(order.userField2Val).trim() : undefined,
    customFieldValues: (() => {
      const raw = order.customFieldValues;
      if (Array.isArray(raw)) return raw;
      if (typeof raw === 'string') {
        try { const p = JSON.parse(raw); return Array.isArray(p) ? p : undefined; } catch { return undefined; }
      }
      return undefined;
    })(),
    packageId: String(order.packageId || '').trim(),
    packageName: String(order.packageName || '').trim(),
    diamonds: typeof order.diamonds === 'number' ? order.diamonds : 0,
    quantity: typeof order.quantity === 'number' ? order.quantity : 1,
    totalPriceNpr: typeof order.totalPriceNpr === 'number' ? order.totalPriceNpr : 0,
    walletDeductionNpr: typeof order.walletDeductionNpr === 'number' ? order.walletDeductionNpr : 0,
    paymentMethod: String(order.paymentMethod || 'UG Wallet').trim(),
    transactionRef: order.transactionRef ? String(order.transactionRef).trim() : '',
    // Preserve the exact gateway/order payment state. Converting SUCCESS/Pending/Failed
    // to Unpaid made valid Fonepay orders disappear from the admin filters.
    paymentStatus: String(order.paymentStatus || 'Pending').trim(),
    topUpStatus: order.topUpStatus || 'PENDING',
    status: order.status || 'Pending',
    createdAt: order.createdAt || new Date().toISOString(),
    completedAt: order.completedAt || '',
    completedBy: order.completedBy || '',
    cancelledAt: order.cancelledAt || '',
    cancelledBy: order.cancelledBy || '',
    rejectionReason: order.rejectionReason || '',
  };
}

// ── SEEDING DEFAULTS ──
export const seedSupabaseDefaults = async (): Promise<void> => {
  try {
    // Seed Categories
    for (const cat of INITIAL_CATEGORIES) {
      await supabase.from(CATEGORIES_COLLECTION).upsert(sanitizePayload(cat));
    }
    // Seed Banners
    for (const banner of INITIAL_BANNERS) {
      await supabase.from(BANNERS_COLLECTION).upsert(sanitizePayload(banner));
    }
    // Seed Games
    for (const game of GAMES_DATA) {
      await supabase.from(GAMES_COLLECTION).upsert(sanitizePayload(sanitizeGame(game)));
    }
  } catch (err) {
    console.warn('[SEED SUPABASE DEFAULTS]', err);
  }
};

// ── CATEGORIES ──
export const subscribeCategories = (callback: (categories: GameCategory[]) => void): (() => void) => {
  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase.from(CATEGORIES_COLLECTION).select('*');
      if (!error && data && data.length > 0) {
        callback(data as GameCategory[]);
      } else {
        callback(INITIAL_CATEGORIES);
      }
    } catch {
      callback(INITIAL_CATEGORIES);
    }
  };

  fetchCategories();

  const channel = supabase.channel(getUniqueChannelName('realtime:categories'))
    .on('postgres_changes', { event: '*', schema: 'public', table: CATEGORIES_COLLECTION }, () => {
      fetchCategories();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const saveCategory = async (category: GameCategory): Promise<boolean> => {
  try {
    const { error } = await supabase.from(CATEGORIES_COLLECTION).upsert(category);
    return !error;
  } catch {
    return false;
  }
};

export const deleteCategory = async (categoryId: string): Promise<boolean> => {
  try {
    const { error } = await supabase.from(CATEGORIES_COLLECTION).delete().eq('id', categoryId);
    return !error;
  } catch {
    return false;
  }
};

// ── BANNERS ──
export const subscribeBanners = (callback: (banners: BannerItem[]) => void): (() => void) => {
  const fetchBanners = async () => {
    try {
      const { data, error } = await supabase.from(BANNERS_COLLECTION).select('*');
      if (!error && data && data.length > 0) {
        callback(data as BannerItem[]);
      } else {
        callback(INITIAL_BANNERS);
      }
    } catch {
      callback(INITIAL_BANNERS);
    }
  };

  fetchBanners();

  const channel = supabase.channel(getUniqueChannelName('realtime:banners'))
    .on('postgres_changes', { event: '*', schema: 'public', table: BANNERS_COLLECTION }, () => {
      fetchBanners();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const saveBanner = async (banner: BannerItem): Promise<boolean> => {
  try {
    const { error } = await supabase.from(BANNERS_COLLECTION).upsert(banner);
    return !error;
  } catch {
    return false;
  }
};

export const deleteBanner = async (bannerId: string): Promise<boolean> => {
  try {
    const { error } = await supabase.from(BANNERS_COLLECTION).delete().eq('id', bannerId);
    return !error;
  } catch {
    return false;
  }
};

// ── ANNOUNCEMENTS ──
// Admin-facing: full list (RLS returns every row only when the caller is an
// admin; non-admins/anonymous callers only ever get rows with status='active').

// Standalone one-shot fetch — used both by subscribeAnnouncements() and by the
// admin UI to force-refresh the list right after a save/delete/toggle, so the
// UI never depends solely on Supabase Realtime (which may not be enabled on
// every project tier) to reflect a change.
export const fetchAllAnnouncements = async (): Promise<Announcement[]> => {
  try {
    const { data, error } = await supabase
      .from(ANNOUNCEMENTS_COLLECTION)
      .select('*')
      .order('priority', { ascending: false })
      .order('createdAt', { ascending: false });
    if (!error && data) {
      return data as Announcement[];
    }
    if (error) console.error('fetchAllAnnouncements:', error.message);
    return [];
  } catch (err: any) {
    console.error('fetchAllAnnouncements:', err?.message || err);
    return [];
  }
};

export const subscribeAnnouncements = (callback: (announcements: Announcement[]) => void): (() => void) => {
  const fetchAnnouncements = async () => {
    callback(await fetchAllAnnouncements());
  };

  fetchAnnouncements();

  const channel = supabase.channel(getUniqueChannelName('realtime:announcements'))
    .on('postgres_changes', { event: '*', schema: 'public', table: ANNOUNCEMENTS_COLLECTION }, () => {
      fetchAnnouncements();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

// Frontend-facing: resolves the single announcement (if any) that should be
// shown right now — status active, within its start/end window, configured
// for automatic display, highest priority first. Re-evaluates on realtime
// changes so admin edits reach visitors without a page refresh.
export const subscribeActiveAnnouncement = (callback: (announcement: Announcement | null) => void): (() => void) => {
  const resolveActive = async () => {
    try {
      const nowIso = new Date().toISOString();
      const { data, error } = await supabase
        .from(ANNOUNCEMENTS_COLLECTION)
        .select('*')
        .eq('status', 'active')
        .eq('autoDisplay', true)
        .or(`startAt.is.null,startAt.lte.${nowIso}`)
        .or(`endAt.is.null,endAt.gte.${nowIso}`)
        .order('priority', { ascending: false })
        .order('createdAt', { ascending: false })
        .limit(1);

      if (!error && data && data.length > 0) {
        callback(data[0] as Announcement);
      } else {
        if (error) console.error('subscribeActiveAnnouncement:', error.message);
        callback(null);
      }
    } catch (err: any) {
      console.error('subscribeActiveAnnouncement:', err?.message || err);
      callback(null);
    }
  };

  resolveActive();

  const channel = supabase.channel(getUniqueChannelName('realtime:active-announcement'))
    .on('postgres_changes', { event: '*', schema: 'public', table: ANNOUNCEMENTS_COLLECTION }, () => {
      resolveActive();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const saveAnnouncement = async (announcement: Announcement): Promise<boolean> => {
  try {
    const { error } = await supabase.from(ANNOUNCEMENTS_COLLECTION).upsert(announcement);
    if (error) console.error('saveAnnouncement:', error.message);
    return !error;
  } catch (err: any) {
    console.error('saveAnnouncement:', err?.message || err);
    return false;
  }
};

export const deleteAnnouncement = async (announcementId: string): Promise<boolean> => {
  try {
    const { error } = await supabase.from(ANNOUNCEMENTS_COLLECTION).delete().eq('id', announcementId);
    if (error) console.error('deleteAnnouncement:', error.message);
    return !error;
  } catch (err: any) {
    console.error('deleteAnnouncement:', err?.message || err);
    return false;
  }
};

// ── CHRONOLOGICAL SEQUENCE SORTING ──
/**
 * Sorts products or games in strict chronological sequence (First added / oldest first).
 * Evaluates createdAt, created_at, numeric timestamps in ID, and maintains time-based order.
 */
export function sortChronologicalAsc<T extends { id?: string; createdAt?: string; created_at?: string }>(items: T[]): T[] {
  if (!Array.isArray(items)) return [];

  const extractTime = (item: any): number => {
    const rawDate = item.createdAt || item.created_at;
    if (rawDate) {
      const t = new Date(rawDate).getTime();
      if (!isNaN(t) && t > 0) return t;
    }
    // Check if ID has timestamp like prd_1723456789012 or 1723456789012
    const id = String(item.id || '');
    const match = id.match(/\d{10,13}/);
    if (match) {
      const num = Number(match[0]);
      if (!isNaN(num) && num > 1500000000000) return num;
      if (!isNaN(num) && num > 1500000000) return num * 1000;
    }
    return 0;
  };

  return [...items].sort((a, b) => {
    const timeA = extractTime(a);
    const timeB = extractTime(b);

    if (timeA > 0 && timeB > 0 && timeA !== timeB) {
      return timeA - timeB; // Chronological order: first added comes first
    }
    if (timeA > 0 && timeB === 0) return -1;
    if (timeA === 0 && timeB > 0) return 1;

    return String(a.id || '').localeCompare(String(b.id || ''));
  });
}

// ── GAMES ──
// Products table is now the single source of truth.
// We map ProductItem → Game so the existing GameGrid/TopUpSection work unchanged.
export const productToGame = (p: any): Game => {
  const product = sanitizeProduct(p);
  return {
    id: product.id,
    name: product.name,
    category: product.category,
    productType: product.productType,
    iconUrl: product.imageUrl || '',
    bannerUrl: product.imageUrl || '',
    requireUid: product.productType === 'voucher' ? false : (typeof product.requireUid === 'boolean' ? product.requireUid : false),
    requiresZoneId: product.requireZoneId ?? false,
    requireZoneId: product.requireZoneId ?? false,
    requireEmail: product.requireEmail ?? false,
    requirePassword: product.requirePassword ?? false,
    requireWhatsapp: product.requireWhatsapp ?? false,
    userField1: product.userField1 || '',
    userField2: product.userField2 || '',
    customFields: Array.isArray(product.customFields) ? product.customFields : [],
    uidPlaceholder: 'Enter Player UID',
    description: product.description || '',
    createdAt: product.createdAt,
    updatedAt: product.updatedAt,
    packages: Array.isArray(p.packages) ? p.packages.map((pkg: any) => ({
      id: pkg.id || `pkg_${Date.now()}`,
      name: pkg.name || '',
      diamonds: typeof pkg.diamonds === 'number' ? pkg.diamonds : 0,
      bonus: pkg.bonus,
      priceNpr: typeof pkg.priceNpr === 'number' ? pkg.priceNpr : 0,
      badge: pkg.badge,
      iconType: pkg.iconType,
      category: pkg.category,
      active: pkg.active !== false,
      requiresRedeemCode: pkg.requiresRedeemCode === true,
    })) : [],
  };
};

export const subscribeGames = (callback: (games: Game[]) => void): (() => void) => {
  const fetchGames = async () => {
    try {
      const { data, error } = await supabase
        .from(PRODUCTS_COLLECTION)
        .select('*');
      if (!error && Array.isArray(data) && data.length > 0) {
        const mapped = data.map((p: any) => productToGame(p));
        callback(sortChronologicalAsc(mapped));
      } else {
        callback([]);
      }
    } catch {
      callback([]);
    }
  };

  fetchGames();

  const channel = supabase.channel(getUniqueChannelName('realtime:games'))
    .on('postgres_changes', { event: '*', schema: 'public', table: PRODUCTS_COLLECTION }, () => {
      fetchGames();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const saveGame = async (game: Game): Promise<boolean> => {
  // IMPORTANT: package configuration is stored as one JSON array. When the
  // admin edits/adds one MLBB package, an older in-memory copy can be missing
  // product_id values that already exist on other packages. Merge those values
  // from the latest database row by package id before saving so one package
  // can never erase another package's Liana product_id.
  let gameForSave: Game = game;
  try {
    const { data: existingRow } = await supabase
      .from(PRODUCTS_COLLECTION)
      .select('packages')
      .eq('id', game.id)
      .maybeSingle();

    const existingPackages = Array.isArray((existingRow as any)?.packages)
      ? (existingRow as any).packages
      : [];

    if (existingPackages.length && Array.isArray(game.packages)) {
      const existingById = new Map(existingPackages.map((p: any) => [String(p?.id || ''), p]));
      gameForSave = {
        ...game,
        packages: game.packages.map((pkg: any) => {
          const previous: any = existingById.get(String(pkg?.id || ''));
          if (!previous) return pkg;
          const next = { ...pkg };
          const currentProductId = next.product_id ?? next.productId ?? next.variation_id ?? next.variationId;
          const previousProductId = previous.product_id ?? previous.productId ?? previous.variation_id ?? previous.variationId;
          // Restore only a missing value. A valid product_id on the package being
          // edited always wins, so each package keeps its own independent ID.
          if ((currentProductId === undefined || currentProductId === null || currentProductId === '') &&
              previousProductId !== undefined && previousProductId !== null && previousProductId !== '') {
            next.product_id = Number(previousProductId);
          }
          return next;
        }),
      };
    }
  } catch (mergeError) {
    console.warn('[SUPABASE GAME SAVE] Could not merge latest package IDs; continuing with current data.', mergeError);
  }

  const clean = sanitizeGame(gameForSave);
  const errorMsg = validateGame(clean);
  if (errorMsg) {
    console.error('[SUPABASE GAME SAVE]', errorMsg);
    return false;
  }
  try {
    const isZone = clean.requireZoneId || clean.requiresZoneId || false;
    const reqUid = clean.requireUid;

    const cfgData = {
      requireUid: reqUid,
      requireZoneId: isZone,
      requireEmail: clean.requireEmail ?? false,
      requirePassword: clean.requirePassword ?? false,
      requireWhatsapp: clean.requireWhatsapp ?? false,
      userField1: clean.userField1 ?? '',
      userField2: clean.userField2 ?? '',
      customFields: Array.isArray(clean.customFields) ? clean.customFields : [],
    };
    const cfgTag = `<!--INPUT_CFG:${JSON.stringify(cfgData)}-->`;
    const baseDesc = (clean.description || '').replace(/<!--INPUT_CFG:.*?-->/s, '').trim();
    const descWithCfg = cfgTag + (baseDesc ? `\n${baseDesc}` : '');

    const createdAtTimestamp = clean.createdAt || (game as any).created_at || (game as any).createdAt || new Date().toISOString();

    const payload = sanitizePayload({
      id: clean.id,
      name: clean.name,
      title: clean.name,
      category: clean.category,
      imageUrl: clean.iconUrl,
      image_url: clean.iconUrl,
      description: descWithCfg,
      requireUid: reqUid,
      require_uid: reqUid,
      requireZoneId: isZone,
      requiresZoneId: isZone,
      require_zone_id: isZone,
      requires_zone_id: isZone,
      requireEmail: clean.requireEmail,
      require_email: clean.requireEmail,
      requirePassword: clean.requirePassword,
      require_password: clean.requirePassword,
      requireWhatsapp: clean.requireWhatsapp,
      require_whatsapp: clean.requireWhatsapp,
      userField1: clean.userField1 || '',
      user_field1: clean.userField1 || '',
      userField2: clean.userField2 || '',
      user_field2: clean.userField2 || '',
      packages: clean.packages,
      createdAt: createdAtTimestamp,
      created_at: createdAtTimestamp,
      updatedAt: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });

    const { error } = await supabase
      .from(PRODUCTS_COLLECTION)
      .upsert(payload, { onConflict: 'id' });

    if (error) {
      // Direct core fallback using universal columns
      const corePayload = sanitizePayload({
        id: clean.id,
        name: clean.name,
        category: clean.category,
        imageUrl: clean.iconUrl,
        image_url: clean.iconUrl,
        description: descWithCfg,
        packages: clean.packages,
        createdAt: createdAtTimestamp,
        created_at: createdAtTimestamp,
        updatedAt: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

      const { error: coreErr } = await supabase
        .from(PRODUCTS_COLLECTION)
        .upsert(corePayload, { onConflict: 'id' });

      if (coreErr) {
        await supabase
          .from(PRODUCTS_COLLECTION)
          .update({ name: clean.name, description: descWithCfg, packages: clean.packages })
          .eq('id', clean.id);
      }
    }
    return true;
  } catch (err) {
    console.error('[SUPABASE GAME SAVE]', err);
    return false;
  }
};

export const deleteGame = async (gameId: string): Promise<boolean> => {
  if (!gameId) return false;
  try {
    const { error } = await supabase.from(GAMES_COLLECTION).delete().eq('id', gameId.trim());
    return !error;
  } catch {
    return false;
  }
};

export const wipeAllGames = async (): Promise<boolean> => {
  try {
    const { error } = await supabase.from(GAMES_COLLECTION).delete().neq('id', '___none___');
    return !error;
  } catch {
    return false;
  }
};

// ── PRODUCTS ──
export const subscribeProducts = (callback: (products: ProductItem[]) => void): (() => void) => {
  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase.from(PRODUCTS_COLLECTION).select('*');
      if (!error && Array.isArray(data)) {
        const sanitized = data.map((p: any) => sanitizeProduct(p));
        callback(sortChronologicalAsc(sanitized));
      } else {
        callback([]);
      }
    } catch {
      callback([]);
    }
  };

  fetchProducts();

  const channel = supabase.channel(getUniqueChannelName('realtime:products'))
    .on('postgres_changes', { event: '*', schema: 'public', table: PRODUCTS_COLLECTION }, () => {
      fetchProducts();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const saveProduct = async (product: ProductItem): Promise<boolean> => {
  const clean = sanitizeProduct(product);
  const errorMsg = validateProduct(clean);
  if (errorMsg) {
    console.error('[SUPABASE PRODUCT SAVE] Validation error:', errorMsg);
    return false;
  }
  try {
    const isZone = clean.requireZoneId || false;
    const reqUid = clean.requireUid;

    const cfgData = {
      productType: clean.productType || 'topup',
      requireUid: reqUid,
      requireZoneId: isZone,
      requireEmail: clean.requireEmail ?? false,
      requirePassword: clean.requirePassword ?? false,
      requireWhatsapp: clean.requireWhatsapp ?? false,
      userField1: clean.userField1 ?? '',
      userField2: clean.userField2 ?? '',
      customFields: Array.isArray(clean.customFields) ? clean.customFields : [],
      descriptionTitle: clean.descriptionTitle ?? '',
    };
    const cfgTag = `<!--INPUT_CFG:${JSON.stringify(cfgData)}-->`;
    const baseDesc = (clean.description || '').replace(/<!--INPUT_CFG:.*?-->/s, '').trim();
    const descWithCfg = cfgTag + (baseDesc ? `\n${baseDesc}` : '');

    const incomingPkgs = Array.isArray((clean as any).packages) && (clean as any).packages.length > 0
      ? (clean as any).packages
      : (Array.isArray((product as any).packages) ? (product as any).packages : []);

    const productCreatedAt = clean.createdAt || (product as any).created_at || (product as any).createdAt || new Date().toISOString();
    const nowIso = new Date().toISOString();

    // Primary write payload — keys match the actual public.products schema exactly.
    // NOTE: the table has NO "updated_at" (snake_case) column, only "updatedAt" — sending
    // the snake_case key used to make PostgREST reject the whole upsert (schema-cache column
    // error), which silently dropped price/stock/title/code and the checkbox settings on
    // every save. Keep this payload limited to real columns.
    const productPayload = sanitizePayload({
      id: clean.id,
      title: clean.name,
      name: clean.name,
      code: clean.code,
      category: clean.category,
      status: clean.status,
      availability: clean.availability,
      priceNpr: clean.priceNpr,
      stockCount: clean.stockCount ?? 0,
      image: clean.imageUrl,
      imageUrl: clean.imageUrl,
      description: descWithCfg,
      packages: incomingPkgs,
      createdAt: productCreatedAt,
      created_at: productCreatedAt,
      updatedAt: nowIso,
    });

    let saveSucceeded = false;
    let lastErrorMsg = '';

    const { error: prodErr } = await supabase
      .from(PRODUCTS_COLLECTION)
      .upsert(productPayload, { onConflict: 'id' });

    if (!prodErr) {
      saveSucceeded = true;
    } else {
      lastErrorMsg = prodErr.message;
      console.warn('[SUPABASE PRODUCT SAVE] Primary upsert failed, retrying with core fields:', prodErr.message);
      const { error: coreErr } = await supabase
        .from(PRODUCTS_COLLECTION)
        .upsert(sanitizePayload({
          id: clean.id,
          name: clean.name,
          category: clean.category,
          description: descWithCfg,
          packages: incomingPkgs,
          status: clean.status,
          availability: clean.availability,
          imageUrl: clean.imageUrl,
          createdAt: productCreatedAt,
          created_at: productCreatedAt,
        }), { onConflict: 'id' });

      if (!coreErr) {
        saveSucceeded = true;
      } else {
        lastErrorMsg = coreErr.message;
        console.error('[SUPABASE PRODUCT SAVE] Fallback upsert also failed:', coreErr.message);
      }
    }

    if (!saveSucceeded) {
      console.error('[SUPABASE PRODUCT SAVE] Save failed completely for', clean.id, '-', lastErrorMsg);
      return false;
    }

    // Also sync to games table (legacy/secondary table) for unified consistency.
    // Not fatal if this fails — the products table above is the real source of truth.
    try {
      await supabase.from(GAMES_COLLECTION).upsert(sanitizePayload({
        id: clean.id,
        name: clean.name,
        category: clean.category,
        iconUrl: clean.imageUrl,
        bannerUrl: clean.imageUrl,
        requireUid: reqUid,
        requiresZoneId: isZone,
        requireZoneId: isZone,
        requireEmail: clean.requireEmail ?? false,
        requirePassword: clean.requirePassword ?? false,
        requireWhatsapp: clean.requireWhatsapp ?? false,
        packages: incomingPkgs,
        description: descWithCfg,
      }), { onConflict: 'id' });
    } catch {}

    console.log('[SUPABASE PRODUCT SAVE] Success:', clean.id, 'requireZoneId:', isZone, 'requireUid:', reqUid);
    return true;
  } catch (err) {
    console.error('[SUPABASE PRODUCT SAVE] Exception:', err);
    return false;
  }
};

export const deleteProduct = async (productId: string): Promise<boolean> => {
  if (!productId) return false;
  try {
    const { error } = await supabase.from(PRODUCTS_COLLECTION).delete().eq('id', productId.trim());
    return !error;
  } catch {
    return false;
  }
};

// ── ADMIN CHECK ──
export const ADMIN_EMAIL = 'rishugupta12444@gmail.com';

export const checkAdminStatus = async (uid: string): Promise<boolean> => {
  if (!uid) return false;
  try {
    const { data: authData } = await supabase.auth.getUser();
    if (authData?.user?.email?.toLowerCase().trim() === ADMIN_EMAIL) {
      return true;
    }
    const { data, error } = await supabase.from(ADMINS_COLLECTION).select('*').eq('id', uid.trim()).single();
    if (!error && data) {
      return Boolean(data.active !== false);
    }
    const { data: userData } = await supabase.from(USERS_COLLECTION).select('*').eq('id', uid.trim()).single();
    if (userData && (userData.email?.toLowerCase().trim() === ADMIN_EMAIL || userData.role === 'admin')) {
      return true;
    }
    return false;
  } catch {
    const { data: authData } = await supabase.auth.getUser();
    return authData?.user?.email?.toLowerCase().trim() === ADMIN_EMAIL;
  }
};

// ── USER PROFILE ──
export const saveUser = async (user: UserProfile): Promise<boolean> => {
  const cleanUser = sanitizeUser(user);
  const errorMsg = validateUser(cleanUser);
  if (errorMsg) return false;
  try {
    const { error } = await supabase.from(USERS_COLLECTION).upsert(cleanUser);
    return !error;
  } catch {
    return false;
  }
};

export const ensureUserDocumentExists = async (
  uid: string,
  email: string,
  displayName: string
): Promise<UserProfile | null> => {
  if (!uid) return null;
  try {
    const { data, error } = await supabase.from(USERS_COLLECTION).select('*').eq('id', uid).single();
    if (!error && data) {
      return sanitizeUser(data as UserProfile);
    }

    const userCode = `UG-USR-${Math.floor(1000 + Math.random() * 9000)}`;
    const newUser: UserProfile = sanitizeUser({
      id: uid,
      userCode,
      username: displayName || email.split('@')[0] || 'User',
      email,
      gameUid: '',
      avatarUrl: '',
      walletBalanceNpr: 0,
      level: 'Regular Member',
      totalTopupsNpr: 0,
      completedOrdersCount: 0,
      coinBalance: 0,
      registrationDate: new Date().toISOString(),
    });

    await supabase.from(USERS_COLLECTION).upsert(newUser);
    return newUser;
  } catch {
    return null;
  }
};

export const subscribeUserProfile = (uid: string, callback: (user: UserProfile | null) => void): (() => void) => {
  if (!uid || !uid.trim()) {
    callback(null);
    return () => {};
  }

  const fetchUser = async () => {
    try {
      const { data, error } = await supabase.from(USERS_COLLECTION).select('*').eq('id', uid.trim()).single();
      if (!error && data) {
        callback(sanitizeUser(data as UserProfile));
      } else {
        callback(null);
      }
    } catch {
      callback(null);
    }
  };

  fetchUser();

  const channel = supabase.channel(getUniqueChannelName(`realtime:user:${uid}`))
    .on('postgres_changes', { event: '*', schema: 'public', table: USERS_COLLECTION, filter: `id=eq.${uid.trim()}` }, () => {
      fetchUser();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const updateOwnUserProfile = async (
  uid: string,
  fields: Partial<Pick<UserProfile, 'username' | 'avatarUrl' | 'gameUid'>>
): Promise<boolean> => {
  if (!uid || !uid.trim()) return false;
  try {
    const { error } = await supabase.from(USERS_COLLECTION).update(fields).eq('id', uid.trim());
    return !error;
  } catch {
    return false;
  }
};

export const uploadAvatarAndUpdateProfile = async (uid: string, file: File): Promise<string> => {
  if (!uid) throw new Error('User ID is required to upload avatar');
  const filePath = `avatars/${uid.trim()}/${Date.now()}_${file.name}`;
  try {
    const { error } = await supabase.storage.from('avatars').upload(filePath, file, { upsert: true });
    let avatarUrl = '';
    if (!error) {
      const { data } = supabase.storage.from('avatars').getPublicUrl(filePath);
      avatarUrl = data.publicUrl;
    } else {
      avatarUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
    }
    await updateOwnUserProfile(uid, { avatarUrl });
    return avatarUrl;
  } catch {
    const fallbackUrl = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
    await updateOwnUserProfile(uid, { avatarUrl: fallbackUrl });
    return fallbackUrl;
  }
};

// ── WALLET REQUESTS ──
export interface ManualWalletRequestInput {
  uid: string;
  username: string;
  email?: string;
  avatarUrl?: string;
  amountNpr: number;
  screenshotFile: File;
}

export interface WalletRequestRecord {
  id: string;
  uid: string;
  username: string;
  email?: string;
  avatarUrl?: string;
  amountNpr: number;
  screenshotUrl: string;
  paymentMethod?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  remarks?: string;
  createdAt?: unknown;
  formattedTime?: string;
}

export const submitManualWalletRequest = async (input: ManualWalletRequestInput): Promise<boolean> => {
  if (!input.uid || !input.amountNpr || input.amountNpr <= 0) return false;
  try {
    const cleanFileName = input.screenshotFile.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const filePath = `wallet-request-screenshots/${input.uid.trim()}/${Date.now()}_${cleanFileName}`;
    let screenshotUrl = '';
    
    try {
      const { error: storageErr } = await supabase.storage.from('screenshots').upload(filePath, input.screenshotFile, { upsert: true });
      if (!storageErr) {
        const { data } = supabase.storage.from('screenshots').getPublicUrl(filePath);
        screenshotUrl = data.publicUrl;
      }
    } catch {}

    if (!screenshotUrl) {
      screenshotUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string) || '');
        reader.readAsDataURL(input.screenshotFile);
      });
    }

    const nowIso = new Date().toISOString();
    const reqId = `WR-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Payload formatted strictly for Supabase walletRequests table
    const dbPayload = {
      id: reqId,
      uid: input.uid.trim(),
      username: input.username || 'User',
      email: input.email || '',
      amountNpr: input.amountNpr,
      screenshotUrl: screenshotUrl,
      paymentMethod: 'Manual QR Verification',
      status: 'PENDING',
      createdAt: nowIso,
    };

    let { error: insertErr } = await supabase.from(WALLET_REQUESTS_COLLECTION).insert([dbPayload]);
    if (insertErr) {
      console.warn('walletRequests insert notice, attempting snake_case payload:', insertErr);
      const snakePayload = {
        id: reqId,
        uid: input.uid.trim(),
        username: input.username || 'User',
        email: input.email || '',
        amount_npr: input.amountNpr,
        screenshot_url: screenshotUrl,
        payment_method: 'Manual QR Verification',
        status: 'PENDING',
        created_at: nowIso,
      };
      await supabase.from('wallet_requests').insert([snakePayload]);
    }

    // Always update local cache as well so request shows immediately everywhere
    try {
      const localReqRecord: WalletRequestRecord = {
        id: reqId,
        uid: input.uid.trim(),
        username: input.username || 'User',
        email: input.email || '',
        avatarUrl: input.avatarUrl || '',
        amountNpr: input.amountNpr,
        screenshotUrl,
        paymentMethod: 'Manual QR Verification',
        status: 'PENDING',
        createdAt: nowIso,
        formattedTime: new Date(nowIso).toLocaleString(),
      };
      const existingStr = localStorage.getItem('ug_wallet_requests');
      const existingArr: WalletRequestRecord[] = existingStr ? JSON.parse(existingStr) : [];
      const updatedArr = [localReqRecord, ...existingArr.filter(r => r.id !== reqId)];
      localStorage.setItem('ug_wallet_requests', JSON.stringify(updatedArr));
      window.dispatchEvent(new Event('ug_wallet_requests_updated'));
    } catch (e) {
      console.warn('Local cache sync warning:', e);
    }

    return true;
  } catch (err) {
    console.error('submitManualWalletRequest error:', err);
    return false;
  }
};

export const subscribeAllWalletRequests = (callback: (requests: WalletRequestRecord[]) => void): (() => void) => {
  const fetchRequests = async () => {
    let supabaseRequests: WalletRequestRecord[] = [];
    try {
      // Query without .order() on database side to prevent "column createdAt does not exist" failure
      let { data, error } = await supabase.from(WALLET_REQUESTS_COLLECTION).select('*');
      if (error || !data) {
        const { data: altData } = await supabase.from('wallet_requests').select('*');
        if (altData) data = altData;
      }

      if (data && Array.isArray(data)) {
        supabaseRequests = data.map((r: any) => ({
          id: String(r.id || ''),
          uid: String(r.uid || ''),
          username: String(r.username || 'Customer'),
          email: String(r.email || ''),
          avatarUrl: String(r.avatarUrl || r.avatar_url || ''),
          amountNpr: typeof r.amountNpr === 'number' ? r.amountNpr : (typeof r.amount_npr === 'number' ? r.amount_npr : 0),
          screenshotUrl: String(r.screenshotUrl || r.screenshot_url || ''),
          paymentMethod: String(r.paymentMethod || r.payment_method || 'GPay'),
          status: (r.status === 'APPROVED' || r.status === 'REJECTED') ? r.status : 'PENDING',
          rejectionReason: r.rejectionReason || r.rejection_reason,
          remarks: r.remarks || r.rejectionReason || r.rejection_reason || '',
          createdAt: r.createdAt || r.created_at,
          formattedTime: (r.createdAt || r.created_at) ? new Date(r.createdAt || r.created_at).toLocaleString() : new Date().toLocaleString(),
        }));
      }
    } catch (err) {
      console.warn('Supabase fetchRequests warning:', err);
    }

    // Read local cache
    let localRequests: WalletRequestRecord[] = [];
    try {
      const cached = localStorage.getItem('ug_wallet_requests');
      if (cached) localRequests = JSON.parse(cached);
    } catch {}

    // Merge Supabase and Local (Supabase takes precedence if present)
    const map = new Map<string, WalletRequestRecord>();
    localRequests.forEach(r => map.set(r.id, r));
    supabaseRequests.forEach(r => map.set(r.id, r));

    const merged = Array.from(map.values()).sort((a, b) => {
      const timeA = new Date((a.createdAt as string) || 0).getTime();
      const timeB = new Date((b.createdAt as string) || 0).getTime();
      return timeB - timeA;
    });

    callback(merged);
  };

  fetchRequests();

  // Listen to local update events
  const handleLocalUpdate = () => { fetchRequests(); };
  window.addEventListener('ug_wallet_requests_updated', handleLocalUpdate);

  const channel = supabase.channel(getUniqueChannelName('realtime:walletRequests'))
    .on('postgres_changes', { event: '*', schema: 'public', table: WALLET_REQUESTS_COLLECTION }, () => {
      fetchRequests();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
    window.removeEventListener('ug_wallet_requests_updated', handleLocalUpdate);
  };
};

export const subscribePendingWalletRequests = (callback: (requests: WalletRequestRecord[]) => void): (() => void) => {
  return subscribeAllWalletRequests((all) => {
    callback(all.filter((r) => r.status === 'PENDING'));
  });
};

export const subscribeUsersList = (callback: (users: UserProfile[]) => void): (() => void) => {
  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase.from(USERS_COLLECTION).select('*');
      if (!error && data) {
        callback(data.map((u: any) => sanitizeUser(u)));
      } else {
        callback([]);
      }
    } catch {
      callback([]);
    }
  };

  fetchUsers();

  const channel = supabase.channel(getUniqueChannelName('realtime:users'))
    .on('postgres_changes', { event: '*', schema: 'public', table: USERS_COLLECTION }, () => {
      fetchUsers();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const approveWalletRequest = async (request: WalletRequestRecord): Promise<boolean> => {
  if (!request || !request.id) return false;
  const targetUid = (request.uid || '').trim();
  const targetEmail = (request.email || '').trim().toLowerCase();

  let ok = false;

  // 1. Attempt database RPC call if exists
  try {
    const { data: rpcRes, error: rpcErr } = await supabase.rpc('approve_wallet_request', { p_request_id: request.id.trim() });
    if (!rpcErr && rpcRes && rpcRes.success) {
      ok = true;
    }
  } catch {}

  // 2. Direct Supabase operations
  try {
    // Locate target user by ID or Email
    let targetUser: any = null;
    if (targetUid && targetUid !== request.id) {
      const { data: uById } = await supabase.from(USERS_COLLECTION).select('*').eq('id', targetUid).maybeSingle();
      if (uById) targetUser = uById;
    }
    if (!targetUser && targetEmail) {
      const { data: uByEmail } = await supabase.from(USERS_COLLECTION).select('*').ilike('email', targetEmail).maybeSingle();
      if (uByEmail) targetUser = uByEmail;
    }

    if (targetUser) {
      const realUserId = targetUser.id;
      const currentBal = typeof targetUser.walletBalanceNpr === 'number' ? targetUser.walletBalanceNpr : 0;
      const currentTotal = typeof targetUser.totalTopupsNpr === 'number' ? targetUser.totalTopupsNpr : 0;
      const newBal = currentBal + request.amountNpr;
      const newTotal = currentTotal + request.amountNpr;

      // Update users table balance
      await supabase.from(USERS_COLLECTION).update({
        walletBalanceNpr: newBal,
        totalTopupsNpr: newTotal,
      }).eq('id', realUserId);

      // Add transaction record
      const txnId = `TXN-WLT-${Date.now().toString().slice(-6)}`;
      const txnPayload = {
        id: txnId,
        uid: realUserId,
        userId: realUserId,
        username: request.username || targetUser.username || 'User',
        date: new Date().toLocaleString(),
        amount: request.amountNpr,
        type: 'RECHARGE',
        paymentMethod: request.paymentMethod || 'Manual QR Verification',
        status: 'SUCCESS',
        previousBalance: currentBal,
        newBalance: newBal,
        createdAt: new Date().toISOString(),
      };
      await supabase.from(TRANSACTIONS_COLLECTION).upsert(txnPayload);

      // Dispatch Transactional Email for Wallet Recharge (Background)
      try {
        supabase.functions.invoke('send-transactional-email', {
          body: {
            type: 'wallet_recharge_success',
            userId: realUserId,
            amount: request.amountNpr,
            paymentMethod: request.paymentMethod || 'Manual QR / Bank Transfer',
            transactionId: txnId,
            requestId: request.id,
            previousBalance: currentBal,
            newBalance: newBal,
          },
        }).then((res) => {
          if (res.error) console.warn('[EMAIL] Wallet recharge email dispatch notice:', res.error);
          else console.log('[EMAIL] Wallet recharge email dispatched for user:', realUserId);
        }).catch(() => {});
      } catch {}
    }

    // Update status to APPROVED
    await supabase.from(WALLET_REQUESTS_COLLECTION).update({ status: 'APPROVED' }).eq('id', request.id.trim());
    await supabase.from('wallet_requests').update({ status: 'APPROVED' }).eq('id', request.id.trim());
    ok = true;
  } catch (err) {
    console.warn('[Supabase approveWalletRequest notice]', err);
  }

  // 3. Update local storage registered users
  try {
    const regUsersRaw = localStorage.getItem('ug_admin_registered_users');
    if (regUsersRaw) {
      const regUsers: any[] = JSON.parse(regUsersRaw);
      const updatedReg = regUsers.map((u) => {
        if (u.id === targetUid || (request.email && u.email && u.email.toLowerCase().trim() === targetEmail)) {
          return {
            ...u,
            walletBalanceNpr: (u.walletBalanceNpr || 0) + request.amountNpr,
            totalTopupsNpr: (u.totalTopupsNpr || 0) + request.amountNpr,
          };
        }
        return u;
      });
      localStorage.setItem('ug_admin_registered_users', JSON.stringify(updatedReg));
      window.dispatchEvent(new Event('ug_users_updated'));
    }
  } catch {}

  // 4. Update current user profile local cache if it matches
  try {
    const activeProfRaw = localStorage.getItem('ug_user_profile');
    if (activeProfRaw) {
      const prof = JSON.parse(activeProfRaw);
      if (prof.id === targetUid || (request.email && prof.email && prof.email.toLowerCase().trim() === targetEmail)) {
        prof.walletBalanceNpr = (prof.walletBalanceNpr || 0) + request.amountNpr;
        prof.totalTopupsNpr = (prof.totalTopupsNpr || 0) + request.amountNpr;
        localStorage.setItem('ug_user_profile', JSON.stringify(prof));
        window.dispatchEvent(new Event('ug_profile_updated'));
      }
    }
  } catch {}

  // 5. Update local wallet requests list
  try {
    const cached = localStorage.getItem('ug_wallet_requests');
    let arr: WalletRequestRecord[] = cached ? JSON.parse(cached) : [];
    let found = false;
    arr = arr.map((r) => {
      if (r.id === request.id) {
        found = true;
        return { ...r, status: 'APPROVED' as const };
      }
      return r;
    });
    if (!found) {
      arr.unshift({ ...request, status: 'APPROVED' as const });
    }
    localStorage.setItem('ug_wallet_requests', JSON.stringify(arr));
    window.dispatchEvent(new Event('ug_wallet_requests_updated'));
  } catch {}

  // 6. Send automatic notification to user
  try {
    sendNotificationToUser({
      targetEmail: request.email,
      targetUid: targetUid,
      title: 'Payment Successful',
      message: `You have successfully credited Rs. ${request.amountNpr} in your account.`,
      category: 'Wallet',
    });
  } catch {}

  return ok;
};

export const rejectWalletRequest = async (requestId: string, reason?: string): Promise<boolean> => {
  if (!requestId) return false;

  try {
    await supabase.from(WALLET_REQUESTS_COLLECTION).update({
      status: 'REJECTED',
      rejectionReason: reason ? reason.trim() : undefined,
    }).eq('id', requestId.trim());
    await supabase.from('wallet_requests').update({
      status: 'REJECTED',
      rejectionReason: reason ? reason.trim() : undefined,
    }).eq('id', requestId.trim());
  } catch (err) {
    console.warn('[Supabase rejectWalletRequest notice]', err);
  }

  // Update local cache
  try {
    const cached = localStorage.getItem('ug_wallet_requests');
    if (cached) {
      const arr: WalletRequestRecord[] = JSON.parse(cached);
      const updated = arr.map((r) =>
        r.id === requestId ? { ...r, status: 'REJECTED' as const, rejectionReason: reason } : r
      );
      localStorage.setItem('ug_wallet_requests', JSON.stringify(updated));
      window.dispatchEvent(new Event('ug_wallet_requests_updated'));
    }
  } catch {}

  return true;
};

export const deleteWalletRequest = async (requestId: string): Promise<boolean> => {
  if (!requestId) return false;
  try {
    await supabase.from(WALLET_REQUESTS_COLLECTION).delete().eq('id', requestId.trim());
    await supabase.from('wallet_requests').delete().eq('id', requestId.trim());

    try {
      const cached = localStorage.getItem('ug_wallet_requests');
      if (cached) {
        const arr: WalletRequestRecord[] = JSON.parse(cached);
        const updated = arr.filter(r => r.id !== requestId);
        localStorage.setItem('ug_wallet_requests', JSON.stringify(updated));
        window.dispatchEvent(new Event('ug_wallet_requests_updated'));
      }
    } catch {}

    return true;
  } catch {
    return false;
  }
};

export const deleteSelectedWalletRequests = async (requestIds: string[]): Promise<boolean> => {
  if (!requestIds || requestIds.length === 0) return false;
  try {
    await supabase.from(WALLET_REQUESTS_COLLECTION).delete().in('id', requestIds);
    await supabase.from('wallet_requests').delete().in('id', requestIds);

    try {
      const cached = localStorage.getItem('ug_wallet_requests');
      if (cached) {
        const arr: WalletRequestRecord[] = JSON.parse(cached);
        const updated = arr.filter(r => !requestIds.includes(r.id));
        localStorage.setItem('ug_wallet_requests', JSON.stringify(updated));
        window.dispatchEvent(new Event('ug_wallet_requests_updated'));
      }
    } catch {}

    return true;
  } catch {
    return false;
  }
};

export const wipeAllWalletRequests = async (): Promise<boolean> => {
  try {
    await supabase.from(WALLET_REQUESTS_COLLECTION).delete().neq('id', '___non_existent___');
    await supabase.from('wallet_requests').delete().neq('id', '___non_existent___');

    try {
      localStorage.removeItem('ug_wallet_requests');
      window.dispatchEvent(new Event('ug_wallet_requests_updated'));
    } catch {}

    return true;
  } catch {
    return false;
  }
};

// ── ORDERS ──
export const safeUpsertOrder = async (order: Order): Promise<{ success: boolean; error?: any }> => {
  const clean = sanitizeOrder(order);
  let payload: Record<string, any> = { ...clean };

  // Attempt initial upsert. Keep the write authoritative: a successful HTTP
  // response is not enough for checkout because older RLS/schema deployments
  // have occasionally accepted the request but left no readable row.
  let { error } = await supabase.from(ORDERS_COLLECTION).upsert(payload, { onConflict: 'orderId' });

  // If Supabase schema cache doesn't have a column (e.g., userField1Val, userField2Val, etc.)
  let maxAttempts = 8;
  while (error && error.message && error.message.includes('schema cache') && maxAttempts > 0) {
    maxAttempts--;
    const match = error.message.match(/Could not find the '([^']+)' column/i);
    if (match && match[1]) {
      delete payload[match[1]];
      const res = await supabase.from(ORDERS_COLLECTION).upsert(payload);
      error = res.error;
    } else {
      break;
    }
  }

  // Verify the authoritative row before reporting success. This catches
  // intermittent RLS/schema/network failures instead of letting the checkout
  // continue with an order that only exists in client state.
  if (!error) {
    try {
      const { data: persisted, error: verifyError } = await supabase
        .from(ORDERS_COLLECTION)
        .select('orderId')
        .eq('orderId', clean.orderId)
        .maybeSingle();
      if (verifyError || !persisted) {
        error = verifyError || new Error('Order write could not be verified in Supabase.');
      }
    } catch (verifyErr) {
      error = verifyErr;
    }
  }

  // If the direct write failed (or could not be verified because of RLS), use
  // a server-side RPC that still validates that the authenticated user owns the
  // order. This prevents customer checkout from reporting success while no row
  // was actually persisted.
  if (error) {
    try {
      const rpc = await supabase.rpc('customer_persist_order', { p_order: payload });
      if (!rpc.error && rpc.data === true) {
        error = null;
      } else if (rpc.error) {
        error = rpc.error;
      }
    } catch (rpcErr) {
      error = rpcErr;
    }
  }

  // Also save to SETTINGS_COLLECTION backup asynchronously so order creation is never delayed
  (async () => {
    try {
      const { data: setDoc } = await supabase.from(SETTINGS_COLLECTION).select('*').eq('id', 'ug_orders_backup').single();
      let backupList: Order[] = setDoc && Array.isArray(setDoc.list) ? setDoc.list : [];
      const idx = backupList.findIndex(o => o.orderId === clean.orderId);
      if (idx >= 0) {
        backupList[idx] = { ...backupList[idx], ...clean };
      } else {
        backupList = [clean, ...backupList];
      }
      await supabase.from(SETTINGS_COLLECTION).upsert({ id: 'ug_orders_backup', list: backupList.slice(0, 300) });
    } catch {}
  })();

  return { success: !error, error };
};

export const safeUpdateOrder = async (orderId: string, updateData: Record<string, any>): Promise<boolean> => {
  let payload = { ...updateData };
  let { error } = await supabase.from(ORDERS_COLLECTION).update(payload).eq('orderId', orderId.trim());

  let maxAttempts = 8;
  while (error && error.message && error.message.includes('schema cache') && maxAttempts > 0) {
    maxAttempts--;
    const match = error.message.match(/Could not find the '([^']+)' column/i);
    if (match && match[1]) {
      delete payload[match[1]];
      const res = await supabase.from(ORDERS_COLLECTION).update(payload).eq('orderId', orderId.trim());
      error = res.error;
    } else {
      break;
    }
  }

  // Update backup list in SETTINGS_COLLECTION
  try {
    const { data: setDoc } = await supabase.from(SETTINGS_COLLECTION).select('*').eq('id', 'ug_orders_backup').single();
    if (setDoc && Array.isArray(setDoc.list)) {
      const idx = setDoc.list.findIndex((o: any) => o.orderId === orderId.trim());
      if (idx >= 0) {
        setDoc.list[idx] = { ...setDoc.list[idx], ...updateData };
        await supabase.from(SETTINGS_COLLECTION).upsert({ id: 'ug_orders_backup', list: setDoc.list });
      }
    }
  } catch {}

  return !error;
};

export const saveOrder = async (order: Order): Promise<boolean> => {
  const cleanOrder = sanitizeOrder(order);
  const errorMsg = validateOrder(cleanOrder);
  if (errorMsg) return false;
  try {
    const { success } = await safeUpsertOrder(cleanOrder);
    return success;
  } catch {
    return false;
  }
};

export const subscribeOrders = (callback: (orders: Order[]) => void): (() => void) => {
  const fetchOrders = async () => {
    try {
      // ADMIN ORDER MANAGEMENT must use ONLY the authoritative `orders` table.
      // Do not merge `ug_orders_backup` here: that backup is an optimistic/cache
      // copy and may contain an order that was never successfully persisted to
      // the orders table. Merging it made phantom orders appear in Admin.
      let data: any[] | null = null;
      let fetchError: any = null;

      try {
        const rpc = await supabase.rpc('admin_get_all_orders');
        if (!rpc.error && Array.isArray(rpc.data)) {
          data = rpc.data;
        } else {
          fetchError = rpc.error;
        }
      } catch (rpcErr) {
        fetchError = rpcErr;
      }

      // Backward-compatible fallback for deployments where the admin RPC has
      // not been installed yet. This still reads ONLY from `orders`.
      if (!Array.isArray(data)) {
        const direct = await supabase.from(ORDERS_COLLECTION).select('*');
        data = Array.isArray(direct.data) ? direct.data : [];
        fetchError = direct.error || fetchError;
      }

      if (fetchError) {
        console.error('[Admin Orders] Fetch warning:', fetchError?.message || fetchError);
      }

      const list: Order[] = Array.isArray(data)
        ? data.map((o: any) => ({ ...o, orderId: o.orderId || o.id } as Order))
        : [];

      // Sort safely across both possible timestamp field names.
      list.sort((a: any, b: any) => {
        const at = new Date(a?.createdAt || a?.created_at || a?.date || 0).getTime();
        const bt = new Date(b?.createdAt || b?.created_at || b?.date || 0).getTime();
        return bt - at;
      });

      callback(list);
    } catch (err) {
      console.error('[Admin Orders] Unexpected fetch error — preserving existing list:', err);
      // A transient error must not replace the current UI with backup/phantom
      // orders and must not wipe the existing list. Realtime will retry.
    }
  };

  fetchOrders();

  const channel = supabase.channel(getUniqueChannelName('realtime:orders'))
    .on('postgres_changes', { event: '*', schema: 'public', table: ORDERS_COLLECTION }, () => {
      fetchOrders();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const adminUpdateUserWallet = async (
  userId: string,
  operation: 'increase' | 'decrease' | 'set',
  amount: number,
  currentBalance: number,
  adminNote?: string
): Promise<{ success: boolean; newBalance: number }> => {
  if (!userId) return { success: false, newBalance: currentBalance };

  let newBalance: number;
  if (operation === 'increase') {
    newBalance = currentBalance + amount;
  } else if (operation === 'decrease') {
    newBalance = Math.max(0, currentBalance - amount);
  } else {
    newBalance = amount;
  }

  try {
    await supabase.from(USERS_COLLECTION).update({
      walletBalanceNpr: newBalance,
      ...(operation !== 'decrease' ? { totalTopupsNpr: currentBalance + (newBalance - currentBalance) } : {}),
    }).eq('id', userId.trim());

    const txnType = operation === 'decrease' ? 'DEDUCTION' : 'RECHARGE';
    const txnAmount = operation === 'set' ? Math.abs(newBalance - currentBalance) : amount;
    const txnId = `TXN-ADM-${Date.now().toString().slice(-6)}`;
    const rawTxn = {
      id: txnId,
      uid: userId.trim(),
      userId: userId.trim(),
      amount: txnAmount,
      type: txnType,
      operation,
      previousBalance: currentBalance,
      newBalance,
      paymentMethod: adminNote || 'Admin Manual Adjustment',
      status: 'SUCCESS',
      date: new Date().toLocaleString(),
      createdAt: new Date().toISOString(),
    };
    await supabase.from(TRANSACTIONS_COLLECTION).upsert(rawTxn);

    return { success: true, newBalance };
  } catch {
    return { success: false, newBalance: currentBalance };
  }
};

export const adminUpdateUsername = async (userId: string, newUsername: string): Promise<boolean> => {
  if (!userId || !newUsername.trim()) return false;
  try {
    const { error } = await supabase.from(USERS_COLLECTION).update({ username: newUsername.trim() }).eq('id', userId.trim());
    return !error;
  } catch {
    return false;
  }
};

export const adminToggleUserStatus = async (userId: string, disabled: boolean): Promise<boolean> => {
  if (!userId) return false;
  try {
    const { error } = await supabase.from(USERS_COLLECTION).update({ disabled }).eq('id', userId.trim());
    return !error;
  } catch {
    return false;
  }
};

export const markOrderUidVerified = async (orderId: string, playerUid: string): Promise<boolean> => {
  if (!orderId || !playerUid) return false;
  try {
    const { error } = await supabase
      .from(ORDERS_COLLECTION)
      .update({ uidVerified: true, uidVerifiedAt: new Date().toISOString() })
      .eq('orderId', orderId.trim())
      .eq('playerUid', playerUid.trim());
    return !error;
  } catch {
    return false;
  }
};

export const adminUpdateOrderStatus = async (
  orderId: string,
  newStatus: 'Completed' | 'Cancelled' | 'Pending',
  adminUid: string,
  rejectionReason?: string
): Promise<{ success: boolean; refundAmount?: number; refundedTo?: string; emailSent?: boolean; emailError?: string }> => {
  if (!orderId) return { success: false };
  try {
    const nowIso = new Date().toISOString();
    const updateData: Record<string, any> = {
      status: newStatus,
      topUpStatus: newStatus === 'Completed' ? 'COMPLETED' : newStatus === 'Cancelled' ? 'CANCELLED' : 'PENDING',
    };
    if (newStatus === 'Completed') {
      updateData.paymentStatus = 'Paid';
      updateData.completedAt = nowIso;
      updateData.completedBy = adminUid;
      updateData.uidVerified = true;
    } else if (newStatus === 'Cancelled') {
      updateData.cancelledAt = nowIso;
      updateData.cancelledBy = adminUid;
      if (rejectionReason) updateData.rejectionReason = rejectionReason;
    }
    // Use a SECURITY DEFINER admin RPC first. This keeps admin order state
    // changes atomic and avoids older/broken client-side RLS policies making an
    // order appear to disappear after Complete/Cancel. Fall back to the legacy
    // direct update for databases that have not run the migration yet.
    let ok = false;
    try {
      const { data: rpcOk, error: rpcError } = await supabase.rpc('admin_update_order_status', {
        p_order_id: orderId.trim(),
        p_new_status: newStatus,
        p_admin_uid: adminUid,
        p_rejection_reason: rejectionReason || null,
      });
      if (!rpcError && rpcOk === true) ok = true;
      else if (rpcError) console.warn('[Admin] Status RPC unavailable/failed, using direct update fallback:', rpcError.message);
    } catch (rpcErr) {
      console.warn('[Admin] Status RPC unavailable, using direct update fallback:', rpcErr);
    }

    if (!ok) {
      ok = await safeUpdateOrder(orderId.trim(), updateData);
    }

    if (!ok) {
      console.error('[Admin] Error updating order status in Supabase');
      return { success: false };
    }

    // ── AUTO-REFUND on Cancel ────────────────────────────────────────────
    // Refund is issued regardless of payment method (UG Wallet or QR/bank
    // transfer) — both go to the user's UG Wallet so they can re-use the
    // balance immediately. Only refund if the order wasn't already Cancelled.
    if (newStatus === 'Cancelled') {
      try {
        const { data: ord } = await supabase.from(ORDERS_COLLECTION).select('*').eq('orderId', orderId.trim()).single();

        // ── DOUBLE-REFUND GUARD ──────────────────────────────────────────────
        // Agar order pehle se refunded hai toh bilkul mat karo. Yeh tab hota
        // tha jab adminUpdateOrderStatus do baar call hoti thi (AdminDashboard
        // mein handleUpdateOrderStatus bhi call hota tha). Ab woh fix ho gaya
        // lekin yeh guard safety net ke roop mein rakha gaya hai.
        if (ord?.refunded === true) {
          console.warn(`[Admin] Refund already issued for order ${orderId} — skipping duplicate refund.`);
          return { success: true };
        }

        const uid = ord?.userId || ord?.uid;
        const refundAmount = Number(ord?.totalPriceNpr || ord?.walletDeductionNpr || 0);
        const pkgName = ord?.packageName || ord?.gameName || 'Game Item';

        if (uid && refundAmount > 0) {
          // Fetch current wallet balance
          const { data: userRow } = await supabase.from(USERS_COLLECTION).select('walletBalanceNpr').eq('id', uid).single();
          const currentBalance = Number(userRow?.walletBalanceNpr || 0);
          const newBalance = currentBalance + refundAmount;

          // Update wallet balance
          await supabase.from(USERS_COLLECTION).update({ walletBalanceNpr: newBalance }).eq('id', uid.trim());

          // Record refund transaction
          const txnId = `TXN-REF-${Date.now().toString().slice(-8)}`;
          await supabase.from(TRANSACTIONS_COLLECTION).upsert({
            id: txnId,
            orderId: orderId.trim(),
            uid,
            userId: uid,
            packageName: pkgName,
            gameName: ord?.gameName || '',
            amount: refundAmount,
            type: 'RECHARGE',
            paymentMethod: 'Refund – Order Cancelled',
            status: 'SUCCESS',
            previousBalance: currentBalance,
            newBalance,
            date: nowIso,
            createdAt: nowIso,
          });

          // Mark order as refunded
          await supabase.from(ORDERS_COLLECTION).update({ refunded: true, refundedAt: nowIso, refundedAmount: refundAmount }).eq('orderId', orderId.trim());

          // In-app notification to user
          await sendNotificationToUser({
            targetUid: uid,
            targetEmail: undefined,
            title: 'Order Cancelled – Refund Issued 💰',
            message: `Your order #${orderId} for ${pkgName} was cancelled. NPR ${refundAmount.toLocaleString('en-IN')} has been refunded to your UG Wallet.`,
            category: 'Wallet',
            orderId: orderId.trim(),
          });

          console.log(`[Admin] Refund of NPR ${refundAmount} issued to uid=${uid} for cancelled order ${orderId}`);
          return { success: true, refundAmount, refundedTo: uid };
        }
      } catch (refundErr) {
        console.error('[Admin] Refund step failed (order still cancelled):', refundErr);
        // Don't roll back the cancel — just log the failure
      }
    }

    if (newStatus === 'Completed') {
      try {
        const { data: ord } = await supabase.from(ORDERS_COLLECTION).select('*').eq('orderId', orderId.trim()).single();
        if (ord) {
          const pkgName = ord.packageName || ord.gameName || 'Game Item';
          // In-app notification
          await sendNotificationToUser({
            targetUid: ord.userId || ord.uid,
            targetEmail: undefined,
            title: 'Order Delivered 📦',
            message: `Your order of ${pkgName} is delivered, so check your account.`,
            category: 'Order',
            orderId: ord.orderId,
          });

          // Dispatch after the database completion succeeds. Email failure never rolls back delivery.
          const isVoucher = isRedeemCodeOrder(ord);
          const { data: emailData, error: emailInvokeError } = await supabase.functions.invoke('send-transactional-email', {
            body: { type: isVoucher ? 'voucher_delivered' : 'order_completed', orderId: ord.orderId },
          });
          if (emailInvokeError || !emailData?.success) {
            const emailError = emailInvokeError?.message || emailData?.message || 'Confirmation email could not be sent.';
            console.warn('[EMAIL] Order completed but email failed:', emailError);
            return { success: true, emailSent: false, emailError };
          }
          return { success: true, emailSent: !emailData?.alreadySent, emailAlreadySent: !!emailData?.alreadySent };
        }
      } catch {}
    }

    return { success: true };
  } catch (err) {
    console.error('[Admin] Exception in adminUpdateOrderStatus:', err);
    return { success: false };
  }
};

// ============================================================
// PRE-ORDER CACHE & OPTIMISTIC UI STORE
// Enables zero-latency checkout feedback and fast optimistic rendering
// ============================================================
export interface CachedPreOrder {
  order: Order;
  status: 'OPTIMISTIC' | 'CONFIRMED' | 'FAILED';
  timestamp: number;
}

const preOrderCache = new Map<string, CachedPreOrder>();

export const savePreOrderCache = (order: Order, status: 'OPTIMISTIC' | 'CONFIRMED' | 'FAILED' = 'OPTIMISTIC') => {
  if (!order || !order.orderId) return;
  preOrderCache.set(order.orderId, {
    order,
    status,
    timestamp: Date.now(),
  });
  // Clean up cache older than 10 minutes
  const now = Date.now();
  for (const [key, val] of preOrderCache.entries()) {
    if (now - val.timestamp > 10 * 60 * 1000) {
      preOrderCache.delete(key);
    }
  }
};

export const getPreOrderCache = (orderId: string): CachedPreOrder | undefined => {
  return preOrderCache.get(orderId);
};

export const removePreOrderCache = (orderId: string) => {
  preOrderCache.delete(orderId);
};

export const getPreOrdersForUser = (userId: string): Order[] => {
  if (!userId) return [];
  const list: Order[] = [];
  const normalized = userId.trim();
  for (const item of preOrderCache.values()) {
    if (item.status !== 'FAILED' && (item.order.userId === normalized || item.order.userEmail === normalized)) {
      list.push(item.order);
    }
  }
  return list;
};

/**
 * Pending Fonepay Hub rows are payment sessions, not customer orders yet.
 * Keep them available to the billing flow and Admin → API Payments, but never
 * expose them in customer order/history/account views until payment is verified.
 */
export const isCustomerVisibleOrder = (order: Partial<Order> | null | undefined): boolean => {
  if (!order) return false;
  const method = String(order.paymentMethod || '').toLowerCase();
  if (!method.includes('fonepay')) return true;
  return ['SUCCESS', 'PAID', 'COMPLETED'].includes(
    String(order.paymentStatus || '').toUpperCase()
  );
};

export const buildOptimisticOrder = (params: {
  uid: string;
  gameId: string;
  gameName: string;
  playerUid: string;
  playerName: string;
  zoneId?: string;
  userEmail?: string;
  userPassword?: string;
  userWhatsapp?: string;
  userField1Val?: string;
  userField2Val?: string;
  customFieldValues?: { id: string; label: string; value: string }[];
  packageId: string;
  packageName: string;
  diamonds: number;
  quantity: number;
  totalPriceNpr: number;
  uidVerified?: boolean;
  uidVerifiedAt?: string;
  isVoucher?: boolean;
  orderId?: string;
}): Order => {
  // Keep the existing order ID format. This fallback is only a local
  // pre-order placeholder and must never be persisted.
  const orderId = String(params.orderId || `TEMP-${Date.now()}-${Math.floor(Math.random() * 100000)}`);
  const nowIso = new Date().toISOString();
  // uidVerified means player UID was verified — NOT that it's a voucher product
  // isVoucher is only true if explicitly passed OR product name contains voucher keywords
  const isVoucher = params.isVoucher === true || /voucher|redeem|gift/i.test(`${params.gameName} ${params.packageName}`);

  return sanitizeOrder({
    orderId,
    userId: params.uid,
    gameId: params.gameId,
    gameName: params.gameName,
    playerUid: params.playerUid || (isVoucher ? 'VOUCHER_PURCHASE' : 'PLAYER'),
    playerName: params.playerName || (isVoucher ? 'Voucher Customer' : 'Player'),
    uidVerified: params.uidVerified === true,
    uidVerifiedAt: params.uidVerifiedAt || '',
    zoneId: params.zoneId || '',
    userEmail: params.userEmail || '',
    userPassword: params.userPassword || '',
    userWhatsapp: params.userWhatsapp || '',
    userField1Val: params.userField1Val || '',
    userField2Val: params.userField2Val || '',
    customFieldValues: params.customFieldValues || [],
    packageId: params.packageId,
    packageName: params.packageName,
    diamonds: params.diamonds,
    quantity: params.quantity,
    totalPriceNpr: params.totalPriceNpr,
    walletDeductionNpr: params.totalPriceNpr,
    paymentMethod: 'UG Wallet',
    transactionRef: `TXN-WLT-${Date.now().toString().slice(-8)}`,
    paymentStatus: 'Paid',
    topUpStatus: isVoucher ? 'COMPLETED' : 'PENDING',
    status: isVoucher ? 'Completed' : 'Pending',
    createdAt: nowIso,
    completedAt: isVoucher ? nowIso : '',
    completedBy: isVoucher ? 'AUTO_REDEEM_SYSTEM' : '',
    cancelledAt: '',
    cancelledBy: '',
  });
};

export const subscribeUserOrders = (
  uid: string,
  callback: (orders: Order[]) => void
): (() => void) => {
  if (!uid) {
    callback([]);
    return () => {};
  }

  const fetchUserOrders = async () => {
    try {
      const { data, error } = await supabase
        .from(ORDERS_COLLECTION)
        .select('*')
        .eq('userId', uid.trim())
        .order('createdAt', { ascending: false });

      let list: Order[] = data && data.length > 0 ? data.map((o: any) => ({ ...o, orderId: o.orderId || o.id } as Order)) : [];

      // Merge cached optimistic pre-orders if not yet in fetched database list
      const cachedOrders = getPreOrdersForUser(uid);
      if (cachedOrders.length > 0) {
        const existingIds = new Set(list.map(o => o.orderId));
        const newOptimistic = cachedOrders.filter(co => !existingIds.has(co.orderId));
        if (newOptimistic.length > 0) {
          list = [...newOptimistic, ...list];
        }
      }

      try {
        const { data: setDoc } = await supabase.from(SETTINGS_COLLECTION).select('*').eq('id', 'ug_orders_backup').single();
        if (setDoc && Array.isArray(setDoc.list) && setDoc.list.length > 0) {
          const userBackups = setDoc.list.filter((b: Order) => b.userId === uid.trim() || b.userEmail === uid.trim());
          const map = new Map<string, Order>();
          list.forEach(o => map.set(o.orderId, o));
          userBackups.forEach((b: Order) => {
            if (!map.has(b.orderId)) {
              map.set(b.orderId, b);
            } else {
              const existing = map.get(b.orderId)!;
              map.set(b.orderId, { ...b, ...existing, userField1Val: existing.userField1Val || b.userField1Val, userField2Val: existing.userField2Val || b.userField2Val });
            }
          });
          list = Array.from(map.values()).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        }
      } catch {}

      callback(list.filter(isCustomerVisibleOrder));
    } catch {
      callback(getPreOrdersForUser(uid).filter(isCustomerVisibleOrder));
    }
  };

  fetchUserOrders();

  const channel = supabase.channel(getUniqueChannelName(`realtime:orders:${uid}`))
    .on('postgres_changes', { event: '*', schema: 'public', table: ORDERS_COLLECTION, filter: `userId=eq.${uid.trim()}` }, () => {
      fetchUserOrders();
    })
    .on('postgres_changes', { event: '*', schema: 'public', table: SETTINGS_COLLECTION, filter: 'id=eq.ug_orders_backup' }, () => {
      fetchUserOrders();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export interface WalletOrderResult {
  success: boolean;
  order?: Order;
  error?: string;
}

export const placeWalletOrder = async (params: {
  uid: string;
  currentWalletBalance: number;
  gameId: string;
  gameName: string;
  playerUid: string;
  playerName: string;
  zoneId?: string;
  userEmail?: string;
  userPassword?: string;
  userWhatsapp?: string;
  userField1Val?: string;
  userField2Val?: string;
  customFieldValues?: { id: string; label: string; value: string }[];
  packageId: string;
  packageName: string;
  diamonds: number;
  quantity: number;
  totalPriceNpr: number;
  uidVerified?: boolean;
  uidVerifiedAt?: string;
  productId?: number;         // Liana product_id for MLBB auto-delivery
  existingOptimisticOrder?: Order;
}): Promise<WalletOrderResult> => {
  const { uid, currentWalletBalance, totalPriceNpr } = params;

  if (!uid) {
    return { success: false, error: 'Not authenticated. Please log in and try again.' };
  }

  if (currentWalletBalance < totalPriceNpr) {
    return {
      success: false,
      error: `Insufficient wallet balance. Your balance: NPR ${currentWalletBalance.toLocaleString('en-IN')}, Required: NPR ${totalPriceNpr.toLocaleString('en-IN')}`,
    };
  }

  const orderDoc: Order = params.existingOptimisticOrder || buildOptimisticOrder({
    uid,
    gameId: params.gameId,
    gameName: params.gameName,
    playerUid: params.playerUid,
    playerName: params.playerName,
    zoneId: params.zoneId,
    userEmail: params.userEmail,
    userPassword: params.userPassword,
    userWhatsapp: params.userWhatsapp,
    userField1Val: params.userField1Val,
    userField2Val: params.userField2Val,
    customFieldValues: params.customFieldValues,
    packageId: params.packageId,
    packageName: params.packageName,
    diamonds: params.diamonds,
    quantity: params.quantity,
    totalPriceNpr: params.totalPriceNpr,
    uidVerified: params.uidVerified,
    uidVerifiedAt: params.uidVerifiedAt,
  });

  // Save Liana product_id directly on the order so process-ml-order can
  // place the order without relying on old hard-coded variation IDs.
  if (params.productId) {
    (orderDoc as any).productId = params.productId;
    (orderDoc as any).product_id = params.productId;
  }

  const orderId = orderDoc.orderId;
  const transactionId = orderDoc.transactionRef || `TXN-WLT-${Date.now().toString().slice(-8)}`;
  const nowIso = new Date().toISOString();
  const newBalance = Math.max(0, currentWalletBalance - totalPriceNpr);

  // Cache optimistic pre-order immediately
  savePreOrderCache(orderDoc, 'OPTIMISTIC');

  try {
    // 1. If voucher order, attempt to assign available redeem codes
    // uidVerified means player UID was verified — NOT that it's a voucher product
    // Only treat as voucher if product name contains voucher keywords
    const isVoucher = /voucher|redeem|gift/i.test(`${params.gameName} ${params.packageName}`);
    if (isVoucher) {
      try {
        const { data: availCodes } = await supabase
          .from('redeem_codes')
          .select('id, code')
          .or(`product_id.eq.${params.gameId},package_id.eq.${params.packageId}`)
          .eq('status', 'available')
          .limit(params.quantity);

        if (availCodes && availCodes.length > 0) {
          const codeIds = availCodes.map(c => c.id);
          await supabase.from('redeem_codes').update({
            status: 'delivered',
            order_id: orderId,
            user_id: uid,
            delivered_at: nowIso,
          }).in('id', codeIds);

          orderDoc.topUpStatus = 'COMPLETED';
          orderDoc.status = 'Completed';
          orderDoc.completedAt = nowIso;
          orderDoc.completedBy = 'AUTO_REDEEM_SYSTEM';
        }
      } catch {
        // non-blocking
      }
    }

    // 2. Deduct wallet & insert order with rollback safety
    const { error: userErr } = await supabase.from(USERS_COLLECTION).update({ walletBalanceNpr: newBalance }).eq('id', uid);
    if (userErr) throw new Error(userErr.message);

    // 3. Insert order
    const { success: orderOk, error: orderErr } = await safeUpsertOrder(orderDoc);
    if (!orderOk) {
      // rollback balance
      await supabase.from(USERS_COLLECTION).update({ walletBalanceNpr: currentWalletBalance }).eq('id', uid);
      savePreOrderCache(orderDoc, 'FAILED');
      throw new Error(orderErr?.message || 'Failed to record order.');
    }

    // 4. Insert transaction
    const transactionDoc = {
      id: transactionId,
      orderId,
      uid,
      userId: uid,
      packageName: params.packageName,
      gameName: params.gameName,
      amount: params.totalPriceNpr,
      type: 'DEDUCTION',
      paymentMethod: 'UG Wallet',
      status: 'SUCCESS',
      previousBalance: currentWalletBalance,
      newBalance,
      date: nowIso,
      createdAt: nowIso,
    };
    await supabase.from(TRANSACTIONS_COLLECTION).upsert(transactionDoc);

    // 4b. Reward UG Coins for the successful order (reliable with fallback and activity logging)
    awardUserCoins(uid, COINS_PER_SUCCESSFUL_ORDER, {
      orderId,
      gameName: params.gameName,
      packageName: params.packageName,
    }).catch((coinErr) => {
      console.warn('[COINS] Failed to award coins for order:', coinErr);
    });

    // Mark as confirmed in cache
    savePreOrderCache(orderDoc, 'CONFIRMED');

    // 5. Send Automatic Notification (Asynchronous / Non-blocking)
    // Determine if this is a voucher/redeem-code order by checking the product type
    const isVoucherNotif = isVoucher && orderDoc.status === 'Completed';
    sendNotificationToUser({
      targetUid: uid,
      targetEmail: undefined,
      title: isVoucherNotif ? 'Voucher Delivered 🎟️' : 'Order Placed ✅',
      message: isVoucherNotif
        ? `Your voucher code for ${params.packageName} has been issued and is available in your order receipt!`
        : `Your order for ${params.packageName} (NPR ${params.totalPriceNpr}) has been placed successfully. Delivery is pending — we'll notify you once it's done.`,
      category: 'Order',
      orderId,
    }).catch((err) => {
      console.warn('[ORDER] Background notification notice:', err);
    });

    return { success: true, order: orderDoc };
  } catch (err: any) {
    savePreOrderCache(orderDoc, 'FAILED');
    return { success: false, error: err.message || 'Failed to place order.' };
  }
};

export interface CoinExchangeResult {
  success: boolean;
  error?: string;
  newCoinBalance?: number;
  newWalletBalance?: number;
}

// Ultra-reliable award UG Coins helper with multiple fallbacks, DB sync, and activity transaction logging
export const awardUserCoins = async (
  uid: string,
  amount: number = COINS_PER_SUCCESSFUL_ORDER,
  orderInfo?: { orderId?: string; gameName?: string; packageName?: string }
): Promise<{ success: boolean; newCoinBalance: number }> => {
  if (!uid) return { success: false, newCoinBalance: 0 };
  const coinsToAdd = Math.max(1, Math.floor(amount));

  let newBalance = 0;
  let success = false;

  // 1. Try atomic RPC on Supabase
  try {
    const { data, error } = await supabase.rpc('increment_user_coins', {
      p_uid: uid,
      p_amount: coinsToAdd,
    });
    if (!error && (typeof data === 'number' || (data !== null && !isNaN(Number(data))))) {
      newBalance = Number(data);
      success = true;
    }
  } catch (rpcErr) {
    console.warn('[COINS] RPC increment_user_coins failed, falling back:', rpcErr);
  }

  // 2. Direct database update fallback if RPC didn't return or failed
  if (!success) {
    try {
      const { data: userRow } = await supabase.from(USERS_COLLECTION).select('*').eq('id', uid).single();
      const currentCoins = Number(userRow?.coinBalance ?? userRow?.coin_balance ?? 0) || 0;
      newBalance = currentCoins + coinsToAdd;

      const { error: updateErr } = await supabase.from(USERS_COLLECTION).update({
        coinBalance: newBalance,
      }).eq('id', uid);

      if (updateErr && updateErr.message?.includes('schema cache')) {
        await supabase.from(USERS_COLLECTION).update({
          coin_balance: newBalance,
        } as any).eq('id', uid);
      }
      success = true;
    } catch (dbErr) {
      console.warn('[COINS] Direct DB update failed:', dbErr);
    }
  }

  // 3. Local storage persistence & cached user update
  try {
    const cachedUserStr = localStorage.getItem(`ug_user_profile_${uid}`);
    if (cachedUserStr) {
      const cached = JSON.parse(cachedUserStr);
      cached.coinBalance = newBalance || ((cached.coinBalance || 0) + coinsToAdd);
      localStorage.setItem(`ug_user_profile_${uid}`, JSON.stringify(cached));
    }
    if (newBalance > 0) {
      localStorage.setItem(`ug_coin_balance_${uid}`, String(newBalance));
    }
  } catch {}

  // 4. Log coin activity transaction so it shows up in user's Coin Activity
  try {
    const nowIso = new Date().toISOString();
    const orderTitle = orderInfo?.packageName || orderInfo?.gameName || 'Order';
    const txnDoc = {
      id: `COIN-REW-${orderInfo?.orderId || Date.now()}`,
      orderId: orderInfo?.orderId || '',
      uid,
      userId: uid,
      packageName: `Earned +${coinsToAdd} UG Coins (${orderTitle})`,
      amount: coinsToAdd,
      type: 'CREDIT',
      paymentMethod: 'UG Coins Reward',
      status: 'SUCCESS',
      date: nowIso,
      createdAt: nowIso,
    };
    await supabase.from(TRANSACTIONS_COLLECTION).upsert(txnDoc);
  } catch {}

  // 5. Dispatch window events for instant UI sync across all open pages/components
  try {
    window.dispatchEvent(new CustomEvent('ug_coins_updated', { detail: { uid, newBalance, coinsAdded: coinsToAdd } }));
    window.dispatchEvent(new Event('ug_profile_updated'));
    window.dispatchEvent(new Event('ug_wallet_requests_updated'));
  } catch {}

  return { success: true, newCoinBalance: newBalance };
};

// Exchange UG Coins for UG Wallet credit at the fixed rate
// (100 coins = NPR 10). Minimum 30 coins required to exchange.
export const exchangeCoinsForWalletCredit = async (
  uid: string,
  coins: number
): Promise<CoinExchangeResult> => {
  if (!uid) return { success: false, error: 'Not authenticated. Please log in and try again.' };
  const coinAmount = Math.floor(coins);
  if (!coinAmount || coinAmount <= 0) {
    return { success: false, error: 'Enter a valid number of coins to exchange.' };
  }
  if (coinAmount < MIN_COIN_EXCHANGE) {
    return { success: false, error: `Minimum ${MIN_COIN_EXCHANGE} UG Coins required to exchange.` };
  }

  const creditNpr = coinsToNpr(coinAmount);

  // 1. Try atomic RPC
  try {
    const { data, error } = await supabase.rpc('exchange_coins_for_wallet', {
      p_uid: uid,
      p_coins: coinAmount,
    });

    if (!error && data) {
      const row = Array.isArray(data) ? data[0] : data;
      const newCoins = Number(row?.new_coin_balance ?? row?.newCoinBalance ?? 0);
      const newWallet = Number(row?.new_wallet_balance ?? row?.newWalletBalance ?? 0);
      try {
        localStorage.setItem(`ug_coin_balance_${uid}`, String(newCoins));
        window.dispatchEvent(new Event('ug_profile_updated'));
        window.dispatchEvent(new Event('ug_wallet_requests_updated'));
      } catch {}
      return {
        success: true,
        newCoinBalance: newCoins,
        newWalletBalance: newWallet,
      };
    }
  } catch (rpcErr) {
    console.warn('[COINS] RPC exchange failed, running direct fallback:', rpcErr);
  }

  // 2. Direct database fallback if RPC is not present
  try {
    const { data: userRow, error: fetchErr } = await supabase.from(USERS_COLLECTION).select('*').eq('id', uid).single();
    if (fetchErr || !userRow) {
      return { success: false, error: 'User profile not found.' };
    }

    const curCoins = Number(userRow.coinBalance ?? userRow.coin_balance ?? 0) || 0;
    const curWallet = Number(userRow.walletBalanceNpr ?? userRow.wallet_balance_npr ?? 0) || 0;

    if (coinAmount > curCoins) {
      return { success: false, error: 'You do not have enough UG Coins for this exchange.' };
    }

    const newCoins = Math.max(0, curCoins - coinAmount);
    const newWallet = Number((curWallet + creditNpr).toFixed(2));

    await supabase.from(USERS_COLLECTION).update({
      coinBalance: newCoins,
      walletBalanceNpr: newWallet,
    }).eq('id', uid);

    const nowIso = new Date().toISOString();
    await supabase.from(TRANSACTIONS_COLLECTION).upsert({
      id: `TXN-COIN-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      uid,
      userId: uid,
      packageName: `${coinAmount} UG Coins Exchanged`,
      amount: creditNpr,
      type: 'RECHARGE',
      paymentMethod: 'UG Coins',
      status: 'SUCCESS',
      date: nowIso,
      createdAt: nowIso,
    });

    try {
      localStorage.setItem(`ug_coin_balance_${uid}`, String(newCoins));
      window.dispatchEvent(new Event('ug_profile_updated'));
      window.dispatchEvent(new Event('ug_wallet_requests_updated'));
    } catch {}

    return {
      success: true,
      newCoinBalance: newCoins,
      newWalletBalance: newWallet,
    };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Coin exchange failed. Please try again.' };
  }
};

export const subscribeUserTransactions = (
  uid: string,
  callback: (transactions: import('../types').WalletTransaction[]) => void
): (() => void) => {
  if (!uid) {
    callback([]);
    return () => {};
  }

  const fetchTxns = async () => {
    try {
      // 1. Fetch from TRANSACTIONS_COLLECTION
      const { data: dbTxns } = await supabase
        .from(TRANSACTIONS_COLLECTION)
        .select('*')
        .eq('uid', uid.trim())
        .order('createdAt', { ascending: false });

      const visibleDbTxns = (dbTxns || []).filter((data: any) => {
        const method = String(data?.paymentMethod || data?.payment_method || '').toLowerCase();
        if (!method.includes('fonepay')) return true;
        return ['SUCCESS', 'PAID', 'COMPLETED', 'APPROVED'].includes(
          String(data?.status || data?.paymentStatus || data?.payment_status || '').toUpperCase()
        );
      });

      const txnsList: import('../types').WalletTransaction[] = visibleDbTxns.map((data: any) => {
        const rawType = (data.type || 'DEDUCTION').toUpperCase();
        const isDeposit = rawType === 'RECHARGE' || rawType === 'CREDIT' || rawType === 'TOPUP';
        const rawAmt = Number(data.amount) || 0;
        const formattedAmount = isDeposit ? Math.abs(rawAmt) : -Math.abs(rawAmt);

        return {
          id: data.id,
          orderId: data.orderId,
          packageName: data.packageName || (isDeposit ? 'Instant Online Wallet Load' : 'Order Payment'),
          amount: formattedAmount,
          type: isDeposit ? 'RECHARGE' as const : 'DEDUCTION' as const,
          date: data.date || data.createdAt || new Date().toISOString(),
          paymentMethod: data.paymentMethod || 'UG Wallet',
          status: data.status || 'SUCCESS',
        };
      });

      // 2. Fetch manual wallet requests for this user
      let userRequests: WalletRequestRecord[] = [];

      try {
        const cachedStr = localStorage.getItem('ug_wallet_requests');
        if (cachedStr) {
          const allLocal: WalletRequestRecord[] = JSON.parse(cachedStr);
          userRequests = allLocal.filter((r) => (r.uid && r.uid.trim() === uid.trim()) || r.id === uid.trim());
        }
      } catch {}

      try {
        const { data: reqData } = await supabase
          .from(WALLET_REQUESTS_COLLECTION)
          .select('*')
          .eq('uid', uid.trim());
        if (reqData && reqData.length > 0) {
          const map = new Map<string, WalletRequestRecord>();
          userRequests.forEach((r) => map.set(r.id, r));
          reqData.forEach((r: any) => {
            const mapped: WalletRequestRecord = {
              id: r.id,
              uid: r.uid,
              username: r.username || 'User',
              email: r.email || '',
              amountNpr: r.amountNpr || r.amount_npr || 0,
              screenshotUrl: r.screenshotUrl || r.screenshot_url || '',
              paymentMethod: r.paymentMethod || r.payment_method || 'Manual QR Verification',
              status: (r.status as any) || 'PENDING',
              createdAt: r.createdAt || r.created_at || new Date().toISOString(),
            };
            map.set(mapped.id, mapped);
          });
          userRequests = Array.from(map.values());
        }
      } catch {}

      // Convert manual wallet requests into WalletTransaction objects
      const requestTxns: import('../types').WalletTransaction[] = userRequests.map((req) => {
        const rawStatus = (req.status || 'PENDING').toString().toUpperCase();
        const mappedStatus: 'SUCCESS' | 'PENDING' | 'REJECTED' =
          rawStatus === 'APPROVED' || rawStatus === 'SUCCESS'
            ? 'SUCCESS'
            : rawStatus === 'REJECTED'
            ? 'REJECTED'
            : 'PENDING';

        return {
          id: req.id,
          packageName: 'Manual QR Wallet Top-Up',
          amount: req.amountNpr,
          type: 'CREDIT',
          date: req.createdAt ? new Date(req.createdAt).toLocaleString() : new Date().toLocaleString(),
          paymentMethod: req.paymentMethod || 'Manual QR Verification',
          status: mappedStatus,
        };
      });

      // Avoid duplication if an approved request was also added to transactions
      const existingIds = new Set(txnsList.map((t) => t.id));
      requestTxns.forEach((rt) => {
        if (!existingIds.has(rt.id)) {
          txnsList.push(rt);
        }
      });

      // Sort by date descending
      txnsList.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      callback(txnsList);
    } catch {
      callback([]);
    }
  };

  fetchTxns();

  const handleLocalUpdate = () => fetchTxns();
  window.addEventListener('ug_wallet_requests_updated', handleLocalUpdate);
  window.addEventListener('ug_profile_updated', handleLocalUpdate);

  const channel = supabase
    .channel(getUniqueChannelName(`realtime:transactions:${uid}`))
    .on('postgres_changes', { event: '*', schema: 'public', table: TRANSACTIONS_COLLECTION, filter: `uid=eq.${uid.trim()}` }, () => {
      fetchTxns();
    })
    .on('postgres_changes', { event: '*', schema: 'public', table: WALLET_REQUESTS_COLLECTION, filter: `uid=eq.${uid.trim()}` }, () => {
      fetchTxns();
    })
    .subscribe();

  return () => {
    window.removeEventListener('ug_wallet_requests_updated', handleLocalUpdate);
    window.removeEventListener('ug_profile_updated', handleLocalUpdate);
    supabase.removeChannel(channel);
  };
};

// ── SOCIAL & CONTACT LINKS ──
export const DEFAULT_SOCIAL_LINKS: SocialLinks = {
  facebook: 'https://facebook.com',
  tiktok: 'https://tiktok.com',
  instagram: 'https://instagram.com',
  youtube: 'https://youtube.com',
  discord: 'https://discord.com',
  whatsapp: 'https://wa.me/9779708562001',
  email: 'mailto:support@ugtopups.com',
  location: 'https://maps.google.com/?q=Kathmandu,Nepal',
};

export const subscribeSocialLinks = (callback: (links: SocialLinks) => void): (() => void) => {
  const cachedStr = localStorage.getItem('ug_social_links');
  if (cachedStr) {
    try {
      callback({ ...DEFAULT_SOCIAL_LINKS, ...JSON.parse(cachedStr) });
    } catch {}
  }

  const fetchLinks = async () => {
    try {
      const { data, error } = await supabase.from(SETTINGS_COLLECTION).select('*').eq('id', 'social_links').single();
      if (!error && data) {
        const merged = { ...DEFAULT_SOCIAL_LINKS, ...data };
        localStorage.setItem('ug_social_links', JSON.stringify(merged));
        callback(merged);
      } else {
        callback(DEFAULT_SOCIAL_LINKS);
      }
    } catch {
      callback(DEFAULT_SOCIAL_LINKS);
    }
  };

  fetchLinks();

  const channel = supabase.channel(getUniqueChannelName('realtime:settings'))
    .on('postgres_changes', { event: '*', schema: 'public', table: SETTINGS_COLLECTION, filter: 'id=eq.social_links' }, () => {
      fetchLinks();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const saveSocialLinks = async (links: SocialLinks): Promise<void> => {
  try {
    await supabase.from(SETTINGS_COLLECTION).upsert({ id: 'social_links', ...links });
    localStorage.setItem('ug_social_links', JSON.stringify(links));
  } catch {
    localStorage.setItem('ug_social_links', JSON.stringify(links));
  }
};

// ── Backward-compatibility aliases ─────────────────────────────────────────
// These allow existing imports (App.tsx, AdminDashboard, etc.) to keep working
// without a mass find-replace across all consumer files.
export const seedFirestoreDefaults        = seedSupabaseDefaults;
export const saveCategoryToFirestore      = saveCategory;
export const deleteCategoryFromFirestore  = deleteCategory;
export const saveBannerToFirestore        = saveBanner;
export const deleteBannerFromFirestore    = deleteBanner;
export const saveGameToFirestore          = saveGame;
export const deleteGameFromFirestore      = deleteGame;
export const wipeAllGamesFromFirestore    = wipeAllGames;
export const saveProductToFirestore       = saveProduct;
export const deleteProductFromFirestore   = deleteProduct;
export const checkAdminStatusInFirestore  = checkAdminStatus;
export const saveUserToFirestore          = saveUser;
export const saveOrderToFirestore         = saveOrder;
export const saveSocialLinksToFirestore   = saveSocialLinks;


// ── MANUAL PAYMENT QR SETTINGS ──
export interface ManualPaymentSettings {
  qrImageUrl: string;
  accountName: string;
  accountNote: string;
  paymentMode?: 'both' | 'online' | 'manual';
}

export const DEFAULT_MANUAL_PAYMENT_SETTINGS: ManualPaymentSettings = {
  qrImageUrl: '/assets/wallet_ug.png',
  accountName: 'bibek',
  accountNote: 'Write your name on remarks when paying',
  paymentMode: 'both',
};

export const subscribeManualPaymentSettings = (callback: (settings: ManualPaymentSettings) => void): (() => void) => {
  const cachedStr = localStorage.getItem('ug_manual_payment_settings');
  if (cachedStr) {
    try { callback({ ...DEFAULT_MANUAL_PAYMENT_SETTINGS, ...JSON.parse(cachedStr) }); } catch {}
  } else {
    callback(DEFAULT_MANUAL_PAYMENT_SETTINGS);
  }

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase.from(SETTINGS_COLLECTION).select('*').eq('id', 'manual_payment_settings').single();
      if (!error && data) {
        const merged = { ...DEFAULT_MANUAL_PAYMENT_SETTINGS, ...data };
        localStorage.setItem('ug_manual_payment_settings', JSON.stringify(merged));
        callback(merged);
      } else {
        if (error && error.code !== 'PGRST116') {
          console.warn('[MANUAL PAYMENT SETTINGS] fetch notice:', error.message);
        }
        callback(DEFAULT_MANUAL_PAYMENT_SETTINGS);
      }
    } catch {
      callback(DEFAULT_MANUAL_PAYMENT_SETTINGS);
    }
  };

  fetchSettings();

  const handleLocal = () => fetchSettings();
  window.addEventListener('ug_manual_payment_settings_updated', handleLocal);

  const channel = supabase.channel(getUniqueChannelName('realtime:manualPaymentSettings'))
    .on('postgres_changes', { event: '*', schema: 'public', table: SETTINGS_COLLECTION, filter: 'id=eq.manual_payment_settings' }, () => {
      fetchSettings();
    })
    .subscribe();

  return () => {
    window.removeEventListener('ug_manual_payment_settings_updated', handleLocal);
    supabase.removeChannel(channel);
  };
};

export const saveManualPaymentSettings = async (settings: ManualPaymentSettings): Promise<void> => {
  const { error } = await supabase.from(SETTINGS_COLLECTION).upsert({ id: 'manual_payment_settings', ...settings });
  if (error) {
    console.error('[MANUAL PAYMENT SETTINGS] Supabase save failed:', error.message);
    // Still cache locally so the admin UI doesn't lose the in-progress edit,
    // but re-throw so the caller shows a real failure instead of a false "Saved!".
    localStorage.setItem('ug_manual_payment_settings', JSON.stringify(settings));
    throw new Error(error.message || 'Failed to save payment settings to the database.');
  }
  localStorage.setItem('ug_manual_payment_settings', JSON.stringify(settings));
  window.dispatchEvent(new Event('ug_manual_payment_settings_updated'));
};

export const uploadManualPaymentQR = async (file: File): Promise<string> => {
  const filePath = `manual-payment-qr/qr_${Date.now()}.${file.name.split('.').pop()}`;
  const { error } = await supabase.storage.from('screenshots').upload(filePath, file, { upsert: true });
  if (error) {
    console.warn('[MANUAL PAYMENT QR] Storage upload failed, falling back to base64:', error.message);
    // fallback: base64
    return new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  }
  const { data } = supabase.storage.from('screenshots').getPublicUrl(filePath);
  return data.publicUrl;
};

// ── REVIEWS MANAGEMENT ──
// Supabase is the single source of truth. localStorage is never written here;
// see notifications_reviews_security_fix.sql for the table + RLS definition.
export const REVIEWS_COLLECTION = 'reviews';

const mapReviewRow = (r: any): Review => ({
  id: r.id,
  userName: r.user_name || r.userName || 'User',
  avatarUrl: r.avatar_url || r.avatarUrl,
  rating: r.rating || 5,
  date: r.date || (r.created_at ? new Date(r.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })),
  game: r.game || 'Free Fire',
  comment: r.comment || '',
  verified: r.verified ?? true,
  status: (r.status as any) || 'APPROVED',
});

export const subscribeReviews = (callback: (reviews: Review[]) => void): (() => void) => {
  let tableChecked = false;
  let tableExists = true;

  const fallbackReviews = INITIAL_REVIEWS.map((r) => ({ ...r, status: 'APPROVED' as const }));

  const fetchReviews = async () => {
    if (tableChecked && !tableExists) {
      callback(fallbackReviews);
      return;
    }

    try {
      const { data, error } = await supabase
        .from(REVIEWS_COLLECTION)
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        tableChecked = true;
        // If table does not exist in Supabase schema cache yet, suppress noisy logs and provide fallback reviews
        if (
          error.message?.includes('schema cache') ||
          error.message?.includes('does not exist') ||
          error.code === 'PGRST205' ||
          error.code === '42P01'
        ) {
          tableExists = false;
        } else {
          console.warn('[REVIEW] fetch notice:', error.message);
        }
        callback(fallbackReviews);
        return;
      }

      tableChecked = true;
      tableExists = true;
      const list = data && data.length > 0
        ? data.map(mapReviewRow)
        : fallbackReviews;

      callback(list);
    } catch {
      callback(fallbackReviews);
    }
  };

  fetchReviews();

  const channel = supabase
    .channel(getUniqueChannelName('realtime:reviews'))
    .on('postgres_changes', { event: '*', schema: 'public', table: REVIEWS_COLLECTION }, () => {
      if (tableExists) {
        fetchReviews();
      }
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const submitReviewRequest = async (review: Review): Promise<boolean> => {
  try {
    const { data: authData } = await supabase.auth.getUser();
    const userId = authData?.user?.id || null;

    const { error } = await supabase.from(REVIEWS_COLLECTION).insert({
      id: review.id,
      user_id: userId,
      user_name: review.userName,
      avatar_url: review.avatarUrl || null,
      rating: review.rating,
      date: review.date,
      game: review.game,
      comment: review.comment,
      verified: review.verified,
      status: 'PENDING',
      created_at: new Date().toISOString(),
    });

    if (error) {
      if (
        !error.message?.includes('schema cache') &&
        !error.message?.includes('does not exist')
      ) {
        console.warn('[REVIEW] insert notice:', error.message);
      }
      return true;
    }

    return true;
  } catch {
    return true;
  }
};

export const updateReviewStatus = async (reviewId: string, status: 'APPROVED' | 'REJECTED'): Promise<boolean> => {
  const { error } = await supabase.from(REVIEWS_COLLECTION).update({ status }).eq('id', reviewId);
  if (error) {
    console.warn('[REVIEW] status update failed:', error.message);
    return false;
  }
  return true;
};

export const deleteReviewRecord = async (reviewId: string): Promise<boolean> => {
  const { error } = await supabase.from(REVIEWS_COLLECTION).delete().eq('id', reviewId);
  if (error) {
    console.warn('[REVIEW] delete failed:', error.message);
    return false;
  }
  return true;
};

// ── SYSTEM NOTIFICATIONS MANAGER ──
export const NOTIFICATIONS_COLLECTION = 'notifications';

export interface SendNotificationParams {
  id?: string;
  targetEmail?: string; // Input only for admin recipient lookup; notifications always store target_email = NULL.
  orderId?: string;
  targetUid?: string;
  title: string;
  message: string;
  category?: 'Announcement' | 'Promo Code' | 'Order' | 'Wallet' | 'System';
  expiresIn?: string;
  isPinned?: boolean;
}

// Admin-only. The actual INSERT happens server-side (service role) inside the
// `send-notification` Edge Function, which verifies the caller is an admin.
// Customers have no INSERT grant on `notifications` at all (see
// notifications_reviews_security_fix.sql) — this is the only path in, along
// with the automatic voucher-delivery inserts done by the payment/redeem
// Edge Functions.
export const sendNotificationToUser = async (params: SendNotificationParams): Promise<boolean> => {
  const { data, error } = await supabase.functions.invoke('send-notification', {
    body: {
      id: params.id,
      targetEmail: params.targetEmail?.trim() || undefined,
      targetUid: params.targetUid?.trim() || undefined,
      orderId: params.orderId?.trim() || undefined,
      title: params.title,
      message: params.message,
      category: params.category || 'System',
      expiresIn: params.expiresIn,
      isPinned: params.isPinned,
    },
  });

  if (error || !data?.success) {
    console.warn('[NOTIFICATION] send failed:', error?.message || data?.message);
    return false;
  }
  return true;
};

const mapNotificationRow = (item: any): import('../types').NotificationItem => ({
  id: item.id,
  title: item.title,
  message: item.message,
  date: item.date || 'Just now',
  unread: item.unread !== false,
  category: item.category || 'System',
  expiresIn: item.expiresIn || undefined,
  isPinned: item.isPinned || false,
  orderId: item.order_id || undefined,
  productId: item.product_id || undefined,
  packageId: item.package_id || undefined,
  code: item.code || undefined,
});

export const deleteNotificationRecord = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from(NOTIFICATIONS_COLLECTION).delete().eq('id', id);
  if (error) {
    console.warn('[NOTIFICATION] delete failed:', error.message);
    return false;
  }
  return true;
};

export const markNotificationRead = async (id: string, unread: boolean): Promise<boolean> => {
  const { error } = await supabase.from(NOTIFICATIONS_COLLECTION).update({ unread }).eq('id', id);
  if (error) {
    console.warn('[NOTIFICATION] mark-read failed:', error.message);
    return false;
  }
  return true;
};

export const togglePinNotification = async (id: string, isPinned: boolean): Promise<boolean> => {
  const { error } = await supabase.from(NOTIFICATIONS_COLLECTION).update({ isPinned }).eq('id', id);
  if (error) {
    console.warn('[NOTIFICATION] pin toggle failed:', error.message);
    return false;
  }
  return true;
};

// Fetches and realtime-subscribes to ONLY the signed-in user's notifications
// (own target_uid, plus broadcast rows targeted at 'ALL'). RLS on
// `notifications` is the actual security boundary — this filter narrows the
// query/realtime channel so one user's browser never even requests another
// user's rows.
export const subscribeNotifications = (
  userEmail?: string,
  userUid?: string,
  callback?: (notifs: import('../types').NotificationItem[]) => void
): (() => void) => {
  const uidClean = (userUid || '').trim();

  const fetchNotifs = async () => {
    if (!uidClean) {
      if (callback) callback([]);
      return;
    }

    const { data, error } = await supabase
      .from(NOTIFICATIONS_COLLECTION)
      .select('*')
      .eq('target_uid', uidClean)
      .order('created_at', { ascending: false })
      .limit(200);

    if (error) {
      console.warn('[NOTIFICATION] fetch failed:', error.message);
      if (callback) callback([]);
      return;
    }

    if (callback) callback((data || []).map(mapNotificationRow));
  };

  fetchNotifs();

  if (!uidClean) return () => {};

  const channel = supabase.channel(getUniqueChannelName('realtime:notifications'))
    .on('postgres_changes', { event: '*', schema: 'public', table: NOTIFICATIONS_COLLECTION, filter: `target_uid=eq.${uidClean}` }, () => {
      fetchNotifs();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

// ── SECURE REDEEM CODES INVENTORY ──
export const REDEEM_CODES_COLLECTION = 'redeem_codes';

const mapRedeemCode = (item: any): import('../types').RedeemCodeRecord => ({
  id: item.id,
  productId: item.product_id || item.productId || undefined,
  gameId: item.product_id || item.game_id || item.gameId || '',
  gameName: item.game_name || item.gameName || '',
  packageId: item.package_id || item.packageId || '',
  packageName: item.package_name || item.packageName || '',
  code: item.code || '',
  status: String(item.status || 'available').toUpperCase() as any,
  usedByOrder: item.order_id || item.usedByOrder || undefined,
  usedByUid: item.user_id || item.usedByUid || undefined,
  createdAt: item.created_at || item.createdAt || new Date().toISOString(),
  assignedAt: item.assigned_at || item.assignedAt || undefined,
  deliveredAt: item.delivered_at || item.deliveredAt || undefined,
  redeemedAt: item.redeemed_at || item.redeemedAt || undefined,
});

// Admin-only inventory subscription. No localStorage/settings backup is used for codes.
export const subscribeRedeemCodes = (callback: (codes: import('../types').RedeemCodeRecord[]) => void): (() => void) => {
  const fetchCodes = async () => {
    try {
      const { data, error } = await supabase.from(REDEEM_CODES_COLLECTION).select('*').order('created_at', { ascending: false });
      if (error) { callback([]); return; }
      // Names are resolved from the existing product/package JSON after fetching the protected inventory.
      const { data: products } = await supabase.from(PRODUCTS_COLLECTION).select('id,name,packages');
      const { data: userRows } = await supabase.from(USERS_COLLECTION).select('id,email,username');
      const productMap = new Map<string, any>((products || []).map((p: any) => [String(p.id), p]));
      const userMap = new Map<string, any>((userRows || []).map((u: any) => [String(u.id), u]));
      callback((data || []).map((row: any) => {
        const product = productMap.get(String(row.product_id));
        const pkg = Array.isArray(product?.packages) ? product.packages.find((x: any) => String(x?.id) === String(row.package_id)) : null;
        const assignedUser = userMap.get(String(row.user_id || ''));
        return mapRedeemCode({ ...row, gameName: product?.name || product?.title || '', packageName: pkg?.name || '', usedByEmail: assignedUser?.email || '', usedByUid: row.user_id || '', });
      }));
    } catch { callback([]); }
  };
  fetchCodes();
  const channel = supabase.channel(getUniqueChannelName('realtime:redeemCodes'))
    .on('postgres_changes', { event: '*', schema: 'public', table: REDEEM_CODES_COLLECTION }, fetchCodes)
    .subscribe();
  return () => supabase.removeChannel(channel);
};

export const addRedeemCodes = async (
  productId: string,
  packageId: string,
  rawCodes: string[]
): Promise<{ success: boolean; count: number; duplicates: number; error?: string }> => {
  const codes = rawCodes.map(c => String(c).trim()).filter(Boolean);
  if (!codes.length) return { success:false, count:0, duplicates:0, error:'No valid redeem codes provided.' };
  try {
    const { data, error } = await supabase.functions.invoke('redeem-code-admin', { body: { productId, packageId, codes } });
    if (error) throw error;
    if (!data?.success) return { success:false, count:Number(data?.added||0), duplicates:Number(data?.duplicates||0), error:data?.message || 'Failed to save codes.' };
    return { success:true, count:Number(data.added||0), duplicates:Number(data.duplicates||0) };
  } catch (e:any) {
    return { success:false, count:0, duplicates:0, error:e?.message || 'Failed to save redeem codes.' };
  }
};

export const deleteRedeemCode = async (id: string): Promise<boolean> => {
  try {
    const { error } = await supabase.from(REDEEM_CODES_COLLECTION).delete().eq('id', id);
    return !error;
  } catch { return false; }
};

export const getRedeemStock = async (productId: string, packageId: string): Promise<number> => {
  try {
    const { data, error } = await supabase.rpc('get_redeem_stock', { p_product_id: productId, p_package_id: packageId });
    if (error) return 0;
    return Number(data || 0);
  } catch { return 0; }
};

export const getMyRedeemCodes = async (orderId: string): Promise<Array<{ id:string; product_id:string; package_id:string; code:string; status:string; delivered_at:string; order_id:string }>> => {
  if (!orderId) return [];
  try {
    const { data, error } = await supabase.functions.invoke('redeem-code-delivery', { body: { action:'get_my_codes', orderId } });
    if (error || !data?.success) return [];
    return data.codes || [];
  } catch { return []; }
};

export const isRedeemCodeOrder = (order: any): boolean => {
  if (!order) return false;
  // Explicit flags take highest priority
  if (order.requiresRedeemCode === true || order.isRedeemCode === true) return true;
  // If product type is explicitly set, use it
  if (order.productType === 'voucher') return true;
  if (order.productType === 'topup') return false;
  // Only fall back to regex if no explicit productType is set
  // Use stricter pattern - must specifically be a voucher/gift/redeem product
  // Exclude diamond/coin/credit packages which are topups
  const combined = `${order.packageName || ''} ${order.gameName || ''} ${order.category || ''}`.toLowerCase();
  const isVoucherKeyword = /\bvoucher\b|\bredeem\b|\bgift card\b|\bgift code\b/i.test(combined);
  const isTopupKeyword = /\bdiamond|\bcoin|\bcredit|\btoken|\buc\b|\bml diamond|\bff diamond/i.test(combined);
  if (isTopupKeyword) return false; // Diamond/coin packages are always topup
  return isVoucherKeyword;
};

// ── TRANSACTIONAL EMAIL DELIVERY TRACKING & HELPER ──
export interface TransactionalEmailDeliveryRecord {
  id: string;
  user_id?: string | null;
  order_id?: string | null;
  transaction_id?: string | null;
  email: string;
  email_type: 'wallet_recharge_success' | 'order_completed' | 'voucher_delivered';
  event_key: string;
  resend_message_id?: string | null;
  status: 'pending' | 'sent' | 'failed';
  error_message?: string | null;
  metadata?: any;
  created_at: string;
  sent_at?: string | null;
}

export const getOrderEmailDeliveryStatus = async (
  orderId: string
): Promise<TransactionalEmailDeliveryRecord | null> => {
  if (!orderId) return null;
  try {
    const { data, error } = await supabase
      .from('transactional_email_deliveries')
      .select('*')
      .eq('order_id', orderId.trim())
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error || !data) return null;
    return data as TransactionalEmailDeliveryRecord;
  } catch {
    return null;
  }
};

export const sendTransactionalEmail = async (payload: {
  type: 'wallet_recharge_success' | 'order_completed' | 'voucher_delivered';
  orderId?: string;
  userId?: string;
  amount?: number;
  paymentMethod?: string;
  transactionId?: string;
  previousBalance?: number;
  newBalance?: number;
}): Promise<{ success: boolean; message?: string; alreadySent?: boolean; messageId?: string }> => {
  try {
    const { data, error } = await supabase.functions.invoke('send-transactional-email', {
      body: payload,
    });
    if (error) {
      return { success: false, message: error.message };
    }
    return data || { success: true };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Failed to invoke email service' };
  }
};


