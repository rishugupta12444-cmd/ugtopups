/**
 * Legacy package-name map is intentionally no longer used for Liana ordering.
 * Liana /order requires the account-specific product_id returned by /products.
 */
export const MLBB_BRAZIL_VARIATIONS: Record<string, number> = {};

/**
 * Checks if a game object represents Mobile Legends Brazil / MLBB.
 */
export function isMlbbBrazilGame(game: { name?: string; id?: string } | null | undefined): boolean {
  if (!game) return false;
  const name = String(game.name || '').toLowerCase();
  const id = String(game.id || '').toLowerCase();
  
  return (
    name.includes('mobile legend') ||   // covers "Mobile Legends" AND "Mobile Legend" AND "MOBILE LEGEND"
    name.includes('mobilelegend') ||
    name.includes('mlbb') ||
    id.includes('mlbb') ||
    id.includes('mobile-legend') ||
    id.includes('mobile_legend') ||
    id.includes('mobilelegend')
  );
}

/**
 * Resolve the Liana product ID configured on a package.
 * `variation_id` is retained only as a legacy alias because older saved
 * packages used that property name for the Liana PRODUCT ID.
 */
export function getMlbbProductId(pkg: any): number | undefined {
  if (!pkg) return undefined;
  const raw = pkg.product_id ?? pkg.productId ?? pkg.variation_id ?? pkg.variationId;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

/** @deprecated Use getMlbbProductId(). */
export function getMlbbVariationId(pkg: any): number | undefined {
  return getMlbbProductId(pkg);
}

/**
 * Checks if a game object represents Free Fire.
 */
export function isFreeFireGame(game: { name?: string; id?: string } | null | undefined): boolean {
  if (!game) return false;
  const name = String(game.name || '').toLowerCase();
  const id = String(game.id || '').toLowerCase();
  return (
    name.includes('free fire') ||
    name.includes('freefire') ||
    id.includes('freefire') ||
    id.includes('free-fire') ||
    id === 'ff'
  );
}
