import { supabase } from './supabase';

/**
 * Everything the payment (billing) page renders is driven by this record so the
 * store owner can rebrand it from Admin → Settings without a redeploy.
 * Stored as ONE JSONB blob in settings.data (id = 'payment_page_settings') —
 * not as one column per key, so adding a new option never needs a migration.
 */
export const PAYMENT_PAGE_SETTINGS_ID = 'payment_page_settings';
const CACHE_KEY = 'ug_payment_page_settings';

export interface PaymentPageSettings {
  /* Branding */
  brandName: string;
  logoUrl: string;
  showLogo: boolean;

  /* Copy */
  billLabel: string;
  currencyLabel: string;
  scanTitle: string;
  scanHighlight: string;
  scanSubtitle: string;
  waitingText: string;
  successText: string;
  failedText: string;
  expiredText: string;
  checkButtonText: string;
  cancelButtonText: string;
  detailsTitle: string;
  orderIdLabel: string;
  createdAtLabel: string;
  expiryLabel: string;
  packageLabel: string;
  playerUidLabel: string;
  footerNote: string;
  supportText: string;
  supportUrl: string;

  /* Theme */
  accentColor: string;
  pageBgColor: string;
  cardBgColor: string;
  textColor: string;
  mutedTextColor: string;
  borderColor: string;
  displayFont: string;
  bodyFont: string;
  glowEnabled: boolean;

  /* Behaviour */
  expiryMinutes: number;
  pollSeconds: number;
  showOrderId: boolean;
  showCreatedAt: boolean;
  showExpiry: boolean;
  showPackage: boolean;
  showPlayerUid: boolean;
  showCancelButton: boolean;
}

export const DEFAULT_PAYMENT_PAGE_SETTINGS: PaymentPageSettings = {
  brandName: 'UG Top Up Center',
  logoUrl: '/assets/brand/ug-gaming-mark.png',
  showLogo: false,

  billLabel: 'BILL AMOUNT',
  currencyLabel: 'NPR',
  scanTitle: 'Scan with {highlight} or mobile banking',
  scanHighlight: 'Fonepay',
  scanSubtitle: 'Complete payment before the QR expires.',
  waitingText: 'Waiting for payment',
  successText: 'Payment received',
  failedText: 'Payment not received yet',
  expiredText: 'QR expired',
  checkButtonText: 'Check Payment Status',
  cancelButtonText: 'Cancel payment',
  detailsTitle: 'PAYMENT DETAILS',
  orderIdLabel: 'Order ID',
  createdAtLabel: 'Created At',
  expiryLabel: 'Qr Expire',
  packageLabel: 'Package',
  playerUidLabel: 'Player UID',
  footerNote: '',
  supportText: '',
  supportUrl: '',

  accentColor: '#e11d2e',
  pageBgColor: '#000000',
  cardBgColor: '#0a0a0a',
  textColor: '#ffffff',
  mutedTextColor: '#a1a1aa',
  borderColor: '#7f1d1d',
  displayFont: "'Playfair Display', Georgia, 'Times New Roman', serif",
  bodyFont: "'Plus Jakarta Sans', system-ui, sans-serif",
  glowEnabled: true,

  expiryMinutes: 5,
  pollSeconds: 4,
  showOrderId: true,
  showCreatedAt: true,
  showExpiry: true,
  showPackage: false,
  showPlayerUid: false,
  showCancelButton: true,
};

/** Drops unknown/null columns and merges over the defaults. */
const normalise = (row: unknown): PaymentPageSettings => {
  const merged: Record<string, unknown> = { ...DEFAULT_PAYMENT_PAGE_SETTINGS };
  if (row && typeof row === 'object') {
    for (const [key, value] of Object.entries(row as Record<string, unknown>)) {
      if (key === 'id' || value === null || value === undefined) continue;
      if (key in DEFAULT_PAYMENT_PAGE_SETTINGS) merged[key] = value;
    }
  }
  merged.expiryMinutes = Math.min(60, Math.max(1, Number(merged.expiryMinutes) || 5));
  merged.pollSeconds = Math.min(60, Math.max(2, Number(merged.pollSeconds) || 4));
  return merged as unknown as PaymentPageSettings;
};

export const subscribePaymentPageSettings = (
  callback: (settings: PaymentPageSettings) => void
): (() => void) => {
  const cached = localStorage.getItem(CACHE_KEY);
  if (cached) {
    try { callback(normalise(JSON.parse(cached))); } catch { callback(DEFAULT_PAYMENT_PAGE_SETTINGS); }
  } else {
    callback(DEFAULT_PAYMENT_PAGE_SETTINGS);
  }

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('settings')
        .select('data')
        .eq('id', PAYMENT_PAGE_SETTINGS_ID)
        .maybeSingle();

      if (!error && data?.data) {
        const merged = normalise(data.data);
        localStorage.setItem(CACHE_KEY, JSON.stringify(merged));
        callback(merged);
      } else {
        callback(DEFAULT_PAYMENT_PAGE_SETTINGS);
      }
    } catch {
      callback(DEFAULT_PAYMENT_PAGE_SETTINGS);
    }
  };

  fetchSettings();

  const handleLocal = () => fetchSettings();
  window.addEventListener('ug_payment_page_settings_updated', handleLocal);

  const channel = supabase
    .channel(`realtime:paymentPageSettings:${Math.random().toString(36).slice(2)}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'settings', filter: `id=eq.${PAYMENT_PAGE_SETTINGS_ID}` },
      () => fetchSettings()
    )
    .subscribe();

  return () => {
    window.removeEventListener('ug_payment_page_settings_updated', handleLocal);
    supabase.removeChannel(channel);
  };
};

export const savePaymentPageSettings = async (settings: PaymentPageSettings): Promise<void> => {
  const clean = normalise(settings);
  const { error } = await supabase
    .from('settings')
    .upsert({ id: PAYMENT_PAGE_SETTINGS_ID, data: clean });

  if (error) {
    throw new Error(error.message || 'Failed to save payment page settings.');
  }
  localStorage.setItem(CACHE_KEY, JSON.stringify(clean));
  window.dispatchEvent(new Event('ug_payment_page_settings_updated'));
};

export const uploadPaymentPageLogo = async (file: File): Promise<string> => {
  const ext = file.name.split('.').pop() || 'png';
  const filePath = `payment-page/logo_${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from('screenshots').upload(filePath, file, { upsert: true });
  if (error) {
    return new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  }
  const { data } = supabase.storage.from('screenshots').getPublicUrl(filePath);
  return data.publicUrl;
};