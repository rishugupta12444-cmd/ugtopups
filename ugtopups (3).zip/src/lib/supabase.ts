import { createClient } from '@supabase/supabase-js';

const rawUrl = import.meta.env.VITE_SUPABASE_URL || 'https://buqummxdfjfaggyypafu.supabase.co';
const rawAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_RuyeAk-1k9adY2ytW1ccbw_VjWVPpFx';

// Validate whether real credentials are present
// Accepts both legacy JWT keys (eyJ...) and new publishable keys (sb_publishable_...)
export const isSupabaseConfigured = Boolean(
  rawUrl &&
  rawAnonKey &&
  !rawUrl.includes('xyzcompany') &&
  !rawUrl.includes('your-project') &&
  rawUrl.startsWith('http') &&
  (rawAnonKey.startsWith('eyJ') || rawAnonKey.startsWith('sb_publishable_'))
);

// Use raw values if present, else safe fallback URL that won't trigger random DNS failures
const supabaseUrl = isSupabaseConfigured ? rawUrl : 'https://unconfigured-supabase-project.supabase.co';
const supabaseAnonKey = isSupabaseConfigured ? rawAnonKey : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.placeholder';

if (!isSupabaseConfigured) {
  console.warn(
    '⚠️ Supabase is not configured yet. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'ug_topup_supabase_auth_token',
  },
});

