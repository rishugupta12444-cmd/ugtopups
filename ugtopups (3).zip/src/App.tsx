import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Loader2 } from 'lucide-react';
import { Header } from './components/Header';
import { Banner } from './components/Banner';
import { GameGrid } from './components/GameGrid';
import { TopUpSection } from './components/TopUpSection';
import { PaymentModal } from './components/PaymentModal';
import { ProfileModal } from './components/ProfileModal';
import { ProfileDrawer } from './components/ProfileDrawer';
import { BottomNav } from './components/BottomNav';
import { AuthModal } from './components/AuthModal';
import { ReviewCarousel } from './components/ReviewCarousel';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { InstallAppPopup } from './components/InstallAppPopup';
import { GlobalToast } from './components/GlobalToast';
import { SuccessReceiptModal } from './components/SuccessReceiptModal';
import { WalletSuccessModal } from './components/WalletSuccessModal';
import { AnnouncementModal, isAnnouncementDismissedToday } from './components/AnnouncementModal';
import { OrderConfirmation } from './pages/OrderConfirmation';
import { BillingPage, cacheBillingQr } from './pages/BillingPage';
import { AccountPage } from './pages/account/AccountPage';
import { OrdersPage } from './pages/account/OrdersPage';
import { TransactionsPage } from './pages/account/TransactionsPage';
import { WalletPage } from './pages/account/WalletPage';
import { CoinExchangePage } from './pages/account/CoinExchangePage';

// Admin-only: wallet load request management
const InstantWalletLoad = React.lazy(() =>
  import('./pages/account/InstantWalletLoad').then((m) => ({ default: m.InstantWalletLoad }))
);
import { SupportPage } from './pages/account/SupportPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { MobileLegendsPage } from './pages/MobileLegendsPage';
import { FaqPage } from './pages/FaqPage';
import { TermsPage } from './pages/TermsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { ErrorBoundary } from './components/ErrorBoundary';

// Code-split the admin dashboard out of the main storefront bundle
const AdminDashboard = React.lazy(() =>
  import('./components/AdminDashboard').then((m) => ({ default: m.AdminDashboard }))
);

import { GAMES_DATA, INITIAL_REVIEWS, INITIAL_USER, INITIAL_BANNERS, INITIAL_CATEGORIES } from './data/initialData';
import { Game, GamePackage, Order, Review, UserProfile, WalletTransaction, PaymentMethodChoice, BannerItem, AdminNotification, GameCategory, Announcement } from './types';
import {
  seedFirestoreDefaults, subscribeBanners, subscribeGames, subscribeCategories, subscribeActiveAnnouncement,
  checkAdminStatusInFirestore, updateOwnUserProfile, uploadAvatarAndUpdateProfile,
  submitManualWalletRequest, ensureUserDocumentExists,
  placeWalletOrder, markOrderUidVerified, subscribeUserOrders, subscribeUserProfile, subscribeUserTransactions,
  subscribeReviews,
  safeJsonStringify,
  buildOptimisticOrder, savePreOrderCache, removePreOrderCache,
  isCustomerVisibleOrder,
  exchangeCoinsForWalletCredit, awardUserCoins, COINS_PER_SUCCESSFUL_ORDER,
} from './lib/store';
import { supabase } from './lib/supabase';
import { isMlbbBrazilGame } from './lib/mlbbVariations';

// Attaches the current Supabase Auth session token as a Bearer header when signed
// in.
async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const headers: Record<string, string> = { ...(options.headers as Record<string, string> || {}) };
  const { data } = await supabase.auth.getSession();
  if (data.session?.access_token) {
    headers['Authorization'] = `Bearer ${data.session.access_token}`;
  }
  return fetch(url, { ...options, headers });
}

// Refresh wallet balance, orders, and wallet history from the backend — a
// no-op for guests, since /api/user requires a signed-in uid.
async function refreshUserFromServer(
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>,
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>,
  setWalletHistory: React.Dispatch<React.SetStateAction<WalletTransaction[]>>
) {
  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user) return;
  try {
    const res = await authFetch('/api/user');
    const data = await res.json();
    if (data.success) {
      if (data.user) {
        setUser((prev) => ({
          ...prev,
          walletBalanceNpr: data.user.walletBalanceNpr,
          completedOrdersCount: data.user.completedOrdersCount || prev.completedOrdersCount,
        }));
      }
      if (data.orders) setOrders(data.orders.filter(isCustomerVisibleOrder));
      if (data.walletHistory) {
        setWalletHistory(data.walletHistory.filter((txn: WalletTransaction) => {
          const method = String(txn?.paymentMethod || '').toLowerCase();
          return !method.includes('fonepay') || ['SUCCESS', 'PAID', 'COMPLETED', 'APPROVED'].includes(
            String(txn?.status || '').toUpperCase()
          );
        }));
      }
    }
  } catch {
    // Safe fallback — UI keeps whatever it already had
  }
}

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => window.location.pathname);
  const [games, setGames] = useState<Game[]>(GAMES_DATA);
  const [banners, setBanners] = useState<BannerItem[]>(INITIAL_BANNERS);
  const [categories, setCategories] = useState<GameCategory[]>(INITIAL_CATEGORIES);
  const [selectedGame, setSelectedGame] = useState<Game | null>(GAMES_DATA[0] || null);
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  // Tracks the actual Supabase Auth session — this is what the Header uses to
  // decide whether to show "Login" or the logged-in state.
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  // Tracks whether Supabase has resolved the initial auth state.
  // Prevents wallet/profile from flickering visible before the check completes.
  const [authChecked, setAuthChecked] = useState<boolean>(false);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [orders, setOrders] = useState<Order[]>([]);
  const [walletHistory, setWalletHistory] = useState<WalletTransaction[]>([]);
  const [activeAnnouncement, setActiveAnnouncement] = useState<Announcement | null>(null);

  // Modal Controls
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const isSubmittingOrderRef = useRef<boolean>(false);

  // Immediate Payment Verification State (Prevents Home Page flash on gateway return)
  const [isVerifyingPayment, setIsVerifyingPayment] = useState<boolean>(() => {
    const urlParams = new URLSearchParams(window.location.search);
    return !!(urlParams.get('orderId') && urlParams.get('payment') === 'success');
  });
  const [verifyingOrderId, setVerifyingOrderId] = useState<string | null>(() => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('orderId');
  });

  // Active Pending Order & QR payload for Payment Modal
  const [pendingOrder, setPendingOrder] = useState<Order | null>(null);
  const [qrPayload, setQrPayload] = useState<string | undefined>(undefined);
  const [paymentUrl, setPaymentUrl] = useState<string | undefined>(undefined);
  const [qrImage, setQrImage] = useState<string | undefined>(undefined);

  // In-app billing page (replaces the apinepal.com redirect)
  const [billingOrderId, setBillingOrderId] = useState<string>(() =>
    window.location.pathname === '/billing'
      ? (new URLSearchParams(window.location.search).get('orderId') || '')
      : ''
  );

  // Admin Notification State for user bell icon
  const [adminNotification, setAdminNotification] = useState<AdminNotification | null>(() => {
    const saved = localStorage.getItem('ug_admin_notification');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return null;
  });

  const handleClearNotification = () => {
    if (adminNotification) {
      const updated = { ...adminNotification, unread: false };
      setAdminNotification(updated);
      localStorage.setItem('ug_admin_notification', safeJsonStringify(updated));
    }
  };

  // Sync URL Path navigation for /admin
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const pendingRedirectPathRef = useRef<string | null>(null);

  const isProtectedRoute = (path: string) => {
    return (
      path === '/notifications' ||
      path === '/account/notifications' ||
      path === '/wallet' ||
      path === '/profile' ||
      path === '/account' ||
      path.startsWith('/account/') ||
      path === '/admin' ||
      path.startsWith('/admin') ||
      path === '/instant-wallet-load' ||
      path === '/billing'
    );
  };

  const navigateTo = (path: string) => {
    if (!isLoggedIn && isProtectedRoute(path)) {
      pendingRedirectPathRef.current = path;
      setIsAuthModalOpen(true);
      return;
    }
    try {
      window.history.pushState({}, '', path);
    } catch {
      // safe fallback
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Opens the in-app payment page. The QR payload is cached in sessionStorage so
  // a refresh on /billing repaints the same QR without another gateway call.
  const openBillingPage = (
    order: Order,
    gatewayQrPayload?: string,
    gatewayQrImage?: string
  ) => {
    if (!order?.orderId) return;
    cacheBillingQr(order.orderId, gatewayQrPayload, gatewayQrImage, (order as any).qrExpiresAt);
    setPendingOrder(order);
    setQrPayload(gatewayQrPayload);
    setQrImage(gatewayQrImage);
    setBillingOrderId(order.orderId);
    try {
      window.history.pushState({}, '', `/billing?orderId=${encodeURIComponent(order.orderId)}`);
    } catch {
      // safe fallback
    }
    setCurrentPath('/billing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPath]);

  const [accessDeniedMessage, setAccessDeniedMessage] = useState<string | null>(null);

  // Keep isLoggedIn / user profile in sync with the Supabase Auth session
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      const sbUser = session?.user;
      if (sbUser) {
        const userEmail = (sbUser.email || '').toLowerCase().trim();

        // Admin check — only the designated admin email gets isAdmin=true
        // All other authenticated users get full storefront access as normal customers
        const userIsAdmin = userEmail === 'rishugupta12444@gmail.com';

        setAccessDeniedMessage(null);
        setIsLoggedIn(true);
        setIsAdmin(userIsAdmin);

        const name = sbUser.user_metadata?.full_name || sbUser.user_metadata?.username || sbUser.email?.split('@')[0] || 'User';
        setUser((prev) => ({
          ...prev,
          id: sbUser.id,
          email: sbUser.email || '',
          username: name,
          avatarUrl: sbUser.user_metadata?.avatar_url || prev.avatarUrl || '',
        }));

        ensureUserDocumentExists(sbUser.id, sbUser.email || '', name).then((userDoc) => {
          if (userDoc) {
            setUser((prev) => ({ ...prev, ...userDoc, id: sbUser.id }));
          }
        });

        if (userIsAdmin) seedFirestoreDefaults();
      } else {
        setIsLoggedIn(false);
        setIsAdmin(false);
        setUser(INITIAL_USER);
      }
      setAuthChecked(true);
    });
    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  const handleAuthSuccess = (authenticatedUser: { email: string; name: string }) => {
    setUser((prev) => ({
      ...prev,
      email: authenticatedUser.email,
      username: authenticatedUser.name,
    }));
    if (pendingRedirectPathRef.current) {
      const target = pendingRedirectPathRef.current;
      pendingRedirectPathRef.current = null;
      navigateTo(target);
    }
  };

  // Initialize Firestore listeners & sync data
  useEffect(() => {
    // Subscribe to Firestore Banners
    const unsubBanners = subscribeBanners((fetchedBanners) => {
      if (fetchedBanners && fetchedBanners.length > 0) {
        setBanners(fetchedBanners);
      }
    });

    // Subscribe to Firestore Categories
    const unsubCategories = subscribeCategories((fetchedCategories) => {
      if (fetchedCategories && fetchedCategories.length > 0) {
        setCategories(fetchedCategories);
      }
    });

    // Subscribe to Firestore Games
    const unsubGames = subscribeGames((fetchedGames) => {
      setGames(fetchedGames || []);
      // Keep selected game updated
      setSelectedGame((prev) => {
        if (!fetchedGames || fetchedGames.length === 0) return null;
        const matched = fetchedGames.find((g) => g.id === prev?.id);
        return matched || fetchedGames[0];
      });
    });

    // Subscribe to Reviews
    const unsubReviews = subscribeReviews((fetchedReviews) => {
      if (fetchedReviews && fetchedReviews.length > 0) {
        setReviews(fetchedReviews);
      }
    });

    // Subscribe to the currently-eligible announcement (status active, within
    // its scheduled window, configured for automatic display, highest
    // priority first). Re-resolves live when the admin makes changes.
    const unsubAnnouncement = subscribeActiveAnnouncement((announcement) => {
      if (announcement && isAnnouncementDismissedToday(announcement.id)) {
        setActiveAnnouncement(null);
      } else {
        setActiveAnnouncement(announcement);
      }
    });

    return () => {
      unsubBanners();
      unsubCategories();
      unsubGames();
      unsubReviews();
      unsubAnnouncement();
    };
  }, []);

  // Subscribe to Firestore user profile, orders, and transactions for the logged-in user.
  // These are the ONLY sources of truth — no server fetch, no local state cache.
  useEffect(() => {
    if (!isLoggedIn || !user.id) return;

    const uid = user.id;

    // Real-time wallet balance + profile from Firestore
    const unsubProfile = subscribeUserProfile(uid, (profile) => {
      if (profile) {
        setUser((prev) => ({ ...prev, ...profile, id: uid }));
      }
    });

    // Real-time orders from Firestore (only this user's orders)
    const unsubOrders = subscribeUserOrders(uid, (userOrders) => {
      setOrders(userOrders);
    });

    // Real-time wallet transactions from Firestore
    const unsubTxns = subscribeUserTransactions(uid, (txns) => {
      setWalletHistory(txns);
    });

    // Handle Fonepay Hub payment redirect return in URL
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
    const paymentCheck = urlParams.get('payment');

    if (orderId && (paymentCheck === 'cancel' || paymentCheck === 'failed')) {
      // Fonepay Hub returned via cancel_url — user did NOT complete payment.
      // Delete/cancel this order so it never shows in admin or customer history.
      supabase.functions.invoke('fonepay-hub-status', {
        body: { orderId, payment: paymentCheck, status: 'cancelled' },
      }).catch(() => {}).finally(() => {
        sessionStorage.removeItem('pending_qr_order_id');
        window.history.replaceState({}, document.title, window.location.pathname);
      });
    }

    // Also handle: user pressed browser back from QR page (no orderId in URL)
    // Check if there is a pending QR order that was never confirmed
    const pendingQrOrderId = sessionStorage.getItem('pending_qr_order_id');
    if (pendingQrOrderId && !orderId) {
      supabase.functions.invoke('fonepay-hub-status', {
        body: { orderId: pendingQrOrderId, payment: 'cancel', status: 'cancelled' },
      }).catch(() => {}).finally(() => {
        sessionStorage.removeItem('pending_qr_order_id');
      });
    }

    if (orderId && paymentCheck === 'success') {
      // Payment successful — clear the pending marker
      sessionStorage.removeItem('pending_qr_order_id');
      setIsVerifyingPayment(true);
      setVerifyingOrderId(orderId);

      // User returned from Fonepay Hub gateway after completing payment.
      // Verify with server before showing success screen.
      supabase.functions.invoke('fonepay-hub-status', {
        body: { orderId, checkGateway: true, isSuccessReturn: true, payment: paymentCheck },
      })
        .then(({ data }) => {
          if (
            data?.success &&
            data?.order &&
            (data?.verified === true || data.order.paymentStatus === 'SUCCESS')
          ) {
            const confirmedOrder = {
              ...data.order,
              paymentStatus: 'SUCCESS',
            };
            // Direct immediate wallet balance update so modal shows new balance instantly
            if (confirmedOrder.totalPriceNpr) {
              setUser((prev) => ({
                ...prev,
                walletBalanceNpr: (prev.walletBalanceNpr || 0) + Number(confirmedOrder.totalPriceNpr),
              }));
            }
            setCompletedOrder(confirmedOrder);
            refreshUserFromServer(setUser, setOrders, setWalletHistory);
          }
        })
        .catch(() => {})
        .finally(() => {
          setIsVerifyingPayment(false);
          setVerifyingOrderId(null);
          window.history.replaceState({}, document.title, window.location.pathname);
        });
    }

    return () => {
      unsubProfile();
      unsubOrders();
      unsubTxns();
    };
  }, [isLoggedIn]);

  // ─── WALLET CHECKOUT ─────────────────────────────────────────────────────────
  // Optimistically deducts UG Wallet in local UI and creates order + transaction in Supabase
  // with atomic rollback on failure. Pre-order cache enables instant zero-latency feedback.
  const walletCheckout = async (params: {
    game: Game;
    playerUid: string;
    playerName: string;
    zoneId?: string;
    userEmail?: string;
    userPassword?: string;
    userWhatsapp?: string;
    userField1Val?: string;
    userField2Val?: string;
    customFieldValues?: { id: string; label: string; value: string }[];
    selectedPackage: GamePackage;
    quantity: number;
    totalPriceNpr: number;
    uidVerified?: boolean;
    uidVerifiedAt?: string;
  }) => {
    if (!isLoggedIn || !user.id) {
      alert('You must be logged in to place an order.');
      setIsAuthModalOpen(true);
      return;
    }

    if (user.walletBalanceNpr < params.totalPriceNpr) {
      alert(`Insufficient wallet balance. Your balance: NPR ${user.walletBalanceNpr.toLocaleString('en-IN')}, Required: NPR ${params.totalPriceNpr.toLocaleString('en-IN')}`);
      return;
    }

    // Save previous balance for rollback safety
    const previousBalance = user.walletBalanceNpr;
    const optimisticBalance = Math.max(0, previousBalance - params.totalPriceNpr);

    // Optimistic balance update in UI
    setUser((prev) => ({ ...prev, walletBalanceNpr: optimisticBalance }));

    const isVoucherProduct =
      params.selectedPackage.requiresRedeemCode === true ||
      (params.selectedPackage as any).isRedeemCode === true ||
      /voucher|gift|redeem|google play|itunes|steam|netflix/i.test(`${params.game.name} ${params.selectedPackage.name}`);

    // Keep the existing order ID format. Do not migrate or renumber existing IDs.
    const stableOrderId = `ODR${Math.floor(10000 + Math.random() * 90000)}`;

    // Create optimistic pre-order and cache it
    const optimisticOrder = buildOptimisticOrder({
      uid: user.id,
      gameId: params.game.id,
      gameName: params.game.name,
      playerUid: params.playerUid,
      playerName: params.playerName,
      zoneId: params.zoneId,
      userEmail: params.userEmail || user.email,
      userPassword: params.userPassword,
      userWhatsapp: params.userWhatsapp,
      userField1Val: params.userField1Val,
      userField2Val: params.userField2Val,
      customFieldValues: params.customFieldValues,
      packageId: params.selectedPackage.id,
      packageName: `${params.selectedPackage.name}${params.quantity > 1 ? ` (x${params.quantity})` : ''}`,
      diamonds: params.selectedPackage.diamonds * params.quantity,
      quantity: params.quantity,
      totalPriceNpr: params.totalPriceNpr,
      uidVerified: params.uidVerified,
      uidVerifiedAt: params.uidVerifiedAt,
      isVoucher: isVoucherProduct,
    });
    optimisticOrder.orderId = stableOrderId;
    savePreOrderCache(optimisticOrder, 'OPTIMISTIC');

    // ⚡ INSTANT UI: Show order successful confirmation immediately (within < 50ms)
    setCompletedOrder(optimisticOrder);

    if (isVoucherProduct) {
      try {
        const payload = {
          orderId: stableOrderId,
          gameId: params.game.id,
          gameName: params.game.name,
          playerUid: params.playerUid || 'VOUCHER_PURCHASE',
          playerName: params.playerName || 'Voucher Customer',
          zoneId: params.zoneId || '',
          packageId: params.selectedPackage.id,
          packageName: params.selectedPackage.name,
          requiresRedeemCode: true,
          isRedeemCode: true,
          isVoucher: true,
          deliveryType: 'VOUCHER',
          uidVerified: true,
          priceNpr: params.selectedPackage.priceNpr,
          totalPriceNpr: params.totalPriceNpr,
          diamonds: params.selectedPackage.diamonds * params.quantity,
          quantity: params.quantity,
          userEmail: params.userEmail || user.email || '',
          userPassword: params.userPassword || '',
          userWhatsapp: params.userWhatsapp || '',
          userField1Val: params.userField1Val || '',
          userField2Val: params.userField2Val || '',
        };

        let data: any = null;
        let error: any = null;
        let responseBody: any = null;
        let httpStatus: number | undefined = undefined;

        try {
          const res = await supabase.functions.invoke('wallet-voucher-checkout', {
            body: payload,
          });
          data = res.data;
          error = res.error;
        } catch (invokeErr: any) {
          error = invokeErr;
        }

        if (error) {
          // Revert optimistic UI updates
          setCompletedOrder(null);
          setUser((prev) => ({ ...prev, walletBalanceNpr: previousBalance }));
          savePreOrderCache(optimisticOrder, 'FAILED');

          if (error.context) {
            httpStatus = error.context.status;
            try {
              if (typeof error.context.clone === 'function') {
                const cloned = error.context.clone();
                responseBody = await cloned.json().catch(async () => {
                  const txt = await cloned.text().catch(() => null);
                  return txt ? { message: txt } : null;
                });
              } else if (typeof error.context.json === 'function') {
                responseBody = await error.context.json().catch(() => null);
              }
            } catch {
              // ignore parse errors
            }
          }

          const errCode = responseBody?.code;
          const errMsg = responseBody?.message || error.message || '';

          if (errCode === 'NO_AVAILABLE_CODE' || /out of stock|no redeem code/i.test(errMsg)) {
            alert('Currently Out of Stock: No redeem code is available for this package.');
            return;
          }
          if (errCode === 'INSUFFICIENT_WALLET_BALANCE' || /insufficient.*balance/i.test(errMsg)) {
            alert('Insufficient wallet balance. Please load your wallet first.');
            return;
          }

          console.error('[VOUCHER CHECKOUT] wallet-voucher-checkout failed', { httpStatus, errCode, errMsg });
          alert(errMsg || 'Voucher checkout failed. Please try again or contact support with your order details.');
          return;
        }

        if (!data?.success) {
          setCompletedOrder(null);
          setUser((prev) => ({ ...prev, walletBalanceNpr: previousBalance }));
          savePreOrderCache(optimisticOrder, 'FAILED');
          throw new Error(data?.message || 'Voucher checkout failed.');
        }

        const confirmedOrder: Order = {
          ...optimisticOrder,
          orderId: stableOrderId,
          userId: user.id,
          gameId: params.game.id,
          gameName: params.game.name,
          playerUid: params.playerUid,
          playerName: params.playerName,
          zoneId: params.zoneId || '',
          packageName: params.selectedPackage.name,
          packageId: params.selectedPackage.id,
          diamonds: params.selectedPackage.diamonds * params.quantity,
          quantity: params.quantity,
          totalPriceNpr: Number(data.order?.totalPriceNpr || params.totalPriceNpr),
          walletDeductionNpr: Number(data.order?.walletDeductionNpr || data.order?.totalPriceNpr || params.totalPriceNpr),
          paymentMethod: 'UG Wallet',
          transactionRef: data.order?.transactionRef || optimisticOrder.transactionRef,
          paymentStatus: 'Paid',
          topUpStatus: 'COMPLETED',
          status: 'Completed',
          createdAt: data.order?.createdAt || optimisticOrder.createdAt,
          completedAt: data.order?.completedAt || new Date().toISOString(),
          completedBy: 'AUTO_REDEEM_SYSTEM',
        };

        savePreOrderCache(confirmedOrder, 'CONFIRMED');
        setCompletedOrder((prev) => {
          if (prev && prev.orderId === stableOrderId) {
            return { ...prev, ...confirmedOrder };
          }
          return confirmedOrder;
        });
        awardUserCoins(user.id, COINS_PER_SUCCESSFUL_ORDER, {
          orderId: confirmedOrder.orderId,
          gameName: params.game.name,
          packageName: params.selectedPackage.name,
        }).catch(() => {});
        setUser((prev) => ({
          ...prev,
          coinBalance: (prev.coinBalance || 0) + COINS_PER_SUCCESSFUL_ORDER,
        }));
        return;
      } catch (e: any) {
        setCompletedOrder(null);
        setUser((prev) => ({ ...prev, walletBalanceNpr: previousBalance }));
        savePreOrderCache(optimisticOrder, 'FAILED');
        alert(e?.message || 'Voucher checkout failed. Please try again.');
        return;
      }
    }

    const result = await placeWalletOrder({
      uid: user.id,
      currentWalletBalance: previousBalance,
      gameId: params.game.id,
      gameName: params.game.name,
      playerUid: params.playerUid,
      playerName: params.playerName,
      zoneId: params.zoneId,
      userEmail: params.userEmail,
      userPassword: params.userPassword,
      userWhatsapp: params.userWhatsapp,
      userField1Val: params.userField1Val,
      userField2Val: params.userField2Val,
      packageId: params.selectedPackage.id,
      packageName: `${params.selectedPackage.name}${params.quantity > 1 ? ` (x${params.quantity})` : ''}`,
      diamonds: params.selectedPackage.diamonds * params.quantity,
      quantity: params.quantity,
      totalPriceNpr: params.totalPriceNpr,
      uidVerified: params.uidVerified,
      uidVerifiedAt: params.uidVerifiedAt,
      existingOptimisticOrder: optimisticOrder,
      // Pass the Liana PRODUCT ID configured on this MLBB package.
      productId: isMlbbBrazilGame(params.game)
        ? (Number((params.selectedPackage as any).product_id || (params.selectedPackage as any).variation_id) || undefined)
        : undefined,
    });

    if (result.success && result.order) {
      const finalConfirmedOrder: Order = {
        ...result.order,
        orderId: stableOrderId,
      };
      savePreOrderCache(finalConfirmedOrder, 'CONFIRMED');
      setCompletedOrder((prev) => {
        if (prev && prev.orderId === stableOrderId) {
          return { ...prev, ...finalConfirmedOrder };
        }
        return finalConfirmedOrder;
      });
      setUser((prev) => ({
        ...prev,
        coinBalance: (prev.coinBalance || 0) + COINS_PER_SUCCESSFUL_ORDER,
      }));

      // ── Mobile Legends: automated diamond delivery via Liana API ─────────
      // 1. Order is saved → customer sees "PENDING" on success page immediately
      // 2. process-ml-order fires in background → Liana delivers diamonds
      // 3. On success → customer UI updates to "COMPLETED" + real IGN shown
      // 4. On failure → stays PENDING, admin can retry from ML API Monitoring
      if (isMlbbBrazilGame(params.game)) {
        // Show delivery-in-progress status immediately
        setCompletedOrder((prev) =>
          prev && prev.orderId === stableOrderId
            ? { ...prev, topUpStatus: 'PENDING', deliveryStatus: 'delivering' }
            : prev
        );

        supabase.functions
          .invoke('process-ml-order', { body: { order_id: stableOrderId } })
          .then(({ data, error }) => {
            if (error || !data?.success) {
              // Delivery failed — keep PENDING, admin will retry
              console.warn('[MLBB AUTO-DELIVERY] Will need manual processing:', error?.message || data?.error);
              setCompletedOrder((prev) =>
                prev && prev.orderId === stableOrderId
                  ? { ...prev, topUpStatus: 'PENDING', deliveryStatus: 'pending', deliveryError: data?.error || error?.message }
                  : prev
              );
              return;
            }
            // Delivery succeeded — update customer UI with real IGN and COMPLETED status
            setCompletedOrder((prev) =>
              prev && prev.orderId === stableOrderId
                ? {
                    ...prev,
                    status: 'Completed',
                    topUpStatus: 'COMPLETED',
                    deliveryStatus: 'delivered',
                    playerName: data.ign || prev.playerName,
                    completedAt: new Date().toISOString(),
                    completedBy: 'LIANA_AUTO_DELIVERY',
                  }
                : prev
            );
          })
          .catch((e) => {
            console.warn('[MLBB AUTO-DELIVERY] invoke failed:', e);
            setCompletedOrder((prev) =>
              prev && prev.orderId === stableOrderId
                ? { ...prev, topUpStatus: 'PENDING', deliveryStatus: 'pending' }
                : prev
            );
          });
      }
    } else {
      // Revert optimistic balance
      setCompletedOrder(null);
      setUser((prev) => ({ ...prev, walletBalanceNpr: previousBalance }));
      savePreOrderCache(optimisticOrder, 'FAILED');
      alert(result.error || 'Checkout failed. Please try again.');
    }
  };

  // ─── FONEPAY HUB CHECKOUT ───────────────────────────────────────────────────────
  // Payment creation is handled by a Supabase Edge Function. FONEPAY HUB public/secret
  // keys never reach the browser. The Edge Function creates the order first, then
  // creates the gateway transaction and returns the real QR payload.
  const fonepayHubCheckout = async (params: {
    game: Game;
    playerUid: string;
    playerName: string;
    zoneId?: string;
    userEmail?: string;
    userPassword?: string;
    userWhatsapp?: string;
    userField1Val?: string;
    userField2Val?: string;
    selectedPackage: GamePackage;
    quantity: number;
    totalPriceNpr: number;
    uidVerified?: boolean;
    uidVerifiedAt?: string;
  }) => {
    // Keep the existing order ID format. Do not migrate or renumber existing IDs.
    // A browser-session idempotency lock prevents one checkout action from creating
    // multiple Fonepay Hub orders when the button/event fires more than once.
    const checkoutKey = [
      user?.id || user?.email || 'guest',
      params.game.id,
      params.playerUid.trim().toLowerCase(),
      params.selectedPackage.id,
      params.quantity,
      params.totalPriceNpr,
    ].join('|');
    const lockStorageKey = 'ug_fonepay_hub_checkout_lock';
    const now = Date.now();
    let stableOrderId = `ODR${Math.floor(10000 + Math.random() * 90000)}`;

    try {
      const rawLock = sessionStorage.getItem(lockStorageKey);
      if (rawLock) {
        const lock = JSON.parse(rawLock);
        if (lock?.key === checkoutKey && Number(lock?.expiresAt || 0) > now) {
          // Re-open the exact payment response already created instead of creating
          // another order. This is the critical duplicate-order protection.
          if (lock?.response?.order) {
            const existing = lock.response;
            openBillingPage(existing.order, existing.qrPayload, existing.qrImage);
            return;
          }
          return;
        }
        sessionStorage.removeItem(lockStorageKey);
      }

      const checkoutLock = { key: checkoutKey, orderId: stableOrderId, startedAt: now, expiresAt: now + 10 * 60 * 1000 };
      sessionStorage.setItem(lockStorageKey, JSON.stringify(checkoutLock));

      const { data, error } = await supabase.functions.invoke('fonepay-hub-initiate', {
        body: {
          userId: user?.id,
          orderId: stableOrderId,
          userEmail: params.userEmail || user?.email,
          gameId: params.game.id,
          gameName: params.game.name,
          playerUid: params.playerUid,
          playerName: params.playerName,
          zoneId: params.zoneId,
          userPassword: params.userPassword,
          userWhatsapp: params.userWhatsapp,
          userField1Val: params.userField1Val,
          userField2Val: params.userField2Val,
          packageId: params.selectedPackage.id,
          packageName: `${params.selectedPackage.name} (x${params.quantity})`,
          diamonds: params.selectedPackage.diamonds * params.quantity,
          quantity: params.quantity,
          totalPriceNpr: params.totalPriceNpr,
          uidVerified: params.uidVerified,
          uidVerifiedAt: params.uidVerifiedAt,
        },
      });

      if (error) {
        let detail = '';
        try {
          const ctx = await (error as any).context?.json();
          detail = ctx?.message || ctx?.error || '';
        } catch {}
        throw new Error(detail || (error.message !== 'Edge Function returned a non-2xx status code' ? error.message : 'Payment service error. Please try again.'));
      }
      if (!data?.success || !data.order) {
        sessionStorage.removeItem(lockStorageKey);
        throw new Error(data?.message || 'Failed to initiate Fonepay Hub payment.');
      }

      // Save the exact gateway response. Any accidental second click/retry during
      // this payment session reuses this response instead of inserting another order.
      try {
        const lock = JSON.parse(sessionStorage.getItem(lockStorageKey) || '{}');
        sessionStorage.setItem(lockStorageKey, JSON.stringify({
          ...lock,
          orderId: data.order.orderId || stableOrderId,
          response: data,
          expiresAt: Date.now() + 10 * 60 * 1000,
        }));
      } catch {}

      // Payment stays on our own domain — render the QR on /billing.
      if (data.order && (data.qrPayload || data.qrImage)) {
        openBillingPage(data.order, data.qrPayload, data.qrImage);
      } else {
        alert(data?.message || 'Fonepay Hub did not return a payment QR code.');
      }
    } catch (err: any) {
      try { sessionStorage.removeItem(lockStorageKey); } catch {}
      console.error('[Fonepay Hub] checkout failed', err);
      alert(err?.message || 'Failed to connect to Fonepay Hub payment server.');
    }
  };

  // ─── PAYMENT ENTRY POINT ──────────────────────────────────────────────────────
  // Routes Buy Now to the correct checkout function based on payment method.
  // This is the ONLY place where the routing decision is made.
  const handleInitiatePayment = async (params: {
    game: Game;
    playerUid: string;
    playerName: string;
    zoneId?: string;
    userEmail?: string;
    userPassword?: string;
    userWhatsapp?: string;
    userField1Val?: string;
    userField2Val?: string;
    selectedPackage: GamePackage;
    quantity: number;
    totalPriceNpr: number;
    paymentMethodChoice: PaymentMethodChoice;
    uidVerified?: boolean;
    uidVerifiedAt?: string;
  }) => {
    if (isSubmittingOrderRef.current) return;

    if (!isLoggedIn) {
      setIsAuthModalOpen(true);
      return;
    }
    if ((/free\s*fire|pubg|bgmi/i.test(params.game.name)) && params.uidVerified !== true) {
      alert(`Please verify the ${/pubg|bgmi/i.test(params.game.name) ? 'PUBG' : 'Free Fire'} UID before placing the order.`);
      return;
    }
    console.log('[UG] Selected Payment Method:', params.paymentMethodChoice);

    isSubmittingOrderRef.current = true;
    try {
      if (params.paymentMethodChoice === 'wallet') {
        await walletCheckout(params);
      } else {
        await fonepayHubCheckout(params);
      }
    } finally {
      // Keep the submission lock until the complete checkout request finishes.
      // A fixed 1.2s timeout allowed slow payments to create a second order.
      isSubmittingOrderRef.current = false;
    }
  };

  // Initiate wallet recharge and keep the customer on our own /billing page.
  // ─── UG COINS: EXCHANGE FOR WALLET CREDIT ────────────────────────────────
  const handleExchangeCoins = async (coins: number) => {
    if (!isLoggedIn || !user.id) {
      setIsAuthModalOpen(true);
      throw new Error('Please log in to exchange coins.');
    }
    const result = await exchangeCoinsForWalletCredit(user.id, coins);
    if (!result.success) {
      throw new Error(result.error || 'Coin exchange failed. Please try again.');
    }
    setUser((prev) => ({
      ...prev,
      coinBalance: result.newCoinBalance ?? Math.max(0, (prev.coinBalance || 0) - coins),
      walletBalanceNpr: result.newWalletBalance ?? prev.walletBalanceNpr,
    }));
  };

  const handleInitiateWalletAdd = async (amount: number) => {
    if (!isLoggedIn) {
      setIsProfileOpen(false);
      setIsAuthModalOpen(true);
      return;
    }
    if (!amount || isNaN(amount) || amount <= 0) {
      alert('Please enter a valid recharge amount.');
      return;
    }
    try {
      const { data, error } = await supabase.functions.invoke('fonepay-hub-initiate', {
        body: {
          userId: user?.id,
          userEmail: user?.email,
          gameId: 'wallet-load',
          gameName: 'UG Wallet Top Up',
          playerUid: user?.id || user?.email || 'WALLET_USER',
          playerName: user?.username || user?.email || 'Wallet Recharge User',
          packageId: 'wallet-recharge',
          packageName: `UG Wallet Load NPR ${amount}`,
          diamonds: 0,
          quantity: 1,
          totalPriceNpr: amount,
        },
      });

      if (error) {
        let detail = '';
        try {
          const ctx = await (error as any).context?.json();
          detail = ctx?.message || ctx?.error || '';
        } catch {}
        throw new Error(detail || (error.message !== 'Edge Function returned a non-2xx status code' ? error.message : 'Wallet payment service error. Please try again.'));
      }

      if (data?.success) {
        setIsProfileOpen(false);
        if (data.order && (data.qrPayload || data.qrImage)) {
          openBillingPage(data.order, data.qrPayload, data.qrImage);
        } else {
          alert(data?.message || 'Gateway did not return a payment QR code.');
        }
      } else {
        alert(data?.message || 'Failed to initiate Fonepay Hub wallet payment.');
      }
    } catch (err: any) {
      console.error('[Fonepay Hub] Wallet load failed:', err);
      alert(err?.message || 'Failed to connect to Fonepay Hub payment gateway.');
    }
  };

  // Callback when QR Payment is verified by Fonepay Hub.
  // The Firestore onSnapshot listeners (subscribeUserOrders / subscribeUserProfile)
  // will automatically update wallet balance and orders list — no local state mutation needed.
  const handlePaymentSuccess = async (verifiedOrder: Order) => {
    console.log('[UG] Payment Verified');
    try { sessionStorage.removeItem('ug_fonepay_hub_checkout_lock'); } catch {}
    // Fonepay Hub orders are created before payment. Once the payment is server-verified,
    // persist the UID verification marker so admin completion remains protected.
    if (verifiedOrder?.orderId && verifiedOrder.uidVerified !== true) {
      await markOrderUidVerified(verifiedOrder.orderId, verifiedOrder.playerUid);
      verifiedOrder.uidVerified = true;
      verifiedOrder.uidVerifiedAt = new Date().toISOString();
    }
    setIsPaymentModalOpen(false);
    if (verifiedOrder) {
      console.log('[UG] Order Created');
      setCompletedOrder(verifiedOrder);
    }
    setPendingOrder(null);
    setQrPayload(undefined);
    setPaymentUrl(undefined);
    setQrImage(undefined);
    // Firestore real-time listeners handle UI refresh automatically.
  };

  // Protected route guard: all protected routes require authentication.
  // If auth has resolved and user is not logged in, redirect to home and open login modal.
  const isAccountRoute = currentPath === '/account' || currentPath.startsWith('/account/');
  if (authChecked && !isLoggedIn && isProtectedRoute(currentPath)) {
    // Save the intended destination so we can redirect back after login
    if (!pendingRedirectPathRef.current) {
      pendingRedirectPathRef.current = currentPath;
    }
    try {
      window.history.replaceState({}, '', '/');
    } catch {}
    setCurrentPath('/');
    setIsAuthModalOpen(true);
    return null;
  }

  // In-app payment page. The customer never leaves the storefront.
  // `!completedOrder` lets the render fall through to the success receipt below
  // the moment the payment verifies.
  if (currentPath === '/billing' && !completedOrder) {
    const activeBillingOrderId =
      billingOrderId || new URLSearchParams(window.location.search).get('orderId') || '';
    return (
      <BillingPage
        orderId={activeBillingOrderId}
        qrPayload={qrPayload}
        qrImage={qrImage}
        order={pendingOrder && pendingOrder.orderId === activeBillingOrderId ? pendingOrder : null}
        onNavigate={navigateTo}
        onPaymentSuccess={(paidOrder) => {
          setBillingOrderId('');
          try { window.history.replaceState({}, '', '/'); } catch { /* safe fallback */ }
          setCurrentPath('/');
          handlePaymentSuccess(paidOrder);
        }}
      />
    );
  }

  // Admin-only route: Instant Wallet Load request management
  if (currentPath === '/admin/payments/instant-wallet-load') {
    if (!isLoggedIn) {
      window.history.replaceState({}, '', '/');
      setCurrentPath('/');
      setIsAuthModalOpen(true);
      return null;
    }
    if (!isAdmin) {
      return (
        <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
          <div className="text-center p-8 rounded-2xl bg-zinc-900 border border-zinc-800 max-w-sm mx-4">
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
              <span className="text-red-400 text-xl">⛔</span>
            </div>
            <h2 className="text-lg font-black text-white mb-1">Admin Access Required</h2>
            <p className="text-xs text-zinc-400 mb-4">This page is restricted to administrators only.</p>
            <button
              onClick={() => navigateTo('/account')}
              className="px-4 py-2 rounded-xl bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs font-bold hover:bg-zinc-700 transition-all cursor-pointer"
            >
              Back to Account
            </button>
          </div>
        </div>
      );
    }
    return (
      <React.Suspense
        fallback={
          <div className="min-h-screen bg-black flex items-center justify-center text-zinc-400 text-sm">
            Loading...
          </div>
        }
      >
        <InstantWalletLoad
          user={user}
          walletHistory={walletHistory}
          onNavigate={navigateTo}
        />
      </React.Suspense>
    );
  }

  if (currentPath === '/admin' || currentPath.startsWith('/admin')) {
    return (
      <ErrorBoundary fallbackTitle="Admin Portal Error" onReset={() => navigateTo('/')}>
        <React.Suspense
          fallback={
            <div className="min-h-screen bg-[#070a11] text-white flex flex-col items-center justify-center p-4 font-sans">
              <div className="w-12 h-12 bg-red-600 text-white font-black text-xl rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-red-600/30 animate-pulse">
                UG
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-zinc-300 mb-1">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                <span>Loading UG Admin Portal...</span>
              </div>
              <p className="text-[11px] text-zinc-500">Preparing store statistics & management controls</p>
            </div>
          }
        >
          <AdminDashboard
            games={games}
            banners={banners}
            categories={categories}
            userProfile={user}
            orders={orders}
            reviews={reviews}
            onUpdateGames={setGames}
            onUpdateBanners={setBanners}
            onUpdateCategories={setCategories}
            onUpdateUserProfile={setUser}
            onUpdateOrders={setOrders}
            onNavigateToStore={() => navigateTo('/')}
            onSendNotification={(notif) => setAdminNotification(notif)}
          />
        </React.Suspense>
        <GlobalToast />
      </ErrorBoundary>
    );
  }

  // Dedicated Full Pages for the Account section — the profile drawer is
  // navigation-only; every menu item routes here instead of rendering
  // content inline inside the drawer.
  if (isAccountRoute) {
    const accountHandlers = {
      onUpdateUsername: async (newName: string) => {
        setUser((prev) => ({ ...prev, username: newName }));
        try {
          if (user.id) {
            await updateOwnUserProfile(user.id, { username: newName });
          }
        } catch (err) {
          console.error('[UPDATE USERNAME ERROR]', err);
        }
      },
      onUpdatePassword: async (newPassword: string) => {
        const { data } = await supabase.auth.getUser();
        if (!data.user) throw new Error('Not signed in');
        const { error } = await supabase.auth.updateUser({ password: newPassword });
        if (error) throw error;
      },
      onUpdateProfilePic: async (file: File) => {
        if (!user.id) return;
        const avatarUrl = await uploadAvatarAndUpdateProfile(user.id, file);
        setUser((prev) => ({ ...prev, avatarUrl }));
      },
      onManualWalletRequest: async (amount: number, screenshot: File) => {
        if (!user.id) throw new Error('Not signed in');
        await submitManualWalletRequest({
          uid: user.id,
          username: user.username,
          email: user.email,
          avatarUrl: user.avatarUrl,
          amountNpr: amount,
          screenshotFile: screenshot,
        });
      },
    };

    let pageContent: React.ReactNode;
    if (currentPath === '/account/orders') {
      pageContent = <OrdersPage orders={orders} onNavigate={navigateTo} />;
    } else if (currentPath === '/account/transactions') {
      pageContent = <TransactionsPage walletHistory={walletHistory} onNavigate={navigateTo} />;
    } else if (currentPath === '/account/wallet') {
      // Customer page: QR Payment, Payment Instructions, Upload Screenshot, Submit Wallet Request
      pageContent = (
        <WalletPage
          user={user}
          walletHistory={walletHistory}
          onNavigate={navigateTo}
          onInitiateWalletAdd={handleInitiateWalletAdd}
          onManualWalletRequest={accountHandlers.onManualWalletRequest}
        />
      );
    } else if (currentPath === '/account/support') {
      pageContent = <SupportPage onNavigate={navigateTo} />;
    } else if (currentPath === '/account/coins') {
      pageContent = (
        <CoinExchangePage
          user={user}
          walletHistory={walletHistory}
          onNavigate={navigateTo}
          onExchangeCoins={handleExchangeCoins}
        />
      );
    } else {
      // '/account'
      pageContent = (
        <AccountPage
          user={user}
          onNavigate={navigateTo}
          onUpdateUsername={accountHandlers.onUpdateUsername}
          onUpdatePassword={accountHandlers.onUpdatePassword}
          onUpdateProfilePic={accountHandlers.onUpdateProfilePic}
          orders={orders}
          walletHistory={walletHistory}
        />
      );
    }

    return (
      <>
        {pageContent}
        <BottomNav
          currentPath={currentPath}
          onNavigate={navigateTo}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onAuthSuccess={handleAuthSuccess}
        />
        <GlobalToast />
      </>
    );
  }

  // Dedicated Full Page for Notifications
  if (currentPath === '/notifications' || currentPath === '/account/notifications') {
    return (
      <>
        <NotificationsPage
          onNavigate={navigateTo}
          adminNotification={adminNotification}
          user={user}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          onOpenWalletAdd={() => navigateTo('/account/wallet')}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenAdmin={() => navigateTo('/admin')}
          onLogout={handleLogout}
        />
        <BottomNav
          currentPath={currentPath}
          onNavigate={navigateTo}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onAuthSuccess={handleAuthSuccess}
        />
        <GlobalToast />
      </>
    );
  }

  // Dedicated Full Page for FAQ (Frequently Asked Questions)
  if (currentPath === '/faq' || currentPath === '/faqs' || currentPath === '/help') {
    return (
      <>
        <FaqPage
          user={user}
          isLoggedIn={isLoggedIn}
          onNavigate={navigateTo}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          onOpenWalletAdd={() => navigateTo('/account/wallet')}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenAdmin={() => navigateTo('/admin')}
          onLogout={handleLogout}
          adminNotification={adminNotification}
        />
        <BottomNav
          currentPath={currentPath}
          onNavigate={navigateTo}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onAuthSuccess={handleAuthSuccess}
        />
        <GlobalToast />
      </>
    );
  }

  // Dedicated Full Page for Terms & Conditions
  if (
    currentPath === '/terms' ||
    currentPath === '/terms-and-conditions' ||
    currentPath === '/terms-conditions' ||
    currentPath === '/legal/terms'
  ) {
    return (
      <>
        <TermsPage
          user={user}
          isLoggedIn={isLoggedIn}
          onNavigate={navigateTo}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          onOpenWalletAdd={() => navigateTo('/account/wallet')}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenAdmin={() => navigateTo('/admin')}
          onLogout={handleLogout}
          adminNotification={adminNotification}
        />
        <BottomNav
          currentPath={currentPath}
          onNavigate={navigateTo}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onAuthSuccess={handleAuthSuccess}
        />
        <GlobalToast />
      </>
    );
  }

  // Dedicated Full Page for Privacy Policy
  if (
    currentPath === '/privacy' ||
    currentPath === '/privacy-policy' ||
    currentPath === '/legal/privacy'
  ) {
    return (
      <>
        <PrivacyPage
          user={user}
          isLoggedIn={isLoggedIn}
          onNavigate={navigateTo}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          onOpenWalletAdd={() => navigateTo('/account/wallet')}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenAdmin={() => navigateTo('/admin')}
          onLogout={handleLogout}
          adminNotification={adminNotification}
        />
        <BottomNav
          currentPath={currentPath}
          onNavigate={navigateTo}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onAuthSuccess={handleAuthSuccess}
        />
        <GlobalToast />
      </>
    );
  }

  // Dedicated Full Page for Mobile Legends Top-Up
  if (
    currentPath === '/product/mobile-legends' ||
    currentPath === '/mobile-legends' ||
    currentPath === '/product/mlbb' ||
    currentPath === '/product/mobilelegends'
  ) {
    return (
      <>
        <MobileLegendsPage
          user={user}
          isLoggedIn={isLoggedIn}
          games={games}
          onNavigate={navigateTo}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          onOpenWalletAdd={() => navigateTo('/account/wallet')}
          onInitiatePayment={handleInitiatePayment}
        />
        <BottomNav
          currentPath={currentPath}
          onNavigate={navigateTo}
          isLoggedIn={isLoggedIn}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
        />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onAuthSuccess={handleAuthSuccess}
        />
        {pendingOrder && (
          <PaymentModal
            isOpen={isPaymentModalOpen}
            onClose={() => {
              setIsPaymentModalOpen(false);
              setPendingOrder(null);
              setQrPayload(undefined);
              setPaymentUrl(undefined);
              setQrImage(undefined);
            }}
            pendingOrder={pendingOrder}
            qrPayload={qrPayload}
            paymentUrl={paymentUrl}
            qrImage={qrImage}
            onPaymentSuccess={handlePaymentSuccess}
          />
        )}
        <GlobalToast />
      </>
    );
  }

  // Dedicated Verification Loading Screen (White + Red theme) when returning from Fonepay Hub
  if (isVerifyingPayment) {
    return (
      <div className="fixed inset-0 z-[99990] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
        <div className="w-full max-w-md bg-white border border-zinc-200/90 rounded-3xl p-8 shadow-2xl text-zinc-900 text-center space-y-6 relative overflow-hidden animate-fadeIn">
          {/* Subtle Decorative Background Light */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-20 bg-red-500/10 blur-2xl pointer-events-none rounded-full" />

          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-red-50 border-2 border-red-500 flex items-center justify-center text-red-600 mx-auto shadow-md shadow-red-500/10 pt-0.5">
            <Loader2 className="w-9 h-9 sm:w-10 sm:h-10 animate-spin text-red-600" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-zinc-900 tracking-tight">Verifying Payment...</h2>
            {verifyingOrderId && (
              <p className="text-sm text-zinc-600 font-medium">
                Order Reference: <span className="font-mono font-bold text-red-600">#{verifyingOrderId}</span>
              </p>
            )}
          </div>

          <div className="bg-zinc-50 border border-zinc-200/80 rounded-2xl p-4 text-xs text-zinc-500 font-medium leading-relaxed">
            Connecting with Fonepay Hub gateway. Please wait a moment while we verify your transaction and update your balance.
          </div>
        </div>
        <GlobalToast />
      </div>
    );
  }

  // Dedicated Full Page or Modal for Payment Successful / Order Created
  // Shown whenever completedOrder is set (from wallet checkout, verified payment gateway, or callback).
  if (completedOrder) {
    const isWalletLoad =
      completedOrder.gameId === 'wallet-load' ||
      completedOrder.packageId === 'wallet-recharge' ||
      completedOrder.packageName?.toLowerCase().includes('wallet') ||
      completedOrder.gameName?.toLowerCase().includes('wallet');

    if (isWalletLoad) {
      return (
        <>
          <WalletSuccessModal
            order={completedOrder}
            user={user}
            onClose={() => setCompletedOrder(null)}
            onGoToDashboard={() => {
              setCompletedOrder(null);
              navigateTo('/account/wallet');
            }}
          />
          <GlobalToast />
        </>
      );
    }

    return (
      <div className="min-h-screen bg-slate-100/90 text-zinc-900 py-6 sm:py-12 px-3 sm:px-6 flex flex-col items-center justify-center">
        <div className="w-full max-w-2xl my-auto">
          <OrderConfirmation
            order={completedOrder}
            user={user}
            onClose={() => {
              setCompletedOrder(null);
            }}
            onOpenWallet={() => {
              setCompletedOrder(null);
              navigateTo('/account/wallet');
            }}
            onOpenCoins={() => {
              setCompletedOrder(null);
              navigateTo('/account/coins');
            }}
          />
        </div>
        <GlobalToast />
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-white text-zinc-900 font-sans selection:bg-red-600 selection:text-white flex flex-col justify-between overflow-x-clip pb-16 md:pb-0">
        
        {/* Main Content Area */}
        <div>
          <Header
            walletBalance={user.walletBalanceNpr}
            isLoggedIn={isLoggedIn}
            authChecked={authChecked}
            userName={user.username}
            avatarUrl={user.avatarUrl}
            user={user}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenWalletAdd={() => navigateTo('/account/wallet')}
            onOpenAuth={() => setIsAuthModalOpen(true)}
            onLogout={handleLogout}
            onOpenHelp={() => {
              const el = document.getElementById('reviews-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            onOpenAdmin={() => navigateTo('/admin')}
            onOpenNotifications={() => { navigateTo('/notifications'); handleClearNotification(); }}
            apiConnected={true}
            adminNotification={adminNotification}
            onClearNotification={handleClearNotification}
          />

          {/* Hero Interactive Carousel Banner */}
          <div>
            <Banner
              banners={banners}
              onSelectGame={(gameId) => {
                const found = games.find((g) => g.id === gameId);
                if (found) {
                  const lowerName = (found.name || '').toLowerCase();
                  if (lowerName.includes('mobile legends') || lowerName.includes('mlbb') || found.id.toLowerCase().includes('mlbb')) {
                    navigateTo('/product/mobile-legends');
                  } else {
                    setSelectedGame(found);
                    setTimeout(() => {
                      const target = document.getElementById('package-selection-section') || document.getElementById('topup-section');
                      if (target) {
                        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    }, 100);
                  }
                }
              }}
              onOpenWalletAdd={() => navigateTo('/account/wallet')}
            />
          </div>

          {/* Game Selection Grid */}
          <div>
            <GameGrid
              games={games}
              categories={categories}
              selectedGameId={selectedGame?.id || ''}
              onSelectGame={(gameId) => {
                const found = games.find((g) => g.id === gameId);
                if (found) {
                  const lowerName = (found.name || '').toLowerCase();
                  if (lowerName.includes('mobile legends') || lowerName.includes('mlbb') || found.id.toLowerCase().includes('mlbb')) {
                    navigateTo('/product/mobile-legends');
                  } else {
                    setSelectedGame(found);
                    setTimeout(() => {
                      const target = document.getElementById('package-selection-section') || document.getElementById('topup-section');
                      if (target) {
                        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    }, 100);
                  }
                }
              }}
            />
          </div>

          {/* Main Product / Top Up Section */}
          <div>
            <TopUpSection
              game={selectedGame}
              walletBalance={user.walletBalanceNpr}
              isLoggedIn={isLoggedIn}
              userAvatarUrl={user.avatarUrl}
              user={user}
              onInitiatePayment={handleInitiatePayment}
              onOpenWalletAdd={() => navigateTo('/account/wallet')}
            />
          </div>
        </div>

        {/* Footer Reviews Section & Footer */}
        <div id="reviews-section">
          <ReviewCarousel
            reviews={reviews}
            onAddReview={(newRev) => setReviews((prev) => [newRev, ...prev])}
            onOpenAdmin={() => navigateTo('/admin')}
          />

          {/* Dedicated Footer */}
          <Footer onNavigate={navigateTo} />
        </div>

        {/* Premium Profile Drawer */}
        <ProfileDrawer
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          user={user}
          orders={orders}
          walletHistory={walletHistory}
          onNavigate={navigateTo}
          onLogout={handleLogout}
          currentPath={currentPath}
        />

        {/* Floating WhatsApp Quick Support Widget */}
        <WhatsAppButton />

      </div>

      {/* Mobile Bottom Navigation — fixed to viewport on mobile screens (< 768px) */}
      <BottomNav
        currentPath={currentPath}
        onNavigate={navigateTo}
        isLoggedIn={isLoggedIn}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        unreadNotificationsCount={adminNotification?.unread ? 1 : 0}
      />

      {/* User Login & Sign Up Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Access Denied Banner Modal for Unauthorized Accounts */}
      {accessDeniedMessage && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="bg-[#121622] border border-red-500/30 rounded-2xl p-6 max-w-sm w-full text-center shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <span className="text-xl font-bold">✕</span>
            </div>
            <h3 className="text-lg font-bold text-white">Access Denied</h3>
            <p className="text-sm text-zinc-300">{accessDeniedMessage}</p>
            <button
              onClick={() => setAccessDeniedMessage(null)}
              className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-medium rounded-xl transition"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Dynamic Fonepay Hub Payment QR Modal */}
      {pendingOrder && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => {
            setIsPaymentModalOpen(false);
            setPendingOrder(null);
            setQrPayload(undefined);
            setPaymentUrl(undefined);
            setQrImage(undefined);
          }}
          pendingOrder={pendingOrder}
          qrPayload={qrPayload}
          paymentUrl={paymentUrl}
          qrImage={qrImage}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Announcement Modal — dark premium promo/notice modal shown to visitors
          when an admin-configured announcement is currently active & scheduled */}
      {activeAnnouncement && (
        <AnnouncementModal
          announcement={activeAnnouncement}
          onClose={() => setActiveAnnouncement(null)}
        />
      )}

      {/* Install App Bottom Middle Popup for Mobile & Desktop */}
      <InstallAppPopup show={true} />

      {/* Global Bottom Right Toast Notification Card */}
      <GlobalToast />
    </>
  );
}
