import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { 
  LayoutGrid, BarChart3, ShoppingBag, CreditCard, Users, 
  Settings, ChevronDown, ChevronRight, Search, 
  RefreshCw, LogOut, Calendar, Clock, Plus, Trash2, Edit3, Image as ImageIcon, 
  Gamepad2, Package, CheckCircle, XCircle, AlertCircle, Tag, Lock, Mail, 
  User as UserIcon, ArrowUpRight, ArrowDownLeft, ShieldCheck, ShieldAlert, Zap, Moon, Sun, Bell, Send, Check,
  ArrowUp, ArrowDown, Loader2, Eye, RotateCcw, X, Copy,
  Power, CheckCircle2, AlertTriangle, Layers, Filter, Save, ArrowLeftRight, Tv, Ticket, Box, Sliders,
  Globe, Key, MessageSquare, User, RotateCw, ZoomIn, ZoomOut, Move, QrCode, Gift, Megaphone
} from 'lucide-react';
import { Game, GamePackage, BannerItem, UserProfile, Order, WalletTransaction, AdminNotification, GameCategory, ProductItem, Review, CustomInputField } from '../types';
import { isMlbbBrazilGame } from '../lib/mlbbVariations';
import { MLApiMonitoring } from './admin/MLApiMonitoring';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS } from '../data/initialData';
import { PaymentPageSettingsCard } from './admin/PaymentPageSettingsCard';
import { 
  saveBannerToFirestore, deleteBannerFromFirestore, 
  saveGameToFirestore, deleteGameFromFirestore, wipeAllGamesFromFirestore,
  saveUserToFirestore, saveOrderToFirestore,
  saveCategoryToFirestore, deleteCategoryFromFirestore,
  checkAdminStatusInFirestore,
  subscribePendingWalletRequests, subscribeAllWalletRequests, subscribeUsersList, approveWalletRequest, rejectWalletRequest, WalletRequestRecord,
  deleteWalletRequest, deleteSelectedWalletRequests, wipeAllWalletRequests,
  subscribeProducts, saveProductToFirestore, deleteProductFromFirestore, sortChronologicalAsc,
  subscribeOrders, adminUpdateUserWallet, adminUpdateUsername, adminToggleUserStatus, adminUpdateOrderStatus, safeJsonStringify,
  subscribeManualPaymentSettings, saveManualPaymentSettings, uploadManualPaymentQR, ManualPaymentSettings, DEFAULT_MANUAL_PAYMENT_SETTINGS,
  subscribeReviews, updateReviewStatus, deleteReviewRecord,
  sendNotificationToUser, deleteNotificationRecord,
  subscribeRedeemCodes, addRedeemCodes, deleteRedeemCode, isRedeemCodeOrder,
  TransactionalEmailDeliveryRecord, getOrderEmailDeliveryStatus, sendTransactionalEmail,
} from '../lib/store';
import { AnnouncementsManager } from './admin/AnnouncementsManager';

interface AdminDashboardProps {
  games: Game[];
  banners: BannerItem[];
  categories?: GameCategory[];
  userProfile: UserProfile;
  orders: Order[];
  reviews?: Review[];
  onUpdateGames: (games: Game[]) => void;
  onUpdateBanners: (banners: BannerItem[]) => void;
  onUpdateCategories?: (categories: GameCategory[]) => void;
  onUpdateUserProfile: (user: UserProfile) => void;
  onUpdateOrders: (orders: Order[]) => void;
  onNavigateToStore: () => void;
  onSendNotification?: (notification: AdminNotification) => void;
}

interface ReceiptImageViewerProps {
  imageSrc?: string;
  zoom: number;
  setZoom: React.Dispatch<React.SetStateAction<number>>;
  rotation: number;
  setRotation: React.Dispatch<React.SetStateAction<number>>;
}

const ReceiptImageViewer: React.FC<ReceiptImageViewerProps> = ({
  imageSrc,
  zoom,
  setZoom,
  rotation,
  setRotation,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [hasError, setHasError] = useState<boolean>(false);

  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const panStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const touchStartRef = useRef<{ dist: number; initialZoom: number } | null>(null);
  const lastTapRef = useRef<number>(0);

  // Fallback demo screenshot if none provided in record
  const effectiveSrc = imageSrc || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=800&auto=format&fit=crop&q=80';

  // Wheel zoom with passive: false to prevent scrolling container/page
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const zoomFactor = e.ctrlKey ? 0.08 : 0.15;
      const delta = -e.deltaY * zoomFactor;

      setZoom((prevZoom) => {
        let newZoom = prevZoom + delta * (prevZoom / 80);
        return Math.min(800, Math.max(100, Math.round(newZoom)));
      });
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      container.removeEventListener('wheel', handleWheel);
    };
  }, [setZoom]);

  // Reset pan when zoom goes back to 100%
  useEffect(() => {
    if (zoom <= 100) {
      setPan({ x: 0, y: 0 });
    }
  }, [zoom]);

  // Reset loading/error when imageSrc changes
  useEffect(() => {
    setIsLoading(true);
    setHasError(false);
    setPan({ x: 0, y: 0 });
  }, [imageSrc]);

  // Mouse drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoom <= 100) return;
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    panStartRef.current = { ...pan };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || zoom <= 100) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    setPan({
      x: panStartRef.current.x + dx,
      y: panStartRef.current.y + dy,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Double Click / Double Tap toggle
  const handleDoubleClick = () => {
    if (zoom === 100) {
      setZoom(200);
    } else if (zoom === 200) {
      setZoom(400);
    } else {
      setZoom(100);
      setPan({ x: 0, y: 0 });
    }
  };

  // Touch drag & pinch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      touchStartRef.current = { dist, initialZoom: zoom };
    } else if (e.touches.length === 1) {
      const now = Date.now();
      if (now - lastTapRef.current < 300) {
        handleDoubleClick();
        lastTapRef.current = 0;
        return;
      }
      lastTapRef.current = now;

      if (zoom > 100) {
        setIsDragging(true);
        dragStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        panStartRef.current = { ...pan };
      }
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchStartRef.current) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / touchStartRef.current.dist;
      let newZoom = Math.round(touchStartRef.current.initialZoom * factor);
      newZoom = Math.min(800, Math.max(100, newZoom));
      setZoom(newZoom);
      if (newZoom <= 100) setPan({ x: 0, y: 0 });
    } else if (e.touches.length === 1 && isDragging && zoom > 100) {
      const dx = e.touches[0].clientX - dragStartRef.current.x;
      const dy = e.touches[0].clientY - dragStartRef.current.y;
      setPan({
        x: panStartRef.current.x + dx,
        y: panStartRef.current.y + dy,
      });
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    touchStartRef.current = null;
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onDoubleClick={handleDoubleClick}
      className={`relative flex-1 bg-[#04060a] overflow-hidden p-4 sm:p-8 flex items-center justify-center min-h-[480px] max-h-[calc(92vh-130px)] select-none ${
        zoom > 100 ? (isDragging ? 'cursor-grabbing' : 'cursor-grab') : 'cursor-default'
      }`}
    >
      {/* Floating Top-Left Drag/Scroll Hint */}
      <div className="absolute top-4 left-4 z-10 bg-[#0e1424]/90 border border-[#1d2842] text-zinc-300 text-[11px] font-semibold px-3 py-1.5 rounded-full flex items-center gap-1.5 backdrop-blur-md shadow-md select-none pointer-events-none">
        <Move className="w-3.5 h-3.5 text-emerald-400" />
        <span>Drag / Scroll / Pinch to Zoom</span>
      </div>

      {/* Floating Top-Right Zoom Percentage */}
      <div className="absolute top-4 right-4 z-10 bg-[#0e1424]/90 border border-[#1d2842] text-[#00e676] font-mono text-xs font-bold px-3 py-1.5 rounded-full backdrop-blur-md shadow-md select-none pointer-events-none">
        {Math.round(zoom)}%
      </div>

      {/* Loading State Spinner */}
      {isLoading && !hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#04060a] z-20 text-zinc-400 gap-3">
          <Loader2 className="w-9 h-9 animate-spin text-emerald-400" />
          <span className="text-xs font-mono font-medium">Loading payment screenshot...</span>
        </div>
      )}

      {/* Error State */}
      {hasError ? (
        <div className="flex flex-col items-center justify-center text-center p-6 bg-[#0c101c] border border-red-900/40 rounded-2xl max-w-md z-20 space-y-3">
          <AlertTriangle className="w-10 h-10 text-red-500" />
          <div>
            <h4 className="text-sm font-bold text-white">Unable to load payment screenshot</h4>
            <p className="text-xs text-zinc-400 mt-1">The image file might be corrupted or missing from server storage.</p>
          </div>
          <button
            onClick={() => {
              setHasError(false);
              setIsLoading(true);
            }}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <RotateCw className="w-3.5 h-3.5" /> Retry Loading
          </button>
        </div>
      ) : (
        /* Image ONLY (No generated receipt card design) */
        <div
          className="will-change-transform flex items-center justify-center w-full h-full"
          style={{
            transform: `translate3d(${pan.x}px, ${pan.y}px, 0px) scale(${zoom / 100}) rotate(${rotation}deg)`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out',
          }}
        >
          <img
            src={effectiveSrc}
            alt="Payment Proof Screenshot"
            onLoad={() => setIsLoading(false)}
            onError={() => {
              setIsLoading(false);
              setHasError(true);
            }}
            className={`max-w-[85vw] max-h-[65vh] object-contain rounded-lg shadow-2xl transition-opacity duration-300 ${
              isLoading ? 'opacity-0' : 'opacity-100'
            }`}
            draggable={false}
          />
        </div>
      )}
    </div>
  );
};

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  games,
  banners,
  categories,
  userProfile,
  orders,
  onUpdateGames,
  onUpdateBanners,
  onUpdateCategories,
  onUpdateUserProfile,
  onUpdateOrders,
  onNavigateToStore,
  onSendNotification,
}) => {
  // Determine if the user passing in via userProfile is already authenticated as admin
  const isPropAdmin = Boolean(
    userProfile &&
    (userProfile.role === 'admin' || userProfile.email?.toLowerCase().trim() === 'rishugupta12444@gmail.com')
  );

  // Authentication State
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(!isPropAdmin);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(isPropAdmin);
  const [adminUser, setAdminUser] = useState<any | null>(isPropAdmin ? userProfile : null);
  const [isAuthSubmitting, setIsAuthSubmitting] = useState<boolean>(false);
  const [loginEmail, setLoginEmail] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginError, setLoginError] = useState<string>('');

  // Listen to Supabase Auth state & getSession
  useEffect(() => {
    let isMounted = true;

    // Safety fallback timer so loading state never hangs indefinitely
    const safetyTimer = setTimeout(() => {
      if (isMounted) setIsAuthLoading(false);
    }, 1500);

    // Initial session check
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!isMounted) return;
      if (session?.user) {
        try {
          const isAdmin = await checkAdminStatusInFirestore(session.user.id);
          if (isAdmin && isMounted) {
            setIsAuthenticated(true);
            setAdminUser(session.user);
          }
        } catch (err) {
          console.error('[ADMIN GET SESSION ERROR]', err);
        }
      }
      if (isMounted) setIsAuthLoading(false);
    }).catch((err) => {
      console.error('[GET SESSION CATCH]', err);
      if (isMounted) setIsAuthLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (!isMounted) return;
      const currentUser = session?.user;
      if (currentUser) {
        try {
          const isAdmin = await checkAdminStatusInFirestore(currentUser.id);
          if (isMounted) {
            if (isAdmin) {
              setIsAuthenticated(true);
              setAdminUser(currentUser);
              setLoginError('');
            } else {
              setIsAuthenticated(false);
              setAdminUser(null);
              setLoginError('Access denied: Your account is not authorized as an active admin.');
            }
          }
        } catch (err: any) {
          console.error('[ADMIN AUTH LISTENER ERROR]', err);
        }
      } else {
        if (isMounted) {
          setIsAuthenticated(false);
          setAdminUser(null);
        }
      }
      if (isMounted) setIsAuthLoading(false);
    });

    return () => {
      isMounted = false;
      clearTimeout(safetyTimer);
      subscription.unsubscribe();
    };
  }, []);

  // UI Theme State (Light vs Dark)
  const [adminTheme, setAdminTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('ug_admin_theme') as 'dark' | 'light') || 'dark';
  });

  // Active Menu / View State
  const [activeMainSection, setActiveMainSection] = useState<string>('ANALYTICS');
  const [activeSubItem, setActiveSubItem] = useState<string>('Dashboard');

  // Notification Manager State
  const [notifTargetType, setNotifTargetType] = useState<'ALL' | 'USER'>('ALL');
  const [notifTargetEmail, setNotifTargetEmail] = useState<string>('');
  const [notifTitle, setNotifTitle] = useState<string>('');
  const [notifMessage, setNotifMessage] = useState<string>('');
  const [notifCategory, setNotifCategory] = useState<'Announcement' | 'Promo Code' | 'Order' | 'Wallet' | 'System'>('Announcement');
  const [notifExpiresIn, setNotifExpiresIn] = useState<string>('');
  const [notifIsPinned, setNotifIsPinned] = useState<boolean>(false);
  const [notifSending, setNotifSending] = useState<boolean>(false);
  const [notifSendMsg, setNotifSendMsg] = useState<string>('');

  // Redeem Codes Manager State
  const [redeemCodesList, setRedeemCodesList] = useState<import('../types').RedeemCodeRecord[]>([]);
  const [selectedRcGameId, setSelectedRcGameId] = useState<string>('');
  const [selectedRcPackageId, setSelectedRcPackageId] = useState<string>('');
  const [rcInputText, setRcInputText] = useState<string>('');
  const [rcFilterSearch, setRcFilterSearch] = useState<string>('');
  const [rcStatusFilter, setRcStatusFilter] = useState<'ALL' | 'AVAILABLE' | 'RESERVED' | 'DELIVERED' | 'REDEEMED' | 'CANCELLED'>('ALL');
  const [rcProductFilter, setRcProductFilter] = useState<string>('ALL');
  const [rcPackageFilter, setRcPackageFilter] = useState<string>('ALL');
  const [revealedRcIds, setRevealedRcIds] = useState<Set<string>>(new Set());
  const [rcSubmitting, setRcSubmitting] = useState<boolean>(false);
  const [rcMsg, setRcMsg] = useState<string>('');

  // Subscribe to real-time Redeem Codes from Supabase
  useEffect(() => {
    const unsub = subscribeRedeemCodes((codes) => {
      setRedeemCodesList(codes);
    });
    return unsub;
  }, []);

  const handleAddRedeemCodesSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rcInputText.trim()) return;

    const game = games.find(g => g.id === selectedRcGameId) || games[0];
    if (!game) {
      setRcMsg('Please select a valid game/product.');
      return;
    }

    const pkgList = game.packages || [];
    const pkg = pkgList.find(p => p.id === selectedRcPackageId) || pkgList[0];
    if (!pkg) {
      setRcMsg('Please select a valid package.');
      return;
    }

    const lines = rcInputText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length === 0) {
      setRcMsg('No valid redeem codes found in input.');
      return;
    }

    setRcSubmitting(true);
    setRcMsg('');

    const res = await addRedeemCodes(game.id, pkg.id, lines);
    setRcSubmitting(false);

    if (res.success) {
      setRcMsg(`Successfully added ${res.count} redeem code(s) for "${pkg.name}" (${game.name}) to Supabase!${res.duplicates ? ` ${res.duplicates} duplicates skipped.` : ''}`);
      setRcInputText('');
    } else {
      setRcMsg(`Failed to add codes: ${res.error || 'Unknown error'}`);
    }
  };

  const handleDeleteRcCode = async (id: string) => {
    if (confirm('Are you sure you want to delete this redeem code from stock?')) {
      await deleteRedeemCode(id);
    }
  };

  // Accordion Expand States
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({
    STORE: true,
    ANALYTICS: true,
    ORDERS: false,
    PAYMENTS: false,
    USERS: false,
    SETTINGS: false,
  });

  // Search & Refresh State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'ALL' | 'Pending' | 'Completed' | 'Cancelled'>('ALL');
  const [orderCategoryFilter, setOrderCategoryFilter] = useState<string>('ALL');
  const [selectedDetailOrder, setSelectedDetailOrder] = useState<Order | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Products Management State (Connected to Supabase)
  const [productsList, setProductsList] = useState<ProductItem[]>([]);
  const [productSearch, setProductSearch] = useState<string>('');
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('ALL');
  const [productStatusFilter, setProductStatusFilter] = useState<string>('ALL');
  const [productAvailabilityFilter, setProductAvailabilityFilter] = useState<string>('ALL');
  const [isRefreshingProducts, setIsRefreshingProducts] = useState<boolean>(false);
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState<boolean>(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);

  const [productForm, setProductForm] = useState<{
    name: string;
    code: string;
    category: string;
    productType: 'voucher' | 'topup';
    status: 'Active' | 'Inactive';
    availability: 'In Stock' | 'Out Of Stock' | 'Pre-Order';
    priceNpr: number;
    stockCount: number;
    imageUrl: string;
    descriptionTitle: string;
    description: string;
    requireUid: boolean;
    requireZoneId: boolean;
    requireEmail: boolean;
    requirePassword: boolean;
    requireWhatsapp: boolean;
    userField1: string;
    userField2: string;
    customFields: CustomInputField[];
  }>({
    name: '',
    code: '',
    category: 'Games',
    productType: 'topup',
    status: 'Active',
    availability: 'In Stock',
    priceNpr: 1000,
    stockCount: 10,
    imageUrl: '',
    descriptionTitle: '',
    description: '',
    requireUid: true,
    requireZoneId: false,
    requireEmail: false,
    requirePassword: false,
    requireWhatsapp: false,
    userField1: '',
    userField2: '',
    customFields: [],
  });

  // Real-time Firestore sync for Products
  useEffect(() => {
    if (!isAuthenticated) return;
    const unsubscribe = subscribeProducts((data) => {
      setProductsList(data);
    });
    return () => unsubscribe();
  }, [isAuthenticated]);

  // Handlers for Products Management
  const handleToggleProductStatus = async (product: ProductItem) => {
    const newStatus: 'Active' | 'Inactive' = product.status === 'Active' ? 'Inactive' : 'Active';
    const saved = await saveProductToFirestore({ ...product, status: newStatus });
    if (!saved) { alert('Could not save product status to Supabase.'); return; }
    setProductsList(productsList.map((p) => p.id === product.id ? { ...p, status: newStatus } : p));
  };

  const handleChangeProductAvailability = async (product: ProductItem, newAvail: 'In Stock' | 'Out Of Stock' | 'Pre-Order') => {
    const saved = await saveProductToFirestore({ ...product, availability: newAvail });
    if (!saved) { alert('Could not save product availability to Supabase.'); return; }
    setProductsList(productsList.map((p) => p.id === product.id ? { ...p, availability: newAvail } : p));
  };

  const handleDeleteProduct = async (productId: string, productName: string) => {
    if (!confirm(`Are you sure you want to delete product "${productName}"?`)) return;
    const deleted = await deleteProductFromFirestore(productId);
    if (!deleted) { alert('Product could not be deleted from Supabase.'); return; }
    setProductsList(productsList.filter((p) => p.id !== productId));
  };

  const handleRefreshProducts = () => {
    setIsRefreshingProducts(true);
    setTimeout(() => {
      setIsRefreshingProducts(false);
    }, 500);
  };

  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setProductForm({
      name: '',
      code: `PRD-${Math.floor(1000 + Math.random() * 9000)}`,
      category: 'Games',
      productType: 'topup',
      status: 'Active',
      availability: 'In Stock',
      priceNpr: 1500,
      stockCount: 10,
      imageUrl: '',
      descriptionTitle: '',
      description: '',
      requireUid: true,
      requireZoneId: false,
      requireEmail: false,
      requirePassword: false,
      requireWhatsapp: false,
      userField1: '',
      userField2: '',
      customFields: [],
    });
    setIsAddProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod: ProductItem) => {
    setEditingProduct(prod);

    let embeddedCfg: any = null;
    const rawDesc = (prod as any).rawDescription || prod.description || '';
    if (rawDesc.includes('<!--INPUT_CFG:')) {
      try {
        const match = rawDesc.match(/<!--INPUT_CFG:(.*?)-->/s);
        if (match && match[1]) {
          embeddedCfg = JSON.parse(match[1]);
        }
      } catch (e) {
        console.warn('[ADMIN EDIT] Parse INPUT_CFG error:', e);
      }
    }

    const isMlbb = /mobile\s*legends|mlbb/i.test(prod.name || '');
    const inferredType: 'voucher' | 'topup' = prod.productType || (prod as any).product_type || (embeddedCfg ? embeddedCfg.productType : undefined) || (prod.category === 'Voucher' ? 'voucher' : 'topup');

    const reqZone = typeof prod.requireZoneId === 'boolean'
      ? prod.requireZoneId
      : (typeof (prod as any).require_zone_id === 'boolean'
          ? (prod as any).require_zone_id
          : (typeof (prod as any).requiresZoneId === 'boolean'
              ? (prod as any).requiresZoneId
              : (typeof (prod as any).requires_zone_id === 'boolean'
                  ? (prod as any).requires_zone_id
                  : (embeddedCfg && typeof embeddedCfg.requireZoneId === 'boolean'
                      ? embeddedCfg.requireZoneId
                      : (isMlbb && inferredType !== 'voucher')))));

    const reqUid = typeof prod.requireUid === 'boolean'
      ? prod.requireUid
      : (typeof (prod as any).require_uid === 'boolean'
          ? (prod as any).require_uid
          : (embeddedCfg && typeof embeddedCfg.requireUid === 'boolean'
              ? embeddedCfg.requireUid
              : false));

    const reqEmail = typeof prod.requireEmail === 'boolean'
      ? prod.requireEmail
      : (typeof (prod as any).require_email === 'boolean'
          ? (prod as any).require_email
          : (embeddedCfg && typeof embeddedCfg.requireEmail === 'boolean' ? embeddedCfg.requireEmail : false));

    const reqPass = typeof prod.requirePassword === 'boolean'
      ? prod.requirePassword
      : (typeof (prod as any).require_password === 'boolean'
          ? (prod as any).require_password
          : (embeddedCfg && typeof embeddedCfg.requirePassword === 'boolean' ? embeddedCfg.requirePassword : false));

    const reqWa = typeof prod.requireWhatsapp === 'boolean'
      ? prod.requireWhatsapp
      : (typeof (prod as any).require_whatsapp === 'boolean'
          ? (prod as any).require_whatsapp
          : (embeddedCfg && typeof embeddedCfg.requireWhatsapp === 'boolean' ? embeddedCfg.requireWhatsapp : false));

    const uField1 = prod.userField1
      || (prod as any).user_field1
      || (embeddedCfg ? embeddedCfg.userField1 : '')
      || '';

    const uField2 = prod.userField2
      || (prod as any).user_field2
      || (embeddedCfg ? embeddedCfg.userField2 : '')
      || '';

    const rawCFields = Array.isArray(prod.customFields)
      ? prod.customFields
      : (Array.isArray((prod as any).custom_fields)
          ? (prod as any).custom_fields
          : (embeddedCfg && Array.isArray(embeddedCfg.customFields) ? embeddedCfg.customFields : []));
    const cFields: CustomInputField[] = rawCFields
      .filter((f: any) => f && String(f.label || '').trim())
      .map((f: any) => ({ id: String(f.id || `cf_${Math.random().toString(36).slice(2, 9)}`), label: String(f.label).trim() }));

    const descTitle = prod.descriptionTitle
      || (prod as any).description_title
      || (embeddedCfg ? embeddedCfg.descriptionTitle : '')
      || '';

    const cleanDesc = prod.description ? prod.description.replace(/<!--INPUT_CFG:.*?-->/s, '').trim() : '';

    setProductForm({
      name: prod.name,
      code: prod.code || prod.id,
      category: prod.category || (inferredType === 'voucher' ? 'Voucher' : 'Games'),
      productType: inferredType,
      status: prod.status || 'Active',
      availability: prod.availability || 'In Stock',
      priceNpr: prod.priceNpr || 0,
      stockCount: prod.stockCount || 0,
      imageUrl: prod.imageUrl || '',
      descriptionTitle: descTitle,
      description: cleanDesc,
      requireUid: reqUid,
      requireZoneId: reqZone,
      requireEmail: reqEmail,
      requirePassword: reqPass,
      requireWhatsapp: reqWa,
      userField1: uField1,
      userField2: uField2,
      customFields: cFields,
    });
    setIsAddProductModalOpen(true);
  };

  const handleSaveProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name.trim()) {
      alert('Product Name is required.');
      return;
    }

    const prodId = editingProduct ? editingProduct.id : `prd_${Date.now()}`;
    const preservedPackages = (editingProduct as any)?.packages || [];

    const prodCreatedAt = editingProduct?.createdAt || (editingProduct as any)?.created_at || new Date().toISOString();

    const prodToSave: ProductItem = {
      id: prodId,
      name: productForm.name.trim(),
      code: productForm.code.trim() || `PRD-${Math.floor(1000 + Math.random() * 9000)}`,
      category: productForm.category,
      productType: productForm.productType,
      status: productForm.status,
      availability: productForm.availability,
      priceNpr: Number(productForm.priceNpr) || 0,
      stockCount: Number(productForm.stockCount) || 0,
      imageUrl: productForm.imageUrl.trim() || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=200&auto=format&fit=crop&q=80',
      descriptionTitle: productForm.descriptionTitle.trim(),
      description: productForm.description.trim(),
      requireUid: productForm.productType === 'voucher' ? false : productForm.requireUid,
      requireZoneId: productForm.productType === 'voucher' ? false : productForm.requireZoneId,
      requireEmail: productForm.requireEmail,
      requirePassword: productForm.requirePassword,
      requireWhatsapp: productForm.requireWhatsapp,
      userField1: productForm.userField1.trim(),
      userField2: productForm.userField2.trim(),
      customFields: productForm.customFields.filter((f) => f.label.trim()),
      packages: preservedPackages,
      createdAt: prodCreatedAt,
      updatedAt: new Date().toISOString(),
    };

    const saved = await saveProductToFirestore(prodToSave);
    if (!saved) {
      alert('Product could not be saved to Supabase. Please check your admin permissions/RLS policies and try again.');
      return;
    }

    if (editingProduct) {
      setProductsList((prev) => sortChronologicalAsc(prev.map((p) => p.id === prodId ? prodToSave : p)));
    } else {
      setProductsList((prev) => sortChronologicalAsc([...prev, prodToSave]));
    }

    setIsAddProductModalOpen(false);
    setEditingProduct(null);
  };

  const filteredProducts = productsList.filter((p) => {
    const matchesSearch =
      !productSearch.trim() ||
      p.name.toLowerCase().includes(productSearch.toLowerCase().trim()) ||
      (p.code && p.code.toLowerCase().includes(productSearch.toLowerCase().trim())) ||
      p.id.toLowerCase().includes(productSearch.toLowerCase().trim());

    const matchesCategory =
      productCategoryFilter === 'ALL' ||
      p.category.toLowerCase() === productCategoryFilter.toLowerCase();

    const matchesStatus =
      productStatusFilter === 'ALL' ||
      p.status.toLowerCase() === productStatusFilter.toLowerCase();

    const matchesAvailability =
      productAvailabilityFilter === 'ALL' ||
      p.availability.toLowerCase() === productAvailabilityFilter.toLowerCase();

    return matchesSearch && matchesCategory && matchesStatus && matchesAvailability;
  });
  const [copyToast, setCopyToast] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const handleCopyUid = (uid: string) => {
    if (!uid) return;
    navigator.clipboard.writeText(uid);
    setCopyToast('UID copied');
    setTimeout(() => {
      setCopyToast(null);
    }, 2500);
  };

  // Category Management State
  const [newCategoryName, setNewCategoryName] = useState<string>('');
  const [editingCategory, setEditingCategory] = useState<GameCategory | null>(null);

  const currentCategories = categories && categories.length > 0 ? categories : INITIAL_CATEGORIES;

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    const newCat: GameCategory = {
      id: `cat_${Date.now()}`,
      name: newCategoryName.trim(),
      enabled: true,
      order: currentCategories.length,
    };

    const updated = [...currentCategories, newCat];
    if (onUpdateCategories) onUpdateCategories(updated);
    saveCategoryToFirestore(newCat);
    setNewCategoryName('');
  };

  const handleToggleCategory = (catId: string) => {
    const updated = currentCategories.map((c) => {
      if (c.id === catId) {
        const changed = { ...c, enabled: !c.enabled };
        saveCategoryToFirestore(changed);
        return changed;
      }
      return c;
    });
    if (onUpdateCategories) onUpdateCategories(updated);
  };

  const handleMoveCategory = (catId: string, direction: 'up' | 'down') => {
    const list = [...currentCategories];
    const idx = list.findIndex((c) => c.id === catId);
    if (idx === -1) return;

    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= list.length) return;

    const temp = list[idx];
    list[idx] = list[targetIdx];
    list[targetIdx] = temp;

    const reordered = list.map((c, i) => ({ ...c, order: i }));
    if (onUpdateCategories) onUpdateCategories(reordered);
    reordered.forEach((c) => saveCategoryToFirestore(c));
  };

  const handleDeleteCategory = (catId: string) => {
    const target = currentCategories.find((c) => c.id === catId);
    if (!target) return;
    if (target.id === 'cat-all' || target.name.toLowerCase() === 'all games') {
      alert('Default "All Games" category cannot be deleted.');
      return;
    }
    if (!confirm(`Are you sure you want to delete category "${target.name}"?`)) return;

    const updated = currentCategories.filter((c) => c.id !== catId);
    if (onUpdateCategories) onUpdateCategories(updated);
    deleteCategoryFromFirestore(catId);
  };

  const handleSaveCategoryEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory || !editingCategory.name.trim()) return;

    const updated = currentCategories.map((c) => (c.id === editingCategory.id ? editingCategory : c));
    if (onUpdateCategories) onUpdateCategories(updated);
    saveCategoryToFirestore(editingCategory);
    setEditingCategory(null);
  };

  // Registered Users Management State
  const [usersList, setUsersList] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('ug_admin_registered_users');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'usr_101',
        username: 'RISHU GUPTA',
        email: 'rishugupta12444@gmail.com',
        gameUid: '284910482',
        walletBalanceNpr: 1500,
        level: 'VIP Diamond Member',
        totalTopupsNpr: 4500,
        completedOrdersCount: 8,
        registrationDate: '2026-05-12',
      },
      {
        id: 'usr_102',
        username: 'AANAND SHARMA',
        email: 'aanand.sharma@gmail.com',
        gameUid: '592019481',
        walletBalanceNpr: 420,
        level: 'Gold Member',
        totalTopupsNpr: 1800,
        completedOrdersCount: 3,
        registrationDate: '2026-06-01',
      },
      {
        id: 'usr_103',
        username: 'BIKASH SHRESTHA',
        email: 'bikash.mlbb@yahoo.com',
        gameUid: '819204918',
        walletBalanceNpr: 90,
        level: 'Silver Member',
        totalTopupsNpr: 600,
        completedOrdersCount: 2,
        registrationDate: '2026-06-18',
      },
    ];
  });

  // Edit User Modal State
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);

  // Deposit Transactions State
  const [depositTransactions, setDepositTransactions] = useState<WalletTransaction[]>(() => {
    const saved = localStorage.getItem('ug_admin_transactions');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'TXN-9081',
        date: '2026-07-25 10:15 AM',
        amount: 500,
        type: 'RECHARGE',
        paymentMethod: 'eSewa QR Nepal',
        status: 'SUCCESS',
      },
      {
        id: 'TXN-9082',
        date: '2026-07-24 04:30 PM',
        amount: 1000,
        type: 'RECHARGE',
        paymentMethod: 'Khalti Digital Wallet',
        status: 'SUCCESS',
      },
      {
        id: 'TXN-9083',
        date: '2026-07-23 01:20 PM',
        amount: 250,
        type: 'RECHARGE',
        paymentMethod: 'IME Pay Gateway',
        status: 'SUCCESS',
      },
    ];
  });

  // Manual Deposit Form State
  const [manualUserEmail, setManualUserEmail] = useState<string>('rishugupta12444@gmail.com');
  const [manualCreditAmount, setManualCreditAmount] = useState<number>(500);
  const [manualCreditMsg, setManualCreditMsg] = useState<string>('');

  // Wallet Top-up requests & real-time subscriptions
  const [pendingWalletRequests, setPendingWalletRequests] = useState<WalletRequestRecord[]>([]);
  const [allWalletRequests, setAllWalletRequests] = useState<WalletRequestRecord[]>([]);

  // Modals state for Wallet Management
  const [screenshotModalUrl, setScreenshotModalUrl] = useState<string | null>(null);
  // Manual Payment QR Settings
  const [manualPaySettings, setManualPaySettings] = useState<ManualPaymentSettings>(DEFAULT_MANUAL_PAYMENT_SETTINGS);
  const [manualPayQrFile, setManualPayQrFile] = useState<File | null>(null);
  const [manualPayQrPreview, setManualPayQrPreview] = useState<string | null>(null);
  const [manualPaySaving, setManualPaySaving] = useState(false);
  const [manualPayMsg, setManualPayMsg] = useState<string>('');
  const [rejectModalState, setRejectModalState] = useState<{ id: string; username: string } | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState<string>('');

  // Pending Requests Table & Filter State
  const [requestSearchQuery, setRequestSearchQuery] = useState<string>('');
  const [requestStatusFilter, setRequestStatusFilter] = useState<'ALL' | 'Pending' | 'Approved' | 'Rejected'>('ALL');
  const [requestDateFilter, setRequestDateFilter] = useState<'ALL' | 'Today' | 'Week' | 'Month'>('ALL');
  const [selectedRequestIds, setSelectedRequestIds] = useState<string[]>([]);
  const [isDeleteAllModalOpen, setIsDeleteAllModalOpen] = useState<boolean>(false);
  const [deleteConfirmInput, setDeleteConfirmInput] = useState<string>('');
  const [expandedRemarksIds, setExpandedRemarksIds] = useState<Record<string, boolean>>({});
  const [previewReceiptModal, setPreviewReceiptModal] = useState<WalletRequestRecord | null>(null);
  const [previewZoom, setPreviewZoom] = useState<number>(100);
  const [previewRotation, setPreviewRotation] = useState<number>(0);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setPreviewReceiptModal(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Modals state for Packages Management
  const [isAddPackageModalOpen, setIsAddPackageModalOpen] = useState<boolean>(false);
  const [previewPackage, setPreviewPackage] = useState<GamePackage | null>(null);

  // ===== NEW USER SECTION STATE =====
  const [userSearch, setUserSearch] = useState<string>('');
  const [userStatusFilter, setUserStatusFilter] = useState<'ALL' | 'Active' | 'Disabled'>('ALL');
  const [userDateFilter, setUserDateFilter] = useState<string>('');
  const [userPage, setUserPage] = useState<number>(1);
  const USERS_PER_PAGE = 10;
  const [openUserMenuId, setOpenUserMenuId] = useState<string | null>(null);

  // Unified Edit User Popup & Confirmation Modal State
  const [editUserModal, setEditUserModal] = useState<{
    user: UserProfile;
    newUsername: string;
    newWalletBalance: number;
  } | null>(null);
  const [editUserConfirmModal, setEditUserConfirmModal] = useState<{
    user: UserProfile;
    newUsername: string;
    newWalletBalance: number;
  } | null>(null);
  const [editUserSaving, setEditUserSaving] = useState<boolean>(false);

  // Edit Username popup
  const [editUsernameModal, setEditUsernameModal] = useState<{ userId: string; current: string } | null>(null);
  const [editUsernameValue, setEditUsernameValue] = useState<string>('');
  const [editUsernameLoading, setEditUsernameLoading] = useState<boolean>(false);
  // Edit Wallet popup
  const [editWalletModal, setEditWalletModal] = useState<{ userId: string; username: string; current: number } | null>(null);
  const [walletEditMode, setWalletEditMode] = useState<'increase' | 'decrease' | 'set'>('increase');
  const [walletEditAmount, setWalletEditAmount] = useState<number>(0);
  const [walletEditNote, setWalletEditNote] = useState<string>('');
  const [walletEditLoading, setWalletEditLoading] = useState<boolean>(false);
  // View Orders / Transactions popup for user
  const [viewUserOrdersModal, setViewUserOrdersModal] = useState<{ userId: string; username: string; email: string } | null>(null);
  const [viewUserTxnsModal, setViewUserTxnsModal] = useState<{ userId: string; username: string } | null>(null);

  // ===== NEW ORDERS SECTION STATE =====
  const [realtimeOrders, setRealtimeOrders] = useState<Order[]>([]);
  const [ordersRealtimeReady, setOrdersRealtimeReady] = useState<boolean>(false);
  const [apiPaymentSearch, setApiPaymentSearch] = useState<string>('');
  const [apiPaymentActionId, setApiPaymentActionId] = useState<string | null>(null);
  const [apiPaymentMessage, setApiPaymentMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  // Successful Fonepay Hub wallet deposits + the balance recorded immediately after each deposit.
  const [instantWalletTransactions, setInstantWalletTransactions] = useState<any[]>([]);
  const [rejectOrderModal, setRejectOrderModal] = useState<Order | null>(null);
  const [rejectOrderReason, setRejectOrderReason] = useState<string>('');
  const [orderDetailModal, setOrderDetailModal] = useState<Order | null>(null);
  const [orderApproveLoading, setOrderApproveLoading] = useState<string | null>(null);
  const [orderActionSuccessMsg, setOrderActionSuccessMsg] = useState<string | null>(null);
  const [orderEmailRecord, setOrderEmailRecord] = useState<TransactionalEmailDeliveryRecord | null>(null);
  const [loadingEmailStatus, setLoadingEmailStatus] = useState<boolean>(false);
  const [manualEmailSending, setManualEmailSending] = useState<boolean>(false);
  const [manualEmailMsg, setManualEmailMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!orderDetailModal?.orderId) {
      setOrderEmailRecord(null);
      setManualEmailMsg(null);
      return;
    }
    let active = true;
    setLoadingEmailStatus(true);
    getOrderEmailDeliveryStatus(orderDetailModal.orderId).then((rec) => {
      if (active) {
        setOrderEmailRecord(rec);
        setLoadingEmailStatus(false);
      }
    }).catch(() => {
      if (active) setLoadingEmailStatus(false);
    });
    return () => { active = false; };
  }, [orderDetailModal?.orderId]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const unsubPending = subscribePendingWalletRequests(setPendingWalletRequests);
    const unsubAll = subscribeAllWalletRequests(setAllWalletRequests);
    const unsubUsers = subscribeUsersList((uList) => {
      if (uList && uList.length > 0) {
        setUsersList(uList);
      }
    });
    // Realtime orders subscription
    const unsubOrders = subscribeOrders((orderList) => {
      setRealtimeOrders(orderList);
      setOrdersRealtimeReady(true);
      // Also sync with parent orders prop
      onUpdateOrders(orderList);
    });
    return () => {
      unsubPending();
      unsubAll();
      unsubUsers();
      unsubOrders();
    };
  }, [isAuthenticated]);

  // Fonepay Hub instant-payment ledger. This is intentionally read from Supabase
  // transactions so the Credits column can show the balance AFTER that exact
  // recharge, not a later/current balance.
  useEffect(() => {
    if (!isAuthenticated) return;

    let active = true;

    const fetchInstantWalletTransactions = async () => {
      try {
        const { data, error } = await supabase
          .from('transactions')
          .select('*')
          .order('createdAt', { ascending: false })
          .limit(500);

        if (!error && active) {
          setInstantWalletTransactions(data || []);
        }
      } catch (err) {
        console.warn('[ADMIN] Instant wallet transaction read failed:', err);
      }
    };

    fetchInstantWalletTransactions();

    const channel = supabase
      .channel(`admin:instant-wallet-transactions:${Date.now()}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'transactions' },
        () => fetchInstantWalletTransactions()
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [isAuthenticated]);

  const [reviewsList, setReviewsList] = useState<Review[]>([]);
  const [reviewStatusFilter, setReviewStatusFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('PENDING');

  useEffect(() => {
    const unsub = subscribeManualPaymentSettings(setManualPaySettings);
    const unsubRev = subscribeReviews(setReviewsList);
    return () => {
      unsub();
      unsubRev();
    };
  }, []);

  const handleApproveReview = async (id: string) => {
    await updateReviewStatus(id, 'APPROVED');
  };

  const handleRejectReview = async (id: string) => {
    await updateReviewStatus(id, 'REJECTED');
  };

  const handleDeleteReview = async (id: string) => {
    if (confirm('Are you sure you want to delete this review?')) {
      await deleteReviewRecord(id);
    }
  };

    const handleManualPayQrChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setManualPayQrFile(file);
    setManualPayQrPreview(URL.createObjectURL(file));
  };

  const handleSaveManualPaySettings = async () => {
    setManualPaySaving(true);
    setManualPayMsg('');
    try {
      let qrImageUrl = manualPaySettings.qrImageUrl;
      if (manualPayQrFile) {
        qrImageUrl = await uploadManualPaymentQR(manualPayQrFile);
      }
      await saveManualPaymentSettings({ ...manualPaySettings, qrImageUrl });
      setManualPaySettings(prev => ({ ...prev, qrImageUrl }));
      setManualPayQrFile(null);
      setManualPayQrPreview(null);
      setManualPayMsg('Saved successfully!');
    } catch (err: any) {
      console.error('[ADMIN] Manual payment settings save failed:', err);
      setManualPayMsg(err?.message ? `Failed to save: ${err.message}` : 'Failed to save. Try again.');
    } finally {
      setManualPaySaving(false);
      setTimeout(() => setManualPayMsg(''), 4000);
    }
  };

    const handleApproveWalletRequest = async (request: WalletRequestRecord) => {
    if (!confirm(`Credit NPR ${request.amountNpr} to ${request.username}?`)) return;
    try {
      const ok = await approveWalletRequest(request);
      // Immediately update local state for real-time reactivity
      setAllWalletRequests((prev) =>
        prev.map((r) => (r.id === request.id ? { ...r, status: 'APPROVED' } : r))
      );
      setUsersList((prevUsers) =>
        prevUsers.map((u) => {
          if (
            u.id === request.uid ||
            (u.email && request.email && u.email.toLowerCase().trim() === request.email.toLowerCase().trim())
          ) {
            return {
              ...u,
              walletBalanceNpr: (u.walletBalanceNpr || 0) + request.amountNpr,
              totalTopupsNpr: (u.totalTopupsNpr || 0) + request.amountNpr,
            };
          }
          return u;
        })
      );
      if (previewReceiptModal && previewReceiptModal.id === request.id) {
        setPreviewReceiptModal((prev) => (prev ? { ...prev, status: 'APPROVED' } : null));
      }
      alert(`Successfully approved and credited NPR ${request.amountNpr} to ${request.username}!`);
    } catch (err) {
      console.error('[APPROVE WALLET REQUEST ERROR]', err);
      alert('Failed to approve this request. Check the console for details.');
    }
  };

  const handleOpenRejectModal = (request: WalletRequestRecord) => {
    setRejectModalState({ id: request.id, username: request.username });
    setRejectReasonInput('Invalid transaction ID or unverified payment proof');
  };

  const handleConfirmRejectRequest = async () => {
    if (!rejectModalState) return;
    try {
      const ok = await rejectWalletRequest(rejectModalState.id, rejectReasonInput || 'Payment proof rejected by administrator');
      setAllWalletRequests((prev) =>
        prev.map((r) =>
          r.id === rejectModalState.id
            ? { ...r, status: 'REJECTED', rejectionReason: rejectReasonInput }
            : r
        )
      );
      if (previewReceiptModal && previewReceiptModal.id === rejectModalState.id) {
        setPreviewReceiptModal((prev) => (prev ? { ...prev, status: 'REJECTED', rejectionReason: rejectReasonInput } : null));
      }
      setRejectModalState(null);
      setRejectReasonInput('');
      alert('Request rejected successfully.');
    } catch (err) {
      console.error('[REJECT WALLET REQUEST ERROR]', err);
      alert('Failed to reject this request.');
    }
  };

  const filteredWalletRequests = React.useMemo(() => {
    return allWalletRequests.filter((req) => {
      const query = requestSearchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        req.username.toLowerCase().includes(query) ||
        (req.email && req.email.toLowerCase().includes(query)) ||
        (req.uid && req.uid.toLowerCase().includes(query)) ||
        (req.remarks && req.remarks.toLowerCase().includes(query)) ||
        (req.paymentMethod && req.paymentMethod.toLowerCase().includes(query));

      let matchesStatus = true;
      if (requestStatusFilter === 'Pending') {
        matchesStatus = req.status === 'PENDING' || req.status === 'Pending';
      } else if (requestStatusFilter === 'Approved') {
        matchesStatus = req.status === 'APPROVED' || req.status === 'Approved';
      } else if (requestStatusFilter === 'Rejected') {
        matchesStatus = req.status === 'REJECTED' || req.status === 'Rejected';
      }

      let matchesDate = true;
      if (requestDateFilter !== 'ALL' && req.createdAt) {
        const reqDate = new Date(req.createdAt as string);
        const now = new Date();
        if (requestDateFilter === 'Today') {
          matchesDate = reqDate.toDateString() === now.toDateString();
        } else if (requestDateFilter === 'Week') {
          const sevenDaysAgo = new Date();
          sevenDaysAgo.setDate(now.getDate() - 7);
          matchesDate = reqDate >= sevenDaysAgo;
        } else if (requestDateFilter === 'Month') {
          const thirtyDaysAgo = new Date();
          thirtyDaysAgo.setDate(now.getDate() - 30);
          matchesDate = reqDate >= thirtyDaysAgo;
        }
      }

      return matchesSearch && matchesStatus && matchesDate;
    });
  }, [allWalletRequests, requestSearchQuery, requestStatusFilter, requestDateFilter]);

  const handleToggleSelectAllRequests = () => {
    if (selectedRequestIds.length === filteredWalletRequests.length && filteredWalletRequests.length > 0) {
      setSelectedRequestIds([]);
    } else {
      setSelectedRequestIds(filteredWalletRequests.map((r) => r.id));
    }
  };

  const handleToggleSelectRequestRow = (id: string) => {
    setSelectedRequestIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleSingleDeleteRequest = async (requestId: string) => {
    if (!confirm('Are you sure you want to delete this credit request permanently?')) return;
    try {
      await deleteWalletRequest(requestId);
      setAllWalletRequests((prev) => prev.filter((r) => r.id !== requestId));
      setPendingWalletRequests((prev) => prev.filter((r) => r.id !== requestId));
      setSelectedRequestIds((prev) => prev.filter((id) => id !== requestId));
    } catch (err) {
      console.error('[SINGLE DELETE REQUEST ERROR]', err);
      alert('Failed to delete request from Supabase.');
    }
  };

  const handleConfirmBatchOrWipeDelete = async () => {
    if (deleteConfirmInput.trim().toLowerCase() !== 'ghop ghop') {
      alert('Secret code incorrect. Please type "ghop ghop" to confirm deletion.');
      return;
    }

    try {
      if (selectedRequestIds.length > 0 && selectedRequestIds.length < allWalletRequests.length) {
        await deleteSelectedWalletRequests(selectedRequestIds);
        setAllWalletRequests((prev) => prev.filter((r) => !selectedRequestIds.includes(r.id)));
        setPendingWalletRequests((prev) => prev.filter((r) => !selectedRequestIds.includes(r.id)));
      } else {
        await wipeAllWalletRequests();
        setAllWalletRequests([]);
        setPendingWalletRequests([]);
      }
      setSelectedRequestIds([]);
      setIsDeleteAllModalOpen(false);
      setDeleteConfirmInput('');
      alert('Credit requests deleted successfully from Supabase!');
    } catch (err) {
      console.error('[DELETE WALLET REQUESTS ERROR]', err);
      alert('Failed to delete requests from Supabase.');
    }
  };

  const handleManualWalletCredit = async (e: React.FormEvent) => {
    e.preventDefault();
    setManualCreditMsg('');
    const targetUser = usersList.find((u) => u.email.toLowerCase().trim() === manualUserEmail.toLowerCase().trim());
    if (!targetUser) {
      setManualCreditMsg('User email not found in registered accounts list.');
      return;
    }

    const updatedUsers = usersList.map((u) => {
      if (u.id === targetUser.id) {
        return {
          ...u,
          walletBalanceNpr: (u.walletBalanceNpr || 0) + manualCreditAmount,
          totalTopupsNpr: (u.totalTopupsNpr || 0) + manualCreditAmount,
        };
      }
      return u;
    });

    setUsersList(updatedUsers);
    const updatedTarget = updatedUsers.find((u) => u.id === targetUser.id);
    if (updatedTarget) saveUserToFirestore(updatedTarget);

    // Add transaction log
    const newTxn: WalletTransaction = {
      id: `TXN-${Date.now().toString().slice(-4)}`,
      date: new Date().toLocaleString(),
      amount: manualCreditAmount,
      type: 'RECHARGE',
      paymentMethod: 'Admin Manual Credit',
      status: 'SUCCESS',
    };
    setDepositTransactions((prev) => [newTxn, ...prev]);

    setManualCreditMsg(`Successfully credited NPR ${manualCreditAmount} to ${targetUser.username}!`);
    setTimeout(() => setManualCreditMsg(''), 4000);
  };

  // Combined list of games and products so every product is selectable in Product Package
  const availableProducts: Game[] = React.useMemo(() => {
    const combinedMap = new Map<string, Game>();

    (games || []).forEach((g) => {
      combinedMap.set(g.id, g);
    });

    (productsList || []).forEach((p) => {
      if (!combinedMap.has(p.id)) {
        combinedMap.set(p.id, {
          id: p.id,
          name: p.name,
          category: p.category || 'Games',
          iconUrl: p.imageUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=200&auto=format&fit=crop&q=80',
          bannerUrl: p.imageUrl || '',
          requireUid: typeof p.requireUid === 'boolean' ? p.requireUid : false,
          requiresZoneId: !!(p.requireZoneId || (p as any).require_zone_id || (p as any).requiresZoneId),
          requireZoneId: !!(p.requireZoneId || (p as any).require_zone_id || (p as any).requiresZoneId),
          requireEmail: !!(p.requireEmail || (p as any).require_email),
          requirePassword: !!(p.requirePassword || (p as any).require_password),
          requireWhatsapp: !!(p.requireWhatsapp || (p as any).require_whatsapp),
          userField1: p.userField1 || (p as any).user_field1 || '',
          userField2: p.userField2 || (p as any).user_field2 || '',
          uidPlaceholder: 'Enter Player UID',
          description: p.description || '',
          packages: p.packages || [],
        });
      }
    });

    return Array.from(combinedMap.values());
  }, [games, productsList]);

  // Selected Game/Product for Packages/Editing
  const [selectedGameId, setSelectedGameId] = useState<string>(availableProducts[0]?.id || 'freefire');
  const selectedGame = availableProducts.find((g) => g.id === selectedGameId) || availableProducts[0];

  // Game Product Pricing / Product Package UI State
  const [isProductDropdownOpen, setIsProductDropdownOpen] = useState<boolean>(false);
  const [productDropdownSearch, setProductDropdownSearch] = useState<string>('');
  const [packageSearchQuery, setPackageSearchQuery] = useState<string>('');
  const [packageSortBy, setPackageSortBy] = useState<string>('Newest');
  const [isRefreshingPricing, setIsRefreshingPricing] = useState<boolean>(false);
  const [pricingSaveToast, setPricingSaveToast] = useState<string | null>(null);

  const handleTogglePackageActive = async (packageId: string) => {
    if (!selectedGame) return;
    const updatedPackages = (selectedGame.packages || []).map((pkg) => {
      if (pkg.id === packageId) {
        return { ...pkg, active: pkg.active === false ? true : false };
      }
      return pkg;
    });

    const updatedGame = { ...selectedGame, packages: updatedPackages };
    const saved = await saveGameToFirestore(updatedGame);
    if (!saved) { alert('Package status could not be saved to Supabase.'); return; }

    const updatedGamesList = games.some((g) => g.id === updatedGame.id)
      ? games.map((g) => (g.id === updatedGame.id ? updatedGame : g))
      : [updatedGame, ...games];
    onUpdateGames(updatedGamesList);
    setProductsList((prev) => prev.map((p) => (p.id === updatedGame.id ? { ...p, packages: updatedPackages } : p)));
  };

  const handleDeletePackage = async (gameId: string, packageId: string, packageName: string) => {
    if (!confirm(`Are you sure you want to delete package "${packageName}"?`)) return;
    const target = availableProducts.find((g) => g.id === gameId);
    if (!target) return;

    const updatedPackages = (target.packages || []).filter((p) => p.id !== packageId);
    const updatedGame = { ...target, packages: updatedPackages };

    const saved = await saveGameToFirestore(updatedGame);
    if (!saved) { alert('Package could not be deleted from Supabase.'); return; }

    const updatedGames = games.map((g) => (g.id === gameId ? updatedGame : g));
    onUpdateGames(updatedGames);
    setProductsList((prev) => prev.map((p) => (p.id === gameId ? { ...p, packages: updatedPackages } : p)));
  };

  const handleDuplicatePackage = async (gameId: string, pkg: GamePackage) => {
    const target = availableProducts.find((g) => g.id === gameId);
    if (!target) return;

    const duplicatedPkg: GamePackage = {
      ...pkg,
      id: `pkg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: `${pkg.name} (Copy)`,
    };

    const updatedPackages = [...(target.packages || []), duplicatedPkg];
    const updatedGame = { ...target, packages: updatedPackages };

    const saved = await saveGameToFirestore(updatedGame);
    if (!saved) { alert('Package could not be duplicated in Supabase.'); return; }

    const updatedGames = games.map((g) => (g.id === gameId ? updatedGame : g));
    onUpdateGames(updatedGames);
    setProductsList((prev) => prev.map((p) => (p.id === gameId ? { ...p, packages: updatedPackages } : p)));
    setPricingSaveToast(`Duplicated package "${pkg.name}"`);
    setTimeout(() => setPricingSaveToast(null), 2500);
  };

  const handleSaveAllPricingChanges = async () => {
    if (selectedGame) {
      const saved = await saveGameToFirestore(selectedGame);
      if (!saved) { alert('Pricing changes could not be saved to Supabase.'); return; }
    }
    setPricingSaveToast('All pricing changes saved successfully!');
    setTimeout(() => setPricingSaveToast(null), 3000);
  };

  const handleRefreshPricing = () => {
    setIsRefreshingPricing(true);
    setTimeout(() => {
      setIsRefreshingPricing(false);
    }, 600);
  };

  // Edit Game State
  const [editingGame, setEditingGame] = useState<Game | null>(null);

  // Edit Package State
  const [editingPackage, setEditingPackage] = useState<{ gameId: string; pkg: GamePackage } | null>(null);

  // New Banner State
  const [newBanner, setNewBanner] = useState<{
    imageUrl: string;
    title: string;
    subtitle: string;
    badge: string;
    actionText: string;
    gameId: string;
  }>({
    imageUrl: '',
    title: '',
    subtitle: '',
    badge: 'OFFICIAL OFFER',
    actionText: 'TOP UP NOW',
    gameId: games[0]?.id || 'freefire',
  });

  const [editingBanner, setEditingBanner] = useState<BannerItem | null>(null);
  const [bannerDragId, setBannerDragId] = useState<string | null>(null);

  // New Game State
  const [newGame, setNewGame] = useState<{
    id: string;
    name: string;
    category: string;
    iconUrl: string;
    bannerUrl: string;
    uidPlaceholder: string;
    requireUid: boolean;
    requiresZoneId: boolean;
    requireEmail: boolean;
    requirePassword: boolean;
    requireWhatsapp: boolean;
    userField1: string;
    userField2: string;
    description: string;
  }>({
    id: '',
    name: '',
    category: 'Battle Royale',
    iconUrl: '',
    bannerUrl: '',
    uidPlaceholder: 'Enter Player UID',
    requireUid: true,
    requiresZoneId: false,
    requireEmail: false,
    requirePassword: false,
    requireWhatsapp: false,
    userField1: '',
    userField2: '',
    description: 'Instant direct in-game top up delivery.',
  });

  // New Package State
  const [newPackage, setNewPackage] = useState<{
    name: string;
    diamonds: number;
    priceNpr: number;
    bonus: number;
    badge: string;
    iconType: 'diamond' | 'membership' | 'pass' | 'coin';
    requiresRedeemCode?: boolean;
    product_id?: number;
    variation_id?: number;
  }>({
    name: '',
    diamonds: 100,
    priceNpr: 95,
    bonus: 0,
    badge: 'POPULAR',
    iconType: 'diamond',
    requiresRedeemCode: false,
    product_id: undefined,
    variation_id: undefined,
  });

  // Admin Password Change Form
  const [pwdCurrent, setPwdCurrent] = useState<string>('');
  const [pwdNew, setPwdNew] = useState<string>('');
  const [pwdConfirm, setPwdConfirm] = useState<string>('');
  const [pwdMsg, setPwdMsg] = useState<string>('');

  // Broadcast Message Form
  const [broadcastTitle, setBroadcastTitle] = useState<string>('📢 Official Offer Alert');
  const [broadcastMessage, setBroadcastMessage] = useState<string>('Get instant extra diamonds on Free Fire and PUBG Mobile today!');
  const [broadcastStatus, setBroadcastStatus] = useState<string>('');
  const [broadcastSending, setBroadcastSending] = useState<boolean>(false);

  // Persist Users
  useEffect(() => {
    localStorage.setItem('ug_admin_registered_users', safeJsonStringify(usersList));
  }, [usersList]);

  // Persist Transactions
  useEffect(() => {
    localStorage.setItem('ug_admin_transactions', safeJsonStringify(depositTransactions));
  }, [depositTransactions]);

  // Handle Supabase Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const normEmail = loginEmail.trim().toLowerCase();
    if (!normEmail || !loginPassword) {
      setLoginError('Please enter both email and password.');
      return;
    }

    setIsAuthSubmitting(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normEmail,
        password: loginPassword,
      });

      if (error) {
        setIsAuthenticated(false);
        setAdminUser(null);
        setLoginError(error.message || 'Invalid email or password.');
      } else if (data.user) {
        const isAdmin = await checkAdminStatusInFirestore(data.user.id);
        if (isAdmin) {
          setIsAuthenticated(true);
          setAdminUser(data.user);
          setLoginError('');
        } else {
          await supabase.auth.signOut();
          setIsAuthenticated(false);
          setAdminUser(null);
          setLoginError('Access denied: this account is not an authorized admin.');
        }
      }
    } catch (err: any) {
      setIsAuthenticated(false);
      setAdminUser(null);
      setLoginError(err.message || 'Sign-in failed. Please try again.');
    } finally {
      setIsAuthSubmitting(false);
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error('Logout error:', err);
    }
    setIsAuthenticated(false);
    setAdminUser(null);
  };

  const toggleMenu = (menuKey: string) => {
    setExpandedMenus((prev) => ({ ...prev, [menuKey]: !prev[menuKey] }));
  };

  const handleRefreshData = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  const toggleTheme = (mode: 'dark' | 'light') => {
    setAdminTheme(mode);
    localStorage.setItem('ug_admin_theme', mode);
  };

  // --- GAME / ITEM CRUD ---
  const handleAddGame = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGame.name.trim() || !newGame.iconUrl.trim()) return;

    const gameId = newGame.id.trim() || newGame.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const createdGame: Game = {
      id: gameId,
      name: newGame.name.trim(),
      category: newGame.category.trim() || 'Popular',
      iconUrl: newGame.iconUrl.trim(),
      bannerUrl: newGame.bannerUrl.trim() || newGame.iconUrl.trim(),
      uidPlaceholder: newGame.uidPlaceholder.trim() || 'Enter Player UID',
      requireUid: newGame.requireUid,
      requiresZoneId: newGame.requiresZoneId,
      requireZoneId: newGame.requiresZoneId,
      requireEmail: newGame.requireEmail,
      requirePassword: newGame.requirePassword,
      requireWhatsapp: newGame.requireWhatsapp,
      userField1: newGame.userField1.trim() || undefined,
      userField2: newGame.userField2.trim() || undefined,
      description: newGame.description.trim(),
      packages: [
        { id: `${gameId}_starter`, name: 'Starter Pack', diamonds: 100, priceNpr: 95, badge: 'POPULAR' },
        { id: `${gameId}_pro`, name: 'Pro Pack', diamonds: 500, priceNpr: 450, badge: 'BEST VALUE' },
      ],
    };

    const saved = await saveGameToFirestore(createdGame);
    if (!saved) {
      alert('Game could not be saved to Supabase. Please run the included RLS fix SQL and try again.');
      return;
    }
    const updatedGames = [...games, createdGame];
    onUpdateGames(updatedGames);

    setNewGame({
      id: '',
      name: '',
      category: 'Battle Royale',
      iconUrl: '',
      bannerUrl: '',
      uidPlaceholder: 'Enter Player UID',
      requireUid: true,
      requiresZoneId: false,
      requireEmail: false,
      requirePassword: false,
      requireWhatsapp: false,
      userField1: '',
      userField2: '',
      description: 'Instant direct in-game top up delivery.',
    });
    setSelectedGameId(gameId);
  };

  const handleSaveGameEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGame) return;

    const saved = await saveGameToFirestore(editingGame);
    if (!saved) { alert('Game could not be saved to Supabase.'); return; }
    const updated = games.map((g) => (g.id === editingGame.id ? editingGame : g));
    onUpdateGames(updated);
    setEditingGame(null);
  };

  const handleDeleteGame = async (gameId: string) => {
    if (!confirm('Are you sure you want to delete this game/item and all its packages?')) return;
    const deleted = await deleteGameFromFirestore(gameId);
    if (!deleted) { alert('Game could not be deleted from Supabase.'); return; }
    const updated = games.filter((g) => g.id !== gameId);
    onUpdateGames(updated);
    if (selectedGameId === gameId) {
      setSelectedGameId(updated[0]?.id || '');
    }
  };

  const handleWipeAllGames = async () => {
    if (!confirm('DANGER: Are you sure you want to delete ALL games and packages from Firestore? User accounts, balances, and orders will remain untouched.')) return;
    onUpdateGames([]);
    await wipeAllGamesFromFirestore();
    setSelectedGameId('');
    alert('All game and package records have been safely wiped from Firestore.');
  };

  // --- PACKAGE CRUD ---
  const handleAddPackage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPackage.name.trim() || newPackage.priceNpr <= 0) return;
    if (!selectedGame) { alert('Please select a product first.'); return; }

    const isVoucher = selectedGame.productType === 'voucher' || selectedGame.category === 'Voucher' || /voucher|redeem/i.test(selectedGame.name || '');

    const pkgId = `pkg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const createdPkg: GamePackage = {
      id: pkgId,
      name: newPackage.name.trim(),
      diamonds: isVoucher ? (newPackage.diamonds || 0) : newPackage.diamonds,
      priceNpr: newPackage.priceNpr,
      bonus: newPackage.bonus > 0 ? newPackage.bonus : undefined,
      badge: newPackage.badge.trim() || undefined,
      iconType: isVoucher ? 'pass' : newPackage.iconType,
      requiresRedeemCode: isVoucher ? (newPackage.requiresRedeemCode !== false) : (newPackage.requiresRedeemCode || false),
      product_id: isMlbbBrazilGame(selectedGame) && newPackage.product_id ? Number(newPackage.product_id) : undefined,
    };

    const targetGame: Game = {
      ...selectedGame,
      packages: [...(selectedGame.packages || []), createdPkg],
    };

    const saved = await saveGameToFirestore(targetGame);
    if (!saved) { alert('Package could not be saved to Supabase.'); return; }

    const updatedGames = games.some((g) => g.id === targetGame.id)
      ? games.map((g) => (g.id === targetGame.id ? targetGame : g))
      : [targetGame, ...games];
    onUpdateGames(updatedGames);
    setProductsList((prev) => prev.map((p) => (p.id === targetGame.id ? { ...p, packages: targetGame.packages } : p)));

    setNewPackage({
      name: '',
      diamonds: isVoucher ? 0 : 200,
      priceNpr: 180,
      bonus: 0,
      badge: '',
      iconType: isVoucher ? 'pass' : 'diamond',
      requiresRedeemCode: isVoucher,
      product_id: undefined,
      variation_id: undefined,
    });
    setIsAddPackageModalOpen(false);
    setPricingSaveToast(`Successfully published new package "${createdPkg.name}"`);
    setTimeout(() => setPricingSaveToast(null), 3000);
  };

  const handleSavePackageEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPackage) return;

    const { gameId, pkg } = editingPackage;
    const target = availableProducts.find((g) => g.id === gameId);
    if (!target) return;

    const updatedPackages = (target.packages || []).map((p) => (p.id === pkg.id ? pkg : p));
    const updatedGame = { ...target, packages: updatedPackages };

    const saved = await saveGameToFirestore(updatedGame);
    if (!saved) { alert('Package changes could not be saved to Supabase.'); return; }

    const updatedGames = games.map((g) => (g.id === gameId ? updatedGame : g));
    onUpdateGames(updatedGames);
    setProductsList((prev) => prev.map((p) => (p.id === gameId ? { ...p, packages: updatedPackages } : p)));
    setEditingPackage(null);
  };

  // --- BANNER CRUD ---
  const handleAddBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBanner.imageUrl.trim() || !newBanner.title.trim()) return;

    const bannerId = `banner_${Date.now()}`;
    const createdBanner: BannerItem = {
      id: bannerId,
      imageUrl: newBanner.imageUrl.trim(),
      title: newBanner.title.trim(),
      subtitle: newBanner.subtitle.trim() || 'Official Direct Game Top Up',
      badge: newBanner.badge.trim() || 'PROMO',
      actionText: newBanner.actionText.trim() || 'TOP UP NOW',
      gameId: newBanner.gameId,
      active: true,
    };

    const updatedBanners = [createdBanner, ...banners];
    onUpdateBanners(updatedBanners);
    saveBannerToFirestore(createdBanner);

    setNewBanner({
      imageUrl: '',
      title: '',
      subtitle: '',
      badge: 'OFFICIAL OFFER',
      actionText: 'TOP UP NOW',
      gameId: selectedGameId,
    });
  };

  const handleDeleteBanner = (bannerId: string) => {
    if (!confirm('Remove this promotional banner from the store hero carousel?')) return;
    const updatedBanners = banners.filter((b) => b.id !== bannerId);
    onUpdateBanners(updatedBanners);
    deleteBannerFromFirestore(bannerId);
  };

  const handleToggleBanner = async (banner: BannerItem) => {
    const updated = { ...banner, active: banner.active !== false ? false : true };
    onUpdateBanners(banners.map((b) => b.id === banner.id ? updated : b));
    await saveBannerToFirestore(updated);
  };

  const handleSaveBannerEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner?.imageUrl.trim() || !editingBanner.title.trim()) return;
    const updated = { ...editingBanner, imageUrl: editingBanner.imageUrl.trim(), title: editingBanner.title.trim(), subtitle: editingBanner.subtitle.trim() };
    onUpdateBanners(banners.map((b) => b.id === updated.id ? updated : b));
    await saveBannerToFirestore(updated);
    setEditingBanner(null);
  };

  const handleBannerDrop = (targetId: string) => {
    if (!bannerDragId || bannerDragId === targetId) return;
    const list = [...banners];
    const from = list.findIndex((b) => b.id === bannerDragId);
    const to = list.findIndex((b) => b.id === targetId);
    if (from < 0 || to < 0) return;
    const [moved] = list.splice(from, 1);
    list.splice(to, 0, moved);
    onUpdateBanners(list);
    setBannerDragId(null);
    list.forEach((b) => { void saveBannerToFirestore(b); });
  };

  // --- USER EDIT / DELETE ---
  const handleSaveUserEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    const updated = usersList.map((u) => (u.id === editingUser.id ? editingUser : u));
    setUsersList(updated);

    if (userProfile.id === editingUser.id) {
      onUpdateUserProfile(editingUser);
    }
    saveUserToFirestore(editingUser);
    setEditingUser(null);
  };

  const handleDeleteUser = (userId: string) => {
    if (!confirm('Are you sure you want to delete this registered user?')) return;
    setUsersList(usersList.filter((u) => u.id !== userId));
  };

  // --- CHANGE PASSWORD ---
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwdNew.length < 6) {
      setPwdMsg('New password must be at least 6 characters long.');
      return;
    }
    if (pwdNew !== pwdConfirm) {
      setPwdMsg('New passwords do not match.');
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { error } = await supabase.auth.updateUser({ password: pwdNew });
        if (error) {
          setPwdMsg(error.message || 'Failed to update password.');
        } else {
          setPwdMsg('Admin Password updated successfully!');
          setPwdCurrent('');
          setPwdNew('');
          setPwdConfirm('');
          setTimeout(() => setPwdMsg(''), 3000);
        }
      } else {
        setPwdMsg('No active user session found.');
      }
    } catch (err: any) {
      console.error('Update password error:', err);
      setPwdMsg(err.message || 'Failed to update password.');
    }
  };

  // --- BROADCAST / DIRECT USER NOTIFICATION MANAGER ---
  const handleAdminSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifMessage.trim()) return;
    if (notifTargetType === 'USER' && !notifTargetEmail.trim()) {
      setNotifSendMsg('Please enter a target user email address.');
      return;
    }

    setNotifSending(true);
    setNotifSendMsg('');

    try {
      const targetEmailVal = notifTargetType === 'ALL' ? 'ALL' : notifTargetEmail.trim();

      await sendNotificationToUser({
        targetEmail: targetEmailVal,
        title: notifTitle.trim(),
        message: notifMessage.trim(),
        category: notifCategory,
        expiresIn: notifExpiresIn.trim() || undefined,
        isPinned: notifIsPinned,
      });

      if (onSendNotification) {
        onSendNotification({
          id: `notif_${Date.now()}`,
          title: notifTitle.trim(),
          message: notifMessage.trim(),
          date: 'Just now',
          unread: true,
        });
      }

      setNotifSendMsg(
        notifTargetType === 'ALL'
          ? 'Notification sent to ALL users successfully!'
          : `Notification sent to ${notifTargetEmail.trim()} successfully!`
      );

      setNotifTitle('');
      setNotifMessage('');
      setNotifCode('');
      setNotifExpiresIn('');
      setNotifIsPinned(false);
    } catch (err: any) {
      setNotifSendMsg(err.message || 'Failed to send notification.');
    } finally {
      setNotifSending(false);
      setTimeout(() => setNotifSendMsg(''), 5000);
    }
  };

  const handleSendBroadcastNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim() || broadcastSending) return;

    setBroadcastSending(true);
    const title = broadcastTitle.trim() || '📢 Admin Alert';
    const message = broadcastMessage.trim();

    // This used to only write to localStorage (a second, non-persistent
    // notification system). It now goes through the same authoritative,
    // Supabase-backed path as the advanced notification form below, so the
    // broadcast actually reaches every user's Notification Center.
    const ok = await sendNotificationToUser({
      targetEmail: 'ALL',
      title,
      message,
      category: 'Announcement',
      isPinned: true,
    });

    if (ok && onSendNotification) {
      // Ephemeral local "bell glow" feedback for the admin's own screen.
      onSendNotification({
        id: `notif_${Date.now()}`,
        title,
        message,
        date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        unread: true,
      });
    }

    setBroadcastStatus(ok ? 'Broadcast notification sent to all users!' : 'Failed to send broadcast notification.');
    setBroadcastSending(false);
    setTimeout(() => setBroadcastStatus(''), 4000);
  };

  // Handle Order Status Update (Manual Completion / Cancellation)
  // Writes ONLY to Firestore — realtimeOrders listener updates the UI automatically.
  const handleUpdateOrderStatus = async (orderId: string, newStatus: 'Completed' | 'Cancelled' | 'Pending') => {
    const adminUid = adminUser?.uid || 'Admin';
    await adminUpdateOrderStatus(orderId, newStatus, adminUid);
    // realtimeOrders listener will reflect the change automatically.
    // Refund (if Cancelled) is handled inside adminUpdateOrderStatus.
  };

  // Calculations for Overview Dashboard — always use realtimeOrders from Firestore onSnapshot
  // Fonepay Hub creates a temporary order record before the QR is paid.
  // Do not expose those unpaid checkout records anywhere in the admin order
  // management/dashboard. Once the gateway confirms payment, paymentStatus
  // becomes SUCCESS and the order automatically becomes visible in realtime.
  const isFonepayHubOrder = (order: any) =>
    String(order?.paymentMethod || '').toLowerCase().includes('fonepay');
  const isConfirmedPayment = (order: any) =>
    ['SUCCESS', 'PAID', 'COMPLETED'].includes(String(order?.paymentStatus || '').toUpperCase());
  const isPendingFonepayPayment = (order: any) => {
    if (!isFonepayHubOrder(order) || isConfirmedPayment(order)) return false;
    const paymentStatus = String(order?.paymentStatus || '').toUpperCase();
    const orderStatus = String(order?.status || '').toUpperCase();
    return !['FAILED', 'CANCELLED', 'REJECTED'].includes(paymentStatus) &&
      !['CANCELLED', 'REJECTED', 'PAYMENT FAILED'].includes(orderStatus);
  };

  const pendingFonepayPayments = realtimeOrders.filter(isPendingFonepayPayment);
  // Fonepay Hub creates a temporary `Payment Pending` row before the QR is paid.
  // Keep that temporary row only in the dedicated Instant/API Payments section.
  // The main Order Management list must contain confirmed product orders only.
  // This also prevents a pending QR checkout from looking like a duplicate order.
  const allOrders = realtimeOrders.filter((order: any) => {
    if (!isFonepayHubOrder(order)) return true;
    return isConfirmedPayment(order);
  });
  const completedOrdersList = allOrders.filter((o) => o.status === 'Completed' || o.status === 'COMPLETED' || o.status === 'Top-Up Successful');
  const completedRevenueNpr = completedOrdersList.reduce((acc, o) => acc + (o.totalPriceNpr || 0), 0);
  const totalOrdersCount = allOrders.length;
  const pendingOrdersCount = allOrders.filter((o) => o.status === 'PENDING' || o.status === 'Pending' || o.status === 'Pending Payment' || o.status === 'Processing').length;
  const pendingRevenueNpr = allOrders
    .filter((o) => o.status === 'PENDING' || o.status === 'Pending' || o.status === 'Pending Payment' || o.status === 'Processing')
    .reduce((acc, o) => acc + (o.totalPriceNpr || 0), 0);

  const handleApiPaymentAction = async (order: Order, action: 'confirm' | 'reject') => {
    const verb = action === 'confirm' ? 'confirm and fully process' : 'reject';
    if (!window.confirm(`Are you sure you want to ${verb} payment ${order.orderId}?`)) return;

    setApiPaymentActionId(order.orderId);
    setApiPaymentMessage(null);
    try {
      const { data, error } = await supabase.functions.invoke('fonepay-hub-admin-action', {
        body: {
          orderId: order.orderId,
          action,
          reason: action === 'reject' ? 'Rejected manually by admin.' : undefined,
        },
      });
      if (error || !data?.success) {
        throw new Error(data?.message || error?.message || 'Payment action failed.');
      }
      setApiPaymentMessage({
        type: 'success',
        text: action === 'confirm'
          ? `Payment ${order.orderId} was confirmed and processed.`
          : `Payment ${order.orderId} was rejected.`,
      });
    } catch (error) {
      setApiPaymentMessage({
        type: 'error',
        text: error instanceof Error ? error.message : 'Payment action failed.',
      });
    } finally {
      setApiPaymentActionId(null);
    }
  };

  // LOGIN / AUTH LOADING SCREEN
  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#070a11] text-white flex flex-col items-center justify-center p-4 font-sans">
        <Loader2 className="w-8 h-8 text-red-600 animate-spin mb-3" />
        <p className="text-xs font-bold text-zinc-400">Verifying Admin Auth Credentials...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#070a11] text-white flex items-center justify-center p-4 font-sans">
        <div className="w-full max-w-md bg-[#0c101c] border border-zinc-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="text-center mb-8">
            <img src="/assets/brand/ug-gaming-mark.png" alt="UG Top Up" className="w-16 h-16 rounded-2xl object-cover mx-auto mb-3 shadow-lg shadow-red-600/30" draggable={false} />
            <h1 className="text-2xl font-black text-white tracking-tight">Admin Portal Login</h1>
            <p className="text-xs text-zinc-400 mt-1">Manage UG Top Up Store, Games, Packages & Users</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="block text-zinc-400 font-bold mb-1">Admin Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
                <input
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="Enter admin email"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#070a11] border border-zinc-800 rounded-xl text-white outline-none focus:border-red-500 font-mono"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-zinc-400 font-bold mb-1">Admin Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-3" />
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Enter admin password"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#070a11] border border-zinc-800 rounded-xl text-white outline-none focus:border-red-500"
                  required
                />
              </div>
            </div>

            {loginError && (
              <div className="p-3 bg-red-950/50 border border-red-800/80 rounded-xl text-red-400 text-xs font-bold text-center">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              disabled={isAuthSubmitting}
              className="w-full py-3 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-black text-sm rounded-xl shadow-lg shadow-red-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              {isAuthSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Supabase Auth...</span>
                </>
              ) : (
                <span>Access Admin Panel</span>
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={onNavigateToStore}
              className="text-xs text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer"
            >
              ← Back to Customer Store
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Theme Styling Classes
  const isDark = adminTheme === 'dark';
  const mainBgClass = isDark ? 'bg-[#070a11] text-zinc-100' : 'bg-slate-50 text-slate-900';
  const sidebarBgClass = isDark ? 'bg-[#090d16] border-zinc-800/80' : 'bg-white border-slate-200';
  const cardBgClass = isDark ? 'bg-[#0c101c] border-zinc-800' : 'bg-white border-slate-200 shadow-sm';
  const inputBgClass = isDark ? 'bg-[#080b14] border-zinc-700 text-white' : 'bg-white border-slate-200 text-slate-900';
  const headerBgClass = isDark ? 'bg-[#090d16] border-zinc-800' : 'bg-white border-slate-200';

  return (
    <div className={`admin-shell ${isDark ? 'admin-dark' : 'admin-light'} min-h-screen flex flex-col md:flex-row font-sans ${mainBgClass} relative`}>
      {/* Top Copy Toast Notification */}
      {copyToast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[100] bg-emerald-600 text-white font-black px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs border border-emerald-400/50 animate-in fade-in slide-in-from-top-4 duration-200">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>{copyToast}</span>
        </div>
      )}
      
      {/* 1. SIDEBAR NAVIGATION */}
      <aside className={`w-full md:w-64 flex-shrink-0 border-r flex flex-col justify-between ${sidebarBgClass}`}>
        
        <div className="p-4 space-y-6">
          {/* Brand & Theme Toggle */}
          <div className="flex items-center justify-between border-b pb-4 border-zinc-800/60">
            <div className="flex items-center gap-2.5">
              <img src="/assets/brand/ug-gaming-mark.png" alt="UG Top Up" className="w-9 h-9 rounded-xl object-cover shadow-md" draggable={false} />
              <div>
                <h1 className="font-extrabold text-sm text-white tracking-tight">ADMIN PANEL</h1>
                <span className="text-[10px] text-red-400 font-bold">UG TOP UP v2.4</span>
              </div>
            </div>

            {/* Light / Dark Mode Switcher */}
            <div className="flex items-center bg-zinc-900/80 p-1 rounded-xl border border-zinc-800">
              <button
                onClick={() => toggleTheme('dark')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isDark ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
                title="Dark Mode"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => toggleTheme('light')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  !isDark ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
                title="Light Mode"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1 text-xs font-bold">
            
            {/* ANALYTICS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('ANALYTICS');
                  setActiveSubItem('Dashboard');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'ANALYTICS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <BarChart3 className="w-4 h-4" />
                  <span>DASHBOARD</span>
                </div>
              </button>
            </div>

            {/* STORE MENU */}
            <div>
              <button
                onClick={() => toggleMenu('STORE')}
                className="w-full flex items-center justify-between px-3 py-2.5 text-zinc-400 hover:text-white hover:bg-zinc-800/40 rounded-xl transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <ShoppingBag className="w-4 h-4 text-emerald-400" />
                  <span>STORE</span>
                </div>
                {expandedMenus.STORE ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              </button>

              {expandedMenus.STORE && (
                <div className="pl-8 pt-1 space-y-1 border-l-2 border-zinc-800 ml-5 my-1">
                  <button
                    onClick={() => {
                      setActiveMainSection('STORE');
                      setActiveSubItem('Products Management');
                    }}
                    className={`w-full text-left py-1.5 px-2 rounded-lg transition-colors cursor-pointer ${
                      activeSubItem === 'Products Management' || activeSubItem === 'Games/Items' ? 'text-red-400 font-extrabold bg-red-950/30' : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    • Products
                  </button>

                  <button
                    onClick={() => {
                      setActiveMainSection('STORE');
                      setActiveSubItem('Packages');
                    }}
                    className={`w-full text-left py-1.5 px-2 rounded-lg transition-colors cursor-pointer ${
                      activeSubItem === 'Packages' ? 'text-red-400 font-extrabold bg-red-950/30' : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    • Product Package
                  </button>

                  <button
                    onClick={() => {
                      setActiveMainSection('STORE');
                      setActiveSubItem('Banners');
                    }}
                    className={`w-full text-left py-1.5 px-2 rounded-lg transition-colors cursor-pointer ${
                      activeSubItem === 'Banners' ? 'text-red-400 font-extrabold bg-red-950/30' : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    • Carousel Banners
                  </button>
                </div>
              )}
            </div>

            {/* ORDERS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('ORDERS');
                  setActiveSubItem('Orders List');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'ORDERS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Package className="w-4 h-4 text-amber-400" />
                  <span>ORDERS</span>
                </div>
                <span className="text-[10px] bg-red-950 text-red-400 px-2 py-0.5 rounded-full font-mono">{allOrders.length}</span>
              </button>
            </div>

            {/* PENDING REQUESTS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('PENDING_REQUESTS');
                  setActiveSubItem('Pending Requests');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'PENDING_REQUESTS' || activeSubItem === 'Pending Requests' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>PENDING REQUESTS</span>
                </div>
                <span className="text-[10px] bg-amber-950/80 text-amber-400 border border-amber-800/60 px-2 py-0.5 rounded-full font-mono font-bold">
                  {allWalletRequests.filter((r) => r.status === 'PENDING' || r.status === 'Pending').length}
                </span>
              </button>
            </div>

            {/* API PAYMENTS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('API_PAYMENTS');
                  setActiveSubItem('API Payments');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'API_PAYMENTS' || activeSubItem === 'API Payments' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <QrCode className="w-4 h-4 text-cyan-400" />
                  <span>API PAYMENTS</span>
                </div>
                <span className="text-[10px] bg-amber-950/80 text-amber-400 border border-amber-800/60 px-2 py-0.5 rounded-full font-mono font-bold">
                  {pendingFonepayPayments.length}
                </span>
              </button>
            </div>

            {/* INSTANT PAYMENT */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('INSTANT_PAYMENT');
                  setActiveSubItem('Instant Wallet Load');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'INSTANT_PAYMENT' || activeSubItem === 'Instant Wallet Load' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Zap className="w-4 h-4 text-purple-400" />
                  <span>INSTANT PAYMENT</span>
                </div>
              </button>
            </div>

            {/* ML API MONITORING */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('ML_API_MONITORING');
                  setActiveSubItem('ML API Monitoring');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'ML_API_MONITORING' || activeSubItem === 'ML API Monitoring' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Gamepad2 className="w-4 h-4 text-sky-400" />
                  <span>ML API MONITORING</span>
                </div>
              </button>
            </div>

            {/* USERS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('USERS');
                  setActiveSubItem('Users');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'USERS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Users className="w-4 h-4 text-blue-400" />
                  <span>USER SECTION</span>
                </div>
                <span className="text-[10px] bg-blue-950 text-blue-400 px-2 py-0.5 rounded-full font-mono">{usersList.length}</span>
              </button>
            </div>

            {/* REVIEWS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('REVIEWS');
                  setActiveSubItem('Reviews');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'REVIEWS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>REVIEWS</span>
                </div>
                {reviewsList.filter((r) => r.status === 'PENDING').length > 0 && (
                  <span className="text-[10px] bg-amber-500 text-zinc-950 px-2 py-0.5 rounded-full font-mono font-bold animate-pulse">
                    {reviewsList.filter((r) => r.status === 'PENDING').length} PENDING
                  </span>
                )}
              </button>
            </div>

            {/* NOTIFICATIONS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('NOTIFICATIONS');
                  setActiveSubItem('Notifications');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'NOTIFICATIONS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Bell className="w-4 h-4 text-amber-400" />
                  <span>NOTIFICATIONS</span>
                </div>
              </button>
            </div>

            {/* REDEEM CODES */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('REDEEM_CODES');
                  setActiveSubItem('Redeem Codes');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'REDEEM_CODES' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Ticket className="w-4 h-4 text-emerald-400" />
                  <span>REDEEM CODES</span>
                </div>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {redeemCodesList.filter(c => c.status === 'AVAILABLE').length}
                </span>
              </button>
            </div>

            {/* ANNOUNCEMENTS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('ANNOUNCEMENTS');
                  setActiveSubItem('Announcements');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'ANNOUNCEMENTS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Megaphone className="w-4 h-4 text-amber-400" />
                  <span>ANNOUNCEMENTS</span>
                </div>
              </button>
            </div>

            {/* SETTINGS */}
            <div>
              <button
                onClick={() => {
                  setActiveMainSection('SETTINGS');
                  setActiveSubItem('Settings');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  activeMainSection === 'SETTINGS' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Settings className="w-4 h-4 text-zinc-300" />
                  <span>SETTINGS</span>
                </div>
              </button>
            </div>

          </nav>
        </div>

        {/* Bottom User Pill & Store Return Button */}
        <div className="p-3 border-t border-zinc-800/80 space-y-2">
          <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs">
            <div className="min-w-0">
              <h4 className="font-bold text-white truncate">
                {adminUser?.username || userProfile?.username || 'Administrator'}
              </h4>
              <p className="text-[10px] text-emerald-400 truncate font-semibold">
                ● Active Admin Session
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="p-1.5 bg-red-950 text-red-400 hover:bg-red-600 hover:text-white rounded-lg transition-all cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={onNavigateToStore}
            className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-bold transition-all cursor-pointer text-center block"
          >
            ← Exit Admin & Open Customer Store
          </button>
        </div>

      </aside>

      {/* 2. MAIN CONTENT PANEL */}
      <main className="flex-1 overflow-y-auto flex flex-col min-w-0">
        <header className={`sticky top-0 z-30 h-[68px] border-b flex items-center gap-4 px-4 md:px-6 backdrop-blur-xl ${headerBgClass}`}>
          <div className="hidden md:flex items-center gap-2 min-w-[145px]">
            <img src="/assets/brand/ug-gaming-mark.png" alt="UG Top Up" className="w-8 h-8 rounded-lg object-cover" draggable={false} />
            <div className="leading-tight"><div className="text-[10px] uppercase tracking-[0.22em] text-red-500 font-bold">UG TOP UP</div><div className="text-sm font-black admin-heading">Admin Control Center</div></div>
          </div>
          <div className={`relative flex-1 max-w-xl ${isDark ? 'text-zinc-300' : 'text-slate-500'}`}>
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" />
            <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search orders, users, products..." className={`w-full pl-9 pr-14 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`} />
            <span className={`absolute right-2.5 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded border text-[9px] font-mono ${isDark ? 'border-zinc-700 text-zinc-500' : 'border-slate-200 text-slate-400'}`}>Ctrl K</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={onNavigateToStore} className={`hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-bold ${isDark ? 'border-zinc-700 text-zinc-200 hover:bg-zinc-800' : 'border-slate-200 text-slate-700 hover:bg-slate-50'}`}><Globe className="w-3.5 h-3.5" /> View Store</button>
            <button onClick={() => toggleTheme(isDark ? 'light' : 'dark')} className={`p-2 rounded-xl border ${isDark ? 'border-zinc-700 text-amber-300 hover:bg-zinc-800' : 'border-slate-200 text-slate-700 hover:bg-slate-50'}`} title="Toggle theme">{isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}</button>
            <button className={`p-2 rounded-xl border ${isDark ? 'border-zinc-700 text-zinc-300' : 'border-slate-200 text-slate-700'}`}><Bell className="w-4 h-4" /></button>
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black ${isDark ? 'bg-zinc-800 text-white' : 'bg-slate-100 text-slate-800'}`}>{(adminUser?.username || userProfile?.username || 'A').charAt(0).toUpperCase()}</div>
          </div>
        </header>

        {/* VIEW 1: DASHBOARD ANALYTICS */}
        {activeMainSection === 'ANALYTICS' && (() => {
          const successCount = completedOrdersList.length;
          const processingCount = allOrders.filter(o => o.status === 'Processing' || o.status === 'PROCESSING').length;
          const pendingCount = allOrders.filter(o => o.status === 'PENDING' || o.status === 'Pending' || o.status === 'Pending Payment').length;
          const cancelledCount = allOrders.filter(o => o.status === 'Cancelled' || o.status === 'CANCELLED').length;
          const maxDaily = Math.max(1, ...Array.from({length: 7}, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (6-i)); return completedOrdersList.filter(o => { const raw = (o as any).createdAt || (o as any).created_at || (o as any).date; if (!raw) return false; return new Date(raw).toDateString() === d.toDateString(); }).reduce((sum,o)=>sum+(o.totalPriceNpr||0),0); }));
          const daily = Array.from({length:7}, (_,i) => { const d=new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate()-(6-i)); const value=completedOrdersList.filter(o=>{const raw=(o as any).createdAt||(o as any).created_at||(o as any).date; return raw && new Date(raw).toDateString()===d.toDateString();}).reduce((sum,o)=>sum+(o.totalPriceNpr||0),0); return {label:d.toLocaleDateString('en-US',{weekday:'short'}),value}; });
          const points = daily.map((d,i)=>`${(i/(daily.length-1))*100},${92-(d.value/maxDaily)*70}`).join(' ');
          const total = Math.max(1, allOrders.length);
          const successPct = Math.round((successCount/total)*100);
          const donut = `conic-gradient(#22c55e 0 ${successCount/total*360}deg, #3b82f6 ${successCount/total*360}deg ${(successCount+processingCount)/total*360}deg, #f59e0b ${(successCount+processingCount)/total*360}deg ${(successCount+processingCount+pendingCount)/total*360}deg, #ef4444 ${(successCount+processingCount+pendingCount)/total*360}deg 360deg)`;
          return (
            <div className="p-4 md:p-6 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
                <div><div className="text-[10px] font-black uppercase tracking-[0.18em] text-red-500">Overview</div><h2 className={`text-2xl md:text-3xl font-black tracking-tight admin-heading`}>Welcome back, Admin! 👋</h2><p className={`text-xs mt-1 admin-muted`}>Here’s what’s happening across your store today.</p></div>
                <div className={`px-3 py-2 rounded-xl border text-xs font-bold ${isDark?'border-zinc-800 bg-zinc-900/60 text-zinc-300':'border-slate-200 bg-white text-slate-700'}`}><Calendar className="w-3.5 h-3.5 inline mr-2 text-red-500"/>Last 7 days</div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                {[
                  ['Completed Sales', `NPR ${completedRevenueNpr.toLocaleString('en-IN')}`, `${successCount} fulfilled orders`, 'emerald', Calendar],
                  ['Total Orders', totalOrdersCount.toLocaleString(), `${pendingOrdersCount} need attention`, 'blue', ShoppingBag],
                  ['Active Games', games.length.toString(), `${games.reduce((a,g)=>a+(g.packages?.length||0),0)} packages listed`, 'purple', Gamepad2],
                  ['Registered Users', usersList.length.toString(), 'Customer profiles', 'amber', Users],
                ].map(([label,value,sub,color,Icon]: any)=><div key={label} className={`p-4 rounded-2xl border ${cardBgClass}`}>
                  <div className="flex items-start justify-between"><div><span className="text-[10px] font-bold uppercase tracking-wider admin-muted">{label}</span><h4 className={`text-2xl font-black mt-1 ${label==='Completed Sales'?'text-emerald-500':'admin-heading'}`}>{value}</h4><p className="text-[11px] admin-muted mt-2">{sub}</p></div><div className={`p-2.5 rounded-xl bg-${color}-500/15 text-${color}-500`}><Icon className="w-5 h-5"/></div></div>
                </div>)}
              </div>
              <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
                <div className={`xl:col-span-3 p-5 rounded-2xl border ${cardBgClass}`}>
                  <div className="flex items-center justify-between mb-4"><div><h3 className="text-sm font-black admin-heading">Sales Overview</h3><p className="text-[11px] admin-muted">Completed revenue for the last 7 days</p></div><span className="text-sm font-black text-emerald-500">NPR {completedRevenueNpr.toLocaleString('en-IN')}</span></div>
                  <div className="relative h-56"><svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 w-full h-full overflow-visible"><defs><linearGradient id="salesFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ef4444" stopOpacity="0.30"/><stop offset="100%" stopColor="#ef4444" stopOpacity="0"/></linearGradient></defs><polyline points={`${points} 100,100 0,100`} fill="url(#salesFill)" stroke="none"/><polyline points={points} fill="none" stroke="#ef4444" strokeWidth="1.8" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round"/></svg><div className="absolute inset-0 flex flex-col justify-between pointer-events-none"><div className="border-t admin-grid-line"/><div className="border-t admin-grid-line"/><div className="border-t admin-grid-line"/><div className="border-t admin-grid-line"/></div></div>
                  <div className="grid grid-cols-7 text-[9px] admin-muted mt-2">{daily.map(d=><span key={d.label} className="text-center">{d.label}</span>)}</div>
                </div>
                <div className={`xl:col-span-2 p-5 rounded-2xl border ${cardBgClass}`}>
                  <div className="flex items-start justify-between"><div><h3 className="text-sm font-black admin-heading">Order Status</h3><p className="text-[11px] admin-muted">Current order health</p></div><span className="text-xs font-black text-emerald-500">{successPct}% success</span></div>
                  <div className="flex items-center gap-5 mt-6"><div className="w-36 h-36 rounded-full p-3 flex-shrink-0" style={{background:donut}}><div className={`w-full h-full rounded-full flex flex-col items-center justify-center ${isDark?'bg-[#0c101c]':'bg-white'}`}><b className="text-2xl admin-heading">{totalOrdersCount}</b><span className="text-[9px] admin-muted uppercase">Total Orders</span></div></div><div className="space-y-2 text-xs flex-1">{[['Completed',successCount,'#22c55e'],['Processing',processingCount,'#3b82f6'],['Pending',pendingCount,'#f59e0b'],['Cancelled',cancelledCount,'#ef4444']].map(([name,count,c]:any)=><div key={name} className="flex items-center justify-between gap-2"><span className="flex items-center gap-2 admin-muted"><i className="w-2 h-2 rounded-full" style={{background:c}}/>{name}</span><b className="admin-heading">{count}</b></div>)}</div></div>
                </div>
              </div>
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <div className={`rounded-2xl border overflow-hidden ${cardBgClass}`}><div className="p-4 flex items-center justify-between"><div><h3 className="text-sm font-black admin-heading">Recent Orders</h3><p className="text-[11px] admin-muted">Latest customer activity</p></div><button onClick={()=>{setActiveMainSection('ORDERS');setActiveSubItem('Orders List')}} className="text-xs font-bold text-red-500 hover:text-red-600">View All →</button></div>{allOrders.slice(0,5).map((o:any,i)=><div key={o.orderId||o.id||i} className={`px-4 py-3 border-t flex items-center gap-3 ${isDark?'border-zinc-800/80':'border-slate-100'}`}><div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black ${isDark?'bg-zinc-800 text-zinc-300':'bg-slate-100 text-slate-700'}`}>{(o.username||o.userName||'U').charAt(0).toUpperCase()}</div><div className="min-w-0 flex-1"><div className="text-xs font-bold admin-heading truncate">{o.gameName||'Order'} <span className="admin-muted font-normal">#{String(o.orderId||'').trim()}</span></div><div className="text-[10px] admin-muted truncate">{o.username||o.email||'Customer'}</div></div><div className="text-right"><div className="text-xs font-black admin-heading">NPR {(o.totalPriceNpr||0).toLocaleString('en-IN')}</div><div className={`text-[9px] font-bold ${o.status==='Completed'||o.status==='COMPLETED'?'text-emerald-500':o.status==='Cancelled'?'text-red-500':'text-amber-500'}`}>{o.status||'Pending'}</div></div></div>)}{allOrders.length===0&&<div className="p-10 text-center text-xs admin-muted">No orders yet.</div>}</div>
                <div className={`p-5 rounded-2xl border ${cardBgClass}`}><div className="flex items-center justify-between"><div><h3 className="text-sm font-black admin-heading">Store Performance</h3><p className="text-[11px] admin-muted">Quick business indicators</p></div><BarChart3 className="w-5 h-5 text-red-500"/></div><div className="grid grid-cols-2 gap-3 mt-5">{[['Average Order', totalOrdersCount ? `NPR ${(completedRevenueNpr/Math.max(1,totalOrdersCount)).toFixed(0)}` : 'NPR 0'],['Pending Value',`NPR ${pendingRevenueNpr.toLocaleString('en-IN')}`],['UG Wallet',allOrders.filter((o:any)=>(o.paymentMethod||'').toLowerCase().includes('wallet')).length],['QR Payment',allOrders.filter((o:any)=>(o.paymentMethod||'').toLowerCase().includes('qr')).length]].map(([a,b])=><div key={a} className={`p-3 rounded-xl border ${isDark?'bg-zinc-950/60 border-zinc-800':'bg-slate-50 border-slate-200'}`}><div className="text-[10px] admin-muted">{a}</div><div className="text-lg font-black admin-heading mt-1">{b}</div></div>)}</div></div>
              </div>
            </div>
          );
        })()}

        {/* VIEW: PRODUCTS MANAGEMENT */}
        {(activeSubItem === 'Products Management' || (activeMainSection === 'STORE' && activeSubItem === 'Dashboard')) && (
          <div className="p-6 space-y-6">
            
            {/* Top Header Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 bg-red-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-red-600/30">
                  <Package className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2.5">
                    <h2 className="text-2xl font-black text-white tracking-tight">
                      Products <span className="text-red-500">Management</span>
                    </h2>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-950/80 text-red-400 border border-red-800/60 font-mono">
                      Admin Console
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Control product details, status badges, and real-time inventory availability
                  </p>
                </div>
              </div>

              <button
                onClick={handleOpenAddProduct}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add Product</span>
              </button>
            </div>

            {/* 4 Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Total Products */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Total Products</span>
                    <span className="text-2xl font-black text-white mt-1 block">{productsList.length}</span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-zinc-800/80 flex items-center justify-center text-zinc-300">
                    <Layers className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Active Status */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Active Status</span>
                    <span className="text-2xl font-black text-white mt-1 block">
                      {productsList.filter((p) => p.status === 'Active').length}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                    <Power className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* In Stock */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">In Stock</span>
                    <span className="text-2xl font-black text-white mt-1 block">
                      {productsList.filter((p) => p.availability === 'In Stock').length}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Out Of Stock */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Out Of Stock</span>
                    <span className="text-2xl font-black text-amber-400 mt-1 block">
                      {productsList.filter((p) => p.availability === 'Out Of Stock').length}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-amber-950/60 border border-amber-800/60 flex items-center justify-center text-amber-400">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>

            {/* Search & Filter Bar */}
            <div className={`p-3 rounded-2xl border flex flex-col md:flex-row items-center justify-between gap-3 ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by Product Name or Product ID..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2 rounded-xl text-xs outline-none ${adminTheme === 'dark' ? 'bg-zinc-950 border border-zinc-800 text-white placeholder-zinc-500 focus:border-red-500' : 'bg-zinc-50 border border-zinc-300 text-zinc-900 placeholder-zinc-400'}`}
                />
              </div>

              <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
                <div className="flex items-center gap-1.5 text-xs text-red-500 font-bold uppercase tracking-wide">
                  <Filter className="w-3.5 h-3.5" />
                  <span>FILTER:</span>
                </div>

                {/* Categories Dropdown */}
                <select
                  value={productCategoryFilter}
                  onChange={(e) => setProductCategoryFilter(e.target.value)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold outline-none cursor-pointer ${adminTheme === 'dark' ? 'bg-zinc-950 border border-zinc-800 text-zinc-200' : 'bg-zinc-50 border border-zinc-300 text-zinc-800'}`}
                >
                  <option value="ALL">All Categories</option>
                  {Array.from(new Set(productsList.map((p) => p.category))).map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>

                {/* Statuses Dropdown */}
                <select
                  value={productStatusFilter}
                  onChange={(e) => setProductStatusFilter(e.target.value)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold outline-none cursor-pointer ${adminTheme === 'dark' ? 'bg-zinc-950 border border-zinc-800 text-zinc-200' : 'bg-zinc-50 border border-zinc-300 text-zinc-800'}`}
                >
                  <option value="ALL">All Statuses</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>

                {/* Availability Dropdown */}
                <select
                  value={productAvailabilityFilter}
                  onChange={(e) => setProductAvailabilityFilter(e.target.value)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold outline-none cursor-pointer ${adminTheme === 'dark' ? 'bg-zinc-950 border border-zinc-800 text-zinc-200' : 'bg-zinc-50 border border-zinc-300 text-zinc-800'}`}
                >
                  <option value="ALL">All Availability</option>
                  <option value="In Stock">In Stock</option>
                  <option value="Out Of Stock">Out Of Stock</option>
                  <option value="Pre-Order">Pre-Order</option>
                </select>
              </div>
            </div>

            {/* Showing count & Refresh Row */}
            <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
              <div>
                Showing <span className="font-bold text-white">{filteredProducts.length}</span> of <span className="font-bold text-white">{productsList.length}</span> products
              </div>

              <button
                onClick={handleRefreshProducts}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-zinc-200 text-xs font-bold transition-all cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-zinc-400 ${isRefreshingProducts ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {/* Products Table */}
            <div className={`rounded-2xl border overflow-hidden ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-zinc-800/80 text-[11px] font-bold text-zinc-400 uppercase tracking-wider bg-zinc-950/40">
                      <th className="py-3.5 px-4">PRODUCT</th>
                      <th className="py-3.5 px-4">CATEGORY</th>
                      <th className="py-3.5 px-4">STATUS</th>
                      <th className="py-3.5 px-4">AVAILABILITY</th>
                      <th className="py-3.5 px-4 text-right">ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50 text-xs">
                    {filteredProducts.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-zinc-500">
                          No products found matching filters.
                        </td>
                      </tr>
                    ) : (
                      filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-zinc-800/30 transition-colors">
                          {/* PRODUCT CELL */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={p.imageUrl}
                                alt={p.name}
                                className="w-11 h-11 rounded-xl object-cover border border-zinc-800/80 bg-zinc-950"
                              />
                              <div>
                                <h4 className="font-bold text-white text-xs">{p.name}</h4>
                                <span className="text-[11px] text-zinc-400 font-mono">
                                  ID: {p.code || p.id}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* CATEGORY CELL */}
                          <td className="py-3.5 px-4">
                            <span className="px-3 py-1 rounded-lg bg-zinc-800/90 border border-zinc-700/60 text-zinc-200 text-[11px] font-medium">
                              {p.category}
                            </span>
                          </td>

                          {/* STATUS CELL */}
                          <td className="py-3.5 px-4">
                            <button
                              onClick={() => handleToggleProductStatus(p)}
                              className={`px-3 py-1 rounded-full text-[11px] font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
                                p.status === 'Active'
                                  ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 hover:bg-emerald-900/80'
                                  : 'bg-red-950/80 text-red-400 border border-red-800/60 hover:bg-red-900/80'
                              }`}
                              title="Click to toggle status"
                            >
                              <span className={`w-2 h-2 rounded-full ${p.status === 'Active' ? 'bg-emerald-400' : 'bg-red-400'}`}></span>
                              <span>{p.status}</span>
                            </button>
                          </td>

                          {/* AVAILABILITY CELL */}
                          <td className="py-3.5 px-4">
                            <div className="inline-flex items-center">
                              <select
                                value={p.availability}
                                onChange={(e) => handleChangeProductAvailability(p, e.target.value as any)}
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold outline-none cursor-pointer border ${
                                  p.availability === 'In Stock'
                                    ? 'bg-emerald-950/60 border-emerald-800/60 text-emerald-400'
                                    : 'bg-amber-950/60 border-amber-800/60 text-amber-400'
                                }`}
                              >
                                <option value="In Stock">• In Stock</option>
                                <option value="Out Of Stock">• Out Of Stock</option>
                                <option value="Pre-Order">• Pre-Order</option>
                              </select>
                            </div>
                          </td>

                          {/* ACTIONS CELL */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleOpenEditProduct(p)}
                                className="p-1.5 hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-white transition-all cursor-pointer"
                                title="Edit Product"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>

                              <button
                                onClick={() => handleDeleteProduct(p.id, p.name)}
                                className="p-1.5 hover:bg-red-950/80 rounded-lg text-zinc-400 hover:text-red-400 transition-all cursor-pointer"
                                title="Delete Product"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* ADD / EDIT PRODUCT POPUP MODAL */}
            {isAddProductModalOpen && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
                <div className="w-full max-w-[750px] bg-[#121212] border border-[#2A2A2A] rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-zinc-200">

                  {/* MODAL HEADER */}
                  <div className="px-6 py-4 border-b border-[#2A2A2A] bg-[#121212] flex items-center justify-between shrink-0">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#FF2D2D] animate-pulse"></span>
                        <h3 className="text-base font-extrabold text-white tracking-tight">
                          {editingProduct ? 'Edit Product' : 'Add Product'}
                        </h3>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        {editingProduct ? (
                          <>Modify specifications and settings for <span className="text-[#FF2D2D] font-medium">{editingProduct.name}</span></>
                        ) : (
                          'Create a new product listing for your store catalogue'
                        )}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => { setIsAddProductModalOpen(false); setEditingProduct(null); }}
                      className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-[#1B1B1B] border border-transparent hover:border-[#2A2A2A] transition-all cursor-pointer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* MODAL FORM BODY */}
                  <form onSubmit={handleSaveProductSubmit} className="flex-1 overflow-y-auto p-6 space-y-5 text-xs font-medium text-zinc-300">

                    {/* SECTION 1: PRODUCT TYPE SELECTION (TOP-UP VS VOUCHER) */}
                    <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-5 space-y-3 shadow-sm">
                      <div className="border-b border-[#2A2A2A]/60 pb-3">
                        <p className="text-[11px] font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                          <Gamepad2 className="w-3.5 h-3.5 text-[#FF2D2D]" />
                          SELECT PRODUCT TYPE & FULFILLMENT METHOD <span className="text-[#FF2D2D]">*</span>
                        </p>
                        <p className="text-[10px] text-zinc-400 mt-0.5">
                          Select whether this product is an In-Game Direct Top-Up (UID/Zone ID) or a Digital Voucher / Redeem Code.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        {/* Option 1: In-Game Direct Top-Up */}
                        <button
                          type="button"
                          onClick={() => setProductForm({
                            ...productForm,
                            productType: 'topup',
                            category: productForm.category === 'Voucher' ? 'Games' : productForm.category,
                            requireUid: true,
                          })}
                          className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 relative ${
                            productForm.productType === 'topup'
                              ? 'bg-red-950/40 border-[#FF2D2D] text-white ring-2 ring-[#FF2D2D]/30'
                              : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-black text-xs text-white">
                              <span className="text-base">🎮</span>
                              <span>In-Game Direct Top-Up</span>
                            </div>
                            {productForm.productType === 'topup' && (
                              <span className="w-2.5 h-2.5 rounded-full bg-[#FF2D2D] animate-pulse"></span>
                            )}
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-relaxed">
                            Requires customer <strong className="text-zinc-200">Player UID</strong> & optional <strong className="text-zinc-200">Zone ID / Server ID</strong>. Perfect for Mobile Legends, Free Fire, PUBG, etc.
                          </p>
                        </button>

                        {/* Option 2: Voucher / Digital Redeem Code */}
                        <button
                          type="button"
                          onClick={() => setProductForm({
                            ...productForm,
                            productType: 'voucher',
                            category: 'Voucher',
                            requireUid: false,
                            requireZoneId: false,
                          })}
                          className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 relative ${
                            productForm.productType === 'voucher'
                              ? 'bg-amber-950/40 border-amber-500 text-white ring-2 ring-amber-500/30'
                              : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-black text-xs text-white">
                              <span className="text-base">🎟️</span>
                              <span>Voucher / Redeem Code</span>
                            </div>
                            {productForm.productType === 'voucher' && (
                              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
                            )}
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-relaxed">
                            Delivers digital codes/PINs upon purchase. <strong className="text-zinc-200">No UID or Zone ID needed</strong> during checkout.
                          </p>
                        </button>
                      </div>
                    </div>

                    {/* SECTION 2: PRODUCT IMAGE & URL */}
                    <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-5 space-y-4 shadow-sm">
                      <div className="border-b border-[#2A2A2A]/60 pb-3">
                        <p className="text-[11px] font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                          <Box className="w-3.5 h-3.5 text-[#FF2D2D]" />
                          PRODUCT IMAGE & URL
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                        {/* Image Preview Box */}
                        <div className="sm:col-span-1 h-32 rounded-xl border-2 border-dashed border-[#2A2A2A] bg-[#0F0F0F] flex flex-col items-center justify-center p-2 text-center overflow-hidden relative">
                          {productForm.imageUrl ? (
                            <img
                              src={productForm.imageUrl}
                              alt="Preview"
                              className="w-full h-full object-contain"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = 'none';
                              }}
                            />
                          ) : (
                            <div className="flex flex-col items-center gap-1.5 text-zinc-500">
                              <Box className="w-8 h-8 opacity-40" />
                              <span className="text-[10px] font-bold">Preview</span>
                            </div>
                          )}
                        </div>

                        {/* Image URL Input */}
                        <div className="sm:col-span-2 space-y-1.5">
                          <label className="block text-zinc-300 font-semibold text-[11px]">
                            Image URL
                          </label>
                          <input
                            type="text"
                            placeholder="https://example.com/product-image.png"
                            value={productForm.imageUrl}
                            onChange={(e) => setProductForm({ ...productForm, imageUrl: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs placeholder:text-zinc-600"
                          />
                          <p className="text-[10px] text-zinc-500">
                            Paste a direct image URL for live preview.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* SECTION 3: PRODUCT DETAILS */}
                    <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-5 space-y-4 shadow-sm">
                      <div className="flex items-center justify-between border-b border-[#2A2A2A]/60 pb-3">
                        <span className="text-[11px] font-extrabold text-white tracking-wider uppercase flex items-center gap-2">
                          <Package className="w-3.5 h-3.5 text-[#FF2D2D]" />
                          PRODUCT DETAILS
                        </span>
                        <span className="text-[10px] text-zinc-500 font-normal">Primary details & descriptions</span>
                      </div>

                      {/* Product Name */}
                      <div>
                        <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">
                          Product Name <span className="text-[#FF2D2D]">*</span>
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Mobile Legends Diamonds"
                          value={productForm.name}
                          onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs placeholder:text-zinc-600"
                          required
                        />
                      </div>

                      {/* Description Title */}
                      <div>
                        <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">
                          Description Title
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Instant Delivery & 100% Safe Recharge"
                          value={productForm.descriptionTitle}
                          onChange={(e) => setProductForm({ ...productForm, descriptionTitle: e.target.value })}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs placeholder:text-zinc-600"
                        />
                      </div>

                      {/* Product Description */}
                      <div>
                        <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">
                          Product Description
                        </label>
                        <textarea
                          rows={4}
                          placeholder="Enter detailed description..."
                          value={productForm.description}
                          onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs resize-none placeholder:text-zinc-600 leading-relaxed"
                        />
                      </div>
                    </div>

                    {/* SECTION 4: USER FIELDS (CUSTOMER INPUT) */}
                    <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-5 space-y-4 shadow-sm">
                      <div className="border-b border-[#2A2A2A]/60 pb-3">
                        <p className="text-[11px] font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                          <Sliders className="w-3.5 h-3.5 text-[#FF2D2D]" />
                          CUSTOMER INPUT FIELDS REQUIRED <span className="normal-case font-normal text-zinc-400 text-[10px]">(Check to require on customer checkout)</span>
                        </p>
                        <p className="text-[10px] text-zinc-500 mt-0.5">
                          {productForm.productType === 'voucher' 
                            ? 'Voucher mode active: UID and Zone ID are automatically optional/hidden on user checkout.' 
                            : 'Select player input requirements. When Zone ID is checked, both UID and Zone ID will appear on user top-up.'}
                        </p>
                      </div>

                      {/* Requirement Checkboxes Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        {/* Require Game UID */}
                        <label className={`flex items-center gap-2.5 p-3 rounded-xl border transition-all cursor-pointer ${productForm.requireUid ? 'bg-[#FF2D2D]/10 border-[#FF2D2D] text-white' : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700'}`}>
                          <input
                            type="checkbox"
                            checked={productForm.requireUid}
                            onChange={(e) => setProductForm({ ...productForm, requireUid: e.target.checked })}
                            className="w-4 h-4 rounded text-[#FF2D2D] focus:ring-[#FF2D2D] bg-zinc-900 border-zinc-700"
                          />
                          <div className="flex items-center gap-1.5 text-xs font-bold">
                            <User className="w-3.5 h-3.5 text-red-500" />
                            <span>User ID</span>
                          </div>
                        </label>

                        {/* Require Zone ID */}
                        <label className={`flex items-center gap-2.5 p-3 rounded-xl border transition-all cursor-pointer ${productForm.requireZoneId ? 'bg-[#FF2D2D]/10 border-[#FF2D2D] text-white' : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700'}`}>
                          <input
                            type="checkbox"
                            checked={productForm.requireZoneId}
                            onChange={(e) => {
                              const isChecked = e.target.checked;
                              setProductForm({ 
                                ...productForm, 
                                requireZoneId: isChecked,
                                ...(isChecked ? { requireUid: true } : {})
                              });
                            }}
                            className="w-4 h-4 rounded text-[#FF2D2D] focus:ring-[#FF2D2D] bg-zinc-900 border-zinc-700"
                          />
                          <div className="flex items-center gap-1.5 text-xs font-bold">
                            <Globe className="w-3.5 h-3.5 text-blue-500" />
                            <span>Zone ID</span>
                          </div>
                        </label>

                        {/* Require Email */}
                        <label className={`flex items-center gap-2.5 p-3 rounded-xl border transition-all cursor-pointer ${productForm.requireEmail ? 'bg-[#FF2D2D]/10 border-[#FF2D2D] text-white' : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700'}`}>
                          <input
                            type="checkbox"
                            checked={productForm.requireEmail}
                            onChange={(e) => setProductForm({ ...productForm, requireEmail: e.target.checked })}
                            className="w-4 h-4 rounded text-[#FF2D2D] focus:ring-[#FF2D2D] bg-zinc-900 border-zinc-700"
                          />
                          <div className="flex items-center gap-1.5 text-xs font-bold">
                            <Mail className="w-3.5 h-3.5 text-emerald-500" />
                            <span>Email Address</span>
                          </div>
                        </label>

                        {/* Require Password */}
                        <label className={`flex items-center gap-2.5 p-3 rounded-xl border transition-all cursor-pointer ${productForm.requirePassword ? 'bg-[#FF2D2D]/10 border-[#FF2D2D] text-white' : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700'}`}>
                          <input
                            type="checkbox"
                            checked={productForm.requirePassword}
                            onChange={(e) => setProductForm({ ...productForm, requirePassword: e.target.checked })}
                            className="w-4 h-4 rounded text-[#FF2D2D] focus:ring-[#FF2D2D] bg-zinc-900 border-zinc-700"
                          />
                          <div className="flex items-center gap-1.5 text-xs font-bold">
                            <Key className="w-3.5 h-3.5 text-amber-500" />
                            <span>Password / PIN</span>
                          </div>
                        </label>

                        {/* Require WhatsApp */}
                        <label className={`flex items-center gap-2.5 p-3 rounded-xl border transition-all cursor-pointer ${productForm.requireWhatsapp ? 'bg-[#FF2D2D]/10 border-[#FF2D2D] text-white' : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-700'}`}>
                          <input
                            type="checkbox"
                            checked={productForm.requireWhatsapp}
                            onChange={(e) => setProductForm({ ...productForm, requireWhatsapp: e.target.checked })}
                            className="w-4 h-4 rounded text-[#FF2D2D] focus:ring-[#FF2D2D] bg-zinc-900 border-zinc-700"
                          />
                          <div className="flex items-center gap-1.5 text-xs font-bold">
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                            <span>WhatsApp Link/No</span>
                          </div>
                        </label>
                      </div>

                      {/* Custom Input Field Names */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-[#2A2A2A]/40">
                        <div>
                          <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">Extra Custom Field #1 Name</label>
                          <input
                            type="text"
                            placeholder="e.g. In-Game Name, Tag"
                            value={productForm.userField1}
                            onChange={(e) => setProductForm({ ...productForm, userField1: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs placeholder:text-zinc-600"
                          />
                        </div>

                        <div>
                          <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">Extra Custom Field #2 Name</label>
                          <input
                            type="text"
                            placeholder="e.g. Server Region"
                            value={productForm.userField2}
                            onChange={(e) => setProductForm({ ...productForm, userField2: e.target.value })}
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs placeholder:text-zinc-600"
                          />
                        </div>
                      </div>

                      {/* Dynamic / Unlimited Custom Fields */}
                      <div className="pt-3 border-t border-[#2A2A2A]/40 space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="block text-zinc-300 font-semibold text-[11px]">
                            Additional Custom Fields <span className="normal-case font-normal text-zinc-500">(shown to every customer on checkout)</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => setProductForm({
                              ...productForm,
                              customFields: [
                                ...productForm.customFields,
                                { id: `cf_${Date.now()}_${Math.floor(Math.random() * 1000)}`, label: '' },
                              ],
                            })}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FF2D2D]/10 border border-[#FF2D2D]/40 text-[#FF2D2D] hover:bg-[#FF2D2D]/20 transition-colors font-bold text-[11px] cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            Add New
                          </button>
                        </div>

                        {productForm.customFields.length === 0 && (
                          <p className="text-[11px] text-zinc-600 italic">No extra fields yet. Click "Add New" to create one (e.g. "In-Game Name", "Discord ID").</p>
                        )}

                        {productForm.customFields.map((field, idx) => (
                          <div key={field.id} className="flex items-center gap-2">
                            <input
                              type="text"
                              placeholder="Field title, e.g. Discord Username"
                              value={field.label}
                              onChange={(e) => {
                                const updated = [...productForm.customFields];
                                updated[idx] = { ...updated[idx], label: e.target.value };
                                setProductForm({ ...productForm, customFields: updated });
                              }}
                              className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs placeholder:text-zinc-600"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                const updated = productForm.customFields.filter((_, i) => i !== idx);
                                setProductForm({ ...productForm, customFields: updated });
                              }}
                              className="w-9 h-9 flex-shrink-0 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-zinc-500 hover:text-red-500 hover:border-red-500/40 flex items-center justify-center transition-colors cursor-pointer"
                              title="Remove field"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* SECTION 3: PRODUCT SETTINGS */}
                    <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-5 space-y-4 shadow-sm">
                      <div className="border-b border-[#2A2A2A]/60 pb-3">
                        <p className="text-[11px] font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                          <Tag className="w-3.5 h-3.5 text-[#FF2D2D]" />
                          PRODUCT SETTINGS
                        </p>
                      </div>

                      {/* Category Chips */}
                      <div>
                        <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2.5">CATEGORY</p>
                        <div className="flex flex-wrap gap-2.5">
                          {[
                            { label: 'Games', icon: '🎮' },
                            { label: 'Subscription', icon: '📺' },
                            { label: 'Voucher', icon: '🎟️' },
                            { label: 'Other', icon: '📦' },
                          ].map((cat) => (
                            <button
                              key={cat.label}
                              type="button"
                              onClick={() => setProductForm({ ...productForm, category: cat.label })}
                              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                                productForm.category === cat.label
                                  ? 'bg-[#FF2D2D] border-[#FF2D2D] text-white shadow-md shadow-[#FF2D2D]/20'
                                  : 'bg-[#0F0F0F] border-[#2A2A2A] text-zinc-400 hover:border-zinc-500 hover:text-zinc-200'
                              }`}
                            >
                              <span className="text-sm">{cat.icon}</span>
                              <span>{cat.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Status & Availability */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                        <div>
                          <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2">STATUS</p>
                          <select
                            value={productForm.status}
                            onChange={(e) => setProductForm({ ...productForm, status: e.target.value as any })}
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none cursor-pointer focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs"
                          >
                            <option value="Active" className="bg-[#121212] text-white">Active</option>
                            <option value="Inactive" className="bg-[#121212] text-white">Inactive</option>
                          </select>
                        </div>

                        <div>
                          <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2">AVAILABILITY</p>
                          <select
                            value={productForm.availability}
                            onChange={(e) => setProductForm({ ...productForm, availability: e.target.value as any })}
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none cursor-pointer focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs"
                          >
                            <option value="In Stock" className="bg-[#121212] text-white">• In Stock</option>
                            <option value="Out Of Stock" className="bg-[#121212] text-white">• Out Of Stock</option>
                            <option value="Pre-Order" className="bg-[#121212] text-white">• Pre-Order</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <button type="submit" className="hidden" />
                  </form>

                  {/* STICKY FOOTER */}
                  <div className="px-6 py-4 border-t border-[#2A2A2A] bg-[#121212] flex items-center justify-end gap-3 shrink-0">
                    <button
                      type="button"
                      onClick={() => { setIsAddProductModalOpen(false); setEditingProduct(null); }}
                      className="px-5 py-2.5 bg-[#1B1B1B] hover:bg-[#252525] border border-[#2A2A2A] text-zinc-300 font-semibold rounded-xl cursor-pointer text-xs transition-all active:scale-95"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveProductSubmit}
                      className="px-6 py-2.5 bg-[#FF2D2D] hover:bg-[#e02626] text-white font-bold rounded-xl shadow-lg shadow-[#FF2D2D]/25 cursor-pointer text-xs flex items-center gap-2 transition-all active:scale-95"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>{editingProduct ? 'Save Changes' : 'Add Product'}</span>
                    </button>
                  </div>

                </div>
              </div>
            )}

          </div>
        )}

        {/* VIEW 2: GAMES / ITEMS MANAGEMENT */}
        {(activeSubItem === 'Games/Items') && (
          <div className="p-6 space-y-6">
            
            {/* Add New Game / Item Form */}
            <div className={`p-5 rounded-2xl space-y-4 ${cardBgClass}`}>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-red-500" />
                Add New Game or Store Item
              </h3>

              <form onSubmit={handleAddGame} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-zinc-400 mb-1">Game / Item Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Free Fire, PUBG Mobile, Genshin Impact"
                    value={newGame.name}
                    onChange={(e) => setNewGame({ ...newGame, name: e.target.value })}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    required
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1">Category / Genre</label>
                  <input
                    type="text"
                    placeholder="e.g. Battle Royale, RPG, Mobile"
                    value={newGame.category}
                    onChange={(e) => setNewGame({ ...newGame, category: e.target.value })}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1">Icon Image URL *</label>
                  <input
                    type="url"
                    placeholder="https://example.com/game-icon.png"
                    value={newGame.iconUrl}
                    onChange={(e) => setNewGame({ ...newGame, iconUrl: e.target.value })}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    required
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1">Banner Cover Image URL</label>
                  <input
                    type="url"
                    placeholder="https://example.com/banner.png"
                    value={newGame.bannerUrl}
                    onChange={(e) => setNewGame({ ...newGame, bannerUrl: e.target.value })}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1">UID Field Label Placeholder</label>
                  <input
                    type="text"
                    placeholder="e.g. Enter Player UID"
                    value={newGame.uidPlaceholder}
                    onChange={(e) => setNewGame({ ...newGame, uidPlaceholder: e.target.value })}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Publish Game / Item</span>
                  </button>
                </div>
              </form>
            </div>

            {/* List of Games / Items with Edit & Delete */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-zinc-300">All Registered Games & Items ({games.length})</h3>
                {games.length > 0 && (
                  <button
                    onClick={handleWipeAllGames}
                    className="px-3 py-1 bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Wipe All Games</span>
                  </button>
                )}
              </div>

              {games.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {games.map((g) => (
                    <div key={g.id} className={`p-4 rounded-2xl flex flex-col justify-between gap-3 ${cardBgClass}`}>
                      <div className="flex items-start gap-3">
                        <img src={g.iconUrl} alt={g.name} className="w-12 h-12 rounded-xl object-cover border border-zinc-700" />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-extrabold text-white text-sm truncate">{g.name}</h4>
                            <span className="text-[10px] bg-red-600/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full font-bold">
                              {g.category || 'Game'}
                            </span>
                          </div>
                          <p className="text-xs text-zinc-400 mt-1">{g.packages?.length || 0} packages listed</p>
                        </div>
                      </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                        <button
                          onClick={() => setEditingGame(g)}
                          className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-blue-400" /> Edit Game
                        </button>

                        <button
                          onClick={() => handleDeleteGame(g.id)}
                          className="p-1.5 bg-red-600/20 text-red-400 hover:bg-red-600 hover:text-white rounded-xl transition-all cursor-pointer"
                          title="Delete Game"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center rounded-2xl bg-zinc-900/60 border border-zinc-800 text-zinc-400">
                  <Gamepad2 className="w-10 h-10 mx-auto text-zinc-600 mb-2" />
                  <p className="text-sm font-bold text-zinc-300">No games or packages currently registered</p>
                  <p className="text-xs text-zinc-500 mt-1">Use the &quot;Publish Game / Item&quot; form above to add new games and packages manually.</p>
                </div>
              )}
            </div>

            {/* Edit Game Modal */}
            {editingGame && (
              <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
                <div className={`w-full max-w-md p-6 rounded-3xl space-y-4 ${cardBgClass}`}>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    <Edit3 className="w-4 h-4 text-blue-400" /> Edit Game: {editingGame.name}
                  </h3>

                  <form onSubmit={handleSaveGameEdit} className="space-y-3 text-xs">
                    <div>
                      <label className="block text-zinc-400 mb-1">Game Name</label>
                      <input
                        type="text"
                        value={editingGame.name}
                        onChange={(e) => setEditingGame({ ...editingGame, name: e.target.value })}
                        className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-zinc-400 mb-1">Category</label>
                      <input
                        type="text"
                        value={editingGame.category}
                        onChange={(e) => setEditingGame({ ...editingGame, category: e.target.value })}
                        className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                      />
                    </div>

                    <div>
                      <label className="block text-zinc-400 mb-1">Icon URL</label>
                      <input
                        type="url"
                        value={editingGame.iconUrl}
                        onChange={(e) => setEditingGame({ ...editingGame, iconUrl: e.target.value })}
                        className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                        required
                      />
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setEditingGame(null)}
                        className="flex-1 py-2 bg-zinc-800 text-zinc-300 font-bold rounded-xl cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl cursor-pointer"
                      >
                        Save Changes
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

          </div>
        )}

        {/* VIEW 3: GAME PRODUCT PRICING & PACKAGES (Matching Image 1 & Image 2) */}
        {activeSubItem === 'Packages' && (
          <div className="p-6 space-y-6 animate-fadeIn">

            {/* No Games Warning Banner */}
            {games.length === 0 && (
              <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-950/60 border border-amber-700/60 text-amber-300">
                <AlertTriangle className="w-5 h-5 mt-0.5 flex-shrink-0 text-amber-400" />
                <div>
                  <p className="text-sm font-bold text-amber-300">No Games / Products Added Yet</p>
                  <p className="text-xs text-amber-400/80 mt-0.5">
                    You need to add a game first before adding packages. Go to{' '}
                    <button
                      onClick={() => { setActiveMainSection('STORE'); setActiveSubItem('Products'); }}
                      className="underline font-bold text-amber-300 hover:text-white cursor-pointer"
                    >
                      Store → Products
                    </button>
                    {' '}and use the <span className="font-bold">"Publish Game / Item"</span> form to add Free Fire, PUBG etc.
                  </p>
                </div>
              </div>
            )}

            {/* Top Status Badge */}
            <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-emerald-950/60 border border-emerald-800/60 text-emerald-400 text-xs font-semibold w-fit shadow-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Real-Time Sync Active</span>
              <span className="text-zinc-600">|</span>
              <span className="text-zinc-300">Database: <strong className="text-white font-bold">Supabase PostgreSQL</strong></span>
            </div>

            {/* Top Header & Header Action Buttons */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <span>Product</span>
                  <span className="text-red-500">Package</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">Manage Game Packages & Pricing</p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  onClick={() => {
                    const isVoucher = selectedGame?.productType === 'voucher' || selectedGame?.category === 'Voucher' || /voucher|redeem/i.test(selectedGame?.name || '');
                    setNewPackage({
                      name: '',
                      diamonds: isVoucher ? 0 : 100,
                      priceNpr: 100,
                      bonus: 0,
                      badge: '',
                      iconType: isVoucher ? 'pass' : 'diamond',
                      requiresRedeemCode: isVoucher,
                    });
                    setEditingPackage(null);
                    setIsAddPackageModalOpen(true);
                  }}
                  className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-red-600/30 active:scale-95"
                >
                  <Plus className="w-4 h-4 text-white" />
                  <span>+ Add Package</span>
                </button>

                <button
                  onClick={handleRefreshPricing}
                  className="px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800/90 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <RefreshCw className={`w-4 h-4 text-zinc-400 ${isRefreshingPricing ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>

                <button
                  onClick={handleSaveAllPricingChanges}
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2 cursor-pointer text-xs"
                >
                  <Save className="w-4 h-4" />
                  <span>Save All Changes</span>
                </button>
              </div>
            </div>

            {/* Active Product Box (Image 1 / Image 2) */}
            <div className={`p-4 rounded-2xl border flex items-center justify-between gap-4 shadow-xl ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-800/60 flex items-center justify-center text-red-500 shadow-md shadow-red-950/40">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block">ACTIVE PRODUCT</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    {selectedGame?.iconUrl && (
                      <img src={selectedGame.iconUrl} alt={selectedGame.name} className="w-5 h-5 rounded-md object-cover border border-zinc-700/60" />
                    )}
                    <span className="text-base font-extrabold text-white">
                      {games.length === 0 ? 'No Products Added' : (selectedGame?.name || 'Select Product')}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer border ${
                  isProductDropdownOpen
                    ? 'bg-red-950/60 border-red-800/80 text-red-400'
                    : adminTheme === 'dark'
                    ? 'bg-zinc-950 border-zinc-800 text-zinc-200 hover:bg-zinc-800'
                    : 'bg-zinc-100 border-zinc-300 text-zinc-800'
                }`}
              >
                <span>Select Product</span>
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isProductDropdownOpen ? 'rotate-180 text-red-400' : ''}`} />
              </button>
            </div>

            {/* Expandable Product Selector Dropdown Drawer (IMAGE 1 SPEC) */}
            {isProductDropdownOpen && (
              <div className={`p-4 rounded-2xl border space-y-3 shadow-2xl animate-fadeIn ${adminTheme === 'dark' ? 'bg-zinc-900/95 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                {/* Search Input inside Dropdown */}
                <div className="relative">
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Filter products..."
                    value={productDropdownSearch}
                    onChange={(e) => setProductDropdownSearch(e.target.value)}
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl text-xs outline-none transition-all ${
                      adminTheme === 'dark'
                        ? 'bg-zinc-950 border border-red-900/50 text-white placeholder-zinc-500 focus:border-red-500'
                        : 'bg-zinc-50 border border-zinc-300 text-zinc-900'
                    }`}
                  />
                </div>

                {/* List of Products (Image 1) */}
                <div className="max-h-80 overflow-y-auto space-y-1.5 pr-1">
                  {availableProducts.length === 0 && (
                    <div className="py-6 text-center">
                      <p className="text-sm font-bold text-zinc-400">No products added yet</p>
                      <p className="text-xs text-zinc-500 mt-1">Go to <span className="text-red-400 font-bold">Store → Products</span> and use <span className="text-red-400 font-bold">"Add Product"</span> to create products first.</p>
                    </div>
                  )}
                  {availableProducts
                    .filter((g) => !productDropdownSearch || g.name.toLowerCase().includes(productDropdownSearch.toLowerCase()))
                    .map((g) => {
                      const isSelected = g.id === selectedGameId;
                      return (
                        <div
                          key={g.id}
                          onClick={() => {
                            setSelectedGameId(g.id);
                            setIsProductDropdownOpen(false);
                          }}
                          className={`p-3 rounded-xl flex items-center justify-between cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-blue-600 text-white font-bold shadow-lg shadow-blue-600/30'
                              : adminTheme === 'dark'
                              ? 'bg-zinc-950 hover:bg-zinc-800/80 text-zinc-200 border border-zinc-800/60'
                              : 'bg-zinc-50 hover:bg-zinc-100 text-zinc-800 border border-zinc-200'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <img src={g.iconUrl} alt={g.name} className="w-7 h-7 rounded-lg object-cover border border-white/20" />
                            <span className="text-xs font-bold">{g.name}</span>
                          </div>

                          {isSelected ? (
                            <span className="px-2.5 py-1 bg-white/20 rounded-md text-[11px] font-extrabold flex items-center gap-1.5">
                              <Check className="w-3.5 h-3.5" /> Selected
                            </span>
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-zinc-700"></div>
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* 4 Stat Cards for Active Selected Product (IMAGE 2 SPEC) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Total Packages */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Total Packages</span>
                    <span className="text-2xl font-black text-white mt-1 block">
                      {selectedGame?.packages.length || 0}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-red-950/60 border border-red-800/60 flex items-center justify-center text-red-500">
                    <Package className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Active Packages */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Active Packages</span>
                    <span className="text-2xl font-black text-emerald-400 mt-1 block">
                      {selectedGame?.packages.filter((p) => p.active !== false).length || 0}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Disabled Packages */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Disabled Packages</span>
                    <span className="text-2xl font-black text-amber-400 mt-1 block">
                      {selectedGame?.packages.filter((p) => p.active === false).length || 0}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-amber-950/60 border border-amber-800/60 flex items-center justify-center text-amber-400">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Last Updated */}
              <div className={`p-4 rounded-2xl border ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Last Updated</span>
                    <span className="text-base font-black text-purple-400 mt-1 block font-mono">
                      28 July 2026
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-purple-950/60 border border-purple-800/60 flex items-center justify-center text-purple-400">
                    <Calendar className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>

            {/* Package Search & Sort Bar (IMAGE 2 SPEC) */}
            <div className={`p-3 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-3 ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search packages..."
                  value={packageSearchQuery}
                  onChange={(e) => setPackageSearchQuery(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2 rounded-xl text-xs outline-none ${
                    adminTheme === 'dark'
                      ? 'bg-zinc-950 border border-zinc-800 text-white placeholder-zinc-500 focus:border-red-500'
                      : 'bg-zinc-50 border border-zinc-300 text-zinc-900'
                  }`}
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <span className="text-xs text-zinc-400 font-semibold whitespace-nowrap">Sort:</span>
                <select
                  value={packageSortBy}
                  onChange={(e) => setPackageSortBy(e.target.value)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold outline-none cursor-pointer ${
                    adminTheme === 'dark' ? 'bg-zinc-950 border border-zinc-800 text-zinc-200' : 'bg-zinc-50 border border-zinc-300 text-zinc-800'
                  }`}
                >
                  <option value="Newest">Newest</option>
                  <option value="Lowest">Lowest Price</option>
                  <option value="Highest">Highest Price</option>
                  <option value="Name">Name</option>
                </select>
              </div>
            </div>

            {/* Package Pricing Table (IMAGE 2 SPEC) */}
            <div className={`rounded-2xl border overflow-hidden shadow-xl ${adminTheme === 'dark' ? 'bg-zinc-900/90 border-zinc-800/90' : 'bg-white border-zinc-200'}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-zinc-800/80 text-[11px] font-bold text-zinc-400 uppercase tracking-wider bg-zinc-950/40">
                      <th className="py-3.5 px-4">PACKAGE</th>
                      <th className="py-3.5 px-4">PRICE (RS)</th>
                      <th className="py-3.5 px-4">ACTIVE</th>
                      <th className="py-3.5 px-4 text-right">ACTION</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50 text-xs">
                    {(selectedGame?.packages || [])
                      .filter((pkg) => {
                        if (!packageSearchQuery.trim()) return true;
                        const q = packageSearchQuery.toLowerCase().trim();
                        return (
                          pkg.name.toLowerCase().includes(q) ||
                          String(pkg.diamonds).includes(q) ||
                          String(pkg.priceNpr).includes(q)
                        );
                      })
                      .sort((a, b) => {
                        if (packageSortBy === 'Lowest') return a.priceNpr - b.priceNpr;
                        if (packageSortBy === 'Highest') return b.priceNpr - a.priceNpr;
                        if (packageSortBy === 'Name') return a.name.localeCompare(b.name);
                        return 0;
                      })
                      .map((pkg) => {
                        const isActive = pkg.active !== false;
                        return (
                          <tr key={pkg.id} className="hover:bg-zinc-800/30 transition-colors">
                            {/* PACKAGE */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-7 h-7 rounded-lg bg-blue-950/80 border border-blue-800/60 flex items-center justify-center text-blue-400 font-extrabold text-xs shadow-sm">
                                  ◆
                                </div>
                                <div>
                                  <span className="font-extrabold text-white text-xs block">{pkg.name}</span>
                                  {pkg.badge && (
                                    <span className="text-[10px] text-red-400 font-bold bg-red-950/60 border border-red-800/40 px-1.5 py-0.2 rounded mt-0.5 inline-block">
                                      {pkg.badge}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </td>

                            {/* PRICE (RS) */}
                            <td className="py-3.5 px-4 font-extrabold text-white text-xs font-mono">
                              ₹ {pkg.priceNpr.toLocaleString()}
                            </td>

                            {/* ACTIVE RED TOGGLE */}
                            <td className="py-3.5 px-4">
                              <button
                                onClick={() => handleTogglePackageActive(pkg.id)}
                                className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer relative ${
                                  isActive ? 'bg-red-600' : 'bg-zinc-800'
                                }`}
                                title="Click to toggle active state"
                              >
                                <div
                                  className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 ${
                                    isActive ? 'translate-x-5' : 'translate-x-0'
                                  }`}
                                ></div>
                              </button>
                            </td>

                            {/* ACTION BUTTONS */}
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => setPreviewPackage(pkg)}
                                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-lg transition-all cursor-pointer border border-zinc-700/50"
                                  title="Preview Package Card"
                                >
                                  <Eye className="w-3.5 h-3.5 text-blue-400" />
                                </button>

                                <button
                                  onClick={() => handleDuplicatePackage(selectedGameId, pkg)}
                                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-lg transition-all cursor-pointer border border-zinc-700/50"
                                  title="Duplicate Package"
                                >
                                  <Copy className="w-3.5 h-3.5 text-purple-400" />
                                </button>

                                <button
                                  onClick={() => setEditingPackage({ gameId: selectedGameId, pkg })}
                                  className="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-bold transition-all cursor-pointer border border-zinc-700/50 shadow-sm"
                                  title="Edit Package"
                                >
                                  Edit
                                </button>

                                <button
                                  onClick={() => handleDeletePackage(selectedGameId, pkg.id, pkg.name)}
                                  className="p-1.5 bg-red-950/60 hover:bg-red-600 text-red-400 hover:text-white rounded-lg transition-all cursor-pointer border border-red-800/40"
                                  title="Delete Package"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>



            {/* Save Toast Banner */}
            {pricingSaveToast && (
              <div className="fixed bottom-6 right-6 z-50 px-5 py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-2xl flex items-center gap-2 animate-bounce">
                <Check className="w-4 h-4" />
                <span>{pricingSaveToast}</span>
              </div>
            )}

            {/* Edit Package Modal */}
            {editingPackage && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="w-full max-w-md p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 shadow-2xl">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                    <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                      <Edit3 className="w-4 h-4 text-red-500" />
                      <span>Edit Package: {editingPackage.pkg.name}</span>
                    </h3>
                    <button
                      onClick={() => setEditingPackage(null)}
                      className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 cursor-pointer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {(() => {
                    const isVoucherProduct = selectedGame?.productType === 'voucher' || selectedGame?.category === 'Voucher' || /voucher|redeem/i.test(selectedGame?.name || '') || editingPackage.pkg.requiresRedeemCode === true;

                    return (
                      <form onSubmit={handleSavePackageEdit} className="space-y-3 text-xs">
                        <div>
                          <label className="block text-zinc-400 mb-1 font-semibold">Package Name *</label>
                          <input
                            type="text"
                            value={editingPackage.pkg.name}
                            onChange={(e) => setEditingPackage({
                              ...editingPackage,
                              pkg: { ...editingPackage.pkg, name: e.target.value }
                            })}
                            placeholder="e.g. Unipin Voucher"
                            className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-zinc-400 mb-1 font-semibold">Price (Rs / NPR) *</label>
                          <input
                            type="number"
                            value={editingPackage.pkg.priceNpr}
                            onChange={(e) => setEditingPackage({
                              ...editingPackage,
                              pkg: { ...editingPackage.pkg, priceNpr: Number(e.target.value) }
                            })}
                            className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500"
                            required
                            min="1"
                          />
                        </div>

                        {/* Diamonds field: Only rendered for standard top-up games, hidden for Vouchers */}
                        {!isVoucherProduct && (
                          <div>
                            <label className="block text-zinc-400 mb-1 font-semibold">Diamonds / In-Game Currency *</label>
                            <input
                              type="number"
                              value={editingPackage.pkg.diamonds}
                              onChange={(e) => setEditingPackage({
                                ...editingPackage,
                                pkg: { ...editingPackage.pkg, diamonds: Number(e.target.value) }
                              })}
                              className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500"
                              required
                            />
                          </div>
                        )}

                        <div>
                          <label className="block text-zinc-400 mb-1 font-semibold">Badge Tag</label>
                          <input
                            type="text"
                            value={editingPackage.pkg.badge || ''}
                            onChange={(e) => setEditingPackage({
                              ...editingPackage,
                              pkg: { ...editingPackage.pkg, badge: e.target.value }
                            })}
                            placeholder="e.g. HOT, POPULAR"
                            className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500"
                          />
                        </div>

                        {(() => {
                          const gameName = String(selectedGame?.name || '').toLowerCase();
                          const gameId   = String(selectedGame?.id   || '').toLowerCase();
                          const isLikelyMlbb =
                            isMlbbBrazilGame(selectedGame) ||
                            gameName.includes('legend') ||
                            gameName.includes('mobile') ||
                            gameId.includes('legend') ||
                            gameId.includes('mobile');
                          return isLikelyMlbb ? (
                            <div>
                              <label className="block text-zinc-400 mb-1 font-semibold">
                                Liana Product ID (MLBB Auto-Delivery) *
                                <span className="ml-2 text-[10px] text-zinc-500 font-normal">
                                  Game: {selectedGame?.name} | ID: {selectedGame?.id}
                                </span>
                              </label>
                              <input
                                type="number"
                                placeholder="e.g. 4"
                                value={(editingPackage.pkg as any).product_id ?? (editingPackage.pkg as any).variation_id ?? ''}
                                onChange={(e) => setEditingPackage({
                                  ...editingPackage,
                                  pkg: { ...editingPackage.pkg, product_id: e.target.value ? Number(e.target.value) : undefined, variation_id: undefined }
                                })}
                                className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 font-mono"
                              />
                              <p className="text-[10px] text-zinc-500 mt-1">Exact product_id from Liana Store's /products response for this diamond pack.</p>
                            </div>
                          ) : null;
                        })()}

                        <label className="flex items-center justify-between gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                          <div>
                            <div className="text-white font-bold">Requires Redeem Code</div>
                            <div className="text-[10px] text-zinc-500">Reserve and automatically deliver voucher inventory after successful payment.</div>
                          </div>
                          <input
                            type="checkbox"
                            checked={editingPackage.pkg.requiresRedeemCode === true || isVoucherProduct}
                            onChange={(e) => setEditingPackage({ ...editingPackage, pkg: { ...editingPackage.pkg, requiresRedeemCode: e.target.checked } })}
                            className="w-4 h-4 accent-red-600"
                          />
                        </label>

                        <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                          <button
                            type="button"
                            onClick={() => setEditingPackage(null)}
                            className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 cursor-pointer"
                          >
                            Save Changes
                          </button>
                        </div>
                      </form>
                    );
                  })()}
                </div>
              </div>
            )}

          </div>
        )}



        {/* VIEW 5: BANNERS */}
        {activeSubItem === 'Banners' && (
          <div className="p-4 md:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3"><div><div className="text-[10px] font-black uppercase tracking-[0.18em] text-red-500">Store Management</div><h2 className="text-2xl md:text-3xl font-black admin-heading">Carousel Banners</h2><p className="text-xs admin-muted mt-1">Manage the promotional banners shown on your homepage.</p></div><div className={`px-4 py-3 rounded-2xl border ${cardBgClass}`}><div className="text-[10px] admin-muted">Total Active Banners</div><div className="text-2xl font-black admin-heading">{banners.filter(b=>b.active!==false).length}</div></div></div>
            <div className={`p-5 rounded-2xl border ${cardBgClass}`}><div className="flex items-center gap-2 mb-4"><div className="w-8 h-8 rounded-lg bg-red-500/10 text-red-500 flex items-center justify-center"><Plus className="w-4 h-4"/></div><h3 className="text-sm font-black admin-heading">Add New Banner</h3></div><form onSubmit={handleAddBanner} className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
              <div className="lg:col-span-4"><label className="block text-[10px] font-bold admin-muted mb-1.5">Banner Image URL *</label><div className="relative"><ImageIcon className="w-4 h-4 absolute left-3 top-3 text-slate-400"/><input type="url" placeholder="https://..." value={newBanner.imageUrl} onChange={e=>setNewBanner({...newBanner,imageUrl:e.target.value})} className={`w-full pl-9 pr-3 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`} required/></div></div>
              <div className="lg:col-span-3"><label className="block text-[10px] font-bold admin-muted mb-1.5">Main Title *</label><input value={newBanner.title} onChange={e=>setNewBanner({...newBanner,title:e.target.value})} placeholder="FREE FIRE 100% DIAMOND BONUS" className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`} required/></div>
              <div className="lg:col-span-3"><label className="block text-[10px] font-bold admin-muted mb-1.5">Subtitle / Description</label><input value={newBanner.subtitle} onChange={e=>setNewBanner({...newBanner,subtitle:e.target.value})} placeholder="Instant delivery..." className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`}/></div>
              <button type="submit" className="lg:col-span-2 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-black shadow-lg shadow-red-600/20 flex items-center justify-center gap-2"><Plus className="w-4 h-4"/> Add Banner</button>
            </form></div>
            <div className={`rounded-2xl border overflow-hidden ${cardBgClass}`}><div className={`px-4 py-3 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${isDark?'border-zinc-800':'border-slate-200'}`}><div><h3 className="text-sm font-black admin-heading">Active Banners ({banners.length})</h3><p className="text-[10px] admin-muted">Drag to reorder • Toggle visibility • Edit content</p></div><span className="text-[10px] font-bold admin-muted">{banners.filter(b=>b.active!==false).length} visible</span></div>
              <div>{banners.map((b,idx)=><div key={b.id} draggable onDragStart={()=>setBannerDragId(b.id)} onDragOver={e=>e.preventDefault()} onDrop={()=>handleBannerDrop(b.id)} className={`group px-4 py-4 flex flex-col lg:flex-row lg:items-center gap-4 border-b last:border-b-0 transition-all ${isDark?'border-zinc-800/80 hover:bg-zinc-900/60':'border-slate-100 hover:bg-slate-50'} ${bannerDragId===b.id?'opacity-50':''}`}>
                <div className="flex items-center gap-3 lg:w-[42%] min-w-0"><Move className="w-4 h-4 admin-muted cursor-grab flex-shrink-0"/><img src={b.imageUrl} alt={b.title} className="w-44 h-20 object-cover rounded-xl border border-black/10 flex-shrink-0 bg-slate-100"/><div className="min-w-0"><span className="inline-flex text-[9px] font-black px-2 py-1 rounded-full bg-red-500/10 text-red-500">{b.badge||'PROMO'}</span><h4 className="text-xs font-black admin-heading mt-1 truncate">{b.title}</h4><p className="text-[10px] admin-muted truncate">{b.subtitle}</p></div></div>
                <div className="flex items-center gap-5 lg:flex-1"><div><div className="text-[9px] admin-muted">Position</div><div className="text-xs font-black admin-heading">#{idx+1}</div></div><div><div className="text-[9px] admin-muted">Status</div><button onClick={()=>handleToggleBanner(b)} className={`mt-1 w-10 h-5 rounded-full p-0.5 transition-colors ${b.active!==false?'bg-emerald-500':'bg-slate-300'}`}><span className={`block w-4 h-4 rounded-full bg-white shadow transition-transform ${b.active!==false?'translate-x-5':'translate-x-0'}`}/></button></div><div className={`text-[10px] font-bold ${b.active!==false?'text-emerald-500':'admin-muted'}`}>{b.active!==false?'Active':'Hidden'}</div></div>
                <div className="flex items-center gap-2 lg:ml-auto"><button onClick={()=>setEditingBanner(b)} className={`p-2.5 rounded-xl border ${isDark?'border-zinc-700 text-zinc-300 hover:bg-zinc-800':'border-slate-200 text-slate-700 hover:bg-slate-100'}`} title="Edit banner"><Edit3 className="w-4 h-4"/></button><button onClick={()=>handleDeleteBanner(b.id)} className="p-2.5 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-colors" title="Delete banner"><Trash2 className="w-4 h-4"/></button></div>
              </div>)}</div>
              {banners.length===0&&<div className="p-12 text-center admin-muted text-xs">No banners added yet.</div>}
            </div>
          </div>
        )}

        {editingBanner && (
          <div className="fixed inset-0 z-[90] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"><form onSubmit={handleSaveBannerEdit} className={`w-full max-w-2xl rounded-2xl border p-5 shadow-2xl ${cardBgClass}`}><div className="flex items-center justify-between mb-5"><div><h3 className="text-lg font-black admin-heading">Edit Banner</h3><p className="text-[10px] admin-muted">Update homepage promotion content.</p></div><button type="button" onClick={()=>setEditingBanner(null)} className="p-2 rounded-lg admin-muted hover:text-red-500"><X className="w-4 h-4"/></button></div><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><div className="md:col-span-2"><label className="block text-[10px] font-bold admin-muted mb-1.5">Image URL</label><input value={editingBanner.imageUrl} onChange={e=>setEditingBanner({...editingBanner,imageUrl:e.target.value})} className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`}/></div><div><label className="block text-[10px] font-bold admin-muted mb-1.5">Title</label><input value={editingBanner.title} onChange={e=>setEditingBanner({...editingBanner,title:e.target.value})} className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`}/></div><div><label className="block text-[10px] font-bold admin-muted mb-1.5">Badge</label><input value={editingBanner.badge||''} onChange={e=>setEditingBanner({...editingBanner,badge:e.target.value})} className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`}/></div><div className="md:col-span-2"><label className="block text-[10px] font-bold admin-muted mb-1.5">Subtitle</label><textarea value={editingBanner.subtitle} onChange={e=>setEditingBanner({...editingBanner,subtitle:e.target.value})} className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none min-h-24 ${inputBgClass}`}/></div></div><div className="flex justify-end gap-2 mt-5"><button type="button" onClick={()=>setEditingBanner(null)} className={`px-4 py-2 rounded-xl text-xs font-bold border ${isDark?'border-zinc-700 text-zinc-300':'border-slate-200 text-slate-700'}`}>Cancel</button><button type="submit" className="px-5 py-2 rounded-xl bg-red-600 text-white text-xs font-black">Save Changes</button></div></form></div>
        )}

        {/* VIEW 6: ORDERS LIST - Replicated Order Management Section & Order Details Drawer */}
        {(activeMainSection === 'ORDERS' || activeSubItem === 'Orders List') && (() => {
          // allOrders already removes unpaid/pending Fonepay Hub checkouts.
          // The regular Orders page therefore receives only confirmed Fonepay Hub
          // purchases, while pending ones stay in Instant/API Payments.
          const displayOrders = allOrders.filter((ord) => {
            // Order Management is for product purchases. Wallet recharges keep
            // their dedicated instant-payment history instead.
            const isWalletRecharge =
              ord.gameId === 'wallet-load' ||
              ord.packageId === 'wallet-recharge';
            return !isWalletRecharge;
          });

          const handleCopyText = (text: string, label: string) => {
            if (!text) return;
            navigator.clipboard.writeText(text);
            setCopiedField(label);
            setTimeout(() => setCopiedField(null), 2000);
          };

          // Filter logic
          const filteredDisplayOrders = displayOrders.filter((ord) => {
            if (orderCategoryFilter !== 'ALL' && ord.gameName !== orderCategoryFilter) return false;
            if (orderStatusFilter !== 'ALL') {
              const statusUpper = (ord.status || '').toUpperCase();
              if (orderStatusFilter === 'Completed' && statusUpper !== 'COMPLETED') return false;
              if (orderStatusFilter === 'Cancelled' && statusUpper !== 'CANCELLED') return false;
              if (orderStatusFilter === 'Pending' && (statusUpper === 'COMPLETED' || statusUpper === 'CANCELLED')) return false;
              if (orderStatusFilter === 'Processing' && statusUpper !== 'PROCESSING') return false;
            }
            if (searchQuery.trim()) {
              const q = searchQuery.toLowerCase().trim();
              return (
                (ord.orderId || '').toLowerCase().includes(q) ||
                (ord.gameName || '').toLowerCase().includes(q) ||
                (ord.packageName || '').toLowerCase().includes(q) ||
                (ord.playerName || '').toLowerCase().includes(q) ||
                (ord.playerUid || '').toLowerCase().includes(q) ||
                ((ord as any).playerEmail || '').toLowerCase().includes(q) ||
                String(ord.totalPriceNpr || '').includes(q) ||
                (ord.status || '').toLowerCase().includes(q)
              );
            }
            return true;
          });

          const getStatusBadge = (ord: Order) => {
            const statusUpper = (ord.status || 'PENDING').toUpperCase();
            if (statusUpper === 'COMPLETED') {
              return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  Completed
                </span>
              );
            }
            if (statusUpper === 'CANCELLED') {
              return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                  Cancelled
                </span>
              );
            }
            if (statusUpper === 'PROCESSING') {
              return (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                  Processing
                </span>
              );
            }
            return (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                Pending
              </span>
            );
          };

          const handleApproveOrder = async (ord: Order) => {
            setOrderApproveLoading(ord.orderId);
            try {
              console.log('[Admin] Approving order:', ord.orderId);
              const result = await adminUpdateOrderStatus(ord.orderId, 'Completed', adminUser?.uid || 'admin');
              const success = result.success;
              console.log('[Admin] adminUpdateOrderStatus result:', result);
              if (success) {
                // adminUpdateOrderStatus already performs the complete status update +
                // user notification. Do NOT call it a second time here, otherwise
                // the same order-completion notification is created twice.
                // Refresh email record
                setTimeout(() => {
                  getOrderEmailDeliveryStatus(ord.orderId).then((r) => r && setOrderEmailRecord(r));
                }, 1200);
                // Close order details modal immediately so page/drawer closes
                setOrderDetailModal(null);
                setOrderActionSuccessMsg(result.emailSent === false
                  ? `Order #${ord.orderId} completed, but confirmation email could not be sent. You can manually resend it.`
                  : `Order #${ord.orderId} marked as COMPLETED successfully!`);
                setTimeout(() => setOrderActionSuccessMsg(null), 5000);
              } else {
                alert('Failed to complete order in database. Please check console for details.');
              }
            } catch (err) {
              console.error('[Admin] Failed to approve order:', err);
              alert('Error completing order: ' + (err as any)?.message);
            } finally {
              setOrderApproveLoading(null);
            }
          };

          const handleSendOrRetryOrderEmail = async (ord: Order) => {
            setManualEmailSending(true);
            setManualEmailMsg(null);
            try {
              const isVoucher = isRedeemCodeOrder(ord);
              const res = await sendTransactionalEmail({
                type: isVoucher ? 'voucher_delivered' : 'order_completed',
                orderId: ord.orderId,
              });
              if (res.success) {
                setManualEmailMsg('Transactional email dispatched successfully via Resend!');
                const updatedRec = await getOrderEmailDeliveryStatus(ord.orderId);
                if (updatedRec) setOrderEmailRecord(updatedRec);
              } else {
                setManualEmailMsg(`Email error: ${res.message || 'Failed to dispatch'}`);
              }
            } catch (err: any) {
              setManualEmailMsg(`Failed: ${err?.message || 'Network error'}`);
            } finally {
              setManualEmailSending(false);
              setTimeout(() => setManualEmailMsg(null), 6000);
            }
          };

          const handleOpenRejectOrder = (ord: Order) => {
            setRejectOrderModal(ord);
            setRejectOrderReason('');
          };

          const handleConfirmRejectOrder = async () => {
            if (!rejectOrderModal) return;
            const result = await adminUpdateOrderStatus(rejectOrderModal.orderId, 'Cancelled', adminUser?.uid || 'admin', rejectOrderReason);
            if (result.success) {
              setOrderDetailModal(null);
              const refundMsg = result.refundAmount
                ? ` NPR ${result.refundAmount.toLocaleString('en-IN')} refunded to user's UG Wallet.`
                : '';
              setOrderActionSuccessMsg(`Order #${rejectOrderModal.orderId} has been CANCELLED.${refundMsg}`);
              setTimeout(() => setOrderActionSuccessMsg(null), 7000);
            }
            setRejectOrderModal(null);
            setRejectOrderReason('');
          };

          return (
            <div className="p-6 space-y-6 animate-fadeIn">
              {/* Header Title Block */}
              <div>
                <h2 className="text-2xl font-black text-white tracking-tight">
                  Order Management
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Manage all product orders from users
                </p>
              </div>

              {/* Order Status Action Banner */}
              {orderActionSuccessMsg && (
                <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-xs flex items-center justify-between shadow-lg animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>{orderActionSuccessMsg}</span>
                  </div>
                  <button onClick={() => setOrderActionSuccessMsg(null)} className="text-zinc-400 hover:text-white text-xs font-bold px-2 py-0.5 rounded bg-zinc-800">
                    Dismiss
                  </button>
                </div>
              )}

              {/* Filter & Search Bar */}
              <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
                {/* Search Input */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by order ID, user, product..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl text-xs bg-[#111111] border border-zinc-800 text-white placeholder-zinc-500 outline-none focus:border-red-500 transition-colors"
                  />
                </div>

                {/* Filter Dropdowns & Date Selector */}
                <div className="flex flex-wrap items-center gap-2.5">
                  {/* Status Dropdown */}
                  <select
                    value={orderStatusFilter}
                    onChange={(e) => setOrderStatusFilter(e.target.value as any)}
                    className="px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-[#111111] border border-zinc-800 text-zinc-200 outline-none cursor-pointer focus:border-zinc-700"
                  >
                    <option value="ALL">All Status</option>
                    <option value="Pending">Pending</option>
                    <option value="Processing">Processing</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>

                  {/* Product Category Dropdown */}
                  <select
                    value={orderCategoryFilter}
                    onChange={(e) => setOrderCategoryFilter(e.target.value)}
                    className="px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-[#111111] border border-zinc-800 text-zinc-200 outline-none cursor-pointer focus:border-zinc-700"
                  >
                    <option value="ALL">All Products</option>
                    {Array.from(new Set(displayOrders.map((o) => o.gameName))).filter(Boolean).map((g) => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>

                  {/* Date Range Selector Button */}
                  <button
                    className="px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-[#111111] border border-zinc-800 text-zinc-300 flex items-center gap-2 hover:bg-zinc-900 transition-colors cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5 text-zinc-400" />
                    <span>01/07/2026 - 26/07/2026</span>
                    <ChevronDown className="w-3.5 h-3.5 text-zinc-500" />
                  </button>
                </div>
              </div>

              {/* Table Container */}
              <div className="rounded-2xl border border-zinc-800/80 bg-[#0a0a0a] overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-zinc-800/80 text-[11px] font-bold text-zinc-400 uppercase tracking-wider bg-[#111111]">
                        <th className="py-4 px-5">ORDER</th>
                        <th className="py-4 px-5">PRODUCT</th>
                        <th className="py-4 px-5">CUSTOMER</th>
                        <th className="py-4 px-5">AMOUNT</th>
                        <th className="py-4 px-5">STATUS</th>
                        <th className="py-4 px-5">DATE</th>
                        <th className="py-4 px-5 text-right">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/50 text-xs">
                      {filteredDisplayOrders.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-12 text-center text-zinc-500">
                            No orders found matching your search criteria
                          </td>
                        </tr>
                      ) : (
                        filteredDisplayOrders.map((ord) => {
                          const orderDate = new Date(ord.createdAt);
                          const formattedDate = isNaN(orderDate.getTime())
                            ? ord.createdAt
                            : orderDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

                          const customerMatchedUser = usersList.find((u) => 
                            (ord.userId && u.id === ord.userId) ||
                            ((ord as any).uid && u.id === (ord as any).uid) ||
                            (u.email && ord.userEmail && u.email.toLowerCase().trim() === ord.userEmail.toLowerCase().trim()) ||
                            (u.email && (ord as any).playerEmail && u.email.toLowerCase().trim() === (ord as any).playerEmail.toLowerCase().trim())
                          );
                          const customerEmailVal = customerMatchedUser?.email || ord.userEmail || (ord as any).playerEmail || 'No email registered';
                          const customerNameVal = customerMatchedUser?.username || ord.playerName || ord.playerUid || 'Customer';

                          return (
                            <tr key={ord.orderId} className="hover:bg-zinc-900/40 transition-colors">
                              {/* ORDER */}
                              <td className="py-4 px-5">
                                <span className="font-mono font-bold text-white block">
                                  #{ord.orderId}
                                </span>
                                <span className="text-[11px] text-zinc-500 block mt-0.5">
                                  {ord.packageName}
                                </span>
                              </td>

                              {/* PRODUCT */}
                              <td className="py-4 px-5">
                                <span className="font-bold text-white block">
                                  {ord.gameName}
                                </span>
                                <span className="text-[11px] text-zinc-500 block mt-0.5">
                                  {ord.packageName}
                                </span>
                              </td>

                              {/* CUSTOMER */}
                              <td className="py-4 px-5">
                                <span className="font-bold text-white block">
                                  {customerNameVal}
                                </span>
                                <span className="text-[11px] text-zinc-500 block mt-0.5 font-mono">
                                  {customerEmailVal}
                                </span>
                              </td>

                              {/* AMOUNT */}
                              <td className="py-4 px-5 font-bold text-white font-mono">
                                ₹{ord.totalPriceNpr}
                              </td>

                              {/* STATUS */}
                              <td className="py-4 px-5">
                                {getStatusBadge(ord)}
                              </td>

                              {/* DATE */}
                              <td className="py-4 px-5 text-zinc-400 font-medium">
                                {formattedDate}
                              </td>

                              {/* ACTION */}
                              <td className="py-4 px-5 text-right">
                                <button
                                  onClick={() => setOrderDetailModal(ord)}
                                  className="px-3.5 py-1.5 bg-[#141414] hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1 shadow-sm"
                                >
                                  <span>View Details</span>
                                  <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SLIDE-OVER DRAWER FOR ORDER DETAILS */}
              {orderDetailModal && (() => {
                const ord = orderDetailModal;
                const statusUpper = (ord.status || 'PENDING').toUpperCase();
                const isPending = statusUpper !== 'COMPLETED' && statusUpper !== 'CANCELLED';
                const isApproving = orderApproveLoading === ord.orderId;
                const orderDateObj = new Date(ord.createdAt);
                const fullFormattedDateTime = isNaN(orderDateObj.getTime())
                  ? ord.createdAt
                  : `${orderDateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}, ${orderDateObj.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;

                return (
                  <div className="fixed inset-0 z-50 flex justify-end">
                    {/* Darkened Backdrop Overlay */}
                    <div
                      onClick={() => setOrderDetailModal(null)}
                      className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
                    />

                    {/* Right Slide-Over Panel */}
                    <div className="relative w-full max-w-lg bg-[#0d0d0d] border-l border-zinc-800/90 shadow-2xl z-50 flex flex-col h-full overflow-hidden animate-in slide-in-from-right duration-300">
                      
                      {/* Drawer Header */}
                      <div className="p-5 bg-[#121212] border-b border-zinc-800 flex items-start justify-between flex-shrink-0">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-bold text-white">Order Details</h3>
                            <span className="px-2.5 py-0.5 rounded bg-zinc-800 text-zinc-300 text-xs font-mono font-bold">
                              #{ord.orderId}
                            </span>
                          </div>
                          <p className="text-xs text-zinc-400 mt-1">
                            Review customer credentials before fulfilling order
                          </p>
                        </div>

                        <button
                          onClick={() => setOrderDetailModal(null)}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>

                      {/* Toast notification inside drawer when copying */}
                      {copiedField && (
                        <div className="bg-red-600 text-white text-xs font-bold px-4 py-2 text-center flex items-center justify-center gap-2 shadow-md">
                          <Check className="w-3.5 h-3.5" />
                          <span>{copiedField} copied to clipboard!</span>
                        </div>
                      )}

                      {/* Drawer Body - Scrollable Content Cards */}
                      <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
                        
                        {/* 1. CURRENT STATUS CARD */}
                        <div className="p-4 rounded-xl bg-[#141414] border border-zinc-800/80 space-y-2">
                          <div className="text-zinc-400 font-semibold uppercase tracking-wider text-[10px]">
                            Current Status
                          </div>
                          <div className="flex items-center justify-between gap-3">
                            <div>
                              {getStatusBadge(ord)}
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] text-zinc-500 block">Order Date & Time</span>
                              <span className="text-zinc-300 font-mono text-[11px] font-semibold">{fullFormattedDateTime}</span>
                            </div>
                          </div>
                        </div>

                        {/* 2. CUSTOMER GAME ACCOUNT INFO CARD */}
                        <div className="p-4 rounded-xl bg-[#141414] border border-red-900/30 space-y-3">
                          <h4 className="text-xs font-bold text-red-500 flex items-center gap-1.5 uppercase tracking-wider">
                            <Gamepad2 className="w-4 h-4 text-red-500" />
                            Customer Game Account Info
                          </h4>

                          {isRedeemCodeOrder(ord) ? (
                            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-2.5">
                              <Gift className="w-4 h-4 text-amber-400 flex-shrink-0" />
                              <span>Digital Redeem Code Package (Auto Delivered - No Player ID required)</span>
                            </div>
                          ) : (
                            <div className="space-y-2.5">
                              {/* Player ID — hide if it's a dummy auto-generated value (game only uses customFields) */}
                              {(() => {
                                const isDummyUid = !ord.playerUid || /^USER_\d+$/i.test(ord.playerUid.trim()) || ord.playerUid.trim() === 'PLAYER';
                                const hasSavedCustomFields = Array.isArray(ord.customFieldValues) && ord.customFieldValues.filter((f: any) => f.value).length > 0;
                                const ordGame = games.find(g => g.id === ord.gameId);
                                const gameHasCustomFields = Array.isArray((ordGame as any)?.customFields) && (ordGame as any).customFields.length > 0;
                                const hasOnlyCustomFields = isDummyUid && (hasSavedCustomFields || gameHasCustomFields);
                                if (hasOnlyCustomFields) return null;
                                return (
                                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                    <div>
                                      <span className="text-[10px] text-zinc-500 block">Player ID</span>
                                      <span className="text-sm font-bold text-white font-mono">{ord.playerUid || 'N/A'}</span>
                                    </div>
                                    <button
                                      onClick={() => handleCopyText(ord.playerUid, 'Player ID')}
                                      className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                    >
                                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                      <span>Copy</span>
                                    </button>
                                  </div>
                                );
                              })()}

                              {/* In-Game Name — hide if dummy (game only uses customFields) */}
                              {(() => {
                                const isDummyUid = !ord.playerUid || /^USER_\d+$/i.test(ord.playerUid.trim()) || ord.playerUid.trim() === 'PLAYER';
                                const isDummyName = !ord.playerName || ord.playerName === ord.playerUid || /^USER_\d+$/i.test(ord.playerName.trim()) || ord.playerName.trim() === 'PLAYER';
                                const hasSavedCF = Array.isArray(ord.customFieldValues) && ord.customFieldValues.filter((f: any) => f.value).length > 0;
                                const ordGame2 = games.find(g => g.id === ord.gameId);
                                const gameHasCF = Array.isArray((ordGame2 as any)?.customFields) && (ordGame2 as any).customFields.length > 0;
                                const hasOnlyCustomFields = isDummyUid && isDummyName && (hasSavedCF || gameHasCF);
                                if (hasOnlyCustomFields) return null;
                                return (
                                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                    <div>
                                      <span className="text-[10px] text-zinc-500 block">In-Game Name</span>
                                      <span className="text-sm font-bold text-white">{ord.playerName || 'N/A'}</span>
                                    </div>
                                    <button
                                      onClick={() => handleCopyText(ord.playerName || '', 'In-Game Name')}
                                      className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                    >
                                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                      <span>Copy</span>
                                    </button>
                                  </div>
                                );
                              })()}

                              {/* Zone / Server ID if present */}
                              {ord.zoneId && (
                                <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                  <div>
                                    <span className="text-[10px] text-zinc-500 block">Zone / Server ID</span>
                                    <span className="text-sm font-bold text-white font-mono">{ord.zoneId}</span>
                                  </div>
                                  <button
                                    onClick={() => handleCopyText(ord.zoneId!, 'Zone ID')}
                                    className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                  >
                                    <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                    <span>Copy</span>
                                  </button>
                                </div>
                              )}

                            {/* Customer Email if provided */}
                            {ord.userEmail && (
                              <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">Customer Email</span>
                                  <span className="text-sm font-bold text-emerald-400 font-mono">{ord.userEmail}</span>
                                </div>
                                <button
                                  onClick={() => handleCopyText(ord.userEmail || '', 'Customer Email')}
                                  className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                >
                                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Copy</span>
                                </button>
                              </div>
                            )}

                            {/* Customer Password if provided */}
                            {ord.userPassword && (
                              <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">Account Password / PIN</span>
                                  <span className="text-sm font-bold text-amber-400 font-mono">{ord.userPassword}</span>
                                </div>
                                <button
                                  onClick={() => handleCopyText(ord.userPassword || '', 'Password')}
                                  className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                >
                                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Copy</span>
                                </button>
                              </div>
                            )}

                            {/* WhatsApp Link/Number if provided */}
                            {ord.userWhatsapp && (
                              <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">WhatsApp Contact</span>
                                  <span className="text-sm font-bold text-emerald-400">{ord.userWhatsapp}</span>
                                </div>
                                <button
                                  onClick={() => handleCopyText(ord.userWhatsapp || '', 'WhatsApp Contact')}
                                  className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                >
                                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Copy</span>
                                </button>
                              </div>
                            )}

                            {/* Assigned Voucher Code(s) — visible only inside the authorized Admin Order Details view */}
                            {(() => {
                              const assignedVoucherCodes = redeemCodesList.filter(rc => rc.usedByOrder === ord.orderId);
                              if (assignedVoucherCodes.length > 0) {
                                return (
                                  <div className="space-y-2 p-2.5 rounded-lg bg-black/60 border border-emerald-500/20">
                                    <div className="text-[10px] text-zinc-500 block">Redeem Code</div>
                                    {assignedVoucherCodes.map((rc) => (
                                      <div key={rc.id} className="flex items-center justify-between gap-3">
                                        <div>
                                          <span className="text-sm font-bold text-emerald-400 break-all">{rc.code}</span>
                                          <span className="ml-2 text-[10px] uppercase text-zinc-500">{rc.status}</span>
                                        </div>
                                        <button onClick={() => handleCopyText(rc.code, 'Redeem Code')} className="shrink-0 px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer">
                                          <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                          <span>Copy</span>
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                );
                              }
                              return ord.userField1Val ? (
                                <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                  <div>
                                    <span className="text-[10px] text-zinc-500 block">Custom Field 1</span>
                                    <span className="text-sm font-bold text-purple-400">{ord.userField1Val}</span>
                                  </div>
                                  <button onClick={() => handleCopyText(ord.userField1Val || '', 'Custom Field 1')} className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer">
                                    <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                    <span>Copy</span>
                                  </button>
                                </div>
                              ) : null;
                            })()}

                            {/* Custom Field 2 Val */}
                            {ord.userField2Val && (
                              <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">Custom Field 2</span>
                                  <span className="text-sm font-bold text-purple-400">{ord.userField2Val}</span>
                                </div>
                                <button
                                  onClick={() => handleCopyText(ord.userField2Val || '', 'Custom Field 2')}
                                  className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                >
                                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Copy</span>
                                </button>
                              </div>
                            )}

                            {/* Dynamic Additional Custom Fields */}
                            {Array.isArray(ord.customFieldValues) && ord.customFieldValues.filter(f => f.value).map((f) => (
                              <div key={f.id} className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">{f.label}</span>
                                  <span className="text-sm font-bold text-purple-400">{f.value}</span>
                                </div>
                                <button
                                  onClick={() => handleCopyText(f.value, f.label)}
                                  className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                                >
                                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Copy</span>
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                        </div>

                        {/* 3. PRODUCT & PACKAGE CARD */}
                        <div className="p-4 rounded-xl bg-[#141414] border border-zinc-800/80 space-y-2">
                          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                            <Package className="w-4 h-4 text-zinc-400" />
                            Product & Package
                          </h4>
                          <div className="grid grid-cols-2 gap-3 pt-1">
                            <div>
                              <span className="text-[10px] text-zinc-500 block">Product</span>
                              <span className="text-xs font-bold text-white">{ord.gameName}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-zinc-500 block">Package / Quantity</span>
                              <span className="text-xs font-bold text-zinc-200">{ord.packageName}</span>
                            </div>
                          </div>
                        </div>

                        {/* 4. CUSTOMER DETAILS CARD */}
                        {(() => {
                          const drawerCustomerUser = usersList.find((u) => 
                            (ord.userId && u.id === ord.userId) ||
                            ((ord as any).uid && u.id === (ord as any).uid) ||
                            (u.email && ord.userEmail && u.email.toLowerCase().trim() === ord.userEmail.toLowerCase().trim()) ||
                            (u.email && (ord as any).playerEmail && u.email.toLowerCase().trim() === (ord as any).playerEmail.toLowerCase().trim())
                          );
                          const drawerEmail = drawerCustomerUser?.email || ord.userEmail || (ord as any).playerEmail || 'No email registered';
                          const drawerName = drawerCustomerUser?.username || ord.playerName || ord.playerUid || 'Customer';

                          return (
                            <div className="p-4 rounded-xl bg-[#141414] border border-zinc-800/80 space-y-2">
                              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                                <UserIcon className="w-4 h-4 text-zinc-400" />
                                Customer Details
                              </h4>
                              <div className="space-y-1.5 pt-1">
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">Username</span>
                                  <span className="text-xs font-bold text-white">{drawerName}</span>
                                </div>
                                <div>
                                  <span className="text-[10px] text-zinc-500 block">Email Address</span>
                                  <span className="text-xs font-mono text-emerald-400">{drawerEmail}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })()}

                        {/* 5. PAYMENT & TRANSACTION CARD */}
                        <div className="p-4 rounded-xl bg-[#141414] border border-zinc-800/80 space-y-3">
                          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                            <CreditCard className="w-4 h-4 text-zinc-400" />
                            Payment & Transaction
                          </h4>
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <span className="text-[10px] text-zinc-500 block">Total Amount Paid</span>
                              <span className="text-sm font-bold text-white font-mono">₹{ord.totalPriceNpr}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-zinc-500 block">Payment Method</span>
                              <span className="text-xs font-semibold text-zinc-200">{ord.paymentMethod || 'eSewa Direct'}</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/60 border border-zinc-800">
                            <div>
                              <span className="text-[10px] text-zinc-500 block">Transaction ID</span>
                              <span className="text-xs font-bold text-white font-mono">{ord.transactionRef || 'TXN-984018241'}</span>
                            </div>
                            <button
                              onClick={() => handleCopyText(ord.transactionRef || 'TXN-984018241', 'Transaction ID')}
                              className="px-3 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <Copy className="w-3.5 h-3.5 text-zinc-400" />
                              <span>Copy</span>
                            </button>
                          </div>
                        </div>

                        {/* 6. TRANSACTIONAL EMAIL STATUS CARD (RESEND) */}
                        <div className="p-4 rounded-xl bg-[#141414] border border-zinc-800/80 space-y-3">
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                              <Mail className="w-4 h-4 text-red-400" />
                              Transactional Email Status (Resend)
                            </h4>
                            {loadingEmailStatus && <Loader2 className="w-3.5 h-3.5 text-zinc-400 animate-spin" />}
                          </div>

                          {manualEmailMsg && (
                            <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-200">
                              {manualEmailMsg}
                            </div>
                          )}

                          {orderEmailRecord ? (
                            <div className="space-y-2 text-xs">
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] text-zinc-500">Status:</span>
                                {orderEmailRecord.status === 'sent' ? (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                                    <CheckCircle2 className="w-3 h-3" /> Sent Successfully
                                  </span>
                                ) : orderEmailRecord.status === 'failed' ? (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/10 text-red-400 border border-red-500/30 flex items-center gap-1">
                                    <XCircle className="w-3 h-3" /> Delivery Failed
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                                    Pending Delivery
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center justify-between text-[11px]">
                                <span className="text-zinc-500">Recipient:</span>
                                <span className="font-mono text-zinc-200">{orderEmailRecord.email}</span>
                              </div>

                              {orderEmailRecord.sent_at && (
                                <div className="flex items-center justify-between text-[11px]">
                                  <span className="text-zinc-500">Sent At:</span>
                                  <span className="text-zinc-300">
                                    {new Date(orderEmailRecord.sent_at).toLocaleString()}
                                  </span>
                                </div>
                              )}

                              {orderEmailRecord.resend_message_id && (
                                <div className="flex items-center justify-between text-[11px]">
                                  <span className="text-zinc-500">Resend Message ID:</span>
                                  <span className="font-mono text-[10px] text-purple-400">
                                    {orderEmailRecord.resend_message_id}
                                  </span>
                                </div>
                              )}

                              {orderEmailRecord.status === 'failed' && (
                                <div className="p-2 rounded-lg bg-red-950/40 border border-red-800/60 text-red-300 text-[11px]">
                                  <strong>Error:</strong> {orderEmailRecord.error_message || 'Unknown provider error'}
                                </div>
                              )}

                              {orderEmailRecord.status === 'failed' && (
                                <button
                                  onClick={() => handleSendOrRetryOrderEmail(ord)}
                                  disabled={manualEmailSending}
                                  className="w-full mt-2 py-2 px-3 bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                                >
                                  {manualEmailSending ? (
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <RotateCw className="w-3.5 h-3.5" />
                                  )}
                                  <span>Retry Sending Email</span>
                                </button>
                              )}
                            </div>
                          ) : (
                            <div className="space-y-2 text-xs">
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] text-zinc-500">Status:</span>
                                {String(ord.status || '').toLowerCase() === 'completed' || String(ord.topUpStatus || '').toLowerCase() === 'completed' ? (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 text-zinc-300 border border-zinc-700">
                                    Not Sent Yet
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800/80 text-zinc-400 border border-zinc-700/50">
                                    Not Required (Pending Order)
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-zinc-400 leading-relaxed">
                                {String(ord.status || '').toLowerCase() === 'completed' || String(ord.topUpStatus || '').toLowerCase() === 'completed'
                                  ? 'This order is marked completed. You can send or resend the official Resend transactional email receipt below.'
                                  : 'UGTOPUPS email rules: emails are sent strictly when orders reach COMPLETED status.'}
                              </p>

                              {(String(ord.status || '').toLowerCase() === 'completed' || String(ord.topUpStatus || '').toLowerCase() === 'completed') && (
                                <button
                                  onClick={() => handleSendOrRetryOrderEmail(ord)}
                                  disabled={manualEmailSending}
                                  className="w-full mt-1 py-2 px-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                                >
                                  {manualEmailSending ? (
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <Send className="w-3.5 h-3.5 text-red-400" />
                                  )}
                                  <span>Send Transactional Receipt Email</span>
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        {/* 7. SYSTEM / PROVIDER API STATUS CARD */}
                        <div className="p-4 rounded-xl bg-[#141414] border border-zinc-800/80 space-y-2">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="text-zinc-400 font-bold">System / Provider API Status</span>
                            <span className="text-zinc-500 font-mono">Attempts: 0</span>
                          </div>
                          <div className="p-2.5 rounded-lg bg-zinc-950 border border-zinc-800/80 text-zinc-300 font-mono text-[11px]">
                            Ready for Manual/Auto Dispatch
                          </div>
                        </div>

                      </div>

                      {/* Drawer Footer - Action Buttons */}
                      <div className="p-4 bg-[#121212] border-t border-zinc-800 grid grid-cols-2 gap-3 flex-shrink-0">
                        <button
                          onClick={() => handleOpenRejectOrder(ord)}
                          className="w-full py-3 px-4 bg-transparent hover:bg-red-950/40 text-red-400 border border-red-600/60 font-bold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
                        >
                          <XCircle className="w-4 h-4" />
                          <span>Cancel Order</span>
                        </button>

                        <button
                          onClick={() => handleApproveOrder(ord)}
                          disabled={isApproving}
                          className="w-full py-3 px-4 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 active:scale-95"
                        >
                          {isApproving ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4" />
                          )}
                          <span>Complete Order</span>
                        </button>
                      </div>

                    </div>
                  </div>
                );
              })()}

              {/* REJECT ORDER MODAL */}
              {rejectOrderModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                  <div className="w-full max-w-md bg-[#0d1117] border border-zinc-800 rounded-2xl p-6 space-y-4 shadow-2xl">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                      <h3 className="text-base font-extrabold text-red-400 flex items-center gap-2">
                        <XCircle className="w-5 h-5" /> Reject / Cancel Order
                      </h3>
                      <button onClick={() => setRejectOrderModal(null)} className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 cursor-pointer">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="space-y-3 text-xs">
                      <p className="text-zinc-300">
                        Cancelling order <span className="font-mono text-white">#{rejectOrderModal.orderId}</span> for <strong className="text-white">{rejectOrderModal.playerName || rejectOrderModal.playerUid}</strong>
                      </p>
                      {(rejectOrderModal.totalPriceNpr > 0) && (
                        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-950/60 border border-emerald-800/50 text-emerald-400 font-semibold">
                          <span>💰</span>
                          <span>NPR {(rejectOrderModal.totalPriceNpr || 0).toLocaleString('en-IN')} will be automatically refunded to user's UG Wallet.</span>
                        </div>
                      )}
                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold">Cancellation Reason</label>
                        <textarea
                          value={rejectOrderReason}
                          onChange={(e) => setRejectOrderReason(e.target.value)}
                          placeholder="e.g. Invalid player UID, payment not received..."
                          rows={3}
                          className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 text-xs"
                        />
                      </div>
                      <div className="flex items-center justify-end gap-3 pt-1">
                        <button onClick={() => setRejectOrderModal(null)} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer">
                          Back
                        </button>
                        <button onClick={handleConfirmRejectOrder} className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 cursor-pointer flex items-center gap-1.5">
                          <XCircle className="w-4 h-4" /> Confirm Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>
          );
        })()}

        {/* VIEW 7: PENDING REQUESTS */}
        {(activeMainSection === 'PENDING_REQUESTS' || activeSubItem === 'Pending Requests') && (
          <div className="p-6 space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-5">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                    <Clock className="w-6 h-6 text-amber-400" />
                    <span>Pending Request</span>
                  </h2>
                  <span className="px-3 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    {allWalletRequests.filter(r => r.status === 'PENDING' || r.status === 'Pending').length} Pending
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Manage all credit requests from users in real-time ({allWalletRequests.length} total)
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Search */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by name or email..."
                    value={requestSearchQuery}
                    onChange={(e) => setRequestSearchQuery(e.target.value)}
                    className="pl-9 pr-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 w-52"
                  />
                </div>

                {/* Status Filter */}
                <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-300">
                  <Filter className="w-3.5 h-3.5 text-zinc-400" />
                  <select
                    value={requestStatusFilter}
                    onChange={(e) => setRequestStatusFilter(e.target.value as any)}
                    className="bg-transparent text-xs text-zinc-200 outline-none cursor-pointer font-semibold"
                  >
                    <option value="ALL" className="bg-zinc-900 text-white">All Status</option>
                    <option value="Pending" className="bg-zinc-900 text-amber-400">Pending</option>
                    <option value="Approved" className="bg-zinc-900 text-emerald-400">Approved</option>
                    <option value="Rejected" className="bg-zinc-900 text-red-400">Rejected</option>
                  </select>
                </div>

                {/* Date Filter */}
                <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-300">
                  <Calendar className="w-3.5 h-3.5 text-zinc-400" />
                  <select
                    value={requestDateFilter}
                    onChange={(e) => setRequestDateFilter(e.target.value as any)}
                    className="bg-transparent text-xs text-zinc-200 outline-none cursor-pointer font-semibold"
                  >
                    <option value="ALL" className="bg-zinc-900 text-white">All Time</option>
                    <option value="Today" className="bg-zinc-900 text-zinc-300">Today</option>
                    <option value="Week" className="bg-zinc-900 text-zinc-300">This Week</option>
                    <option value="Month" className="bg-zinc-900 text-zinc-300">This Month</option>
                  </select>
                </div>

                {/* Refresh Button */}
                <button
                  onClick={() => {
                    setRequestSearchQuery('');
                    setRequestStatusFilter('ALL');
                    setRequestDateFilter('ALL');
                  }}
                  className="p-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white rounded-xl transition-colors cursor-pointer"
                  title="Reset Filters & Refresh"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Bulk Selection Bar */}
            <div className="bg-[#0b0e17] border border-zinc-800/80 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={filteredWalletRequests.length > 0 && selectedRequestIds.length === filteredWalletRequests.length}
                    onChange={handleToggleSelectAllRequests}
                    className="w-4 h-4 rounded border-zinc-700 bg-zinc-900 text-red-600 focus:ring-0 cursor-pointer"
                  />
                  <span className="text-sm font-extrabold text-white">Select All</span>
                </label>
                <div className="h-4 w-px bg-zinc-800" />
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-zinc-300 font-mono">{selectedRequestIds.length} Selected</span>
                  <span className="text-xs text-zinc-500 hidden md:inline">• Select one or more requests to delete.</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  disabled={selectedRequestIds.length === 0}
                  onClick={() => setIsDeleteAllModalOpen(true)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    selectedRequestIds.length > 0
                      ? 'bg-zinc-800 hover:bg-zinc-700 text-red-400 border border-red-500/30 shadow-md'
                      : 'bg-zinc-900/50 text-zinc-600 border border-zinc-800/60 cursor-not-allowed'
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Selected ({selectedRequestIds.length})</span>
                </button>

                <button
                  onClick={() => {
                    setSelectedRequestIds(filteredWalletRequests.map(r => r.id));
                    setIsDeleteAllModalOpen(true);
                  }}
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-lg shadow-red-600/30 active:scale-95"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete All</span>
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="border border-zinc-800/80 rounded-2xl overflow-hidden bg-zinc-950/60 shadow-xl">
              {filteredWalletRequests.length === 0 ? (
                <div className="py-16 text-center text-zinc-500 text-xs">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500/30 mx-auto mb-3" />
                  <p className="font-bold text-zinc-400 text-sm">No credit requests found.</p>
                  <p className="text-zinc-600 text-xs mt-1">Try resetting filters or searching with a different term.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-zinc-800 text-[11px] font-bold text-zinc-400 uppercase tracking-wider bg-zinc-950/90">
                        <th className="py-3.5 px-4 w-10"></th>
                        <th className="py-3.5 px-4">USER</th>
                        <th className="py-3.5 px-4">AMOUNT</th>
                        <th className="py-3.5 px-4">TIME</th>
                        <th className="py-3.5 px-4">SCREENSHOT</th>
                        <th className="py-3.5 px-4">STATUS</th>
                        <th className="py-3.5 px-4 text-center">ACTIONS</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/60 text-xs">
                      {filteredWalletRequests.map((reqItem) => {
                        const isSelected = selectedRequestIds.includes(reqItem.id);
                        const isPending = reqItem.status === 'PENDING' || reqItem.status === 'Pending';
                        const isApproved = reqItem.status === 'APPROVED' || reqItem.status === 'Approved';
                        const isRejected = reqItem.status === 'REJECTED' || reqItem.status === 'Rejected';

                        // Lookup real user profile from usersList
                        const matchingUser = usersList.find((u) => u.id === reqItem.uid);
                        const displayUsername = matchingUser?.username || reqItem.username || 'User';
                        const rawEmail = matchingUser?.email || reqItem.email || '';
                        const displayEmail = rawEmail && !rawEmail.includes('@gamer.io') ? rawEmail : (matchingUser?.email || '');
                        const displayAvatar = matchingUser?.avatarUrl || (reqItem as any).avatarUrl || '';

                        const initials = displayUsername
                          ? displayUsername.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
                          : 'US';

                        return (
                          <tr
                            key={reqItem.id}
                            className={`hover:bg-zinc-900/50 transition-colors ${isSelected ? 'bg-red-950/10' : ''}`}
                          >
                            {/* Checkbox */}
                            <td className="py-3.5 px-4">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => handleToggleSelectRequestRow(reqItem.id)}
                                className="w-4 h-4 rounded border-zinc-700 bg-zinc-900 text-red-600 focus:ring-0 cursor-pointer"
                              />
                            </td>

                            {/* USER */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                {displayAvatar ? (
                                  <img
                                    src={displayAvatar}
                                    alt={displayUsername}
                                    className="w-9 h-9 rounded-full object-cover border border-emerald-500/40 shadow-md shrink-0"
                                  />
                                ) : (
                                  <div className="w-9 h-9 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-400 font-extrabold flex items-center justify-center text-xs shadow-md shrink-0">
                                    {initials}
                                  </div>
                                )}
                                <div>
                                  <div className="font-extrabold text-white text-xs">{displayUsername}</div>
                                  {displayEmail ? (
                                    <div className="text-[11px] text-zinc-400 font-mono">{displayEmail}</div>
                                  ) : null}
                                </div>
                              </div>
                            </td>

                            {/* AMOUNT */}
                            <td className="py-3.5 px-4">
                              <span className="font-black text-emerald-400 text-sm font-mono tracking-tight">
                                ₹{reqItem.amountNpr.toLocaleString()}
                              </span>
                            </td>

                            {/* TIME */}
                            <td className="py-3.5 px-4 text-xs font-mono">
                              <div className="font-bold text-white">
                                {reqItem.formattedTime ? reqItem.formattedTime.split(',')[0] : 'Aug 06, 2026'}
                              </div>
                              <div className="text-[10px] text-zinc-500">
                                {reqItem.formattedTime ? reqItem.formattedTime.split(',')[1] : '08:07 PM'}
                              </div>
                            </td>

                            {/* SCREENSHOT */}
                            <td className="py-3.5 px-4">
                              <div className="w-16 h-10 bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden relative flex items-center justify-center group shadow-sm">
                                {reqItem.screenshotUrl ? (
                                  <img src={reqItem.screenshotUrl} alt="Proof" className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full bg-zinc-950 flex items-center justify-center text-[9px] text-zinc-600 font-mono">
                                    <span>Proof</span>
                                  </div>
                                )}
                                <button
                                  onClick={() => {
                                    setPreviewZoom(100);
                                    setPreviewRotation(0);
                                    setPreviewReceiptModal(reqItem);
                                  }}
                                  className="absolute inset-0 bg-black/70 hover:bg-black/85 text-white text-[10px] font-bold flex items-center justify-center gap-1 opacity-90 hover:opacity-100 transition-opacity cursor-pointer"
                                >
                                  <Eye className="w-3 h-3 text-emerald-400" />
                                  <span>View</span>
                                </button>
                              </div>
                            </td>

                            {/* STATUS */}
                            <td className="py-3.5 px-4">
                              {isPending && (
                                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1.5 w-fit">
                                  <Clock className="w-3.5 h-3.5" />
                                  <span>Pending</span>
                                </span>
                              )}
                              {isApproved && (
                                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5 w-fit">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Approved</span>
                                </span>
                              )}
                              {isRejected && (
                                <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-400 border border-red-500/30 flex items-center gap-1.5 w-fit">
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>Rejected</span>
                                </span>
                              )}
                            </td>

                            {/* ACTIONS */}
                            <td className="py-3.5 px-4 text-center">
                              <div className="flex items-center justify-center gap-2">
                                {/* Tick and Cross icons ONLY show when status is PENDING */}
                                {isPending && (
                                  <>
                                    <button
                                      onClick={() => handleApproveWalletRequest(reqItem)}
                                      className="w-7 h-7 rounded-lg bg-emerald-500/20 hover:bg-emerald-500 text-emerald-400 hover:text-white flex items-center justify-center transition-all cursor-pointer border border-emerald-500/30 active:scale-95"
                                      title="Approve Request"
                                    >
                                      <Check className="w-4 h-4" />
                                    </button>
                                    <button
                                      onClick={() => handleOpenRejectModal(reqItem)}
                                      className="w-7 h-7 rounded-lg bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white flex items-center justify-center transition-all cursor-pointer border border-red-500/30 active:scale-95"
                                      title="Reject Request"
                                    >
                                      <X className="w-4 h-4" />
                                    </button>
                                  </>
                                )}

                                {/* Delete button ALWAYS shows */}
                                <button
                                  onClick={() => handleSingleDeleteRequest(reqItem.id)}
                                  className="w-7 h-7 rounded-lg bg-zinc-800/80 hover:bg-red-950 text-zinc-400 hover:text-red-400 flex items-center justify-center transition-all cursor-pointer border border-zinc-700/60 active:scale-95"
                                  title="Delete Request"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 7A: PENDING FONEPAY HUB API PAYMENTS */}
        {(activeMainSection === 'API_PAYMENTS' || activeSubItem === 'API Payments') && (() => {
          const query = apiPaymentSearch.trim().toLowerCase();
          const rows = pendingFonepayPayments
            .map((order) => {
              const matchedUser = usersList.find((user) => String(user.id) === String(order.userId || ''));
              const username = matchedUser?.username || order.playerName || 'User';
              const email = matchedUser?.email || order.userEmail || '—';
              const remarks = order.orderId;
              return { order, username, email, remarks };
            })
            .filter(({ order, username, email, remarks }) => {
              if (!query) return true;
              return [
                remarks,
                username,
                email,
                order.transactionRef,
                order.gameName,
                order.packageName,
                order.playerUid,
                order.playerName,
                String(order.totalPriceNpr || ''),
              ].some((value) => String(value || '').toLowerCase().includes(query));
            });

          return (
            <div className="p-6 space-y-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                <div>
                  <h2 className="text-xl font-black admin-heading flex items-center gap-2">
                    <QrCode className="w-5 h-5 text-cyan-400" />
                    <span>API Payments</span>
                  </h2>
                  <p className="text-xs admin-muted mt-1">
                    Pending Fonepay Hub payments only. Confirmed purchases move to Orders automatically.
                  </p>
                </div>
                <div className="relative w-full lg:w-[390px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 admin-muted" />
                  <input
                    value={apiPaymentSearch}
                    onChange={(event) => setApiPaymentSearch(event.target.value)}
                    placeholder="Search remarks, username, email, UID..."
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-xs outline-none ${inputBgClass}`}
                  />
                </div>
              </div>

              {apiPaymentMessage && (
                <div className={`px-4 py-3 rounded-xl border text-xs font-semibold ${
                  apiPaymentMessage.type === 'success'
                    ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                    : 'bg-red-950/40 border-red-800 text-red-300'
                }`}>
                  {apiPaymentMessage.text}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className={`p-4 rounded-2xl border ${cardBgClass}`}>
                  <span className="text-[10px] font-bold admin-muted uppercase tracking-wider block">Pending Payments</span>
                  <span className="text-2xl font-black text-amber-400 mt-1 block">{pendingFonepayPayments.length}</span>
                </div>
                <div className={`p-4 rounded-2xl border ${cardBgClass}`}>
                  <span className="text-[10px] font-bold admin-muted uppercase tracking-wider block">Pending Amount</span>
                  <span className="text-2xl font-black text-white mt-1 block font-mono">
                    NPR {pendingFonepayPayments.reduce((sum, order) => sum + Number(order.totalPriceNpr || 0), 0).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className={`p-4 rounded-2xl border ${cardBgClass}`}>
                  <span className="text-[10px] font-bold admin-muted uppercase tracking-wider block">Search Results</span>
                  <span className="text-2xl font-black text-cyan-400 mt-1 block">{rows.length}</span>
                </div>
              </div>

              <div className={`rounded-2xl border overflow-hidden ${cardBgClass}`}>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[1180px]">
                    <thead>
                      <tr className={`border-b text-[10px] font-bold uppercase tracking-wider ${isDark ? 'border-zinc-800 bg-zinc-950/50 text-zinc-400' : 'border-slate-200 bg-slate-50 text-slate-500'}`}>
                        <th className="py-3 px-4">Remarks</th>
                        <th className="py-3 px-4">Username</th>
                        <th className="py-3 px-4">Email</th>
                        <th className="py-3 px-4">Product / Package</th>
                        <th className="py-3 px-4">Player UID</th>
                        <th className="py-3 px-4">Amount</th>
                        <th className="py-3 px-4">Created</th>
                        <th className="py-3 px-4 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className={`divide-y text-xs ${isDark ? 'divide-zinc-800/60' : 'divide-slate-200'}`}>
                      {rows.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="py-14 text-center admin-muted">
                            {query ? 'No pending API payments match your search.' : 'No pending Fonepay Hub payments.'}
                          </td>
                        </tr>
                      ) : rows.map(({ order, username, email, remarks }) => {
                        const isActing = apiPaymentActionId === order.orderId;
                        const createdAt = (order as any).createdAt || (order as any).created_at;
                        return (
                          <tr key={order.orderId} className={isDark ? 'hover:bg-zinc-800/25' : 'hover:bg-slate-50'}>
                            <td className="py-3.5 px-4">
                              <div className="font-bold admin-heading font-mono">{remarks}</div>
                              <div className="text-[9px] admin-muted mt-1 max-w-[190px] truncate" title={order.transactionRef}>
                                Ref: {order.transactionRef || '—'}
                              </div>
                            </td>
                            <td className="py-3.5 px-4 font-bold admin-heading">{username}</td>
                            <td className="py-3.5 px-4 admin-muted max-w-[220px] truncate" title={email}>{email}</td>
                            <td className="py-3.5 px-4">
                              <div className="font-bold admin-heading">{order.gameName || 'Order'}</div>
                              <div className="text-[10px] admin-muted mt-0.5">{order.packageName || '—'}</div>
                            </td>
                            <td className="py-3.5 px-4 font-mono admin-heading">{order.playerUid || '—'}</td>
                            <td className="py-3.5 px-4 font-black text-amber-400 whitespace-nowrap">
                              NPR {Number(order.totalPriceNpr || 0).toLocaleString('en-IN')}
                            </td>
                            <td className="py-3.5 px-4 admin-muted whitespace-nowrap">
                              {createdAt ? new Date(createdAt).toLocaleString() : '—'}
                            </td>
                            <td className="py-3.5 px-4">
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  disabled={isActing}
                                  onClick={() => handleApiPaymentAction(order, 'confirm')}
                                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-[10px] font-black uppercase transition-colors"
                                >
                                  {isActing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                                  Confirm
                                </button>
                                <button
                                  disabled={isActing}
                                  onClick={() => handleApiPaymentAction(order, 'reject')}
                                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-[10px] font-black uppercase transition-colors"
                                >
                                  <X className="w-3.5 h-3.5" />
                                  Reject
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          );
        })()}

        {/* VIEW 7B: INSTANT PAYMENT */}
        {(activeMainSection === 'INSTANT_PAYMENT' || activeSubItem === 'Instant Wallet Load') && (
          <div className="p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-400" />
                  <span>Online Instant Payments</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Live Fonepay Hub QR payments, wallet credits and successful recharge history.
                </p>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className={`p-4 rounded-2xl border ${cardBgClass}`}>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">REGISTERED ACCOUNTS</span>
                <span className="text-2xl font-black text-white mt-1 block">{usersList.length}</span>
              </div>
              <div className={`p-4 rounded-2xl border ${cardBgClass}`}>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">TOTAL USER BALANCES</span>
                <span className="text-2xl font-black text-emerald-400 mt-1 block font-mono">
                  NPR {usersList.reduce((acc, u) => acc + (u.walletBalanceNpr || 0), 0).toLocaleString()}
                </span>
              </div>
              <div className={`p-4 rounded-2xl border ${cardBgClass}`}>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">PENDING PROOF REQUESTS</span>
                <span className="text-2xl font-black text-amber-400 mt-1 block">
                  {allWalletRequests.filter(r => r.status === 'PENDING' || r.status === 'Pending').length}
                </span>
              </div>
            </div>

            {/* Fonepay Hub Instant Payment History */}
            <div className={`p-5 rounded-2xl border space-y-3 ${cardBgClass}`}>
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">
                    Online Instant Payments
                  </h3>
                  <p className="text-[11px] text-zinc-500 mt-1">
                    Every successful Fonepay Hub QR wallet recharge appears here automatically.
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-800/70 text-[10px] font-bold text-emerald-400 uppercase">
                  Live
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[900px]">
                  <thead>
                    <tr className="border-b border-zinc-800 text-[11px] font-bold text-zinc-400 uppercase tracking-wider bg-zinc-950/40">
                      <th className="py-3 px-4">USERNAME</th>
                      <th className="py-3 px-4">EMAIL</th>
                      <th className="py-3 px-4">AMOUNT</th>
                      <th className="py-3 px-4">CREDITS</th>
                      <th className="py-3 px-4">GATEWAY</th>
                      <th className="py-3 px-4">STATUS</th>
                      <th className="py-3 px-4">COMPLETED AT</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50 text-xs">
                    {(() => {
                      // Build this table from the transaction ledger, not only from
                      // orders. Fonepay Hub wallet payments are recorded in `transactions`
                      // after successful gateway verification, so this also shows older
                      // successful payments that may not be present in the current orders
                      // shape/backup data.
                      const instantOnlineLoads = instantWalletTransactions
                        .filter((txn: any) => {
                          const type = String(txn?.type || '').toUpperCase();
                          const status = String(txn?.status || '').toUpperCase();
                          const method = String(txn?.paymentMethod || txn?.payment_method || '').toLowerCase();
                          return (
                            (type === 'RECHARGE' || type === 'CREDIT' || type === 'TOPUP') &&
                            (status === 'SUCCESS' || status === 'COMPLETED') &&
                            method.includes('fonepay')
                          );
                        })
                        .map((txn: any) => {
                          const orderId = String(txn?.orderId || '').trim();
                          const userId = String(txn?.uid || txn?.userId || '').trim();

                          const matchingOrder = realtimeOrders.find((ord: any) =>
                            orderId && String(ord?.orderId || ord?.id || '') === orderId
                          );

                          const matchingUser =
                            usersList.find((u) => userId && String(u.id) === userId) ||
                            usersList.find((u) => txn?.email && u.email?.toLowerCase() === String(txn.email).toLowerCase()) ||
                            usersList.find((u) => txn?.username && u.username?.toLowerCase() === String(txn.username).toLowerCase());

                          const amount = Number(txn?.amount ?? matchingOrder?.totalPriceNpr ?? 0) || 0;
                          const creditsAfter =
                            txn?.newBalance !== null && txn?.newBalance !== undefined
                              ? Number(txn.newBalance) || 0
                              : Number(matchingUser?.walletBalanceNpr || 0);

                          const completedAt =
                            txn?.createdAt ||
                            txn?.date ||
                            matchingOrder?.completedAt ||
                            matchingOrder?.createdAt ||
                            new Date().toISOString();

                          return {
                            id: txn?.id || orderId || `${userId}-${completedAt}-${amount}`,
                            username: txn?.username || matchingUser?.username || matchingOrder?.playerName || 'User',
                            email: txn?.email || matchingUser?.email || matchingOrder?.userEmail || '—',
                            amount,
                            credits: creditsAfter,
                            gateway: 'Fonepay Hub',
                            status: 'COMPLETED',
                            completedAt,
                          };
                        })
                        .sort(
                          (a, b) =>
                            new Date(String(b.completedAt || '')).getTime() -
                            new Date(String(a.completedAt || '')).getTime()
                        );

                      if (instantOnlineLoads.length === 0) {
                        return (
                          <tr>
                            <td colSpan={7} className="py-10 text-center text-zinc-500">
                              No successful Fonepay Hub instant payments recorded yet.
                            </td>
                          </tr>
                        );
                      }

                      return instantOnlineLoads.map((payment) => (
                        <tr key={payment.id} className="hover:bg-zinc-800/30 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-white whitespace-nowrap">
                            {payment.username}
                          </td>
                          <td className="py-3.5 px-4 text-zinc-400 max-w-[240px] truncate" title={payment.email}>
                            {payment.email}
                          </td>
                          <td className="py-3.5 px-4 font-extrabold text-emerald-400 whitespace-nowrap">
                            Rs. {payment.amount.toLocaleString('en-IN')}
                          </td>
                          <td className="py-3.5 px-4 font-extrabold text-white whitespace-nowrap">
                            {payment.credits.toLocaleString('en-IN')}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-700 text-zinc-200 font-semibold whitespace-nowrap">
                              {payment.gateway}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                              Completed
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-zinc-400 whitespace-nowrap">
                            {payment.completedAt
                              ? new Date(String(payment.completedAt)).toLocaleString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })
                              : '—'}
                          </td>
                        </tr>
                      ));
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PAYMENT RECEIPT PREVIEW MODAL */}
        {previewReceiptModal && (() => {
          const modalMatchingUser = usersList.find((u) => u.id === previewReceiptModal.uid);
          const modalUsername = modalMatchingUser?.username || previewReceiptModal.username || 'User';
          const rawModalEmail = modalMatchingUser?.email || previewReceiptModal.email || '';
          const modalEmail = rawModalEmail && !rawModalEmail.includes('@gamer.io') ? rawModalEmail : (modalMatchingUser?.email || '');
          const modalAvatar = modalMatchingUser?.avatarUrl || (previewReceiptModal as any).avatarUrl || '';

          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
              <div className="w-full max-w-6xl max-h-[92vh] bg-[#0a0d16] border border-[#1b2338] rounded-2xl overflow-hidden shadow-2xl flex flex-col">
                {/* Header Bar */}
                <div className="px-5 py-3.5 bg-[#0e121e] border-b border-[#1b2338] flex items-center justify-between gap-4 shrink-0">
                  <div className="flex items-center gap-3">
                    {modalAvatar ? (
                      <img
                        src={modalAvatar}
                        alt={modalUsername}
                        className="w-9 h-9 rounded-full object-cover border border-emerald-500/40 shadow-md shrink-0"
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-xl bg-[#082215] border border-[#0e4d2a] text-[#00e676] flex items-center justify-center shrink-0 shadow-md font-bold text-sm">
                        {modalUsername.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div>
                      <h3 className="text-base font-black text-white tracking-tight">Payment Receipt Preview</h3>
                      <p className="text-xs text-zinc-400 font-sans flex items-center gap-1.5 flex-wrap">
                        <span className="text-zinc-200 font-bold">{modalUsername}</span>
                        {modalEmail ? <span className="text-zinc-400">({modalEmail})</span> : null}
                        <span>•</span>
                        <span className="text-[#00e676] font-extrabold">₹{previewReceiptModal.amountNpr}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Zoom & Rotate Control Bar */}
                    <div className="flex items-center bg-[#121828] border border-[#212b45] rounded-xl px-2 py-1 gap-1 text-zinc-300 shadow-inner">
                      <button
                        onClick={() => setPreviewZoom((p) => Math.min(p + 25, 800))}
                        className="p-1 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setPreviewZoom((p) => Math.max(p - 25, 100))}
                        className="p-1 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setPreviewZoom(100);
                          setPreviewRotation(0);
                        }}
                        className="p-1 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                        title="Reset Zoom & Rotation"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setPreviewRotation((r) => (r + 90) % 360)}
                        className="p-1 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                        title="Rotate Clockwise"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {(previewReceiptModal.status === 'PENDING' || previewReceiptModal.status === 'Pending') && (
                      <>
                        <button
                          onClick={async () => {
                            await handleApproveWalletRequest(previewReceiptModal);
                            setPreviewReceiptModal(null);
                          }}
                          className="bg-[#00c853] hover:bg-[#00e676] text-white font-extrabold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                        >
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => {
                            handleOpenRejectModal(previewReceiptModal);
                            setPreviewReceiptModal(null);
                          }}
                          className="bg-[#ff1744] hover:bg-[#ff4569] text-white font-extrabold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-lg shadow-red-500/20 active:scale-95 transition-all"
                        >
                          <X className="w-4 h-4 stroke-[3]" />
                          <span>Reject</span>
                        </button>
                      </>
                    )}

                    <button
                      onClick={() => setPreviewReceiptModal(null)}
                      className="p-2 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors cursor-pointer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Main Viewer Body - Direct Uploaded Screenshot View (No Fake Receipt Card) */}
                <ReceiptImageViewer
                  imageSrc={previewReceiptModal.screenshotUrl}
                  zoom={previewZoom}
                  setZoom={setPreviewZoom}
                  rotation={previewRotation}
                  setRotation={setPreviewRotation}
                />

                {/* Footer Bar */}
                <div className="px-6 py-3 bg-[#090d16] border-t border-[#1b2336] flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-400 gap-3 shrink-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-zinc-400">Submitted:</span>
                      <span className="font-mono text-white font-bold">{previewReceiptModal.formattedTime || 'Recently'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="text-zinc-400">Status:</span>
                      <span className="font-extrabold text-white">
                        {previewReceiptModal.status === 'PENDING' || previewReceiptModal.status === 'Pending' ? 'Pending' : previewReceiptModal.status}
                      </span>
                    </div>
                    <span>•</span>
                    <span className="text-zinc-500 font-mono">ESC to close</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {/* BATCH DELETE / WIPE CONFIRMATION MODAL */}
        {isDeleteAllModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
            <div className="w-full max-w-md bg-zinc-900 border border-red-900/60 rounded-3xl p-6 space-y-5 shadow-2xl relative">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-red-950/90 border border-red-800/80 flex items-center justify-center text-red-500 shadow-lg">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white tracking-wide">DANGER: Delete Credit Requests</h3>
                    <p className="text-xs text-red-400 font-semibold">Irreversible database wipe operation</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsDeleteAllModalOpen(false);
                    setDeleteConfirmInput('');
                  }}
                  className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-red-950/40 border border-red-800/60 rounded-2xl p-4 text-xs space-y-1.5">
                <div className="font-extrabold text-red-400 text-sm flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  <span>WARNING: You are about to wipe {selectedRequestIds.length || allWalletRequests.length} credit requests!</span>
                </div>
                <p className="text-zinc-300 leading-relaxed">
                  This will permanently erase all credit requests, transaction records, and uploaded screenshots from Supabase database and storage.
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <label className="block text-zinc-300 font-semibold">
                  To confirm, type <span className="text-red-400 font-mono font-bold bg-red-950/80 px-1.5 py-0.5 rounded border border-red-800/60">secret code</span> in the box below:
                </label>
                <input
                  type="text"
                  placeholder="Type secret code here..."
                  value={deleteConfirmInput}
                  onChange={(e) => setDeleteConfirmInput(e.target.value)}
                  className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white font-mono outline-none focus:border-red-500 text-sm tracking-wider"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => {
                    setIsDeleteAllModalOpen(false);
                    setDeleteConfirmInput('');
                  }}
                  className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  disabled={deleteConfirmInput.trim().toLowerCase() !== 'ghop ghop'}
                  onClick={handleConfirmBatchOrWipeDelete}
                  className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer shadow-lg ${
                    deleteConfirmInput.trim().toLowerCase() === 'ghop ghop'
                      ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/40 active:scale-95'
                      : 'bg-zinc-800 text-zinc-600 border border-zinc-700/50 cursor-not-allowed opacity-50'
                  }`}
                >
                  Confirm Wipe All Data
                </button>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 8: USER SECTION - Premium Redesign */}
        {(activeMainSection === 'USERS' || activeSubItem === 'Users') && (() => {
          // Helper: generate deterministic avatar color from username
          const getAvatarColor = (name: string) => {
            const colors = [
              'bg-red-600','bg-blue-600','bg-purple-600','bg-emerald-600',
              'bg-amber-600','bg-pink-600','bg-indigo-600','bg-teal-600',
            ];
            const idx = (name || 'U').charCodeAt(0) % colors.length;
            return colors[idx];
          };

          // Filter users
          const today = new Date().toDateString();
          const filteredUsers = usersList.filter(u => {
            const matchSearch = !userSearch.trim() ||
              (u.username || '').toLowerCase().includes(userSearch.toLowerCase()) ||
              (u.email || '').toLowerCase().includes(userSearch.toLowerCase());
            const isDisabled = (u as any).disabled === true;
            const matchStatus = userStatusFilter === 'ALL' ? true :
              userStatusFilter === 'Active' ? !isDisabled : isDisabled;
            const matchDate = !userDateFilter || (u.registrationDate || '').startsWith(userDateFilter);
            return matchSearch && matchStatus && matchDate;
          });

          const totalPages = Math.ceil(filteredUsers.length / USERS_PER_PAGE);
          const paginatedUsers = filteredUsers.slice((userPage - 1) * USERS_PER_PAGE, userPage * USERS_PER_PAGE);

          const totalWallet = usersList.reduce((acc, u) => acc + (u.walletBalanceNpr || 0), 0);
          const activeCount = usersList.filter(u => !(u as any).disabled).length;
          const newTodayCount = usersList.filter(u => {
            try { return new Date(u.registrationDate || '').toDateString() === today; } catch { return false; }
          }).length;

          const handleEditUsername = (u: typeof usersList[0]) => {
            setEditUsernameModal({ userId: u.id, current: u.username });
            setEditUsernameValue(u.username);
          };

          const handleSaveUsername = async () => {
            if (!editUsernameModal || !editUsernameValue.trim()) return;
            setEditUsernameLoading(true);
            const success = await adminUpdateUsername(editUsernameModal.userId, editUsernameValue.trim());
            if (success) {
              const updated = usersList.map(u => u.id === editUsernameModal.userId ? { ...u, username: editUsernameValue.trim() } : u);
              setUsersList(updated);
            }
            setEditUsernameLoading(false);
            setEditUsernameModal(null);
          };

          const handleEditWallet = (u: typeof usersList[0]) => {
            setEditWalletModal({ userId: u.id, username: u.username, current: u.walletBalanceNpr });
            setWalletEditMode('increase');
            setWalletEditAmount(0);
            setWalletEditNote('');
          };

          const handleSaveWallet = async () => {
            if (!editWalletModal) return;
            setWalletEditLoading(true);
            const result = await adminUpdateUserWallet(
              editWalletModal.userId, walletEditMode, walletEditAmount,
              editWalletModal.current, walletEditNote || 'Admin Manual Adjustment'
            );
            if (result.success) {
              const updated = usersList.map(u => u.id === editWalletModal.userId ? { ...u, walletBalanceNpr: result.newBalance } : u);
              setUsersList(updated);
            }
            setWalletEditLoading(false);
            setEditWalletModal(null);
          };

          const handleToggleUserDisabled = async (u: typeof usersList[0]) => {
            const isDisabled = (u as any).disabled === true;
            const success = await adminToggleUserStatus(u.id, !isDisabled);
            if (success) {
              const updated = usersList.map(usr => usr.id === u.id ? { ...usr, disabled: !isDisabled } as any : usr);
              setUsersList(updated);
            }
            setOpenUserMenuId(null);
          };

          return (
            <div className="p-6 space-y-6">
              {/* Page Header */}
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-600/30">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-white tracking-tight">User <span className="text-red-500">Management</span></h2>
                  <p className="text-xs text-zinc-400 mt-0.5">Manage and monitor all registered users</p>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Users', value: usersList.length.toString(), sub: 'All registered users', icon: <Users className="w-5 h-5"/>, iconBg: 'bg-blue-500/10 text-blue-400 border-blue-500/20', isBalance: false },
                  { label: 'Active Users', value: activeCount.toString(), sub: 'Currently active users', icon: <UserIcon className="w-5 h-5"/>, iconBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', isBalance: false },
                  { label: 'Total Balance', value: `NPR ${totalWallet.toLocaleString('en-IN', {minimumFractionDigits:2,maximumFractionDigits:2})}`, sub: 'Total wallet balance', icon: <CreditCard className="w-5 h-5"/>, iconBg: 'bg-emerald-500/10 text-[#00e676] border-emerald-500/20', isBalance: true },
                  { label: 'New Today', value: newTodayCount.toString(), sub: 'Users registered today', icon: <ArrowUpRight className="w-5 h-5"/>, iconBg: 'bg-amber-500/10 text-amber-400 border-amber-500/20', isBalance: false },
                ].map(stat => (
                  <div key={stat.label} className="relative p-5 rounded-2xl overflow-hidden border border-zinc-800 bg-[#0d1117] hover:border-zinc-700 transition-all shadow-md">
                    <div className="relative flex items-start justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">{stat.label}</div>
                        <div className={`text-2xl font-black mt-1.5 ${stat.isBalance ? 'text-[#00e676] font-mono' : 'text-white'}`}>{stat.value}</div>
                        <div className="text-[11px] text-zinc-500 mt-1">{stat.sub}</div>
                      </div>
                      <div className={`w-10 h-10 rounded-xl ${stat.iconBg} border flex items-center justify-center shrink-0`}>
                        {stat.icon}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Filter Bar */}
              <div className={`p-3 rounded-2xl border flex flex-col md:flex-row items-center gap-3 ${isDark ? 'bg-zinc-900/80 border-zinc-800' : 'bg-white border-zinc-200'}`}>
                <div className="relative flex-1 w-full">
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input type="text" value={userSearch} onChange={e => { setUserSearch(e.target.value); setUserPage(1); }}
                    placeholder="Search users..."
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl text-xs outline-none ${isDark ? 'bg-zinc-950 border border-zinc-800 text-white placeholder-zinc-500 focus:border-red-500' : 'bg-zinc-50 border border-zinc-300 text-zinc-900'}`} />
                </div>
                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                  <select value={userStatusFilter} onChange={e => { setUserStatusFilter(e.target.value as any); setUserPage(1); }}
                    className={`px-3 py-2.5 rounded-xl text-xs font-semibold outline-none cursor-pointer flex items-center gap-2 ${isDark ? 'bg-zinc-950 border border-zinc-800 text-zinc-200' : 'bg-zinc-50 border border-zinc-300 text-zinc-800'}`}>
                    <option value="ALL">● Status</option>
                    <option value="Active">Active</option>
                    <option value="Disabled">Disabled</option>
                  </select>
                  <input type="date" value={userDateFilter} onChange={e => { setUserDateFilter(e.target.value); setUserPage(1); }}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold outline-none cursor-pointer ${isDark ? 'bg-zinc-950 border border-zinc-800 text-zinc-200' : 'bg-zinc-50 border border-zinc-300 text-zinc-800'}`} />
                  {(userSearch || userStatusFilter !== 'ALL' || userDateFilter) && (
                    <button onClick={() => { setUserSearch(''); setUserStatusFilter('ALL'); setUserDateFilter(''); setUserPage(1); }}
                      className="px-3 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-700 cursor-pointer transition-all">
                      Clear
                    </button>
                  )}
                </div>
              </div>

              {/* Users Table */}
              <div className={`rounded-2xl border overflow-hidden ${isDark ? 'bg-[#0d1117] border-zinc-800' : 'bg-white border-zinc-200'}`}>
                {/* Table Header */}
                <div className="hidden md:grid grid-cols-[2fr_2fr_1.5fr_1fr_1fr_0.5fr] gap-4 px-5 py-3.5 bg-zinc-950/60 border-b border-zinc-800/80 text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  <div>Profile</div>
                  <div>Email</div>
                  <div>Wallet Balance</div>
                  <div>Status</div>
                  <div>Joined Date</div>
                  <div className="text-right">Actions</div>
                </div>

                {/* Table Rows */}
                <div className="divide-y divide-zinc-800/50">
                  {paginatedUsers.length === 0 ? (
                    <div className="py-16 text-center text-zinc-500">
                      <Users className="w-10 h-10 mx-auto text-zinc-700 mb-3" />
                      <p className="font-bold text-zinc-400">No users found</p>
                      <p className="text-xs mt-1">Try adjusting your search filters</p>
                    </div>
                  ) : paginatedUsers.map((u) => {
                    const isDisabled = (u as any).disabled === true;
                    const joinDate = u.registrationDate ? new Date(u.registrationDate).toLocaleDateString('en-US', { day:'2-digit', month:'short', year:'numeric' }) : '—';
                    const isMenuOpen = openUserMenuId === u.id;
                    const initials = (u.username || 'U').substring(0, 2).toUpperCase();

                    return (
                      <div key={u.id} className="grid grid-cols-1 md:grid-cols-[2fr_2fr_1.5fr_1fr_1fr_0.5fr] gap-4 items-center px-5 py-4 hover:bg-zinc-900/40 transition-colors">
                        {/* Profile */}
                        <div className="flex items-center gap-3">
                          {u.avatarUrl ? (
                            <img src={u.avatarUrl} alt={u.username} className="w-10 h-10 rounded-full object-cover border-2 border-zinc-700 flex-shrink-0" />
                          ) : (
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0 ${getAvatarColor(u.username)}`}>
                              {initials}
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-white truncate">{u.username}</div>
                            <div className="text-[10px] text-zinc-500 font-mono truncate">{u.email}</div>
                          </div>
                        </div>

                        {/* Email (hidden on mobile) */}
                        <div className="hidden md:block text-xs text-zinc-400 font-mono truncate">{u.email}</div>

                        {/* Wallet Balance (Green NPR & Number) */}
                        <div className="text-sm font-extrabold text-[#00e676] font-mono">
                          NPR {(u.walletBalanceNpr || 0).toFixed(2)}
                        </div>

                        {/* Status */}
                        <div>
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                            isDisabled
                              ? 'bg-red-950/60 border-red-800/60 text-red-400'
                              : 'bg-emerald-950/60 border-emerald-800/60 text-emerald-400'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${isDisabled ? 'bg-red-400' : 'bg-emerald-400'}`}></span>
                            {isDisabled ? 'Disabled' : 'Active'}
                          </span>
                        </div>

                        {/* Joined Date */}
                        <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                          <Calendar className="w-3.5 h-3.5 flex-shrink-0" />
                          {joinDate}
                        </div>

                        {/* Actions - Three Dot Menu */}
                        <div className="relative flex justify-end" onClick={e => e.stopPropagation()}>
                          <button
                            onClick={() => {
                              setEditUserModal({
                                user: u,
                                newUsername: u.username || '',
                                newWalletBalance: u.walletBalanceNpr || 0,
                              });
                              setOpenUserMenuId(null);
                            }}
                            className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all cursor-pointer border border-transparent hover:border-zinc-700"
                            title="Edit User Details & Balance"
                          >
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                              <circle cx="10" cy="4" r="1.5"/><circle cx="10" cy="10" r="1.5"/><circle cx="10" cy="16" r="1.5"/>
                            </svg>
                          </button>

                          {isMenuOpen && (
                            <div className="absolute right-0 top-9 z-50 w-56 bg-[#111827] border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden">
                              <div className="p-1">
                                {[
                                  {
                                    label: 'Edit User (Name & Balance)',
                                    icon: <Edit3 className="w-3.5 h-3.5 text-emerald-400" />,
                                    onClick: () => {
                                      setEditUserModal({
                                        user: u,
                                        newUsername: u.username || '',
                                        newWalletBalance: u.walletBalanceNpr || 0,
                                      });
                                      setOpenUserMenuId(null);
                                    }
                                  },
                                  { label: 'Edit Username', icon: <Edit3 className="w-3.5 h-3.5 text-blue-400" />, onClick: () => { handleEditUsername(u); setOpenUserMenuId(null); } },
                                  { label: 'Edit Wallet Balance', icon: <CreditCard className="w-3.5 h-3.5 text-emerald-400" />, onClick: () => { handleEditWallet(u); setOpenUserMenuId(null); } },
                                  { label: 'View Orders', icon: <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />, onClick: () => { setViewUserOrdersModal({ userId: u.id, username: u.username, email: u.email }); setOpenUserMenuId(null); } },
                                  { label: 'View Transactions', icon: <ArrowLeftRight className="w-3.5 h-3.5 text-purple-400" />, onClick: () => { setViewUserTxnsModal({ userId: u.id, username: u.username }); setOpenUserMenuId(null); } },
                                ].map(item => (
                                  <button key={item.label} onClick={item.onClick}
                                    className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800 rounded-xl transition-all cursor-pointer">
                                    {item.icon}
                                    {item.label}
                                  </button>
                                ))}
                                <div className="my-1 h-px bg-zinc-800"></div>
                                <button onClick={() => handleToggleUserDisabled(u)}
                                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                                    isDisabled
                                      ? 'text-emerald-400 hover:bg-emerald-950/60'
                                      : 'text-red-400 hover:bg-red-950/60'
                                  }`}>
                                  <Power className={`w-3.5 h-3.5 ${isDisabled ? 'text-emerald-400' : 'text-red-400'}`} />
                                  {isDisabled ? 'Enable User' : 'Disable User'}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>Showing {(userPage-1)*USERS_PER_PAGE+1} to {Math.min(userPage*USERS_PER_PAGE, filteredUsers.length)} of {filteredUsers.length} users</span>
                  <div className="flex items-center gap-1">
                    <button disabled={userPage <= 1} onClick={() => setUserPage(p => p-1)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center bg-zinc-900 border border-zinc-800 disabled:opacity-30 hover:bg-zinc-800 cursor-pointer transition-all">
                      ‹
                    </button>
                    {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                      const pg = i + 1;
                      return (
                        <button key={pg} onClick={() => setUserPage(pg)}
                          className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold border transition-all cursor-pointer ${
                            userPage === pg ? 'bg-red-600 border-red-600 text-white' : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                          }`}>
                          {pg}
                        </button>
                      );
                    })}
                    {totalPages > 5 && <span className="px-1 text-zinc-500">...</span>}
                    {totalPages > 5 && (
                      <button onClick={() => setUserPage(totalPages)}
                        className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold border transition-all cursor-pointer ${
                          userPage === totalPages ? 'bg-red-600 border-red-600 text-white' : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                        }`}>
                        {totalPages}
                      </button>
                    )}
                    <button disabled={userPage >= totalPages} onClick={() => setUserPage(p => p+1)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center bg-zinc-900 border border-zinc-800 disabled:opacity-30 hover:bg-zinc-800 cursor-pointer transition-all">
                      ›
                    </button>
                  </div>
                </div>
              )}

              {/* Click outside to close menu */}
              {openUserMenuId && (
                <div className="fixed inset-0 z-40" onClick={() => setOpenUserMenuId(null)} />
              )}

              {/* EDIT USERNAME MODAL */}
              {editUsernameModal && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="w-full max-w-sm bg-[#0d1117] border border-zinc-800 rounded-2xl p-6 space-y-4 shadow-2xl">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                      <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                        <Edit3 className="w-4 h-4 text-blue-400" /> Edit Username
                      </h3>
                      <button onClick={() => setEditUsernameModal(null)} className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 cursor-pointer">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold">New Username</label>
                        <input type="text" value={editUsernameValue} onChange={e => setEditUsernameValue(e.target.value)}
                          placeholder="Enter new username..."
                          className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 text-xs" />
                      </div>
                      <div className="flex items-center justify-end gap-3 pt-1">
                        <button onClick={() => setEditUsernameModal(null)} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer">Cancel</button>
                        <button onClick={handleSaveUsername} disabled={editUsernameLoading || !editUsernameValue.trim()}
                          className="px-5 py-2 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 cursor-pointer flex items-center gap-1.5">
                          {editUsernameLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* EDIT WALLET MODAL */}
              {editWalletModal && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="w-full max-w-sm bg-[#0d1117] border border-zinc-800 rounded-2xl p-6 space-y-4 shadow-2xl">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                      <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-emerald-400" /> Edit Wallet Balance
                      </h3>
                      <button onClick={() => setEditWalletModal(null)} className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 cursor-pointer">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="space-y-3 text-xs">
                      <div className="flex items-center justify-between bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                        <span className="text-zinc-400">Current Balance</span>
                        <span className="font-black text-white font-mono">NPR {(editWalletModal.current).toFixed(2)}</span>
                      </div>
                      {/* Operation Tabs */}
                      <div className="grid grid-cols-3 gap-1.5 bg-zinc-950 p-1.5 rounded-xl border border-zinc-800">
                        {(['increase','decrease','set'] as const).map(mode => (
                          <button key={mode} onClick={() => setWalletEditMode(mode)}
                            className={`py-2 rounded-lg text-xs font-bold capitalize cursor-pointer transition-all ${
                              walletEditMode === mode
                                ? mode === 'increase' ? 'bg-emerald-600 text-white' : mode === 'decrease' ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'
                                : 'text-zinc-400 hover:text-white'
                            }`}>
                            {mode === 'increase' ? '+ Increase' : mode === 'decrease' ? '− Decrease' : '= Set Exact'}
                          </button>
                        ))}
                      </div>
                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold">Amount (NPR)</label>
                        <input type="number" value={walletEditAmount || ''} onChange={e => setWalletEditAmount(Number(e.target.value))} min="0"
                          placeholder="Enter amount..."
                          className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-emerald-500 text-xs font-mono" />
                      </div>
                      {/* Preview new balance */}
                      {walletEditAmount > 0 && (
                        <div className="flex items-center justify-between bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                          <span className="text-zinc-400">New Balance</span>
                          <span className="font-black text-emerald-400 font-mono">
                            NPR {(walletEditMode === 'increase'
                              ? editWalletModal.current + walletEditAmount
                              : walletEditMode === 'decrease'
                              ? Math.max(0, editWalletModal.current - walletEditAmount)
                              : walletEditAmount
                            ).toFixed(2)}
                          </span>
                        </div>
                      )}
                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold">Note (optional)</label>
                        <input type="text" value={walletEditNote} onChange={e => setWalletEditNote(e.target.value)}
                          placeholder="e.g. Admin credit, Refund..."
                          className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-emerald-500 text-xs" />
                      </div>
                      <div className="flex items-center justify-end gap-3 pt-1">
                        <button onClick={() => setEditWalletModal(null)} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer">Cancel</button>
                        <button onClick={handleSaveWallet} disabled={walletEditLoading || walletEditAmount <= 0}
                          className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/30 cursor-pointer flex items-center gap-1.5">
                          {walletEditLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                          Save Wallet
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW USER ORDERS MODAL */}
              {viewUserOrdersModal && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="w-full max-w-2xl bg-[#0d1117] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl max-h-[80vh] flex flex-col">
                    <div className="p-5 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between flex-shrink-0">
                      <div>
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <ShoppingBag className="w-4 h-4 text-amber-400" /> Orders — {viewUserOrdersModal.username}
                        </h3>
                        <p className="text-[11px] text-zinc-400 mt-0.5 font-mono">{viewUserOrdersModal.email}</p>
                      </div>
                      <button onClick={() => setViewUserOrdersModal(null)} className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-xl cursor-pointer">
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="overflow-y-auto flex-1 p-4 space-y-2">
                      {allOrders.filter(o => o.playerUid === viewUserOrdersModal.userId || (o as any).userId === viewUserOrdersModal.userId || (o as any).playerEmail === viewUserOrdersModal.email).length === 0 ? (
                        <div className="py-12 text-center text-zinc-500 text-xs">No orders found for this user.</div>
                      ) : allOrders.filter(o => o.playerUid === viewUserOrdersModal.userId || (o as any).userId === viewUserOrdersModal.userId || (o as any).playerEmail === viewUserOrdersModal.email).map(ord => (
                        <div key={ord.orderId} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between text-xs">
                          <div>
                            <div className="font-mono text-zinc-400 text-[10px]">#{(ord.orderId || '').slice(-6)}</div>
                            <div className="font-bold text-white">{ord.gameName} — {ord.packageName}</div>
                            <div className="text-zinc-400">{new Date(ord.createdAt).toLocaleDateString()}</div>
                          </div>
                          <div className="text-right">
                            <div className="font-black text-red-400 font-mono">NPR {ord.totalPriceNpr}</div>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              ord.status === 'Completed' || ord.status === 'COMPLETED'
                                ? 'bg-emerald-950 text-emerald-400'
                                : ord.status === 'Cancelled' || ord.status === 'CANCELLED'
                                ? 'bg-red-950 text-red-400'
                                : 'bg-amber-950 text-amber-400'
                            }`}>{ord.status}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW USER TRANSACTIONS MODAL */}
              {viewUserTxnsModal && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="w-full max-w-lg bg-[#0d1117] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl max-h-[80vh] flex flex-col">
                    <div className="p-5 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between flex-shrink-0">
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <ArrowLeftRight className="w-4 h-4 text-purple-400" /> Transactions — {viewUserTxnsModal.username}
                      </h3>
                      <button onClick={() => setViewUserTxnsModal(null)} className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-xl cursor-pointer">
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="overflow-y-auto flex-1 p-4">
                      <div className="py-12 text-center text-zinc-500 text-xs">
                        <ArrowLeftRight className="w-8 h-8 mx-auto text-zinc-700 mb-2" />
                        Transaction history is stored in Firestore walletTransactions collection.
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* UNIFIED EDIT USER MODAL (Product Package Popup Style) */}
              {editUserModal && (
                <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
                  <div className="w-full max-w-lg bg-[#141414] border border-[#2A2A2A] rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
                    {/* Header */}
                    <div className="px-6 py-4 bg-[#1B1B1B] border-b border-[#2A2A2A] flex items-center justify-between shrink-0">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-red-600/10 border border-red-500/20 text-red-500 flex items-center justify-center shrink-0">
                          <UserIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-base font-extrabold text-white tracking-tight">Edit User Account</h3>
                          <p className="text-xs text-zinc-400">Modify username and wallet balance for user</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setEditUserModal(null)}
                        className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Body */}
                    <div className="p-6 overflow-y-auto space-y-5">
                      {/* User Avatar & Info Card */}
                      <div className="flex items-center gap-3 p-3.5 bg-[#0F0F0F] border border-[#2A2A2A] rounded-xl">
                        {editUserModal.user.avatarUrl ? (
                          <img src={editUserModal.user.avatarUrl} alt={editUserModal.user.username} className="w-10 h-10 rounded-full object-cover border border-zinc-700" />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-emerald-950 border border-emerald-800/80 text-[#00e676] font-bold flex items-center justify-center text-sm">
                            {(editUserModal.user.username || 'U').substring(0, 2).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold text-white font-mono">ID: {editUserModal.user.id}</div>
                          <div className="text-[11px] text-zinc-400 font-mono truncate">{editUserModal.user.email || 'No email registered'}</div>
                        </div>
                      </div>

                      {/* Username Section */}
                      <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-4 space-y-3">
                        <div className="text-[11px] font-extrabold text-white uppercase tracking-wider flex items-center gap-2 border-b border-[#2A2A2A]/60 pb-2">
                          <Edit3 className="w-3.5 h-3.5 text-blue-400" />
                          <span>USER USERNAME</span>
                        </div>
                        <div>
                          <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">
                            User Display Name <span className="text-[#FF2D2D]">*</span>
                          </label>
                          <input
                            type="text"
                            value={editUserModal.newUsername}
                            onChange={(e) => setEditUserModal({ ...editUserModal, newUsername: e.target.value })}
                            placeholder="Enter username..."
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-white outline-none focus:border-[#FF2D2D] focus:ring-1 focus:ring-[#FF2D2D]/30 transition-all font-medium text-xs"
                            required
                          />
                        </div>
                      </div>

                      {/* Wallet Balance Section */}
                      <div className="bg-[#1B1B1B] border border-[#2A2A2A] rounded-xl p-4 space-y-3">
                        <div className="text-[11px] font-extrabold text-white uppercase tracking-wider flex items-center justify-between border-b border-[#2A2A2A]/60 pb-2">
                          <div className="flex items-center gap-2">
                            <CreditCard className="w-3.5 h-3.5 text-[#00e676]" />
                            <span>WALLET BALANCE (NPR)</span>
                          </div>
                          <div className="text-[11px] font-mono">
                            <span className="text-zinc-400">Current: </span>
                            <span className="text-[#00e676] font-bold">NPR {(editUserModal.user.walletBalanceNpr || 0).toFixed(2)}</span>
                          </div>
                        </div>

                        <div>
                          <label className="block text-zinc-300 mb-1.5 font-semibold text-[11px]">
                            New Wallet Balance (NPR)
                          </label>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={editUserModal.newWalletBalance}
                            onChange={(e) => setEditUserModal({ ...editUserModal, newWalletBalance: Math.max(0, Number(e.target.value)) })}
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0F0F0F] border border-[#2A2A2A] text-[#00e676] font-mono font-extrabold text-sm outline-none focus:border-[#00e676] focus:ring-1 focus:ring-[#00e676]/30 transition-all"
                          />
                        </div>

                        {/* Quick Preset Buttons */}
                        <div className="flex items-center gap-2 pt-1 flex-wrap">
                          <span className="text-[10px] text-zinc-400 font-bold uppercase">Quick Add:</span>
                          {[100, 500, 1000, 2000].map((amt) => (
                            <button
                              key={amt}
                              type="button"
                              onClick={() => setEditUserModal({ ...editUserModal, newWalletBalance: editUserModal.newWalletBalance + amt })}
                              className="px-2.5 py-1 rounded-lg bg-[#0F0F0F] hover:bg-[#252525] border border-[#2A2A2A] text-[#00e676] font-mono text-[11px] font-bold cursor-pointer transition-all active:scale-95"
                            >
                              +NPR {amt}
                            </button>
                          ))}
                          <button
                            type="button"
                            onClick={() => setEditUserModal({ ...editUserModal, newWalletBalance: 0 })}
                            className="px-2.5 py-1 rounded-lg bg-[#0F0F0F] hover:bg-red-950/40 border border-[#2A2A2A] text-red-400 font-mono text-[11px] font-bold cursor-pointer transition-all active:scale-95 ml-auto"
                          >
                            Reset to 0
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="px-6 py-4 bg-[#0F0F0F] border-t border-[#2A2A2A] flex items-center justify-end gap-3 shrink-0">
                      <button
                        onClick={() => setEditUserModal(null)}
                        className="px-4 py-2.5 bg-[#1B1B1B] hover:bg-[#252525] text-zinc-300 font-bold rounded-xl text-xs cursor-pointer transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          if (!editUserModal.newUsername.trim()) {
                            alert('Username cannot be empty');
                            return;
                          }
                          setEditUserConfirmModal(editUserModal);
                        }}
                        className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-black rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer active:scale-95 transition-all"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Save Changes</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* CONFIRMATION POPUP FOR EDIT USER */}
              {editUserConfirmModal && (
                <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
                  <div className="w-full max-w-md bg-[#141414] border border-[#2A2A2A] rounded-2xl p-6 space-y-5 shadow-2xl relative">
                    <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 shadow-md">
                          <AlertTriangle className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-base font-black text-white tracking-tight">Confirm User Update</h3>
                          <p className="text-xs text-zinc-400 font-medium">Please review details before saving</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setEditUserConfirmModal(null)}
                        className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="bg-[#0F0F0F] border border-[#2A2A2A] rounded-xl p-4 space-y-3 text-xs">
                      <div className="text-zinc-300 font-medium">
                        Are you sure you want to update user account details for <span className="text-white font-bold">{editUserConfirmModal.user.username}</span>?
                      </div>

                      <div className="space-y-2.5 pt-2.5 border-t border-[#2A2A2A]">
                        {/* Username diff */}
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-zinc-400 font-medium">Username:</span>
                          <div className="flex items-center gap-1.5 font-mono">
                            <span className="text-zinc-500 line-through">{editUserConfirmModal.user.username}</span>
                            <span className="text-white font-bold">→ {editUserConfirmModal.newUsername}</span>
                          </div>
                        </div>

                        {/* Wallet balance diff */}
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-zinc-400 font-medium">Wallet Balance:</span>
                          <div className="flex items-center gap-1.5 font-mono">
                            <span className="text-zinc-500 line-through">NPR {(editUserConfirmModal.user.walletBalanceNpr || 0).toFixed(2)}</span>
                            <span className="text-[#00e676] font-extrabold">→ NPR {editUserConfirmModal.newWalletBalance.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-3 pt-1">
                      <button
                        onClick={() => setEditUserConfirmModal(null)}
                        className="px-4 py-2.5 bg-[#1B1B1B] hover:bg-[#252525] text-zinc-300 font-bold rounded-xl text-xs cursor-pointer transition-all"
                      >
                        Go Back
                      </button>
                      <button
                        disabled={editUserSaving}
                        onClick={async () => {
                          setEditUserSaving(true);
                          const { user, newUsername, newWalletBalance } = editUserConfirmModal;

                          try {
                            // 1. Update Username if changed
                            if (newUsername.trim() !== user.username) {
                              await adminUpdateUsername(user.id, newUsername.trim());
                            }

                            // 2. Update Wallet Balance if changed
                            if (newWalletBalance !== (user.walletBalanceNpr || 0)) {
                              await adminUpdateUserWallet(
                                user.id,
                                'set',
                                newWalletBalance,
                                user.walletBalanceNpr || 0,
                                'Admin Manual Adjustment'
                              );
                            }

                            // 3. Update local state
                            setUsersList((prev) =>
                              prev.map((u) =>
                                u.id === user.id
                                  ? {
                                      ...u,
                                      username: newUsername.trim(),
                                      walletBalanceNpr: newWalletBalance,
                                    }
                                  : u
                              )
                            );

                            setCopyToast('User profile & wallet balance updated successfully!');
                            setTimeout(() => setCopyToast(null), 3000);
                          } catch (err) {
                            console.error('Error saving user update:', err);
                          } finally {
                            setEditUserSaving(false);
                            setEditUserConfirmModal(null);
                            setEditUserModal(null);
                          }
                        }}
                        className="px-5 py-2.5 bg-[#00c853] hover:bg-[#00e676] text-white font-black rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
                      >
                        {editUserSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4 stroke-[3]" />}
                        <span>Confirm & Save</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          );
        })()}

        {/* VIEW 8.5: REVIEWS MANAGEMENT */}
        {(activeMainSection === 'REVIEWS' || activeSubItem === 'Reviews') && (
          <div className="p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-emerald-400" /> Customer Reviews Management
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Approve customer feedback before it appears in the "What Our Customer Say" marquee carousel on the home page.
                </p>
              </div>

              {/* Status Filter Tabs */}
              <div className="flex items-center gap-1.5 bg-zinc-900/90 p-1.5 rounded-xl border border-zinc-800 text-xs">
                {(['PENDING', 'APPROVED', 'REJECTED', 'ALL'] as const).map((st) => {
                  const count = st === 'ALL' 
                    ? reviewsList.length 
                    : reviewsList.filter((r) => (r.status || 'APPROVED') === st).length;
                  const isActive = reviewStatusFilter === st;

                  return (
                    <button
                      key={st}
                      onClick={() => setReviewStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        isActive
                          ? 'bg-red-600 text-white shadow-md shadow-red-900/30'
                          : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                      }`}
                    >
                      <span>{st === 'PENDING' ? 'Pending' : st === 'APPROVED' ? 'Approved' : st === 'REJECTED' ? 'Rejected' : 'All'}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${isActive ? 'bg-white/20 text-white' : 'bg-zinc-800 text-zinc-400'}`}>
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reviews Grid */}
            {(() => {
              const filtered = reviewsList.filter((r) => {
                const currentStatus = r.status || 'APPROVED';
                if (reviewStatusFilter === 'ALL') return true;
                return currentStatus === reviewStatusFilter;
              });

              if (filtered.length === 0) {
                return (
                  <div className={`p-12 text-center rounded-2xl border border-zinc-800 ${cardBgClass} space-y-3`}>
                    <MessageSquare className="w-10 h-10 text-zinc-600 mx-auto opacity-50" />
                    <h3 className="font-extrabold text-sm text-zinc-300">No Reviews Found</h3>
                    <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                      There are no customer reviews matching the "{reviewStatusFilter}" filter at the moment.
                    </p>
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filtered.map((rev) => {
                    const status = rev.status || 'APPROVED';

                    return (
                      <div
                        key={rev.id}
                        className={`p-5 rounded-2xl border transition-all flex flex-col justify-between gap-4 ${cardBgClass} ${
                          status === 'PENDING'
                            ? 'border-amber-500/50 shadow-lg shadow-amber-950/10'
                            : status === 'APPROVED'
                            ? 'border-emerald-500/30'
                            : 'border-red-900/40 opacity-75'
                        }`}
                      >
                        <div className="space-y-3">
                          {/* Card Header: User info & Status badge */}
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2.5">
                              {rev.avatarUrl ? (
                                <img src={rev.avatarUrl} alt={rev.userName} className="w-9 h-9 rounded-full object-cover border border-zinc-700" />
                              ) : (
                                <div className="w-9 h-9 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-300 font-bold text-xs">
                                  {rev.userName.charAt(0).toUpperCase()}
                                </div>
                              )}
                              <div>
                                <h4 className="font-black text-sm text-white">{rev.userName}</h4>
                                <span className="text-[10px] text-zinc-400 font-medium">{rev.date} • {rev.game}</span>
                              </div>
                            </div>

                            {/* Status Pill */}
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                                status === 'APPROVED'
                                  ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                                  : status === 'PENDING'
                                  ? 'bg-amber-950 text-amber-400 border-amber-800 animate-pulse'
                                  : 'bg-red-950 text-red-400 border-red-900'
                              }`}
                            >
                              {status}
                            </span>
                          </div>

                          {/* Star Rating */}
                          <div className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <span key={i} className={i < rev.rating ? 'text-amber-400' : 'text-zinc-700'}>★</span>
                            ))}
                            <span className="ml-1.5 text-zinc-400 text-[11px] font-normal">({rev.rating}/5)</span>
                          </div>

                          {/* Review Comment Text */}
                          <p className="text-xs text-zinc-300 leading-relaxed bg-zinc-900/60 p-3 rounded-xl border border-zinc-800/80 italic">
                            "{rev.comment}"
                          </p>
                        </div>

                        {/* Card Footer Actions */}
                        <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-2 text-xs">
                          <button
                            onClick={() => handleDeleteReview(rev.id)}
                            className="p-2 rounded-xl bg-zinc-900 hover:bg-red-950 text-zinc-400 hover:text-red-400 border border-zinc-800 hover:border-red-900 transition-colors cursor-pointer"
                            title="Delete Review"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                          <div className="flex items-center gap-2">
                            {status !== 'REJECTED' && (
                              <button
                                onClick={() => handleRejectReview(rev.id)}
                                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-red-900/50 text-zinc-300 hover:text-red-300 border border-zinc-700 hover:border-red-800 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            )}

                            {status !== 'APPROVED' && (
                              <button
                                onClick={() => handleApproveReview(rev.id)}
                                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-md shadow-emerald-950/40 transition-colors cursor-pointer flex items-center gap-1"
                              >
                                <CheckCircle className="w-3.5 h-3.5 stroke-[2.5]" />
                                <span>Approve</span>
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        )}

        {/* VIEW 8: NOTIFICATIONS MANAGER (Send to ALL or Specific User by Email) */}
        {(activeMainSection === 'NOTIFICATIONS' || activeSubItem === 'Notifications') && (
          <div className="p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
              <div>
                <h2 className="text-lg font-black text-white flex items-center gap-2">
                  <Bell className="w-5 h-5 text-amber-400" /> System & User Notifications Center
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Send notifications to all store users or target a single user directly by entering their registered email address.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Form: Send Notification */}
              <div className={`lg:col-span-7 p-5 rounded-2xl space-y-4 ${cardBgClass}`}>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2 border-b border-zinc-800/80 pb-3">
                  <Send className="w-4 h-4 text-amber-400" /> Send Custom Notification
                </h3>

                <form onSubmit={handleAdminSendNotification} className="space-y-4 text-xs">
                  {/* Target Choice */}
                  <div>
                    <label className="block text-zinc-400 font-extrabold mb-1.5 uppercase tracking-wider text-[11px]">
                      Target Audience
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setNotifTargetType('ALL')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          notifTargetType === 'ALL'
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-extrabold shadow-xs'
                            : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        <div className="font-extrabold flex items-center gap-1.5 text-xs">
                          <Users className="w-4 h-4 text-amber-400" /> All Store Users (Broadcast)
                        </div>
                        <div className="text-[10px] text-zinc-400 mt-1">Visible to all registered & guest users</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setNotifTargetType('USER')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          notifTargetType === 'USER'
                            ? 'bg-red-500/20 border-red-500 text-red-300 font-extrabold shadow-xs'
                            : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        <div className="font-extrabold flex items-center gap-1.5 text-xs">
                          <User className="w-4 h-4 text-red-400" /> Specific User Only
                        </div>
                        <div className="text-[10px] text-zinc-400 mt-1">Target user by exact Email address</div>
                      </button>
                    </div>
                  </div>

                  {/* Target Email (If specific user selected) */}
                  {notifTargetType === 'USER' && (
                    <div className="space-y-1">
                      <label className="block text-zinc-400 font-semibold mb-1">
                        Target User Email <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="email"
                        value={notifTargetEmail}
                        onChange={(e) => setNotifTargetEmail(e.target.value)}
                        placeholder="e.g. user@gmail.com"
                        className={`w-full p-2.5 rounded-xl outline-none border border-red-500/40 focus:border-red-500 ${inputBgClass}`}
                        required={notifTargetType === 'USER'}
                      />
                      <p className="text-[10px] text-zinc-500 mt-1">
                        Click user email from list to fill:
                      </p>
                      <div className="flex flex-wrap gap-1 mt-1 max-h-24 overflow-y-auto">
                        {usersList.slice(0, 10).map((u) => (
                          <button
                            key={u.id}
                            type="button"
                            onClick={() => setNotifTargetEmail(u.email || '')}
                            className="px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-[10px] font-mono text-zinc-300 truncate max-w-[160px] cursor-pointer"
                          >
                            {u.email}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Category Dropdown */}
                  <div>
                    <label className="block text-zinc-400 font-semibold mb-1">Notification Category</label>
                    <select
                      value={notifCategory}
                      onChange={(e: any) => setNotifCategory(e.target.value)}
                      className={`w-full p-2.5 rounded-xl outline-none cursor-pointer ${inputBgClass}`}
                    >
                      <option value="Announcement">Announcement 📢</option>
                      <option value="Promo Code">Promo Code 🏷️</option>
                      <option value="Order">Order Status 📦</option>
                      <option value="Wallet">Wallet Update 💳</option>
                      <option value="System">System Alert ⚡</option>
                    </select>
                  </div>

                  {/* Title */}
                  <div>
                    <label className="block text-zinc-400 font-semibold mb-1">Title</label>
                    <input
                      type="text"
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      placeholder="e.g. Your Order is Completed!"
                      className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                      required
                    />
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-zinc-400 font-semibold mb-1">Message Content</label>
                    <textarea
                      value={notifMessage}
                      onChange={(e) => setNotifMessage(e.target.value)}
                      placeholder="e.g. Your Free Fire Diamonds have been delivered to your UID. Thank you!"
                      className={`w-full p-2.5 rounded-xl outline-none h-24 ${inputBgClass}`}
                      required
                    />
                  </div>

                  {/* Expiration Text & Pin Switch */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-zinc-400 font-semibold mb-1">Expiration Text (Optional)</label>
                      <input
                        type="text"
                        value={notifExpiresIn}
                        onChange={(e) => setNotifExpiresIn(e.target.value)}
                        placeholder="e.g. Valid till 24 Hours"
                        className={`w-full p-2 rounded-xl outline-none ${inputBgClass}`}
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-5">
                      <input
                        type="checkbox"
                        id="pinNotif"
                        checked={notifIsPinned}
                        onChange={(e) => setNotifIsPinned(e.target.checked)}
                        className="w-4 h-4 rounded text-amber-500 accent-amber-500 cursor-pointer"
                      />
                      <label htmlFor="pinNotif" className="text-zinc-300 font-bold cursor-pointer">
                        Pin to Top of User Feed
                      </label>
                    </div>
                  </div>

                  {notifSendMsg && (
                    <p className={`text-xs font-bold p-2.5 rounded-xl ${
                      notifSendMsg.includes('successfully') ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' : 'bg-red-950/80 text-red-400 border border-red-800'
                    }`}>
                      {notifSendMsg}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={notifSending}
                    className="w-full py-3 px-5 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 text-sm"
                  >
                    {notifSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    Send Notification Now
                  </button>
                </form>
              </div>

              {/* Right Panel: Preview & Helper Card */}
              <div className="lg:col-span-5 space-y-4">
                <div className={`p-5 rounded-2xl space-y-3 ${cardBgClass}`}>
                  <h4 className="text-xs font-extrabold text-amber-400 uppercase tracking-wider flex items-center gap-2">
                    <Eye className="w-4 h-4" /> Live Card Preview
                  </h4>
                  <p className="text-[11px] text-zinc-400">
                    How this notification will appear on the user's device:
                  </p>

                  <div className="p-4 rounded-xl bg-white text-zinc-900 border border-zinc-200 shadow-md space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase bg-red-100 text-red-700 border border-red-200">
                        {notifCategory}
                      </span>
                      <span className="text-[10px] text-zinc-400 font-semibold">Just now</span>
                    </div>

                    <h5 className="font-extrabold text-xs text-zinc-900">
                      {notifTitle || 'Sample Title'}
                    </h5>
                    <p className="text-[11px] text-zinc-600 leading-normal">
                      {notifMessage || 'Sample notification content message preview...'}
                    </p>
                  </div>
                </div>

                <div className={`p-4 rounded-2xl space-y-2 text-xs text-zinc-400 ${cardBgClass}`}>
                  <h5 className="font-bold text-white flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-emerald-400" /> Automatic Triggers Active
                  </h5>
                  <ul className="space-y-1.5 text-[11px] text-zinc-300 list-disc list-inside">
                    <li><b>Wallet Deposit:</b> Approving manual deposit or completing online load auto-sends <i>"You have successfully credited Rs. X in your account"</i>.</li>
                    <li><b>Order Completion:</b> Marking an order Completed auto-delivers voucher codes to the buyer's email when the package requires a redeem code.</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 8.5: REDEEM CODES STOCK MANAGER */}
        {(activeMainSection === 'REDEEM_CODES' || activeSubItem === 'Redeem Codes') && (() => {
          const activeGame = games.find(g => g.id === (selectedRcGameId || games[0]?.id)) || games[0];
          const activePkgs = activeGame?.packages || [];
          const activePkg = activePkgs.find(p => p.id === (selectedRcPackageId || activePkgs[0]?.id)) || activePkgs[0];

          const filteredCodes = redeemCodesList.filter(c => {
            if (rcStatusFilter !== 'ALL' && c.status !== rcStatusFilter) return false;
            if (rcProductFilter !== 'ALL' && (c.productId || c.gameId) !== rcProductFilter) return false;
            if (rcPackageFilter !== 'ALL' && c.packageId !== rcPackageFilter) return false;
            if (rcFilterSearch.trim()) {
              const q = rcFilterSearch.toLowerCase().trim();
              return c.code.toLowerCase().includes(q) || c.packageName.toLowerCase().includes(q) || c.gameName.toLowerCase().includes(q) || (c.usedByEmail || '').toLowerCase().includes(q) || (c.usedByOrder || '').toLowerCase().includes(q);
            }
            return true;
          });

          const totalCount = redeemCodesList.length;
          const availCount = redeemCodesList.filter(c => c.status === 'AVAILABLE').length;
          const reservedCount = redeemCodesList.filter(c => c.status === 'RESERVED').length;
          const deliveredCount = redeemCodesList.filter(c => c.status === 'DELIVERED').length;
          const redeemedCount = redeemCodesList.filter(c => c.status === 'REDEEMED').length;

          return (
            <div className="p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <Ticket className="w-5 h-5 text-emerald-400" /> Redeem Codes & Stock Manager
                  </h2>
                  <p className="text-xs text-zinc-400 mt-1">
                    Select any game or product, select a package, and add redeem codes to stock. When a user buys that package, an available code will automatically be assigned and delivered to their email address!
                  </p>
                </div>
              </div>

              {/* Stats Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className={`p-4 rounded-2xl flex items-center justify-between border border-zinc-800 ${cardBgClass}`}>
                  <div>
                    <p className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">Total Stock Codes</p>
                    <p className="text-2xl font-black text-white mt-1">{totalCount}</p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center text-zinc-300">
                    <Box className="w-5 h-5" />
                  </div>
                </div>

                <div className={`p-4 rounded-2xl flex items-center justify-between border border-emerald-500/30 bg-emerald-950/20`}>
                  <div>
                    <p className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Available (In Stock)</p>
                    <p className="text-2xl font-black text-emerald-300 mt-1">{availCount}</p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                </div>

                <div className={`p-4 rounded-2xl flex items-center justify-between border border-zinc-800 ${cardBgClass}`}>
                  <div>
                    <p className="text-[11px] font-bold text-red-400 uppercase tracking-wider">Used / Delivered</p>
                    <p className="text-2xl font-black text-red-300 mt-1">{reservedCount + deliveredCount + redeemedCount}</p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center text-red-400">
                    <Tag className="w-5 h-5" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: Add Redeem Codes Form */}
                <div className={`lg:col-span-5 p-5 rounded-2xl space-y-4 ${cardBgClass}`}>
                  <h3 className="text-sm font-extrabold text-white flex items-center gap-2 border-b border-zinc-800/80 pb-3">
                    <Plus className="w-4 h-4 text-emerald-400" /> Add Redeem Codes Stock
                  </h3>

                  <form onSubmit={handleAddRedeemCodesSubmit} className="space-y-4 text-xs">
                    {/* Select Game / Product */}
                    <div>
                      <label className="block text-zinc-400 font-extrabold mb-1.5 uppercase text-[10px]">
                        1. Select Game / Product
                      </label>
                      <select
                        value={selectedRcGameId || activeGame?.id || ''}
                        onChange={(e) => {
                          const gid = e.target.value;
                          setSelectedRcGameId(gid);
                          const g = games.find(gm => gm.id === gid);
                          if (g && g.packages && g.packages.length > 0) {
                            setSelectedRcPackageId(g.packages[0].id);
                          }
                        }}
                        className={`w-full p-2.5 rounded-xl outline-none cursor-pointer font-bold ${inputBgClass}`}
                      >
                        {games.map((g) => (
                          <option key={g.id} value={g.id}>
                            {g.name} ({g.packages?.length || 0} packages)
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Select Package */}
                    <div>
                      <label className="block text-zinc-400 font-extrabold mb-1.5 uppercase text-[10px]">
                        2. Select Package / Item
                      </label>
                      <select
                        value={selectedRcPackageId || activePkg?.id || ''}
                        onChange={(e) => setSelectedRcPackageId(e.target.value)}
                        className={`w-full p-2.5 rounded-xl outline-none cursor-pointer font-bold ${inputBgClass}`}
                      >
                        {activePkgs.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} - NPR {p.priceNpr.toLocaleString('en-IN')} ({p.diamonds} Units)
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Input Codes Area */}
                    <div>
                      <label className="block text-zinc-400 font-extrabold mb-1.5 uppercase text-[10px]">
                        3. Redeem Codes (Paste 1 Code per line)
                      </label>
                      <textarea
                        value={rcInputText}
                        onChange={(e) => setRcInputText(e.target.value)}
                        placeholder="e.g.&#10;UG-CODE-882190&#10;UG-CODE-994120&#10;FF-PROMO-102931"
                        className={`w-full p-3 rounded-xl outline-none font-mono text-emerald-300 h-32 leading-relaxed ${inputBgClass}`}
                        required
                      />
                      <p className="text-[10px] text-zinc-500 mt-1">
                        ⚡ Tip: You can paste multiple codes at once. Each line will be saved as an available redeem code in Supabase!
                      </p>
                    </div>

                    {rcMsg && (
                      <p className={`text-xs font-bold p-2.5 rounded-xl ${
                        rcMsg.includes('Successfully') ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' : 'bg-red-950/80 text-red-400 border border-red-800'
                      }`}>
                        {rcMsg}
                      </p>
                    )}

                    <button
                      type="submit"
                      disabled={rcSubmitting}
                      className="w-full py-3 px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 text-xs"
                    >
                      {rcSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                      Save Redeem Codes to Supabase
                    </button>
                  </form>
                </div>

                {/* Right: Stock Table & Filters */}
                <div className={`lg:col-span-7 p-5 rounded-2xl space-y-4 ${cardBgClass}`}>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800/80 pb-3">
                    <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                      <Box className="w-4 h-4 text-amber-400" /> Stock Table ({filteredCodes.length})
                    </h3>

                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                        <input
                          type="text"
                          value={rcFilterSearch}
                          onChange={(e) => setRcFilterSearch(e.target.value)}
                          placeholder="Search code or user..."
                          className={`pl-8 pr-3 py-1.5 rounded-xl text-xs outline-none ${inputBgClass}`}
                        />
                      </div>

                      <select value={rcProductFilter} onChange={(e) => { setRcProductFilter(e.target.value); setRcPackageFilter('ALL'); }} className={`p-1.5 rounded-xl text-xs outline-none font-bold cursor-pointer ${inputBgClass}`}>
                        <option value="ALL">All Products</option>
                        {[...new Map(redeemCodesList.map((r) => [r.productId || r.gameId, r.gameName])).entries()].filter(([id]) => id).map(([id,name]) => <option key={id} value={id as string}>{name as string || id as string}</option>)}
                      </select>
                      <select value={rcPackageFilter} onChange={(e) => setRcPackageFilter(e.target.value)} className={`p-1.5 rounded-xl text-xs outline-none font-bold cursor-pointer ${inputBgClass}`}>
                        <option value="ALL">All Packages</option>
                        {[...new Map(redeemCodesList.filter(r => rcProductFilter==='ALL' || (r.productId||r.gameId)===rcProductFilter).map((r) => [r.packageId, r.packageName])).entries()].filter(([id]) => id).map(([id,name]) => <option key={id} value={id as string}>{name as string || id as string}</option>)}
                      </select>

                      <select
                        value={rcStatusFilter}
                        onChange={(e: any) => setRcStatusFilter(e.target.value)}
                        className={`p-1.5 rounded-xl text-xs outline-none font-bold cursor-pointer ${inputBgClass}`}
                      >
                        <option value="ALL">All Status</option>
                        <option value="AVAILABLE">Available</option>
                        <option value="RESERVED">Reserved</option><option value="DELIVERED">Delivered</option><option value="REDEEMED">Redeemed</option><option value="CANCELLED">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  <div className="overflow-x-auto max-h-[480px] overflow-y-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-zinc-800 text-[10px] text-zinc-400 uppercase tracking-wider">
                          <th className="p-2.5 font-extrabold">Redeem Code</th>
                          <th className="p-2.5 font-extrabold">Game / Package</th>
                          <th className="p-2.5 font-extrabold">Status</th>
                          <th className="p-2.5 font-extrabold">Used By</th>
                          <th className="p-2.5 font-extrabold text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800/50">
                        {filteredCodes.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="p-6 text-center text-zinc-500 font-semibold">
                              No redeem codes found in database. Add codes using the form on the left!
                            </td>
                          </tr>
                        ) : (
                          filteredCodes.map((rc) => (
                            <tr key={rc.id} className="hover:bg-zinc-800/30 transition-colors">
                              <td className="p-2.5">
                                <div className="font-mono text-emerald-400 font-extrabold flex items-center gap-1.5">
                                  {revealedRcIds.has(rc.id) ? rc.code : `${rc.code.slice(0, Math.max(0, Math.min(8, rc.code.length)))}${rc.code.length > 8 ? '-****-****' : '****'}`}
                                  <button onClick={() => setRevealedRcIds(prev => { const next=new Set(prev); if(next.has(rc.id)) next.delete(rc.id); else next.add(rc.id); return next; })} className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer" title={revealedRcIds.has(rc.id) ? 'Hide Code' : 'Reveal Code'}>
                                    {revealedRcIds.has(rc.id) ? <Lock className="w-3 h-3" /> : <ZoomIn className="w-3 h-3" />}
                                  </button>
                                  {revealedRcIds.has(rc.id) && <button onClick={() => { navigator.clipboard.writeText(rc.code); setCopiedField(rc.id); setTimeout(() => setCopiedField(null), 2000); }} className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer" title="Copy Code">{copiedField === rc.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}</button>}
                                </div>
                              </td>

                              <td className="p-2.5">
                                <div className="font-bold text-white text-xs">{rc.packageName}</div>
                                <div className="text-[10px] text-zinc-400">{rc.gameName}</div>
                              </td>

                              <td className="p-2.5">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                                  rc.status === 'AVAILABLE' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                                  rc.status === 'RESERVED' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                                  rc.status === 'DELIVERED' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' :
                                  rc.status === 'REDEEMED' ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' :
                                  'bg-red-500/20 text-red-300 border border-red-500/30'
                                }`}>
                                  {rc.status}
                                </span>
                              </td>

                              <td className="p-2.5">
                                {rc.status !== 'AVAILABLE' ? (
                                  <div>
                                    <div className="font-semibold text-zinc-200 text-[11px] truncate max-w-[140px]">{rc.usedByEmail || 'User'}</div>
                                    <div className="font-mono text-[9px] text-zinc-500">Order: {rc.usedByOrder || 'N/A'}</div>
                                  </div>
                                ) : (
                                  <span className="text-zinc-600 font-mono text-[10px]">—</span>
                                )}
                              </td>

                              <td className="p-2.5 text-right">
                                <button
                                  onClick={() => handleDeleteRcCode(rc.id)}
                                  className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-400 hover:text-white transition-all cursor-pointer"
                                  title="Delete Code"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {/* VIEW 9: SETTINGS (Password Change, Theme, Broadcast Notification) */}
        {(activeMainSection === 'SETTINGS' || activeSubItem === 'Settings') && (
          <div className="p-6 space-y-6">
            
            {/* Change Admin Password */}
            <div className={`p-5 rounded-2xl space-y-4 max-w-xl ${cardBgClass}`}>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-red-500" /> Change Admin Password
              </h3>

              <form onSubmit={handleChangePassword} className="space-y-3 text-xs">
                <div>
                  <label className="block text-zinc-400 mb-1">Current Password</label>
                  <input
                    type="password"
                    value={pwdCurrent}
                    onChange={(e) => setPwdCurrent(e.target.value)}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    required
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1">New Password</label>
                  <input
                    type="password"
                    value={pwdNew}
                    onChange={(e) => setPwdNew(e.target.value)}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    required
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1">Confirm New Password</label>
                  <input
                    type="password"
                    value={pwdConfirm}
                    onChange={(e) => setPwdConfirm(e.target.value)}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    required
                  />
                </div>

                {pwdMsg && (
                  <p className={`text-xs font-bold ${pwdMsg.includes('successfully') ? 'text-emerald-400' : 'text-red-400'}`}>
                    {pwdMsg}
                  </p>
                )}

                <button
                  type="submit"
                  className="py-2.5 px-5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
                >
                  Update Admin Password
                </button>
              </form>
            </div>
{/* Payment page (QR checkout) branding */}
<PaymentPageSettingsCard isDark={isDark} />
            {/* Manual Payment QR Settings & Deposit Control */}
            <div className={`p-5 rounded-2xl space-y-5 max-w-xl ${cardBgClass}`}>
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-amber-400" /> Manual Payment QR Code & Deposit Options
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Manage the manual QR code image and control which wallet top-up payment methods are enabled for users.
                </p>
              </div>

              {/* Deposit Payment Mode Toggle */}
              <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-2">
                <label className="block text-xs font-extrabold text-amber-400 uppercase tracking-wider">
                  Active Wallet Deposit Methods
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setManualPaySettings(prev => ({ ...prev, paymentMode: 'both' }))}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      (manualPaySettings.paymentMode || 'both') === 'both'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold">Both Active</div>
                    <div className="text-[10px] text-zinc-400 mt-0.5">Online & Manual QR</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setManualPaySettings(prev => ({ ...prev, paymentMode: 'online' }))}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      manualPaySettings.paymentMode === 'online'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold">Instant Online Only</div>
                    <div className="text-[10px] text-zinc-400 mt-0.5">eSewa/Khalti/FonePay</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setManualPaySettings(prev => ({ ...prev, paymentMode: 'manual' }))}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      manualPaySettings.paymentMode === 'manual'
                        ? 'bg-purple-500/20 border-purple-500 text-purple-300 font-bold'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold">Manual QR Only</div>
                    <div className="text-[10px] text-zinc-400 mt-0.5">Scan & Upload Screenshot</div>
                  </button>
                </div>
              </div>

              {/* Current QR preview */}
              <div className="flex flex-col items-center gap-3">
                <img
                  src={manualPayQrPreview || manualPaySettings.qrImageUrl}
                  alt="Current QR"
                  className="w-44 h-44 object-contain rounded-xl bg-white p-2 border border-zinc-700"
                  onError={(e) => { (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" viewBox="0 0 160 160"><rect width="160" height="160" fill="%2318181b"/><text x="50%" y="50%" fill="%23888" font-size="12" text-anchor="middle" dy=".3em">No QR</text></svg>'; }}
                />
                <label className="w-full py-2.5 px-4 rounded-xl border border-dashed border-zinc-600 text-zinc-400 text-xs font-bold text-center cursor-pointer hover:border-amber-500/60 hover:text-amber-400 transition-all">
                  {manualPayQrFile ? manualPayQrFile.name : 'Click to upload new QR image'}
                  <input type="file" accept="image/*" className="hidden" onChange={handleManualPayQrChange} />
                </label>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-zinc-400 mb-1 font-semibold">QR Image URL (direct link option)</label>
                  <input
                    type="text"
                    value={manualPaySettings.qrImageUrl}
                    onChange={(e) => setManualPaySettings(prev => ({ ...prev, qrImageUrl: e.target.value }))}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    placeholder="https://example.com/qr-code.png"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 mb-1 font-semibold">Account Name (shown in remarks hint)</label>
                  <input
                    type="text"
                    value={manualPaySettings.accountName}
                    onChange={(e) => setManualPaySettings(prev => ({ ...prev, accountName: e.target.value }))}
                    className={`w-full p-2.5 rounded-xl outline-none ${inputBgClass}`}
                    placeholder="e.g. bibek"
                  />
                </div>
              </div>

              {manualPayMsg && (
                <p className={`text-xs font-bold ${manualPayMsg.includes('success') ? 'text-emerald-400' : 'text-red-400'}`}>
                  {manualPayMsg}
                </p>
              )}

              <button
                onClick={handleSaveManualPaySettings}
                disabled={manualPaySaving}
                className="py-2.5 px-5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50"
              >
                {manualPaySaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save QR Settings
              </button>
            </div>

          </div>
        )}

        {/* SCREENSHOT PROOF MODAL */}
        {screenshotModalUrl && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
            <div className="w-full max-w-xl bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
              <div className="p-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Eye className="w-4 h-4 text-blue-400" /> Payment Screenshot Proof
                </h3>
                <button
                  onClick={() => setScreenshotModalUrl(null)}
                  className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 flex-1 overflow-auto bg-black/50 flex items-center justify-center">
                <img
                  src={screenshotModalUrl}
                  alt="Payment Proof Screenshot"
                  className="max-w-full max-h-[70vh] rounded-xl object-contain shadow-lg"
                />
              </div>
              <div className="p-4 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between">
                <a
                  href={screenshotModalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-blue-400 hover:underline flex items-center gap-1 font-semibold"
                >
                  Open Original Image in New Tab ↗
                </a>
                <button
                  onClick={() => setScreenshotModalUrl(null)}
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl text-xs cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* REJECT PAYMENT REQUEST MODAL */}
        {rejectModalState && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
            <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-6 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h3 className="text-base font-extrabold text-red-500 flex items-center gap-2">
                  <XCircle className="w-5 h-5" /> Reject Payment Request
                </h3>
                <button
                  onClick={() => setRejectModalState(null)}
                  className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <p className="text-zinc-300">
                  Rejecting request for <strong className="text-white font-bold">{rejectModalState.username}</strong>.
                </p>

                <div>
                  <label className="block text-zinc-400 mb-1 font-semibold">Rejection Reason for User</label>
                  <textarea
                    value={rejectReasonInput}
                    onChange={(e) => setRejectReasonInput(e.target.value)}
                    placeholder="e.g. Invalid Transaction ID, illegible screenshot..."
                    rows={3}
                    className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 text-xs"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    onClick={() => setRejectModalState(null)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleConfirmRejectRequest}
                    className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 cursor-pointer flex items-center gap-1.5"
                  >
                    <X className="w-4 h-4" /> Confirm Rejection
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PACKAGE PREVIEW MODAL */}
        {previewPackage && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
            <div className="w-full max-w-sm bg-zinc-900 border border-zinc-800 rounded-3xl p-6 space-y-4 shadow-2xl relative">
              <button
                onClick={() => setPreviewPackage(null)}
                className="absolute top-4 right-4 p-1.5 text-zinc-400 hover:text-white bg-zinc-800/80 rounded-full cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="text-center space-y-2 pt-2">
                <div className="w-12 h-12 rounded-2xl bg-blue-950/80 border border-blue-800/60 flex items-center justify-center text-blue-400 font-black text-xl mx-auto shadow-lg shadow-blue-950/50">
                  ◆
                </div>
                <h3 className="text-lg font-black text-white">{previewPackage.name}</h3>
                {previewPackage.badge && (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-950 text-red-400 border border-red-800 inline-block uppercase tracking-wider">
                    {previewPackage.badge}
                  </span>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 space-y-2 text-xs font-mono text-center">
                {previewPackage.requiresRedeemCode || selectedGame?.productType === 'voucher' || selectedGame?.category === 'Voucher' || !previewPackage.diamonds ? (
                  <>
                    <div className="text-zinc-400">Package Type</div>
                    <div className="text-base font-bold text-amber-400">Digital Redeem Voucher</div>
                  </>
                ) : (
                  <>
                    <div className="text-zinc-400">In-game Diamonds / Points</div>
                    <div className="text-xl font-black text-white">{previewPackage.diamonds} Diamonds</div>
                  </>
                )}
                <div className="text-2xl font-black text-emerald-400 font-sans pt-1">
                  NPR {previewPackage.priceNpr.toLocaleString()}
                </div>
              </div>

              <button
                onClick={() => setPreviewPackage(null)}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Close Preview
              </button>
            </div>
          </div>
        )}

        {/* ADD NEW PACKAGE POPUP MODAL */}
        {isAddPackageModalOpen && (() => {
          const isSelectedGameVoucher = selectedGame?.productType === 'voucher' || selectedGame?.category === 'Voucher' || /voucher|redeem/i.test(selectedGame?.name || '');

          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
              <div className="w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-3xl p-6 space-y-5 shadow-2xl relative">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-red-950/80 border border-red-800/60 flex items-center justify-center text-red-500 font-extrabold shadow-md">
                      <Plus className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-white">Add New Package</h3>
                      <p className="text-xs text-zinc-400">Publishing to {selectedGame?.name || 'Selected Game'}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsAddPackageModalOpen(false)}
                    className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleAddPackage} className="space-y-4 text-xs">
                  <div>
                    <label className="block text-zinc-400 mb-1 font-semibold">Package Name *</label>
                    <input
                      type="text"
                      placeholder={isSelectedGameVoucher ? "e.g. Unipin Voucher" : "e.g. 1080 Diamonds"}
                      value={newPackage.name}
                      onChange={(e) => setNewPackage({ ...newPackage, name: e.target.value })}
                      className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 font-sans"
                      required
                    />
                  </div>

                  {isSelectedGameVoucher ? (
                    <div>
                      <label className="block text-zinc-400 mb-1 font-semibold font-mono">Price (NPR / Rs) *</label>
                      <input
                        type="number"
                        placeholder="920"
                        value={newPackage.priceNpr}
                        onChange={(e) => setNewPackage({ ...newPackage, priceNpr: Number(e.target.value) })}
                        className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 font-mono"
                        required
                        min="1"
                      />
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold">Points / Diamonds *</label>
                        <input
                          type="number"
                          placeholder="1080"
                          value={newPackage.diamonds}
                          onChange={(e) => setNewPackage({ ...newPackage, diamonds: Number(e.target.value) })}
                          className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 font-mono"
                          required
                          min="1"
                        />
                      </div>

                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold font-mono">Price (NPR / Rs) *</label>
                        <input
                          type="number"
                          placeholder="920"
                          value={newPackage.priceNpr}
                          onChange={(e) => setNewPackage({ ...newPackage, priceNpr: Number(e.target.value) })}
                          className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 font-mono"
                          required
                          min="1"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-zinc-400 mb-1 font-semibold">Badge Tag (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. POPULAR, BEST VALUE, 10% EXTRA"
                      value={newPackage.badge}
                      onChange={(e) => setNewPackage({ ...newPackage, badge: e.target.value })}
                      className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500"
                    />
                  </div>

                  {/* Liana Product ID — shown for MLBB games */}
                  {(() => {
                    const gameName = String(selectedGame?.name || '').toLowerCase();
                    const gameId   = String(selectedGame?.id   || '').toLowerCase();
                    const isLikelyMlbb =
                      isMlbbBrazilGame(selectedGame) ||
                      gameName.includes('legend') ||
                      gameName.includes('mobile') ||
                      gameId.includes('legend') ||
                      gameId.includes('mobile');
                    return isLikelyMlbb ? (
                      <div>
                        <label className="block text-zinc-400 mb-1 font-semibold">
                          Liana Product ID (MLBB Auto-Delivery) *
                          <span className="ml-2 text-[10px] text-zinc-500 font-normal">
                            Game: {selectedGame?.name} | ID: {selectedGame?.id}
                          </span>
                        </label>
                        <input
                          type="number"
                          placeholder="e.g. 4"
                          value={newPackage.product_id ?? ''}
                          onChange={(e) => setNewPackage({ ...newPackage, product_id: e.target.value ? Number(e.target.value) : undefined })}
                          className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-white outline-none focus:border-red-500 font-mono"
                        />
                        <p className="text-[10px] text-zinc-500 mt-1">
                          Exact product_id from Liana Store's /products response for this diamond pack.
                        </p>
                      </div>
                    ) : null;
                  })()}

                  <label className="flex items-center justify-between gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <div>
                      <div className="text-white font-bold">Requires Redeem Code</div>
                      <div className="text-[10px] text-zinc-500">Reserve and automatically deliver voucher inventory after successful payment.</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={newPackage.requiresRedeemCode === true || isSelectedGameVoucher}
                      onChange={(e) => setNewPackage({ ...newPackage, requiresRedeemCode: e.target.checked })}
                      className="w-4 h-4 accent-red-600"
                    />
                  </label>

                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-800">
                    <button
                      type="button"
                      onClick={() => setIsAddPackageModalOpen(false)}
                      className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-600/30 cursor-pointer flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Publish Package</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          );
        })()}

        {/* VIEW: ANNOUNCEMENTS */}
        {(activeMainSection === 'ANNOUNCEMENTS' || activeSubItem === 'Announcements') && (
          <AnnouncementsManager isDark={isDark} />
        )}

        {/* VIEW: ML API MONITORING */}
        {(activeMainSection === 'ML_API_MONITORING' || activeSubItem === 'ML API Monitoring') && (
          <div className="space-y-1">
            <div className="mb-4">
              <h2 className="text-lg font-black admin-heading">Mobile Legends API Monitoring</h2>
              <p className="text-[11px] admin-muted">Live status of automated Liana diamond deliveries — retry failed orders and audit merchant wallet activity.</p>
            </div>
            <MLApiMonitoring />
          </div>
        )}

      </main>

    </div>
  );
};
