import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mail, Lock, User, X, Loader2, AlertCircle, CheckCircle2,
  Eye, EyeOff, LogIn, UserPlus, ArrowRight, ArrowLeft,
  RefreshCw, ShieldCheck
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup';
  onAuthSuccess?: (user: { email: string; name: string; uid: string }) => void;
}

const PASSWORD_RULE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
const EMAIL_RULE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function friendlyAuthError(err: any): string {
  const message = err?.message || err?.error_description || '';
  if (message.includes('Invalid login credentials')) return 'Invalid email or password.';
  if (message.includes('User already registered')) return 'This email is already registered. Please sign in instead.';
  if (message.includes('Password should be')) return 'Password is too weak.';
  if (message.includes('provider is disabled') || message.includes('Unsupported provider') || message.includes('provider_not_enabled')) {
    return 'Google Sign-In is not enabled in your Supabase Dashboard. Please enable Google under Authentication -> Providers in Supabase.';
  }
  if (message.includes('invalid_client') || message.includes('OAuth client was not found')) {
    return 'Google OAuth Client ID is invalid or missing in Supabase Dashboard -> Authentication -> Providers -> Google.';
  }
  if (message.includes('Failed to fetch') || message.includes('unconfigured') || message.includes('xyzcompany')) {
    return 'Supabase URL is not configured. Please set VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY in environment variables.';
  }
  return message || 'Something went wrong. Please try again.';
}

/* ── Forgot Password Modal ── */
interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
}
const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setTimeout(() => { setEmail(''); setStatus('idle'); setErrorMsg(''); }, 300);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!EMAIL_RULE.test(email.trim())) {
      setStatus('error');
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    setIsLoading(true);
    setStatus('idle');
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) {
        setStatus('error');
        setErrorMsg(error.message);
      } else {
        setStatus('success');
      }
    } catch (err: any) {
      setStatus('success');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm cursor-pointer"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 15 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative bg-white border-2 border-red-500/20 rounded-3xl shadow-2xl shadow-red-950/20 w-full max-w-sm p-7 z-10 text-zinc-900"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 text-zinc-400 hover:text-red-600 bg-zinc-100 hover:bg-red-50 border border-zinc-200 rounded-full transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {status === 'success' ? (
              <div className="text-center py-4">
                <div className="w-14 h-14 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-7 h-7 text-emerald-600" />
                </div>
                <h3 className="text-lg font-extrabold text-zinc-900 mb-2">Check Your Email</h3>
                <p className="text-xs text-zinc-600 leading-relaxed">
                  If an account exists for <span className="text-zinc-900 font-bold">{email}</span>, a password reset link has been sent.
                </p>
                <button
                  onClick={onClose}
                  className="mt-6 w-full py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl cursor-pointer shadow-lg shadow-red-600/30 transition-all border border-red-500"
                >
                  Back to Sign In
                </button>
              </div>
            ) : (
              <>
                <div className="mb-6 text-center">
                  <div className="w-12 h-12 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-center mx-auto mb-3">
                    <Lock className="w-5 h-5 text-red-600" />
                  </div>
                  <h3 className="text-lg font-black text-zinc-900">Reset Password</h3>
                  <p className="text-xs text-zinc-500 mt-1">Enter your email and we'll send a reset link</p>
                </div>

                {status === 'error' && (
                  <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-zinc-700">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-red-600 pointer-events-none" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.com"
                        required
                        className="w-full bg-zinc-50 border border-zinc-200 rounded-xl pl-10 pr-4 py-3 text-xs text-zinc-900 placeholder-zinc-400 outline-none focus:bg-white focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all font-medium"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-sm rounded-xl transition-all cursor-pointer shadow-lg shadow-red-600/30 active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 border border-red-500"
                  >
                    {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /><span>Sending…</span></> : <span>Send Reset Link</span>}
                  </button>

                  <button type="button" onClick={onClose} className="w-full text-center text-xs font-bold text-zinc-500 hover:text-red-600 transition-colors cursor-pointer py-1">
                    Back to Sign In
                  </button>
                </form>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

/* ── Email Verification Screen ── */
interface VerificationScreenProps {
  email: string;
  onResend: () => Promise<void>;
  onClose: () => void;
}
const VerificationScreen: React.FC<VerificationScreenProps> = ({ email, onResend, onClose }) => {
  const [isResending, setIsResending] = useState(false);
  const [resendMsg, setResendMsg] = useState<string | null>(null);

  const handleResend = async () => {
    setIsResending(true);
    setResendMsg(null);
    try {
      await onResend();
      setResendMsg('Verification email sent! Check your inbox.');
    } catch {
      setResendMsg('Failed to resend. Please try again shortly.');
    } finally {
      setIsResending(false);
      setTimeout(() => setResendMsg(null), 4000);
    }
  };

  return (
    <div className="text-center py-2">
      <div className="w-16 h-16 bg-amber-50 border border-amber-200 rounded-full flex items-center justify-center mx-auto mb-4">
        <Mail className="w-8 h-8 text-amber-600" />
      </div>
      <h3 className="text-xl font-extrabold text-zinc-900 mb-2">Verify Your Email</h3>
      <p className="text-xs text-zinc-600 leading-relaxed mb-1">
        We sent a verification link to:
      </p>
      <p className="text-sm font-extrabold text-red-600 mb-5">{email}</p>
      <p className="text-xs text-zinc-500 leading-relaxed mb-6">
        Check your inbox (and spam folder). Click the link to activate your account.
      </p>

      {resendMsg && (
        <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          <span>{resendMsg}</span>
        </div>
      )}

      <button
        onClick={handleResend}
        disabled={isResending}
        className="w-full py-3 bg-zinc-50 border border-zinc-200 hover:border-red-500 text-zinc-800 hover:bg-red-50 hover:text-red-600 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 mb-3 disabled:opacity-50"
      >
        {isResending ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
        Resend Verification Email
      </button>

      <button
        onClick={onClose}
        className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-sm rounded-xl transition-all cursor-pointer shadow-lg shadow-red-600/30 border border-red-500"
      >
        Continue to Dashboard
      </button>

      <p className="text-[10px] text-zinc-500 mt-3">
        You can still explore while your email is pending verification.
      </p>
    </div>
  );
};

/* ── Google Icon ── */
const GoogleIcon = () => (
  <svg className="w-5 h-5" viewBox="0 0 24 24">
    <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.3 9 5 12 5z" />
    <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z" />
    <path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.3 0 15s.7 5.3 1.9 7.7l3.7-2.9c-.8-.8-1.4-1.8-1.6-3z" />
    <path fill="#34A853" d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.3-6.4-5.2L1.9 16C3.7 19.7 7.5 23 12 23z" />
  </svg>
);

/* ── Input Field Helper ── */
interface FieldProps {
  label: string;
  icon: React.ReactNode;
  type: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  required?: boolean;
  autoComplete?: string;
  suffix?: React.ReactNode;
  hint?: string;
}
const Field: React.FC<FieldProps> = ({ label, icon, type, value, onChange, placeholder, required, autoComplete, suffix, hint }) => (
  <div className="space-y-1.5">
    <label className="block text-xs font-bold text-zinc-700">{label}</label>
    <div className="relative">
      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-red-600">{icon}</div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        autoComplete={autoComplete}
        className="w-full bg-zinc-50 border border-zinc-200 rounded-xl pl-10 pr-10 py-3 text-xs text-zinc-900 placeholder-zinc-400 outline-none focus:bg-white focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all font-medium"
      />
      {suffix && <div className="absolute inset-y-0 right-0 pr-3 flex items-center">{suffix}</div>}
    </div>
    {hint && <p className="text-[10px] text-zinc-500 mt-1">{hint}</p>}
  </div>
);

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  onAuthSuccess,
}) => {
  const [isFlipped, setIsFlipped] = useState(initialMode === 'signup');

  // Shared form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPw, setShowLoginPw] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const [signupUsername, setSignupUsername] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [showSignupPw, setShowSignupPw] = useState(false);

  // UI state
  const [isLoading, setIsLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [signupError, setSignupError] = useState<string | null>(null);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setTimeout(() => {
        setLoginEmail(''); setLoginPassword(''); setLoginError(null); setShowLoginPw(false);
        setSignupEmail(''); setSignupPassword(''); setSignupUsername(''); setSignupError(null); setShowSignupPw(false);
        setVerificationEmail(null); setIsLoading(false);
        setIsFlipped(initialMode === 'signup');
      }, 300);
    }
  }, [isOpen, initialMode]);

  const flipToSignup = () => { setIsFlipped(true); setLoginError(null); };
  const flipToLogin = () => { setIsFlipped(false); setSignupError(null); };

  /* ── Login Submit ── */
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    if (!isSupabaseConfigured) {
      setLoginError('Supabase URL is not configured. Please set VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY in your environment.');
      return;
    }
    if (!EMAIL_RULE.test(loginEmail.trim())) { setLoginError('Please enter a valid email.'); return; }
    if (!loginPassword) { setLoginError('Please enter your password.'); return; }
    if (isLoading) return;
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginEmail.trim(),
        password: loginPassword,
      });
      if (error) {
        setLoginError(friendlyAuthError(error));
      } else if (data.user) {
        onAuthSuccess?.({
          email: data.user.email || loginEmail,
          name: data.user.user_metadata?.username || loginEmail.split('@')[0],
          uid: data.user.id,
        });
        onClose();
      }
    } catch (err: any) {
      setLoginError(friendlyAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  /* ── Signup Submit ── */
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError(null);
    if (!isSupabaseConfigured) {
      setSignupError('Supabase URL is not configured. Please set VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY in your environment.');
      return;
    }
    if (!signupUsername.trim()) { setSignupError('Please choose a username.'); return; }
    if (!EMAIL_RULE.test(signupEmail.trim())) { setSignupError('Please enter a valid email.'); return; }
    if (signupPassword.length < 6) {
      setSignupError('Password must be at least 6 characters long.');
      return;
    }
    if (isLoading) return;
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email: signupEmail.trim(),
        password: signupPassword,
        options: {
          data: {
            username: signupUsername.trim(),
          },
        },
      });
      if (error) {
        setSignupError(friendlyAuthError(error));
      } else if (data.user) {
        onAuthSuccess?.({ email: data.user.email || signupEmail, name: signupUsername.trim(), uid: data.user.id });
        setVerificationEmail(data.user.email || signupEmail);
      }
    } catch (err: any) {
      setSignupError(friendlyAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  /* ── Google Sign In ── */
  const handleGoogle = async () => {
    if (isLoading) return;
    if (!isSupabaseConfigured) {
      setLoginError('Supabase URL is not configured. Please set VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY in your environment.');
      return;
    }
    setIsLoading(true);
    setLoginError(null);
    try {
      const redirectUrl = window.location.origin;
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: redirectUrl,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
        },
      });
      if (error) setLoginError(friendlyAuthError(error));
    } catch (err: any) {
      setLoginError(friendlyAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  /* ── Resend Verification ── */
  const handleResendVerification = async () => {
    const { data } = await supabase.auth.getUser();
    if (data.user?.email) {
      await supabase.auth.resend({
        type: 'signup',
        email: data.user.email,
      });
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
            onClick={onClose}
          />

          {verificationEmail ? (
            <motion.div
              key="verification-screen"
              initial={{ opacity: 0, scale: 0.9, y: 25 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="relative w-full max-w-sm bg-[#0f0f0f] border border-zinc-800/80 rounded-3xl shadow-[0_0_50px_rgba(239,68,68,0.15)] p-8 z-10"
            >
              <VerificationScreen
                email={verificationEmail}
                onResend={handleResendVerification}
                onClose={() => { setVerificationEmail(null); onClose(); }}
              />
            </motion.div>
          ) : (
            <motion.div
              key="auth-scene"
              initial={{ opacity: 0, scale: 0.92, y: 25 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 20 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="relative z-10 w-full"
              style={{ maxWidth: '820px', perspective: '1400px' }}
            >
              <div
                style={{
                  position: 'relative',
                  width: '100%',
                  minHeight: '520px',
                  transformStyle: 'preserve-3d',
                  WebkitTransformStyle: 'preserve-3d',
                  transition: 'transform 0.7s cubic-bezier(0.65, 0, 0.35, 1)',
                  transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
                  willChange: 'transform',
                }}
              >
            <div
              style={{
                position: 'absolute',
                top: 0, left: 0,
                width: '100%',
                height: '100%',
                minHeight: '520px',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden',
                transform: 'rotateY(0deg) translateZ(0)',
                WebkitTransform: 'rotateY(0deg) translateZ(0)',
              }}
            >
              <div
                style={{
                  width: '100%',
                  height: '100%',
                  minHeight: '520px',
                  borderRadius: '1.5rem',
                  overflow: 'hidden',
                  display: 'flex',
                  border: '2px solid rgba(239, 68, 68, 0.2)',
                  boxShadow: '0 25px 50px -12px rgba(185, 28, 28, 0.25)',
                }}
              >
              <div className="flex-1 bg-white flex flex-col justify-center px-8 py-8">
                <div className="mb-7 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-red-50 border border-red-200/80 rounded-2xl mb-3">
                    <LogIn className="w-5 h-5 text-red-600" />
                  </div>
                  <h2 className="text-2xl font-black text-zinc-900 tracking-tight">Welcome Back</h2>
                  <p className="text-xs text-zinc-500 mt-1">Sign in to your UG Top-Up account</p>
                </div>

                {loginError && (
                  <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2 animate-shake font-medium">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />
                    <span>{loginError}</span>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-3.5">
                  <Field
                    label="Email Address"
                    icon={<Mail className="w-4 h-4" />}
                    type="email"
                    value={loginEmail}
                    onChange={setLoginEmail}
                    placeholder="your@email.com"
                    required
                    autoComplete="email"
                  />
                  <Field
                    label="Password"
                    icon={<Lock className="w-4 h-4" />}
                    type={showLoginPw ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={setLoginPassword}
                    placeholder="••••••••"
                    required
                    autoComplete="current-password"
                    suffix={
                      <button type="button" onClick={() => setShowLoginPw(!showLoginPw)} className="text-zinc-400 hover:text-red-600 transition-colors cursor-pointer">
                        {showLoginPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    }
                  />

                  <div className="flex items-center justify-between pt-0.5">
                    <label className="flex items-center gap-2 text-[11px] font-semibold text-zinc-600 cursor-pointer select-none">
                      <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="w-3.5 h-3.5 rounded border-zinc-300 bg-zinc-50 accent-red-600 cursor-pointer" />
                      Remember me
                    </label>
                    <button type="button" onClick={() => setShowForgotPassword(true)} className="text-[11px] text-red-600 font-bold hover:underline cursor-pointer">
                      Forgot password?
                    </button>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-sm rounded-xl transition-all cursor-pointer shadow-lg shadow-red-600/30 active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 mt-2 border border-red-500"
                  >
                    {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /><span>Signing in…</span></> : <span>Sign In</span>}
                  </button>
                </form>

                <div className="relative my-5">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-zinc-200" />
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase font-extrabold tracking-wider">
                    <span className="bg-white px-3 text-zinc-400">or continue with</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleGoogle}
                  disabled={isLoading}
                  className="w-full py-2.5 flex items-center justify-center gap-3 bg-zinc-50 border border-zinc-200 hover:border-zinc-300 rounded-xl text-zinc-800 text-xs font-bold transition-all cursor-pointer hover:bg-zinc-100 active:scale-[0.99]"
                >
                  <GoogleIcon />
                  Continue with Google
                </button>

                <p className="text-center text-xs text-zinc-500 mt-5 md:hidden">
                  No account?{' '}
                  <button type="button" onClick={flipToSignup} className="text-red-600 font-black hover:underline cursor-pointer">Sign up</button>
                </p>
              </div>

              <div
                className="hidden md:flex w-[45%] flex-shrink-0 flex-col items-center justify-center p-10 text-center"
                style={{ background: 'linear-gradient(135deg, #dc2626 0%, #ef4444 50%, #b91c1c 100%)' }}
              >
                <UserPlus className="w-10 h-10 text-white mb-5 drop-shadow-md" />
                <div className="w-10 h-0.5 bg-white/40 rounded-full mx-auto mb-5" />
                <h2 className="text-3xl font-black text-white mb-3 leading-tight">New Here?</h2>
                <p className="text-sm text-red-100/90 leading-relaxed mb-8 max-w-[240px]">
                  Create your account and start topping up your favorite games instantly.
                </p>
                <button
                  onClick={flipToSignup}
                  className="inline-flex items-center gap-2 border-2 border-white bg-white/10 hover:bg-white hover:text-red-600 text-white font-extrabold py-3 px-8 rounded-full text-sm uppercase tracking-wider transition-all cursor-pointer active:scale-95 shadow-md"
                >
                  Create Account <ArrowRight className="w-4 h-4" />
                </button>
                <div className="mt-8 flex items-center gap-2 text-xs text-red-100/80 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Secure · Fast · Trusted</span>
                </div>
              </div>
              </div>
            </div>

            <div
              style={{
                position: 'absolute',
                top: 0, left: 0,
                width: '100%',
                height: '100%',
                minHeight: '520px',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden',
                transform: 'rotateY(180deg) translateZ(0)',
                WebkitTransform: 'rotateY(180deg) translateZ(0)',
              }}
            >
              <div
                style={{
                  width: '100%',
                  height: '100%',
                  minHeight: '520px',
                  borderRadius: '1.5rem',
                  overflow: 'hidden',
                  display: 'flex',
                  border: '2px solid rgba(239, 68, 68, 0.2)',
                  boxShadow: '0 25px 50px -12px rgba(185, 28, 28, 0.25)',
                }}
              >
              <div
                className="hidden md:flex w-[45%] flex-shrink-0 flex-col items-center justify-center p-10 text-center"
                style={{ background: 'linear-gradient(135deg, #b91c1c 0%, #dc2626 50%, #ef4444 100%)' }}
              >
                <LogIn className="w-10 h-10 text-white mb-5 drop-shadow-md" />
                <div className="w-10 h-0.5 bg-white/40 rounded-full mx-auto mb-5" />
                <h2 className="text-3xl font-black text-white mb-3 leading-tight">Welcome Back!</h2>
                <p className="text-sm text-red-100/90 leading-relaxed mb-8 max-w-[240px]">
                  Already have an account? Sign in to access your wallet and order history.
                </p>
                <button
                  onClick={flipToLogin}
                  className="inline-flex items-center gap-2 border-2 border-white bg-white/10 hover:bg-white hover:text-red-600 text-white font-extrabold py-3 px-8 rounded-full text-sm uppercase tracking-wider transition-all cursor-pointer active:scale-95 shadow-md"
                >
                  <ArrowLeft className="w-4 h-4" /> Sign In
                </button>
              </div>

              <div className="flex-1 bg-white flex flex-col justify-center px-8 py-8">
                <div className="mb-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-red-50 border border-red-200/80 rounded-2xl mb-3">
                    <UserPlus className="w-5 h-5 text-red-600" />
                  </div>
                  <h2 className="text-2xl font-black text-zinc-900 tracking-tight">Create Account</h2>
                  <p className="text-xs text-zinc-500 mt-1">Join thousands of gamers on UG Top-Up</p>
                </div>

                {signupError && (
                  <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2 animate-shake font-medium">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />
                    <span>{signupError}</span>
                  </div>
                )}

                <form onSubmit={handleSignup} className="space-y-3">
                  <Field
                    label="Username"
                    icon={<User className="w-4 h-4" />}
                    type="text"
                    value={signupUsername}
                    onChange={setSignupUsername}
                    placeholder="johndoe"
                    required
                    autoComplete="username"
                  />
                  <Field
                    label="Email Address"
                    icon={<Mail className="w-4 h-4" />}
                    type="email"
                    value={signupEmail}
                    onChange={setSignupEmail}
                    placeholder="your@email.com"
                    required
                    autoComplete="email"
                  />
                  <Field
                    label="Password"
                    icon={<Lock className="w-4 h-4" />}
                    type={showSignupPw ? 'text' : 'password'}
                    value={signupPassword}
                    onChange={setSignupPassword}
                    placeholder="••••••••"
                    required
                    autoComplete="new-password"
                    suffix={
                      <button type="button" onClick={() => setShowSignupPw(!showSignupPw)} className="text-zinc-400 hover:text-red-600 transition-colors cursor-pointer">
                        {showSignupPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    }
                    hint="Must be at least 6 characters long"
                  />

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-sm rounded-xl transition-all cursor-pointer shadow-lg shadow-red-600/30 active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 mt-2 border border-red-500"
                  >
                    {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /><span>Creating account…</span></> : <span>Create Account</span>}
                  </button>
                </form>

                <p className="text-center text-xs text-zinc-500 mt-4 md:hidden">
                  Already have an account?{' '}
                  <button type="button" onClick={flipToLogin} className="text-red-600 font-black hover:underline cursor-pointer">Sign in</button>
                </p>

                <p className="text-center text-[10px] text-zinc-400 mt-4 leading-relaxed">
                  By creating an account you agree to our Terms of Service and Privacy Policy.
                </p>
              </div>
              </div>
            </div>

          </div>

          <button
            onClick={onClose}
            className="absolute -top-4 -right-4 sm:top-3 sm:right-3 z-20 p-2 text-zinc-500 hover:text-red-600 bg-white hover:bg-red-50 border-2 border-red-500/20 shadow-xl rounded-full transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
        )}

        <ForgotPasswordModal isOpen={showForgotPassword} onClose={() => setShowForgotPassword(false)} />
      </div>
      )}
    </AnimatePresence>
  );
};
