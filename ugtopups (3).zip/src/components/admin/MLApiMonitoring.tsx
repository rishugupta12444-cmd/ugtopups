import { useState, useEffect, useCallback } from 'react';
import { RefreshCw, AlertTriangle, CheckCircle2, Loader2, Gem } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { LianaWalletCard } from './LianaWalletCard';

interface LianaOrder {
  id: string;
  order_id: string;
  liana_product_id: number | null;
  user_id: string;
  zone_id: string;
  ign: string | null;
  status: string;
  error_message: string | null;
  retry_count: number;
  created_at: string;
}

interface WalletLog {
  id: string;
  action: string;
  order_number: string | null;
  api_status: string | null;
  error_message: string | null;
  coins_used: number | null;
  created_at: string;
}

const STATUS_STYLES: Record<string, string> = {
  completed: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  failed: 'bg-red-500/15 text-red-400 border-red-500/30',
  processing: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  pending: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
};

const API_STATUS_STYLES: Record<string, string> = {
  success: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  verification_failed: 'bg-red-500/15 text-red-400 border-red-500/30',
  api_error: 'bg-red-500/15 text-red-400 border-red-500/30',
  insufficient_funds: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  connection_error: 'bg-orange-500/15 text-orange-400 border-orange-500/30',
  error: 'bg-red-500/15 text-red-400 border-red-500/30',
};

function Badge({ label, className }: { label: string; className?: string }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${className || 'bg-zinc-800 text-zinc-300 border-zinc-700'}`}>
      {label}
    </span>
  );
}

export const MLApiMonitoring: React.FC = () => {
  const [failedOrders, setFailedOrders] = useState<LianaOrder[]>([]);
  const [walletLogs, setWalletLogs] = useState<WalletLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [tab, setTab] = useState<'failed' | 'logs'>('failed');
  const [toast, setToast] = useState<string | null>(null);
  const [stats, setStats] = useState({ total: 0, completed: 0, failed: 0 });

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [ordersRes, logsRes, statsRes] = await Promise.all([
        supabase
          .from('liana_orders')
          .select('*')
          .in('status', ['failed', 'pending', 'processing'])
          .order('created_at', { ascending: false })
          .limit(50),
        supabase
          .from('wallet_activity_logs')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100),
        supabase.from('liana_orders').select('status'),
      ]);

      if (ordersRes.data) setFailedOrders(ordersRes.data as LianaOrder[]);
      if (logsRes.data) setWalletLogs(logsRes.data as WalletLog[]);
      if (statsRes.data) {
        const all = statsRes.data as any[];
        setStats({
          total: all.length,
          completed: all.filter((o) => o.status === 'completed').length,
          failed: all.filter((o) => o.status === 'failed').length,
        });
      }
    } catch (err) {
      console.error('[MLApiMonitoring] Failed to fetch monitoring data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(t);
  }, [toast]);

  const handleRetry = async (orderId: string) => {
    setRetryingId(orderId);
    try {
      const { data, error } = await supabase.functions.invoke('process-ml-order', {
        body: { order_id: orderId, is_retry: true },
      });
      if (error) throw error;
      if (data?.success) {
        setToast('Order reprocessed successfully — diamonds delivered.');
      } else {
        setToast(data?.error || 'Retry failed. Order still needs manual attention.');
      }
      await fetchData();
    } catch (err: any) {
      setToast(err?.message || 'Retry failed.');
    } finally {
      setRetryingId(null);
    }
  };

  const successRate = stats.total > 0 ? ((stats.completed / stats.total) * 100).toFixed(1) : '0';

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-7 w-7 animate-spin text-red-500" />
      </div>
    );
  }

  return (
    <div className="space-y-5 text-xs">
      {toast && (
        <div className="fixed bottom-6 right-6 z-[999] bg-zinc-900 border border-zinc-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl">
          {toast}
        </div>
      )}

      <LianaWalletCard onShowLogs={() => setTab('logs')} />

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total API Orders', value: stats.total, color: 'text-white' },
          { label: 'Completed', value: stats.completed, color: 'text-emerald-400' },
          { label: 'Failed', value: stats.failed, color: 'text-red-400' },
          { label: 'Success Rate', value: `${successRate}%`, color: 'text-red-500' },
        ].map((s) => (
          <div key={s.label} className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-center">
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-zinc-500 font-semibold mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 bg-zinc-950 border border-zinc-800 rounded-xl p-1">
          <button
            type="button"
            onClick={() => setTab('failed')}
            className={`px-3 py-1.5 rounded-lg font-bold text-[11px] transition ${tab === 'failed' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'}`}
          >
            Failed / Pending ({failedOrders.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('logs')}
            className={`px-3 py-1.5 rounded-lg font-bold text-[11px] transition ${tab === 'logs' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'}`}
          >
            API Logs ({walletLogs.length})
          </button>
        </div>
        <button
          type="button"
          onClick={fetchData}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-700 font-bold text-[11px] transition"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh
        </button>
      </div>

      {tab === 'failed' && (
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden">
          {failedOrders.length === 0 ? (
            <div className="text-center py-10 text-zinc-500">
              <CheckCircle2 className="h-10 w-10 mx-auto mb-2 text-emerald-500" />
              <p className="font-semibold">No failed orders — everything is running smoothly!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500 text-[10px] uppercase">
                    <th className="px-4 py-3 font-bold">Order</th>
                    <th className="px-4 py-3 font-bold">Player</th>
                    <th className="px-4 py-3 font-bold">Status</th>
                    <th className="px-4 py-3 font-bold">Error</th>
                    <th className="px-4 py-3 font-bold">Retries</th>
                    <th className="px-4 py-3 font-bold">Time</th>
                    <th className="px-4 py-3 font-bold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {failedOrders.map((order) => (
                    <tr key={order.id} className="border-b border-zinc-900 last:border-0 hover:bg-zinc-900/40">
                      <td className="px-4 py-3 font-mono text-zinc-400">{order.order_id}</td>
                      <td className="px-4 py-3">
                        <div className="text-zinc-300">{order.user_id} <span className="text-zinc-600">({order.zone_id})</span></div>
                        {order.ign && <div className="text-zinc-500">IGN: {order.ign}</div>}
                      </td>
                      <td className="px-4 py-3">
                        <Badge label={order.status} className={STATUS_STYLES[order.status] || undefined} />
                      </td>
                      <td className="px-4 py-3 max-w-[220px] truncate text-red-400" title={order.error_message || ''}>
                        {order.error_message || '—'}
                      </td>
                      <td className="px-4 py-3 text-zinc-400">{order.retry_count || 0}</td>
                      <td className="px-4 py-3 text-zinc-500 whitespace-nowrap">{new Date(order.created_at).toLocaleString()}</td>
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          disabled={retryingId === order.order_id}
                          onClick={() => handleRetry(order.order_id)}
                          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-white font-bold text-[10px] transition"
                        >
                          {retryingId === order.order_id ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                          Retry
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === 'logs' && (
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden">
          {walletLogs.length === 0 ? (
            <div className="text-center py-10 text-zinc-500">
              <Gem className="h-10 w-10 mx-auto mb-2 text-zinc-700" />
              <p className="font-semibold">No API activity yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500 text-[10px] uppercase">
                    <th className="px-4 py-3 font-bold">Action</th>
                    <th className="px-4 py-3 font-bold">Order</th>
                    <th className="px-4 py-3 font-bold">API Status</th>
                    <th className="px-4 py-3 font-bold">Coins</th>
                    <th className="px-4 py-3 font-bold">Error</th>
                    <th className="px-4 py-3 font-bold">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {walletLogs.map((log) => (
                    <tr key={log.id} className="border-b border-zinc-900 last:border-0 hover:bg-zinc-900/40">
                      <td className="px-4 py-3">
                        <Badge label={log.action.replace(/_/g, ' ')} />
                      </td>
                      <td className="px-4 py-3 font-mono text-zinc-400">{log.order_number || '—'}</td>
                      <td className="px-4 py-3">
                        {log.api_status ? <Badge label={log.api_status.replace(/_/g, ' ')} className={API_STATUS_STYLES[log.api_status] || undefined} /> : '—'}
                      </td>
                      <td className="px-4 py-3 text-zinc-300">{log.coins_used ?? '—'}</td>
                      <td className="px-4 py-3 max-w-[220px] truncate text-red-400" title={log.error_message || ''}>
                        {log.error_message || '—'}
                      </td>
                      <td className="px-4 py-3 text-zinc-500 whitespace-nowrap">{new Date(log.created_at).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <div className="flex items-start gap-2.5 bg-red-500/5 border border-red-500/20 rounded-2xl p-4 text-zinc-400">
        <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
        <p>
          Only <strong className="text-zinc-200">failed / pending / processing</strong> Liana orders are listed above.
          Completed orders are already reflected as <strong className="text-zinc-200">Completed</strong> on the main Orders tab.
        </p>
      </div>
    </div>
  );
};
