import React, { useEffect, useMemo, useState } from 'react';
import {
  Megaphone, Plus, Edit3, Trash2, Copy, Power, Eye, X,
  Loader2, AlertCircle, CheckCircle2, Clock, BarChart3, Link as LinkIcon, RefreshCw,
} from 'lucide-react';
import { Announcement } from '../../types';
import { subscribeAnnouncements, saveAnnouncement, deleteAnnouncement, fetchAllAnnouncements } from '../../lib/store';
import { showToast } from '../GlobalToast';
import { AnnouncementPreview, isSafeAnnouncementUrl } from '../AnnouncementModal';

interface AnnouncementsManagerProps {
  isDark: boolean;
}

type AnnouncementFormState = {
  title: string;
  description: string;
  icon: string;
  status: 'active' | 'inactive';
  buttonEnabled: boolean;
  buttonText: string;
  buttonUrl: string;
  buttonIcon: string;
  openInNewTab: boolean;
  startAt: string; // datetime-local value
  endAt: string;   // datetime-local value
  priority: string;
  autoDisplay: boolean;
  allowDontShowAgain: boolean;
};

const EMPTY_FORM: AnnouncementFormState = {
  title: '',
  description: '',
  icon: '',
  status: 'inactive',
  buttonEnabled: false,
  buttonText: 'Learn More',
  buttonUrl: '',
  buttonIcon: '',
  openInNewTab: true,
  startAt: '',
  endAt: '',
  priority: '0',
  autoDisplay: true,
  allowDontShowAgain: true,
};

// datetime-local <-> ISO helpers (local-time round trip, no timezone math surprises)
function isoToLocalInput(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function localInputToIso(value: string): string | null {
  if (!value) return null;
  const d = new Date(value);
  if (isNaN(d.getTime())) return null;
  return d.toISOString();
}

function formToAnnouncement(form: AnnouncementFormState, id: string, createdAt?: string): Announcement {
  return {
    id,
    title: form.title.trim(),
    description: form.description.trim(),
    icon: form.icon.trim() || undefined,
    status: form.status,
    buttonEnabled: form.buttonEnabled,
    buttonText: form.buttonEnabled ? form.buttonText.trim() : undefined,
    buttonUrl: form.buttonEnabled ? form.buttonUrl.trim() : undefined,
    buttonIcon: form.buttonEnabled ? (form.buttonIcon.trim() || undefined) : undefined,
    openInNewTab: form.openInNewTab,
    startAt: localInputToIso(form.startAt),
    endAt: localInputToIso(form.endAt),
    priority: Number(form.priority) || 0,
    autoDisplay: form.autoDisplay,
    allowDontShowAgain: form.allowDontShowAgain,
    createdAt: createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function announcementToForm(a: Announcement): AnnouncementFormState {
  return {
    title: a.title || '',
    description: a.description || '',
    icon: a.icon || '',
    status: a.status || 'inactive',
    buttonEnabled: !!a.buttonEnabled,
    buttonText: a.buttonText || 'Learn More',
    buttonUrl: a.buttonUrl || '',
    buttonIcon: a.buttonIcon || '',
    openInNewTab: a.openInNewTab !== false,
    startAt: isoToLocalInput(a.startAt),
    endAt: isoToLocalInput(a.endAt),
    priority: String(a.priority ?? 0),
    autoDisplay: a.autoDisplay !== false,
    allowDontShowAgain: a.allowDontShowAgain !== false,
  };
}

function isScheduled(a: Announcement): boolean {
  if (!a.startAt) return false;
  return new Date(a.startAt).getTime() > Date.now();
}

export const AnnouncementsManager: React.FC<AnnouncementsManagerProps> = ({ isDark }) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingCreatedAt, setEditingCreatedAt] = useState<string | undefined>(undefined);
  const [form, setForm] = useState<AnnouncementFormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);

  const [previewOnlyAnnouncement, setPreviewOnlyAnnouncement] = useState<Announcement | null>(null);

  const cardBgClass = isDark ? 'bg-[#0c101c] border-zinc-800' : 'bg-white border-slate-200 shadow-sm';
  const inputBgClass = isDark ? 'bg-[#080b14] border-zinc-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  useEffect(() => {
    const unsub = subscribeAnnouncements((list) => {
      setAnnouncements(list);
      setIsLoading(false);
    });
    return unsub;
  }, []);

  // Force a direct refetch — used after every save/delete/toggle so the list
  // updates immediately even if Supabase Realtime isn't enabled for this table.
  const refreshList = async () => {
    const list = await fetchAllAnnouncements();
    setAnnouncements(list);
  };

  const stats = useMemo(() => {
    const total = announcements.length;
    const active = announcements.filter((a) => a.status === 'active').length;
    const inactive = announcements.filter((a) => a.status === 'inactive').length;
    const scheduled = announcements.filter((a) => a.status === 'active' && isScheduled(a)).length;
    return { total, active, inactive, scheduled };
  }, [announcements]);

  const openCreateEditor = () => {
    setEditingId(null);
    setEditingCreatedAt(undefined);
    setForm(EMPTY_FORM);
    setErrors({});
    setIsEditorOpen(true);
  };

  const openEditEditor = (a: Announcement) => {
    setEditingId(a.id);
    setEditingCreatedAt(a.createdAt);
    setForm(announcementToForm(a));
    setErrors({});
    setIsEditorOpen(true);
  };

  const closeEditor = () => {
    if (isSaving) return;
    setIsEditorOpen(false);
  };

  const validate = (f: AnnouncementFormState): Record<string, string> => {
    const errs: Record<string, string> = {};
    if (!f.title.trim()) errs.title = 'Title cannot be empty.';
    if (!f.description.trim()) errs.description = 'Description cannot be empty.';

    if (f.buttonEnabled) {
      if (!f.buttonText.trim()) errs.buttonText = 'Button text is required when the button is enabled.';
      if (!f.buttonUrl.trim()) {
        errs.buttonUrl = 'Button URL is required when the button is enabled.';
      } else if (!isSafeAnnouncementUrl(f.buttonUrl.trim())) {
        errs.buttonUrl = 'Enter a valid https:// / http:// URL or an internal route starting with "/".';
      }
    }

    if (f.startAt && isNaN(new Date(f.startAt).getTime())) errs.startAt = 'Start date/time is invalid.';
    if (f.endAt && isNaN(new Date(f.endAt).getTime())) errs.endAt = 'End date/time is invalid.';
    if (f.startAt && f.endAt) {
      const s = new Date(f.startAt).getTime();
      const e = new Date(f.endAt).getTime();
      if (!isNaN(s) && !isNaN(e) && e < s) errs.endAt = 'End time cannot be earlier than start time.';
    }

    if (f.priority.trim() === '' || isNaN(Number(f.priority))) errs.priority = 'Priority must be a valid number.';

    return errs;
  };

  const previewAnnouncement: Announcement = useMemo(
    () => formToAnnouncement(form, editingId || 'preview', editingCreatedAt),
    [form, editingId, editingCreatedAt]
  );

  const handleSave = async () => {
    const validation = validate(form);
    setErrors(validation);
    if (Object.keys(validation).length > 0) {
      showToast('Please fix the highlighted fields before saving.', 'warning', 'Validation');
      return;
    }

    setIsSaving(true);
    try {
      const id = editingId || `announcement_${Date.now()}`;
      const payload = formToAnnouncement(form, id, editingCreatedAt);
      const ok = await saveAnnouncement(payload);
      if (ok) {
        showToast(editingId ? 'Announcement updated successfully.' : 'Announcement created successfully.', 'success');
        setIsEditorOpen(false);
        await refreshList();
      } else {
        showToast('Could not save the announcement. Please check your Supabase connection and try again.', 'error');
      }
    } catch (err: any) {
      showToast(err?.message || 'Unexpected error while saving the announcement.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (a: Announcement) => {
    if (!confirm(`Delete announcement "${a.title}"? This cannot be undone.`)) return;
    const ok = await deleteAnnouncement(a.id);
    if (ok) {
      showToast('Announcement deleted.', 'success');
      await refreshList();
    } else {
      showToast('Could not delete the announcement. Please try again.', 'error');
    }
  };

  const handleToggleActive = async (a: Announcement) => {
    const updated: Announcement = { ...a, status: a.status === 'active' ? 'inactive' : 'active', updatedAt: new Date().toISOString() };
    const ok = await saveAnnouncement(updated);
    if (ok) {
      showToast(updated.status === 'active' ? 'Announcement activated.' : 'Announcement deactivated.', 'success');
      await refreshList();
    } else {
      showToast('Could not update the announcement status.', 'error');
    }
  };

  const handleDuplicate = async (a: Announcement) => {
    const duplicated: Announcement = {
      ...a,
      id: `announcement_${Date.now()}`,
      title: `${a.title} (Copy)`,
      status: 'inactive',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const ok = await saveAnnouncement(duplicated);
    if (ok) {
      showToast('Announcement duplicated as inactive draft.', 'success');
      await refreshList();
    } else {
      showToast('Could not duplicate the announcement.', 'error');
    }
  };

  const fieldError = (key: string) =>
    errors[key] ? <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors[key]}</p> : null;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-white flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-red-500" />
            Announcements
          </h2>
          <p className="text-xs text-zinc-500 mt-0.5">Create and schedule modal announcements shown to visitors on the store.</p>
        </div>
        <button
          onClick={openCreateEditor}
          className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-black text-sm rounded-xl shadow-lg shadow-red-600/20 transition-all cursor-pointer flex items-center gap-2 justify-center"
        >
          <Plus className="w-4 h-4" />
          Create Announcement
        </button>
      </div>

      <div className="flex justify-end -mt-2">
        <button
          onClick={refreshList}
          className="text-xs text-zinc-500 hover:text-white flex items-center gap-1.5 cursor-pointer"
        >
          <RefreshCw className="w-3 h-3" />
          Refresh list
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className={`p-5 rounded-2xl ${cardBgClass}`}>
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">TOTAL</span>
              <h4 className="text-2xl font-black text-white mt-1">{stats.total}</h4>
            </div>
            <div className="p-2.5 rounded-xl bg-zinc-500/20 text-zinc-300"><BarChart3 className="w-5 h-5" /></div>
          </div>
        </div>
        <div className={`p-5 rounded-2xl ${cardBgClass}`}>
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">ACTIVE</span>
              <h4 className="text-2xl font-black text-emerald-400 mt-1">{stats.active}</h4>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400"><CheckCircle2 className="w-5 h-5" /></div>
          </div>
        </div>
        <div className={`p-5 rounded-2xl ${cardBgClass}`}>
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">INACTIVE</span>
              <h4 className="text-2xl font-black text-zinc-400 mt-1">{stats.inactive}</h4>
            </div>
            <div className="p-2.5 rounded-xl bg-zinc-500/20 text-zinc-400"><Power className="w-5 h-5" /></div>
          </div>
        </div>
        <div className={`p-5 rounded-2xl ${cardBgClass}`}>
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">SCHEDULED</span>
              <h4 className="text-2xl font-black text-red-500 mt-1">{stats.scheduled}</h4>
            </div>
            <div className="p-2.5 rounded-xl bg-red-600/20 text-red-500"><Clock className="w-5 h-5" /></div>
          </div>
        </div>
      </div>

      {/* List */}
      <div className={`rounded-2xl overflow-hidden ${cardBgClass}`}>
        {isLoading ? (
          <div className="p-10 flex flex-col items-center justify-center text-zinc-500 gap-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-xs font-semibold">Loading announcements...</span>
          </div>
        ) : announcements.length === 0 ? (
          <div className="p-10 flex flex-col items-center justify-center text-zinc-500 gap-3 text-center">
            <Megaphone className="w-8 h-8 text-zinc-700" />
            <p className="text-sm font-bold text-zinc-300">No announcements yet</p>
            <p className="text-xs text-zinc-500 max-w-xs">Create your first announcement to show a promo, update, or important notice to visitors.</p>
            <button
              onClick={openCreateEditor}
              className="mt-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl cursor-pointer"
            >
              + Create Announcement
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-zinc-800/80 text-zinc-500 uppercase tracking-wider text-[10px]">
                  <th className="text-left font-bold px-4 py-3">Title</th>
                  <th className="text-left font-bold px-4 py-3">Status</th>
                  <th className="text-left font-bold px-4 py-3">Auto Display</th>
                  <th className="text-left font-bold px-4 py-3">Start</th>
                  <th className="text-left font-bold px-4 py-3">End</th>
                  <th className="text-left font-bold px-4 py-3">Priority</th>
                  <th className="text-left font-bold px-4 py-3">Created</th>
                  <th className="text-right font-bold px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {announcements.map((a) => (
                  <tr key={a.id} className="border-b border-zinc-800/40 hover:bg-zinc-800/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="font-bold text-white truncate max-w-[220px]">{a.title}</div>
                      {a.buttonEnabled && a.buttonUrl && (
                        <div className="flex items-center gap-1 text-[10px] text-zinc-500 mt-0.5 truncate max-w-[220px]">
                          <LinkIcon className="w-2.5 h-2.5 flex-shrink-0" />
                          <span className="truncate">{a.buttonUrl}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                        a.status === 'active' ? 'bg-emerald-500/15 text-emerald-400' : 'bg-zinc-700/40 text-zinc-400'
                      }`}>
                        {a.status === 'active' ? 'Active' : 'Inactive'}
                      </span>
                      {a.status === 'active' && isScheduled(a) && (
                        <span className="ml-1 px-2 py-1 rounded-full text-[10px] font-bold bg-red-600/15 text-red-500">Scheduled</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-zinc-400">{a.autoDisplay ? 'On' : 'Off'}</td>
                    <td className="px-4 py-3 text-zinc-400 whitespace-nowrap">{a.startAt ? new Date(a.startAt).toLocaleString() : '—'}</td>
                    <td className="px-4 py-3 text-zinc-400 whitespace-nowrap">{a.endAt ? new Date(a.endAt).toLocaleString() : '—'}</td>
                    <td className="px-4 py-3 text-zinc-300 font-mono">{a.priority}</td>
                    <td className="px-4 py-3 text-zinc-500 whitespace-nowrap">{a.createdAt ? new Date(a.createdAt).toLocaleDateString() : '—'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        <button title="Preview" onClick={() => setPreviewOnlyAnnouncement(a)} className="p-1.5 rounded-lg bg-zinc-800/60 hover:bg-zinc-700 text-zinc-300 cursor-pointer">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button title="Edit" onClick={() => openEditEditor(a)} className="p-1.5 rounded-lg bg-zinc-800/60 hover:bg-zinc-700 text-zinc-300 cursor-pointer">
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button title="Duplicate" onClick={() => handleDuplicate(a)} className="p-1.5 rounded-lg bg-zinc-800/60 hover:bg-zinc-700 text-zinc-300 cursor-pointer">
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title={a.status === 'active' ? 'Deactivate' : 'Activate'}
                          onClick={() => handleToggleActive(a)}
                          className={`p-1.5 rounded-lg cursor-pointer ${a.status === 'active' ? 'bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25' : 'bg-zinc-800/60 text-zinc-300 hover:bg-zinc-700'}`}
                        >
                          <Power className="w-3.5 h-3.5" />
                        </button>
                        <button title="Delete" onClick={() => handleDelete(a)} className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-600 text-red-400 hover:text-white cursor-pointer">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Preview-only modal (from list "Preview" action) */}
      {previewOnlyAnnouncement && (
        <div className="fixed inset-0 z-[99998] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md" onClick={(e) => { if (e.target === e.currentTarget) setPreviewOnlyAnnouncement(null); }}>
          <div className="relative">
            <button
              onClick={() => setPreviewOnlyAnnouncement(null)}
              className="absolute -top-3 -right-3 z-10 p-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white cursor-pointer shadow-lg"
            >
              <X className="w-4 h-4" />
            </button>
            <AnnouncementPreview announcement={previewOnlyAnnouncement} />
          </div>
        </div>
      )}

      {/* Create / Edit Editor */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-[99997] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md overflow-y-auto">
          <div className={`w-full max-w-5xl my-6 rounded-3xl border ${isDark ? 'bg-[#0a0d16] border-zinc-800' : 'bg-white border-slate-200'} shadow-2xl overflow-hidden`}>
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800/80">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-red-500" />
                {editingId ? 'Edit Announcement' : 'Create Announcement'}
              </h3>
              <button onClick={closeEditor} className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800/60 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 max-h-[75vh]">
              {/* Form column */}
              <div className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
                {/* Basic Information */}
                <div className="space-y-3">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Basic Information</h4>

                  <div>
                    <label className="block text-xs text-zinc-400 mb-1 font-semibold">Announcement Title</label>
                    <input
                      type="text"
                      value={form.title}
                      onChange={(e) => setForm({ ...form, title: e.target.value })}
                      className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass} ${errors.title ? 'border-red-500' : ''}`}
                      placeholder="e.g. WhatsApp Community"
                    />
                    {fieldError('title')}
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-400 mb-1 font-semibold">Announcement Description</label>
                    <textarea
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      rows={3}
                      className={`w-full p-2.5 rounded-xl outline-none text-sm resize-none ${inputBgClass} ${errors.description ? 'border-red-500' : ''}`}
                      placeholder="e.g. Join our WhatsApp Community for updates, giveaways, and exclusive offers!"
                    />
                    {fieldError('description')}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-zinc-400 mb-1 font-semibold">Icon (optional emoji)</label>
                      <input
                        type="text"
                        value={form.icon}
                        onChange={(e) => setForm({ ...form, icon: e.target.value })}
                        className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass}`}
                        placeholder="🎉"
                        maxLength={4}
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-400 mb-1 font-semibold">Status</label>
                      <select
                        value={form.status}
                        onChange={(e) => setForm({ ...form, status: e.target.value as 'active' | 'inactive' })}
                        className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass}`}
                      >
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Button Settings */}
                <div className="space-y-3 pt-3 border-t border-zinc-800/60">
                  <div className="flex items-center justify-between">
                    <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Button Settings</h4>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <span className="text-[11px] text-zinc-400 font-semibold">Enable Button</span>
                      <input
                        type="checkbox"
                        checked={form.buttonEnabled}
                        onChange={(e) => setForm({ ...form, buttonEnabled: e.target.checked })}
                        className="w-4 h-4 accent-red-600 cursor-pointer"
                      />
                    </label>
                  </div>

                  {form.buttonEnabled && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs text-zinc-400 mb-1 font-semibold">Button Text</label>
                          <input
                            type="text"
                            value={form.buttonText}
                            onChange={(e) => setForm({ ...form, buttonText: e.target.value })}
                            className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass} ${errors.buttonText ? 'border-red-500' : ''}`}
                            placeholder="Learn More"
                          />
                          {fieldError('buttonText')}
                        </div>
                        <div>
                          <label className="block text-xs text-zinc-400 mb-1 font-semibold">Button Icon (optional emoji)</label>
                          <input
                            type="text"
                            value={form.buttonIcon}
                            onChange={(e) => setForm({ ...form, buttonIcon: e.target.value })}
                            className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass}`}
                            placeholder="💬"
                            maxLength={4}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs text-zinc-400 mb-1 font-semibold">Button Link / URL</label>
                        <input
                          type="text"
                          value={form.buttonUrl}
                          onChange={(e) => setForm({ ...form, buttonUrl: e.target.value })}
                          className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass} ${errors.buttonUrl ? 'border-red-500' : ''}`}
                          placeholder="https://chat.whatsapp.com/... or /wallet"
                        />
                        {fieldError('buttonUrl')}
                      </div>

                      <div>
                        <label className="block text-xs text-zinc-400 mb-1 font-semibold">Button opens in</label>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setForm({ ...form, openInNewTab: false })}
                            className={`flex-1 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${!form.openInNewTab ? 'bg-red-600 text-white' : 'bg-zinc-800/60 text-zinc-400'}`}
                          >
                            Same Tab
                          </button>
                          <button
                            type="button"
                            onClick={() => setForm({ ...form, openInNewTab: true })}
                            className={`flex-1 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${form.openInNewTab ? 'bg-red-600 text-white' : 'bg-zinc-800/60 text-zinc-400'}`}
                          >
                            New Tab
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Display Settings */}
                <div className="space-y-3 pt-3 border-t border-zinc-800/60">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Display Settings</h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-zinc-400 mb-1 font-semibold">Start Date & Time</label>
                      <input
                        type="datetime-local"
                        value={form.startAt}
                        onChange={(e) => setForm({ ...form, startAt: e.target.value })}
                        className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass} ${errors.startAt ? 'border-red-500' : ''}`}
                      />
                      {fieldError('startAt')}
                    </div>
                    <div>
                      <label className="block text-xs text-zinc-400 mb-1 font-semibold">End Date & Time</label>
                      <input
                        type="datetime-local"
                        value={form.endAt}
                        onChange={(e) => setForm({ ...form, endAt: e.target.value })}
                        className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass} ${errors.endAt ? 'border-red-500' : ''}`}
                      />
                      {fieldError('endAt')}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-zinc-400 mb-1 font-semibold">Priority (higher shows first)</label>
                    <input
                      type="number"
                      value={form.priority}
                      onChange={(e) => setForm({ ...form, priority: e.target.value })}
                      className={`w-full p-2.5 rounded-xl outline-none text-sm ${inputBgClass} ${errors.priority ? 'border-red-500' : ''}`}
                      placeholder="0"
                    />
                    {fieldError('priority')}
                  </div>

                  <label className="flex items-center justify-between gap-3 p-3 rounded-xl bg-zinc-900/40 border border-zinc-800/60 cursor-pointer">
                    <div>
                      <div className="text-white font-bold text-xs">Show announcement automatically</div>
                      <div className="text-[10px] text-zinc-500">If off, this announcement won't appear on its own even when active.</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={form.autoDisplay}
                      onChange={(e) => setForm({ ...form, autoDisplay: e.target.checked })}
                      className="w-4 h-4 accent-red-600 cursor-pointer flex-shrink-0"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-3 p-3 rounded-xl bg-zinc-900/40 border border-zinc-800/60 cursor-pointer">
                    <div>
                      <div className="text-white font-bold text-xs">Allow "Don't show again today"</div>
                      <div className="text-[10px] text-zinc-500">Lets visitors dismiss it for the rest of the day.</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={form.allowDontShowAgain}
                      onChange={(e) => setForm({ ...form, allowDontShowAgain: e.target.checked })}
                      className="w-4 h-4 accent-red-600 cursor-pointer flex-shrink-0"
                    />
                  </label>
                </div>
              </div>

              {/* Live Preview column */}
              <div className={`p-6 flex flex-col ${isDark ? 'bg-[#05070c]' : 'bg-slate-50'} border-t lg:border-t-0 lg:border-l border-zinc-800/60`}>
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-4">Live Preview</h4>
                <div className="flex-1 flex items-center justify-center">
                  <AnnouncementPreview announcement={previewAnnouncement} />
                </div>
              </div>
            </div>

            {/* Footer actions */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-zinc-800/80">
              <button
                onClick={closeEditor}
                disabled={isSaving}
                className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl cursor-pointer text-sm disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white font-black rounded-xl shadow-lg shadow-red-600/25 cursor-pointer text-sm flex items-center gap-2 disabled:opacity-60"
              >
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                <span>{isSaving ? 'Saving...' : editingId ? 'Save Changes' : 'Create Announcement'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
