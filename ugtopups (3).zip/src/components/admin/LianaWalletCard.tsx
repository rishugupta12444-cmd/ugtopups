import { useState, useEffect, useCallback, useRef } from 'react';
import { Wallet, Clock, RefreshCw, ShieldAlert, ShieldCheck, ShieldQuestion, Megaphone, TrendingDown } from 'lucide-react';
import { supabase } from '../../lib/supabase';

// Thresholds (in coins) that decide the wallet health badge below.
// Tune these to whatever actually makes an order fail on your Liana account.
const CRITICAL_THRESHOLD = 50;
const WARNING_THRESHOLD = 200;

type WalletStatus = 'critical' | 'warning' | 'healthy';

interface LianaWalletCardProps {
  onShowLogs?: () => void;
}

function extractBalance(raw: any): number | null {
  if (raw == null) return null;
  // Current contract: process-ml-order's check-balance action returns a clean
  // numeric/numeric-string `balance` field directly (see supabase/functions/_shared/liana.ts).
  if (typeof raw === 'number') return Number.isFinite(raw) ? raw : null;
  if (typeof raw === 'string') {
    const num = Number(raw);
    return Number.isFinite(num) ? num : null;
  }
  // Back-compat: older deploys returned the whole raw Liana object as `balance`.
  const candidate =
    raw.balance ??
    raw.data?.balance ??
    raw.wallet_balance ??
    raw.data?.wallet_balance ??
    raw.coins ??
    raw.amount;
  const num = Number(candidate);
  return Number.isFinite(num) ? num : null;
}

const STATUS_META: Record<WalletStatus, { label: string; badgeClass: string; icon: typeof ShieldAlert; message: string; barClass: string }> = {
  critical: {
    label: 'Critical',
    badgeClass: 'bg-red-500/15 text-red-400 border-red-500/30',
    icon: ShieldAlert,
    message: 'CRITICAL: Wallet balance is extremely low! Orders will fail. Top up immediately.',
    barClass: 'border-red-500/60',
  },
  warning: {
    label: 'Low',
    badgeClass: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
    icon: ShieldQuestion,
    message: 'WARNING: Wallet balance is getting low. Consider topping up soon.',
    barClass: 'border-yellow-500/50',
  },
  healthy: {
    label: 'Healthy',
    badgeClass: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
    icon: ShieldCheck,
    message: 'Wallet balance is healthy. Orders are processing normally.',
    barClass: 'border-emerald-500/40',
  },
};

export const LianaWalletCard: React.FC<LianaWalletCardProps> = ({ onShowLogs }) => {
  const [balance, setBalance] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [credentialsExpired, setCredentialsExpired] = useState(false);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);
  const mounted = useRef(true);

  const fetchBalance = useCallback(async () => {
    setRefreshing(true);
    try {
      const { data, error: invokeError } = await supabase.functions.invoke('process-ml-order', {
        body: { action: 'check-balance' },
      });
      if (invokeError) throw invokeError;
      if (!mounted.current) return;

      if (!data?.success) {
        setError(data?.error || 'Unable to fetch wallet balance right now.');
        setCredentialsExpired(!!data?.credentials_expired);
        setBalance(null);
      } else {
        const numeric = extractBalance(data.balance);
        setBalance(numeric);
        setError(numeric === null ? 'Liana returned an unexpected balance response.' : null);
        setCredentialsExpired(false);
        setLastChecked(new Date());
      }
    } catch (err: any) {
      if (!mounted.current) return;
      setError(err?.message || 'Failed to reach the Liana API.');
      setBalance(null);
    } finally {
      if (mounted.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    fetchBalance();
    const interval = setInterval(fetchBalance, 60000); // keep it live — refresh every 60s
    return () => {
      mounted.current = false;
      clearInterval(interval);
    };
  }, [fetchBalance]);

  const status: WalletStatus | null =
    balance === null ? null : balance < CRITICAL_THRESHOLD ? 'critical' : balance < WARNING_THRESHOLD ? 'warning' : 'healthy';
  const meta = status ? STATUS_META[status] : null;
  const StatusIcon = meta?.icon;

  return (
    <div className="space-y-2.5">
      <div
        className={`bg-zinc-950 border rounded-2xl p-5 transition-colors ${
          meta ? meta.barClass : error ? 'border-orange-500/40' : 'border-zinc-800'
        }`}
      >
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <Wallet className={`h-5 w-5 ${status === 'critical' ? 'text-red-500' : status === 'warning' ? 'text-yellow-500' : 'text-zinc-400'}`} />
            <h3 className="text-sm font-bold text-white">Liana API Wallet</h3>
          </div>
          <div className="flex items-center gap-3 text-zinc-500">
            <div className="flex items-center gap-1.5 text-[11px]">
              <Clock className="h-3.5 w-3.5" />
              {lastChecked ? lastChecked.toLocaleTimeString() : '—'}
            </div>
            <button
              type="button"
              onClick={fetchBalance}
              disabled={refreshing}
              aria-label="Refresh wallet balance"
              className="text-zinc-500 hover:text-white transition disabled:opacity-40"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-3">
          {loading ? (
            <div className="h-9 w-32 bg-zinc-900 rounded-lg animate-pulse" />
          ) : balance !== null ? (
            <>
              <span className="text-3xl font-black text-white">{balance.toFixed(2)}</span>
              <span className="text-sm text-zinc-500 font-semibold">coins</span>
              {meta && StatusIcon && (
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border ${meta.badgeClass}`}>
                  <StatusIcon className="h-3 w-3" />
                  {meta.label}
                </span>
              )}
            </>
          ) : (
            <span className="text-sm text-orange-400 font-semibold">Balance unavailable</span>
          )}
        </div>

        {!loading && meta && (
          <p className={`mt-3 flex items-start gap-2 text-[11px] font-semibold ${status === 'critical' ? 'text-red-400' : status === 'warning' ? 'text-yellow-400' : 'text-emerald-400'}`}>
            <Megaphone className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
            {meta.message}
          </p>
        )}

        {!loading && error && (
          <p className="mt-3 flex items-start gap-2 text-[11px] font-semibold text-orange-400">
            <Megaphone className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
            <span>
              {credentialsExpired && <span className="mr-1.5 px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-300 uppercase tracking-wide text-[9px] font-bold">Credentials</span>}
              {error}
            </span>
          </p>
        )}
      </div>

      <button
        type="button"
        onClick={onShowLogs}
        className="w-full flex items-center gap-2 bg-zinc-950 border border-zinc-800 hover:border-red-500/40 rounded-2xl px-4 py-3 text-red-500 font-bold text-[13px] transition"
      >
        <TrendingDown className="h-4 w-4" />
        Show Wallet Activity Logs
      </button>
    </div>
  );
};
