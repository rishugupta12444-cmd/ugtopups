import React, { useEffect, useRef, useState } from 'react';
import { Palette, Save, Loader2, RotateCcw, ExternalLink } from 'lucide-react';
import {
  PaymentPageSettings,
  DEFAULT_PAYMENT_PAGE_SETTINGS,
  subscribePaymentPageSettings,
  savePaymentPageSettings,
  uploadPaymentPageLogo,
} from '../../lib/paymentPageSettings';

interface Props {
  /** Pass the dashboard's own theme flag so the card matches the surrounding panels. */
  isDark?: boolean;
}

type TextKey = {
  [K in keyof PaymentPageSettings]: PaymentPageSettings[K] extends string ? K : never
}[keyof PaymentPageSettings];

type BoolKey = {
  [K in keyof PaymentPageSettings]: PaymentPageSettings[K] extends boolean ? K : never
}[keyof PaymentPageSettings];

const TEXT_FIELDS: Array<{ key: TextKey; label: string; hint?: string }> = [
  { key: 'brandName',        label: 'Brand name',        hint: 'Shown above the bill card' },
  { key: 'billLabel',        label: 'Amount label' },
  { key: 'currencyLabel',    label: 'Currency label' },
  { key: 'scanTitle',        label: 'Scan heading',      hint: 'Use {highlight} where the wallet name goes' },
  { key: 'scanHighlight',    label: 'Highlighted word',  hint: 'Rendered in the accent colour' },
  { key: 'scanSubtitle',     label: 'Scan sub-line' },
  { key: 'waitingText',      label: 'Waiting status' },
  { key: 'successText',      label: 'Paid status' },
  { key: 'failedText',       label: 'Not-paid-yet message' },
  { key: 'expiredText',      label: 'Expired status' },
  { key: 'checkButtonText',  label: 'Primary button' },
  { key: 'cancelButtonText', label: 'Cancel link' },
  { key: 'detailsTitle',     label: 'Details heading' },
  { key: 'orderIdLabel',     label: 'Order ID row label' },
  { key: 'createdAtLabel',   label: 'Created At row label' },
  { key: 'expiryLabel',      label: 'Expiry row label' },
  { key: 'packageLabel',     label: 'Package row label' },
  { key: 'playerUidLabel',   label: 'Player UID row label' },
  { key: 'footerNote',       label: 'Footer note',       hint: 'Leave blank to hide' },
  { key: 'supportText',      label: 'Support link text', hint: 'Leave blank to hide' },
  { key: 'supportUrl',       label: 'Support link URL' },
  { key: 'displayFont',      label: 'Heading font stack', hint: 'CSS font-family value' },
  { key: 'bodyFont',         label: 'Body font stack',    hint: 'CSS font-family value' },
];

const COLOR_FIELDS: Array<{ key: TextKey; label: string }> = [
  { key: 'accentColor',     label: 'Accent' },
  { key: 'pageBgColor',     label: 'Page background' },
  { key: 'cardBgColor',     label: 'Card background' },
  { key: 'borderColor',     label: 'Card border' },
  { key: 'textColor',       label: 'Text' },
  { key: 'mutedTextColor',  label: 'Muted text' },
];

const TOGGLES: Array<{ key: BoolKey; label: string }> = [
  { key: 'showLogo',         label: 'Show logo' },
  { key: 'glowEnabled',      label: 'Background glow' },
  { key: 'showOrderId',      label: 'Order ID row' },
  { key: 'showCreatedAt',    label: 'Created At row' },
  { key: 'showExpiry',       label: 'Expiry countdown' },
  { key: 'showPackage',      label: 'Package row' },
  { key: 'showPlayerUid',    label: 'Player UID row' },
  { key: 'showCancelButton', label: 'Cancel link' },
];

export const PaymentPageSettingsCard: React.FC<Props> = ({ isDark = true }) => {
  const [settings, setSettings] = useState<PaymentPageSettings>(DEFAULT_PAYMENT_PAGE_SETTINGS);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);
  const [uploading, setUploading] = useState(false);
  // Stops the realtime subscription from overwriting edits in progress.
  const dirtyRef = useRef(false);

  useEffect(() => subscribePaymentPageSettings((next) => {
    if (!dirtyRef.current) setSettings(next);
  }), []);

  const cardBgClass = isDark ? 'bg-[#0c101c] border-zinc-800' : 'bg-white border-slate-200 shadow-sm';
  const inputBgClass = isDark
    ? 'bg-[#080b14] border-zinc-700 text-white'
    : 'bg-white border-slate-200 text-slate-900';

  const patch = <K extends keyof PaymentPageSettings>(key: K, value: PaymentPageSettings[K]) => {
    dirtyRef.current = true;
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleLogoUpload = async (file?: File | null) => {
    if (!file) return;
    setUploading(true);
    try {
      patch('logoUrl', await uploadPaymentPageLogo(file));
      patch('showLogo', true);
    } catch {
      setMessage({ text: 'Logo upload failed. Paste a URL instead.', ok: false });
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);
    try {
      await savePaymentPageSettings(settings);
      dirtyRef.current = false;
      setMessage({ text: 'Payment page updated. Customers see it on the next load.', ok: true });
    } catch (err) {
      setMessage({ text: err instanceof Error ? err.message : 'Save failed.', ok: false });
    } finally {
      setSaving(false);
      setTimeout(() => setMessage(null), 5000);
    }
  };

  const handleReset = () => {
    dirtyRef.current = true;
    setSettings(DEFAULT_PAYMENT_PAGE_SETTINGS);
    setMessage({ text: 'Defaults loaded — press Save to apply them.', ok: true });
  };

  return (
    <div className={`p-5 rounded-2xl space-y-5 border ${cardBgClass}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Palette className="w-4 h-4 text-red-400" /> Payment Page Design
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            Controls the QR checkout page customers see at <code className="text-zinc-300">/billing</code>.
          </p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-700 text-zinc-400 hover:text-white text-[11px] font-bold transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
      </div>

      {/* Live preview */}
      <div
        className="rounded-xl p-4"
        style={{
          backgroundColor: settings.pageBgColor,
          backgroundImage: settings.glowEnabled
            ? `radial-gradient(220px 130px at 8% -6%, ${settings.accentColor}2e, transparent 70%)`
            : undefined,
        }}
      >
        <div className="text-xs font-extrabold mb-2" style={{ color: settings.textColor }}>
          {settings.brandName}
        </div>
        <div
          className="rounded-xl px-3 py-4 text-center"
          style={{ backgroundColor: settings.cardBgColor, border: `1px solid ${settings.borderColor}` }}
        >
          <div
            className="text-[9px] uppercase tracking-[0.14em]"
            style={{ color: settings.textColor, fontFamily: settings.displayFont }}
          >
            {settings.billLabel}
          </div>
          <div
            className="text-2xl leading-none mt-0.5"
            style={{ fontFamily: settings.displayFont, fontWeight: 800, color: settings.textColor }}
          >
            <span style={{ color: settings.accentColor }}>{settings.currencyLabel}</span> 10.00
          </div>
          <div className="mx-auto my-3 h-14 w-14 rounded-lg bg-white" />
          <div className="text-[10px] font-bold" style={{ color: settings.textColor }}>
            {settings.scanTitle.replace('{highlight}', settings.scanHighlight)}
          </div>
          <div className="text-[9px] mt-0.5" style={{ color: settings.mutedTextColor }}>
            {settings.scanSubtitle}
          </div>
          <div
            className="mt-2.5 rounded-lg py-1.5 text-[10px]"
            style={{ border: `1px solid ${settings.borderColor}66`, color: settings.accentColor, fontFamily: settings.displayFont }}
          >
            ● {settings.waitingText}
          </div>
          <div
            className="mt-1.5 rounded-lg py-2 text-[11px] font-bold"
            style={{ backgroundColor: settings.accentColor, color: '#fff', fontFamily: settings.displayFont }}
          >
            {settings.checkButtonText}
          </div>
        </div>
      </div>

      {/* Logo */}
      <div className="space-y-2 text-xs">
        <label className="block text-zinc-400 font-semibold">Logo</label>
        <div className="flex items-center gap-3">
          {settings.logoUrl ? (
            <img
              src={settings.logoUrl}
              alt="Logo"
              className="w-11 h-11 rounded-lg object-cover border border-zinc-700 bg-zinc-900"
              onError={(e) => { e.currentTarget.style.visibility = 'hidden'; }}
            />
          ) : null}
          <input
            type="text"
            value={settings.logoUrl}
            onChange={(e) => patch('logoUrl', e.target.value)}
            placeholder="https://…/logo.png"
            className={`flex-1 p-2.5 rounded-xl outline-none border ${inputBgClass}`}
          />
          <label className="px-3 py-2.5 rounded-xl border border-dashed border-zinc-600 text-zinc-400 font-bold cursor-pointer hover:border-red-500/60 hover:text-red-400 transition-all whitespace-nowrap">
            {uploading ? 'Uploading…' : 'Upload'}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleLogoUpload(e.target.files?.[0])}
            />
          </label>
        </div>
      </div>

      {/* Copy */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        {TEXT_FIELDS.map(({ key, label, hint }) => (
          <div key={key}>
            <label className="block text-zinc-400 mb-1 font-semibold">{label}</label>
            <input
              type="text"
              value={String(settings[key] ?? '')}
              onChange={(e) => patch(key, e.target.value as PaymentPageSettings[typeof key])}
              className={`w-full p-2.5 rounded-xl outline-none border ${inputBgClass}`}
            />
            {hint ? <p className="text-[10px] text-zinc-500 mt-1">{hint}</p> : null}
          </div>
        ))}
      </div>

      {/* Colours */}
      <div>
        <label className="block text-zinc-400 mb-2 font-semibold text-xs">Colours</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {COLOR_FIELDS.map(({ key, label }) => (
            <div key={key} className="flex items-center gap-2 p-2 rounded-xl border border-zinc-800 bg-zinc-900/50">
              <input
                type="color"
                value={String(settings[key] ?? '#000000')}
                onChange={(e) => patch(key, e.target.value as PaymentPageSettings[typeof key])}
                className="w-7 h-7 rounded cursor-pointer bg-transparent border-0 p-0"
              />
              <div className="min-w-0">
                <div className="text-[10px] text-zinc-400 font-semibold truncate">{label}</div>
                <div className="text-[10px] text-zinc-500 font-mono truncate">{String(settings[key])}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timing */}
      <div className="grid grid-cols-2 gap-3 text-xs">
        <div>
          <label className="block text-zinc-400 mb-1 font-semibold">QR lifetime (minutes)</label>
          <input
            type="number"
            min={1}
            max={60}
            value={settings.expiryMinutes}
            onChange={(e) => patch('expiryMinutes', Number(e.target.value))}
            className={`w-full p-2.5 rounded-xl outline-none border ${inputBgClass}`}
          />
          <p className="text-[10px] text-zinc-500 mt-1">The Hub expiry is authoritative; this is used only as a fallback display.</p>
        </div>
        <div>
          <label className="block text-zinc-400 mb-1 font-semibold">Auto-check every (seconds)</label>
          <input
            type="number"
            min={2}
            max={60}
            value={settings.pollSeconds}
            onChange={(e) => patch('pollSeconds', Number(e.target.value))}
            className={`w-full p-2.5 rounded-xl outline-none border ${inputBgClass}`}
          />
        </div>
      </div>

      {/* Toggles */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {TOGGLES.map(({ key, label }) => {
          const on = Boolean(settings[key]);
          return (
            <button
              key={key}
              type="button"
              onClick={() => patch(key, !on as PaymentPageSettings[typeof key])}
              className={`p-2.5 rounded-xl border text-[11px] font-bold text-left transition-all cursor-pointer ${
                on
                  ? 'bg-red-500/15 border-red-500/60 text-red-300'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {label}
              <span className="block text-[9px] font-semibold opacity-70 mt-0.5">{on ? 'Visible' : 'Hidden'}</span>
            </button>
          );
        })}
      </div>

      {message ? (
        <p className={`text-xs font-bold ${message.ok ? 'text-emerald-400' : 'text-red-400'}`}>
          {message.text}
        </p>
      ) : null}

      <div className="flex items-center gap-3">
        <button
          onClick={handleSave}
          disabled={saving}
          className="py-2.5 px-5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50 text-xs"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save payment page
        </button>
        <a
          href="/billing"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[11px] text-zinc-400 hover:text-white font-bold flex items-center gap-1.5"
        >
          Open live page <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
};
