import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, CheckCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  message: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title?: string;
  timestamp: number;
}

export function showToast(message: string, type: 'error' | 'warning' | 'info' | 'success' = 'error', title?: string) {
  if (!message || typeof window === 'undefined') return;
  window.dispatchEvent(
    new CustomEvent('app-global-toast', {
      detail: { message: String(message), type, title },
    })
  );
}

if (typeof window !== 'undefined') {
  (window as any).showToast = showToast;
}

export const GlobalToast: React.FC = () => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (message: string, type: 'error' | 'warning' | 'info' | 'success' = 'error', title?: string) => {
    if (!message) return;
    const cleanMsg = String(message).trim();
    if (!cleanMsg) return;

    // Ignore noise from Vite/HMR or React dev environment errors
    if (
      cleanMsg.includes('[vite]') ||
      cleanMsg.includes('websocket') ||
      cleanMsg.includes('HMR') ||
      cleanMsg.includes('failed to connect to websocket') ||
      cleanMsg.includes('Download the React DevTools')
    ) {
      return;
    }

    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

    setToasts((prev) => {
      // Prevent duplicate messages within 2 seconds
      const existsRecent = prev.some(
        (t) => t.message === cleanMsg && Date.now() - t.timestamp < 2000
      );
      if (existsRecent) return prev;
      return [...prev.slice(-2), { id, message: cleanMsg, type, title, timestamp: Date.now() }];
    });
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  useEffect(() => {
    const handleCustomToast = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.message) {
        addToast(detail.message, detail.type || 'error', detail.title);
      }
    };

    window.addEventListener('app-global-toast', handleCustomToast);

    // Intercept window.alert so all alert() calls appear as bottom-right toast
    const originalAlert = window.alert;
    window.alert = (msg?: any) => {
      if (msg !== undefined && msg !== null && String(msg).trim()) {
        setTimeout(() => addToast(String(msg), 'error'), 0);
      }
    };

    // Intercept console.error
    const originalConsoleError = console.error;
    console.error = (...args: any[]) => {
      originalConsoleError.apply(console, args);
      const parts = args
        .map((a) => {
          if (!a) return '';
          if (typeof a === 'string') return a;
          if (a instanceof Error) return a.message;
          if (typeof a === 'object' && a.message) return String(a.message);
          return '';
        })
        .filter(Boolean);
      const text = parts.join(' ').trim();
      if (
        text &&
        !text.includes('[object Object]') &&
        !text.includes('ReactWillUnmount') &&
        !text.startsWith('Warning:') &&
        !text.includes('Cannot update a component') &&
        !text.includes('The above error occurred in') &&
        !text.includes('React will try to recreate')
      ) {
        setTimeout(() => addToast(text, 'error'), 0);
      }
    };

    // Unhandled promise rejections
    const handleUnhandledRejection = (e: PromiseRejectionEvent) => {
      const reason = e.reason?.message || e.reason || 'Unhandled promise rejection';
      if (typeof reason === 'string' && reason) {
        setTimeout(() => addToast(reason, 'error'), 0);
      }
    };

    // Unhandled window errors
    const handleWindowError = (e: ErrorEvent) => {
      if (e.message) {
        setTimeout(() => addToast(e.message, 'error'), 0);
      }
    };

    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    window.addEventListener('error', handleWindowError);

    return () => {
      window.removeEventListener('app-global-toast', handleCustomToast);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      window.removeEventListener('error', handleWindowError);
      window.alert = originalAlert;
      console.error = originalConsoleError;
    };
  }, []);

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-[999999] flex flex-col gap-2.5 max-w-sm sm:max-w-md w-[calc(100vw-2rem)] pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => (
          <ToastCard key={toast.id} toast={toast} onClose={() => removeToast(toast.id)} />
        ))}
      </AnimatePresence>
    </div>
  );
};

interface ToastCardProps {
  toast: ToastMessage;
  onClose: () => void;
}

const ToastCard: React.FC<ToastCardProps> = ({ toast, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 6000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const isError = toast.type === 'error' || toast.type === 'warning';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.9, transition: { duration: 0.15 } }}
      className="pointer-events-auto bg-[#121318]/95 border border-zinc-800/90 text-white rounded-2xl p-4 shadow-2xl backdrop-blur-xl flex items-start gap-3 relative overflow-hidden group"
    >
      {/* Icon Badge */}
      <div
        className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 font-black text-xs shadow-md mt-0.5 ${
          toast.type === 'success'
            ? 'bg-emerald-500 text-black'
            : isError
            ? 'bg-white text-black'
            : 'bg-blue-500 text-white'
        }`}
      >
        {toast.type === 'success' ? (
          <CheckCircle className="w-4 h-4 text-black stroke-[2.5]" />
        ) : isError ? (
          <AlertCircle className="w-4 h-4 text-black stroke-[2.5]" />
        ) : (
          <Info className="w-4 h-4 text-white stroke-[2.5]" />
        )}
      </div>

      {/* Message Body */}
      <div className="flex-1 pr-6 min-w-0">
        {toast.title && (
          <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-0.5">
            {toast.title}
          </h4>
        )}
        <p className="text-xs sm:text-sm font-semibold text-zinc-100 leading-snug break-words">
          {toast.message}
        </p>
      </div>

      {/* Close Button */}
      <button
        onClick={onClose}
        className="absolute top-3.5 right-3 text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-zinc-800/80 transition cursor-pointer"
        aria-label="Close error toast"
      >
        <X className="w-4 h-4" />
      </button>

      {/* Progress Line */}
      <motion.div
        initial={{ width: '100%' }}
        animate={{ width: '0%' }}
        transition={{ duration: 6, ease: 'linear' }}
        className={`absolute bottom-0 left-0 right-0 h-0.5 ${
          toast.type === 'success'
            ? 'bg-emerald-500'
            : isError
            ? 'bg-gradient-to-r from-red-500 via-amber-500 to-red-600'
            : 'bg-blue-500'
        }`}
      />
    </motion.div>
  );
};
