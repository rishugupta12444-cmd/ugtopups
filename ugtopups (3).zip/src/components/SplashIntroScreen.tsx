import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { UGLogo } from './UGLogo';

interface SplashIntroScreenProps {
  onComplete: () => void;
}

export const SplashIntroScreen: React.FC<SplashIntroScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const duration = 1750; // Exactly 1.75 seconds as requested

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const currentProgress = Math.min(Math.round((elapsed / duration) * 100), 100);
      setProgress(currentProgress);

      if (elapsed >= duration) {
        clearInterval(interval);
        setTimeout(() => {
          onComplete();
        }, 100);
      }
    }, 16);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.08, filter: 'blur(12px)' }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="fixed inset-0 z-[9999] bg-black text-white flex flex-col items-center justify-center p-6 select-none overflow-hidden"
    >
      {/* Subtle Glow Behind Center Logo */}
      <div className="absolute w-[280px] h-[280px] bg-red-600/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative flex flex-col items-center max-w-sm w-full z-10 text-center">
        
        {/* White Ring Emblem around Logo - matching reference image style */}
        <motion.div
          initial={{ scale: 0.75, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="relative mb-6"
        >
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full border border-white/80 bg-black/60 flex items-center justify-center shadow-[0_0_25px_rgba(255,255,255,0.08)] relative z-10 p-3">
            <UGLogo size="lg" className="w-16 h-16 sm:w-18 sm:h-18" />
          </div>
        </motion.div>

        {/* Reference Image Typography Style: Bold White + Light Grey */}
        <motion.div
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mb-8"
        >
          <h1 className="text-2xl sm:text-3xl tracking-tight uppercase flex items-center justify-center gap-1.5 font-sans">
            <span className="font-extrabold text-white">UG</span>
            <span className="font-light text-zinc-400">GAMING</span>
          </h1>
        </motion.div>

        {/* Minimalist White Line Loader - Exactly 1.75s progress */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-48 sm:w-56 h-[2.5px] bg-zinc-800/90 rounded-full overflow-hidden relative shadow-inner"
        >
          <div
            className="h-full bg-white transition-all ease-linear duration-75 rounded-full shadow-[0_0_10px_rgba(255,255,255,0.9)]"
            style={{ width: `${progress}%` }}
          />
        </motion.div>

      </div>
    </motion.div>
  );
};
