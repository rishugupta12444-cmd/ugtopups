import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Order, UserProfile } from '../types';
import { OrderConfirmation } from '../pages/OrderConfirmation';

interface SuccessReceiptModalProps {
  order: Order | null;
  user?: UserProfile;
  onClose: () => void;
  onOpenTrackOrder?: () => void;
  onOpenWallet?: () => void;
}

export const SuccessReceiptModal: React.FC<SuccessReceiptModalProps> = ({
  order,
  user,
  onClose,
  onOpenWallet,
}) => {
  if (!order) return null;

  return (
    <AnimatePresence>
      <div 
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          onClick={(e) => e.stopPropagation()}
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-2xl my-auto max-h-[92vh] overflow-y-auto scrollbar-thin"
        >
          <OrderConfirmation
            order={order}
            user={user}
            onClose={onClose}
            onOpenWallet={onOpenWallet}
          />
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
