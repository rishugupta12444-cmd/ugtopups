import React from 'react';
import {
  X, User, Wallet, Power, Bookmark, ListFilter, Plus, PhoneCall,
  ChevronRight, Headphones,
} from 'lucide-react';
import { UserProfile, Order, WalletTransaction } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  orders: Order[];
  walletHistory: WalletTransaction[];
  onNavigate: (path: string) => void;
  onLogout?: () => void;
}

/**
 * Profile Drawer — navigation panel ONLY.
 *
 * This drawer never renders forms, never expands sections inline, and
 * never shows page content below the menu. Every menu item navigates to
 * its own dedicated full page (/account, /account/orders, etc.) and the
 * drawer closes automatically right after navigating.
 */
export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen, onClose, user, orders, onNavigate, onLogout,
}) => {
  if (!isOpen) return null;

  const initialLetter = user.username ? user.username.charAt(0).toUpperCase() : 'U';

  const goTo = (path: string) => {
    onNavigate(path);
    onClose();
  };

  const navItems = [
    { path: '/account', icon: User, label: 'My Account', color: 'text-blue-400', badge: null as string | number | null },
    { path: '/account/orders', icon: Bookmark, label: 'My Orders', color: 'text-purple-400', badge: orders.length > 0 ? orders.length : null },
    { path: '/account/transactions', icon: ListFilter, label: 'Transactions', color: 'text-amber-400', badge: null },
    { path: '/account/wallet', icon: Plus, label: 'Instant Wallet Load', color: 'text-emerald-400', badge: 'Load' },
    { path: '/account/support', icon: PhoneCall, label: 'Support', color: 'text-indigo-400', badge: null },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm cursor-pointer" onClick={onClose} />

      {/* Drawer */}
      <div className="absolute inset-y-0 right-0 flex max-w-full pl-10">
        <div className="w-screen max-w-sm sm:max-w-md bg-[#0f0f0f] border-l border-zinc-800 shadow-2xl flex flex-col text-white animate-slide-left">

          {/* ── Header: Avatar / Username / Email ── */}
          <div className="relative px-6 pt-6 pb-5 bg-gradient-to-br from-zinc-900 to-[#0f0f0f] border-b border-zinc-800 flex-shrink-0">
            <button onClick={onClose} className="absolute top-4 right-4 p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-all cursor-pointer">
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-2xl text-white font-black text-2xl flex items-center justify-center shadow-lg border border-red-500/30 overflow-hidden flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #dc2626, #7f1d1d)' }}
              >
                {initialLetter}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <h3 className="font-black text-base text-white truncate">{user.username}</h3>
                </div>
                <p className="text-xs text-zinc-500 truncate mb-3">{user.email}</p>
                <button
                  onClick={onLogout || onClose}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold rounded-full transition-all cursor-pointer border border-zinc-700"
                >
                  <Power className="w-3 h-3" /> Logout
                </button>
              </div>
            </div>

            {/* Wallet Balance Strip */}
            <div className="mt-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-zinc-300">UG Wallet Balance</span>
              </div>
              <span className="text-base font-black text-emerald-400 font-mono">
                NPR {user.walletBalanceNpr.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* ── Nav Menu (navigation only — no inline content) ── */}
          <div className="px-4 py-3 space-y-0.5 flex-1 overflow-y-auto">
            {navItems.map(({ path, icon: Icon, label, color, badge }) => (
              <button
                key={path}
                onClick={() => goTo(path)}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-200 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${color}`} />
                  <span>{label}</span>
                </div>
                <div className="flex items-center gap-2">
                  {badge !== null && (
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                      typeof badge === 'number'
                        ? 'bg-zinc-800 text-zinc-400'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}>{badge}</span>
                  )}
                  <ChevronRight className="w-3.5 h-3.5 text-zinc-700" />
                </div>
              </button>
            ))}
          </div>

          {/* ── Footer ── */}
          <div className="p-4 bg-[#0f0f0f] border-t border-zinc-800 flex-shrink-0">
            <a
              href="https://wa.me/9779708562001"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-red-600 hover:bg-red-700 active:scale-[0.99] text-white font-extrabold text-xs rounded-xl shadow-md shadow-red-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Headphones className="w-4 h-4" />
              Chat with Support on WhatsApp
            </a>
          </div>

        </div>
      </div>
    </div>
  );
};
