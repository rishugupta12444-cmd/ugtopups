import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Pause, Play, Sparkles, ArrowRight, ShieldCheck, Zap } from 'lucide-react';
import { BannerItem } from '../types';
import { UGLogo } from './UGLogo';

interface BannerProps {
  banners: BannerItem[];
  onSelectGame?: (gameId: string) => void;
  onOpenWalletAdd?: () => void;
}

export const Banner: React.FC<BannerProps> = ({ banners, onSelectGame, onOpenWalletAdd }) => {
  const activeBanners = banners.filter((b) => b.active !== false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto rotate banners
  useEffect(() => {
    if (!isPlaying || activeBanners.length <= 1) return;

    timerRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 4500);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, activeBanners.length, currentIndex]);

  const handleNext = () => {
    if (activeBanners.length === 0) return;
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  const handlePrev = () => {
    if (activeBanners.length === 0) return;
    setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  // Swipe gesture handlers
  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      handleNext();
    } else if (isRightSwipe) {
      handlePrev();
    }
  };

  if (activeBanners.length === 0) return null;

  const currentBanner = activeBanners[currentIndex] || activeBanners[0];

  const handleAction = () => {
    if (currentBanner.gameId && onSelectGame) {
      onSelectGame(currentBanner.gameId);
      const el = document.getElementById('topup-section');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (currentBanner.linkUrl === '#wallet' && onOpenWalletAdd) {
      onOpenWalletAdd();
    } else {
      const el = document.getElementById('games-section');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="hero-section" className="bg-white py-4 sm:py-6 px-3 sm:px-6 lg:px-8 border-b border-zinc-100 select-none">
      <div className="max-w-7xl mx-auto">
        
        {/* Swipeable & Auto-rotating Interactive Hero Carousel Banner */}
        <div
          className="relative rounded-3xl overflow-hidden bg-zinc-950 text-white shadow-xl border border-zinc-800 group min-h-[210px] sm:min-h-[250px] lg:min-h-[270px] flex items-center"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          {/* Animated Background Banner Image & Overlays */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentBanner.id}
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.5, ease: 'easeInOut' }}
              className="absolute inset-0 z-0"
            >
              <img
                src={currentBanner.imageUrl}
                alt={currentBanner.title}
                className="w-full h-full object-cover object-center opacity-30 sm:opacity-40 filter brightness-75 contrast-125"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent" />
            </motion.div>
          </AnimatePresence>

          {/* Ambient Glowing Effects */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/20 rounded-full blur-3xl pointer-events-none z-0" />
          <div className="absolute bottom-0 left-10 w-56 h-56 bg-red-900/30 rounded-full blur-3xl pointer-events-none z-0" />

          {/* Banner Content Container */}
          <div className="relative z-10 w-full p-4 sm:p-6 lg:p-8 flex flex-col justify-between min-h-[210px] sm:min-h-[250px] lg:min-h-[270px]">
            
            {/* Top Bar: Official Badge & Auto-Play Status */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 flex-wrap">
                <UGLogo size="sm" />
                {currentBanner.badge && (
                  <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest bg-red-600 text-white px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1">
                    {currentBanner.badge}
                  </span>
                )}
                <span className="text-[11px] font-semibold text-zinc-300 hidden sm:inline-block">
                  Swipeable Banner • UG Top Up Center
                </span>
              </div>

              {/* Play / Pause Toggle Button */}
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-1 sm:p-1.5 rounded-full bg-black/40 backdrop-blur-md border border-white/20 text-zinc-300 hover:text-white hover:bg-black/70 transition-all cursor-pointer"
                title={isPlaying ? 'Pause Auto-Rotation' : 'Play Auto-Rotation'}
              >
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              </button>
            </div>

            {/* Center Content Column */}
            <div className="my-auto max-w-2xl py-2">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentBanner.id + '-text'}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-1.5 sm:space-y-2"
                >
                  <h1 className="text-lg sm:text-2xl lg:text-3xl font-black tracking-tight text-white leading-tight drop-shadow-md">
                    {currentBanner.title}
                  </h1>

                  <p className="text-[11px] sm:text-xs lg:text-sm text-zinc-200 font-normal leading-relaxed max-w-xl line-clamp-2">
                    {currentBanner.subtitle}
                  </p>

                  <div className="pt-1.5 flex flex-wrap items-center gap-2.5">
                    <button
                      onClick={handleAction}
                      className="px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-[11px] sm:text-xs uppercase tracking-wider shadow-md shadow-red-900/50 hover:shadow-red-900/70 transition-all transform hover:-translate-y-0.5 active:scale-95 flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>{currentBanner.actionText || 'TOP UP NOW'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/10 backdrop-blur-md border border-white/15 text-[11px] text-zinc-300 font-bold">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Instant UID Auto Delivery</span>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Bottom Bar: Carousel Indicators & Arrows */}
            <div className="flex items-center justify-between pt-1.5 border-t border-white/10">
              {/* Pagination Dots */}
              <div className="flex items-center gap-1.5">
                {activeBanners.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-1.5 sm:h-2 rounded-full transition-all cursor-pointer ${
                      idx === currentIndex
                        ? 'w-6 sm:w-7 bg-red-600 shadow-md shadow-red-500/50'
                        : 'w-1.5 sm:w-2 bg-white/30 hover:bg-white/60'
                    }`}
                    title={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>

              {/* Prev / Next Swipe Arrow Buttons */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handlePrev}
                  className="p-1.5 sm:p-2 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all active:scale-95 cursor-pointer backdrop-blur-md"
                  title="Previous Banner (Or swipe right)"
                >
                  <ChevronLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-1.5 sm:p-2 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all active:scale-95 cursor-pointer backdrop-blur-md"
                  title="Next Banner (Or swipe left)"
                >
                  <ChevronRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
