import React, { useState, useRef } from 'react';
import { Star, Zap, ShieldCheck, Headphones, Plus, CheckCircle2, MessageSquare, X, Check } from 'lucide-react';
import { Review } from '../types';
import { submitReviewRequest } from '../lib/store';

interface ReviewCarouselProps {
  reviews: Review[];
  onAddReview: (newReview: Review) => void;
  onOpenAdmin?: () => void;
}

export const ReviewCarousel: React.FC<ReviewCarouselProps> = ({
  reviews,
  onAddReview,
  onOpenAdmin,
}) => {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [comment, setComment] = useState<string>('');
  const [game, setGame] = useState<string>('Free Fire');
  const [rating, setRating] = useState<number>(5);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedSuccess, setSubmittedSuccess] = useState<boolean>(false);

  const clickTimestampsRef = useRef<number[]>([]);

  const handlePlusClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const now = Date.now();
    const recentClicks = [...clickTimestampsRef.current, now].filter((t) => now - t <= 1000);
    clickTimestampsRef.current = recentClicks;

    if (recentClicks.length >= 5) {
      clickTimestampsRef.current = [];
      if (onOpenAdmin) {
        onOpenAdmin();
      }
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim() || isSubmitting) return;

    setIsSubmitting(true);

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      userName: name.trim(),
      rating,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      game,
      comment: comment.trim(),
      verified: true,
      status: 'PENDING',
    };

    try {
      const ok = await submitReviewRequest(newRev);
      if (!ok) {
        alert('Failed to submit review. Please try again.');
        return;
      }
      onAddReview(newRev);
      setSubmittedSuccess(true);
      setTimeout(() => {
        setName('');
        setComment('');
        setSubmittedSuccess(false);
        setIsModalOpen(false);
      }, 2000);
    } catch {
      alert('Failed to submit review. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Only display approved reviews in the public marquee carousel
  const approvedReviews = reviews.filter((r) => !r.status || r.status === 'APPROVED');
  const displayReviews = approvedReviews.length > 0 ? approvedReviews : reviews;
  const duplicatedReviews = [...displayReviews, ...displayReviews, ...displayReviews];

  return (
    <section className="bg-zinc-50 text-zinc-900 py-6 sm:py-8 px-4 sm:px-6 lg:px-8 border-t border-zinc-200 relative overflow-hidden">
      
      <div className="max-w-7xl mx-auto relative z-10 space-y-6">
        
        {/* Reviews Section Header */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-1 text-amber-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400 stroke-amber-500" />
              ))}
              <span className="ml-2 font-black text-sm text-zinc-900 font-mono">4.9 / 5</span>
              <span className="text-xs text-zinc-500">
                · 1450<span
                  onClick={handlePlusClick}
                  className="cursor-pointer select-none font-bold hover:text-red-600 transition-colors inline-block px-0.5"
                  title=""
                >+</span> verifyed costumers reviews
              </span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-zinc-900 tracking-tight">
              What Our Customers Say
            </h3>
            <p className="text-xs text-zinc-500">Real automated feedback from Nepali gamers</p>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-white border border-zinc-300 hover:border-red-600 text-zinc-800 hover:text-red-600 text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:shadow"
          >
            <Plus className="w-4 h-4 text-red-600" />
            <span>Write a Review</span>
          </button>
        </div>

        {/* AUTOMATIC SCROLLING CONTINUOUS CAROUSEL MARQUEE */}
        <div className="relative w-full overflow-hidden py-2 group">
          
          {/* Left & Right Shadow Gradient Fades */}
          <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-zinc-50 to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-zinc-50 to-transparent z-10 pointer-events-none" />

          <div className="flex gap-4 w-max animate-marquee hover:[animation-play-state:paused]">
            {duplicatedReviews.map((rev, index) => (
              <div
                key={`${rev.id}-${index}`}
                className="w-80 sm:w-88 flex-shrink-0 bg-white border border-zinc-200 rounded-2xl p-5 shadow-sm flex flex-col justify-between gap-4 hover:border-red-500 hover:shadow-md transition-all duration-300"
              >
                <div className="space-y-2">
                  {/* Rating Stars */}
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 stroke-amber-500" />
                    ))}
                  </div>

                  {/* Comment Quote */}
                  <p className="text-xs text-zinc-700 leading-relaxed font-medium line-clamp-3">
                    "{rev.comment}"
                  </p>
                </div>

                <div className="pt-3 border-t border-zinc-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-zinc-900 capitalize">{rev.userName}</span>
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Verified
                    </span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono">{rev.date}</span>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* 3 Value Proposition Cards (White + Red Theme) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-zinc-200">
          
          {/* Card 1: Instant Delivery */}
          <div className="bg-white border border-zinc-200/90 rounded-2xl p-5 shadow-xs flex items-start gap-4 hover:border-red-500/80 hover:shadow-md transition-all duration-200">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-100 flex items-center justify-center flex-shrink-0 shadow-xs">
              <Zap className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="font-black text-sm text-zinc-900 tracking-tight">Instant Delivery</h4>
              <p className="text-xs text-zinc-500 leading-relaxed font-medium">
                Get your digital items and reloads instantly after payment confirmation.
              </p>
            </div>
          </div>

          {/* Card 2: Secure Payment */}
          <div className="bg-white border border-zinc-200/90 rounded-2xl p-5 shadow-xs flex items-start gap-4 hover:border-red-500/80 hover:shadow-md transition-all duration-200">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-100 flex items-center justify-center flex-shrink-0 shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="font-black text-sm text-zinc-900 tracking-tight">Secure Payment</h4>
              <p className="text-xs text-zinc-500 leading-relaxed font-medium">
                100% secure transactions via reliable Nepal gateways.
              </p>
            </div>
          </div>

          {/* Card 3: 24/7 Support */}
          <div className="bg-white border border-zinc-200/90 rounded-2xl p-5 shadow-xs flex items-start gap-4 hover:border-red-500/80 hover:shadow-md transition-all duration-200">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-100 flex items-center justify-center flex-shrink-0 shadow-xs">
              <Headphones className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="font-black text-sm text-zinc-900 tracking-tight">24/7 Support</h4>
              <p className="text-xs text-zinc-500 leading-relaxed font-medium">
                Our dedicated support team is always ready to help you.
              </p>
            </div>
          </div>

        </div>

      </div>

      {/* Write Review Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-white border border-zinc-200 rounded-3xl p-6 shadow-2xl text-zinc-900 my-auto">
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-lg font-black text-zinc-900 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-red-600" /> Write a Review
              </h4>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {submittedSuccess ? (
              <div className="py-8 text-center space-y-3 animate-fade-in">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6 stroke-[3]" />
                </div>
                <h5 className="font-extrabold text-base text-zinc-900">Review Submitted!</h5>
                <p className="text-xs text-zinc-600 max-w-xs mx-auto leading-relaxed">
                  Thank you! Your review has been sent to our admin team. It will appear on the site once approved.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Your Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Sujan Sorali"
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-4 py-2.5 text-zinc-900 text-sm outline-none focus:border-red-600"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Game Top Up</label>
                  <select
                    value={game}
                    onChange={(e) => setGame(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-4 py-2.5 text-zinc-900 text-sm outline-none"
                  >
                    <option value="Free Fire">Free Fire</option>
                    <option value="Mobile Legends">Mobile Legends</option>
                    <option value="Call of Duty">Call of Duty</option>
                    <option value="PUBG Mobile">PUBG Mobile</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        type="button"
                        key={s}
                        onClick={() => setRating(s)}
                        className={`p-2 rounded-xl border text-xs font-extrabold transition-all cursor-pointer ${
                          rating >= s ? 'bg-amber-400 text-zinc-900 border-amber-500 shadow-sm' : 'bg-zinc-50 text-zinc-400 border-zinc-200'
                        }`}
                      >
                        ★ {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">Your Feedback</label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Share your top up experience..."
                    rows={3}
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl p-3 text-zinc-900 text-sm outline-none focus:border-red-600"
                    required
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-zinc-100 text-zinc-700 font-bold text-xs hover:bg-zinc-200 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-extrabold text-xs uppercase tracking-wider shadow-md shadow-red-200 cursor-pointer flex items-center gap-1.5"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Review'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </section>
  );
};

