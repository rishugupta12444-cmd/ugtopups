import React from 'react';

interface UGLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const UGLogo: React.FC<UGLogoProps> = ({ className = '', size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16',
  };

  return (
    <img
      src="/assets/brand/ug-gaming-mark.png"
      alt="UG Gaming"
      title="UG Top Up Center"
      className={`relative rounded-xl shadow-lg shadow-red-900/30 object-cover select-none transition-transform hover:scale-105 ${sizeClasses[size]} ${className}`}
      draggable={false}
    />
  );
};
