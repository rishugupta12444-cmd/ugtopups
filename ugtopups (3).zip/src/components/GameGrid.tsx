import React, { useState } from 'react';
import { Game, GameCategory } from '../types';
import { Check, Gamepad2 } from 'lucide-react';

interface GameGridProps {
  games: Game[];
  selectedGameId: string;
  onSelectGame: (gameId: string) => void;
  categories?: GameCategory[];
}

export const GameGrid: React.FC<GameGridProps> = ({
  games,
  selectedGameId,
  onSelectGame,
  categories,
}) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('cat-games');
  const [imageErrors, setImageErrors] = useState<Record<string, boolean>>({});

  const STANDARD_CATEGORIES: { id: string; name: string; icon?: string }[] = [
    { id: 'cat-games', name: 'Games', icon: '🎮' },
    { id: 'cat-subscription', name: 'Subscription', icon: '📺' },
    { id: 'cat-voucher', name: 'Voucher', icon: '🎟️' },
    { id: 'cat-other', name: 'Other', icon: '📦' },
  ];

  const filteredGames = games.filter((game) => {
    const catObj = STANDARD_CATEGORIES.find((c) => c.id === selectedCategoryId);
    if (!catObj) return true;

    const gameCat = (game.category || '').toLowerCase();
    const targetCat = catObj.name.toLowerCase();

    if (targetCat === 'games') {
      if (gameCat === 'subscription' || gameCat === 'voucher' || gameCat === 'other') {
        return false;
      }
      return true;
    }

    return gameCat === targetCat;
  });

  const handleImageError = (gameId: string) => {
    setImageErrors((prev) => ({ ...prev, [gameId]: true }));
  };

  const getInitials = (name: string) => {
    return name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 4);
  };

  return (
    <section id="games-section" className="py-4 sm:py-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto bg-white">
      <style>{`
        .ug-game-card {
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-start;
          padding: 4px 2px;
          border-radius: 0;
          background: transparent;
          border: none;
          box-shadow: none;
          cursor: pointer;
          text-align: center;
          min-width: 0;
          transition: transform 0.2s cubic-bezier(0.22,1,0.36,1);
          will-change: transform;
          user-select: none;
          -webkit-tap-highlight-color: transparent;
        }
        .ug-game-card:hover {
          transform: translateY(-2px);
          box-shadow: none;
        }
        .ug-game-card:active {
          transform: translateY(0px) scale(0.96);
        }
        .ug-game-card.selected {
          background: transparent;
          border: none;
          box-shadow: none;
        }
        .ug-game-card.selected:hover {
          transform: translateY(-2px);
          box-shadow: none;
        }

        .ug-game-icon {
          width: 64px;
          height: 64px;
          border-radius: 16px;
          overflow: hidden;
          background: #f4f4f5;
          border: 2px solid transparent;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          transition: transform 0.22s cubic-bezier(0.22,1,0.36,1), border-color 0.2s ease, box-shadow 0.2s ease;
          position: relative;
          box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .ug-game-card.selected .ug-game-icon {
          border: 2.5px solid #E50914;
          box-shadow: 0 0 14px rgba(229,9,20,0.35);
        }
        .ug-game-card:hover .ug-game-icon {
          transform: scale(1.06);
          box-shadow: 0 6px 16px rgba(0,0,0,0.12);
        }
        .ug-game-icon img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          border-radius: 14px;
        }

        .ug-game-check {
          position: absolute;
          top: 0;
          left: 0;
          width: 18px;
          height: 18px;
          background: #E50914;
          border-bottom-right-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 10;
          animation: ugCheckPop 0.2s cubic-bezier(0.34,1.56,0.64,1) both;
        }
        @keyframes ugCheckPop {
          from { opacity: 0; transform: scale(0.4); }
          to   { opacity: 1; transform: scale(1); }
        }

        .ug-game-name {
          font-size: 11px;
          font-weight: 800;
          color: #18181b;
          margin-top: 7px;
          line-height: 1.2;
          width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          padding: 0 2px;
          transition: color 0.18s ease;
        }
        .ug-game-card.selected .ug-game-name,
        .ug-game-card:hover .ug-game-name {
          color: #E50914;
        }

        .ug-game-badge {
          position: absolute;
          bottom: 3px;
          right: 3px;
          padding: 1px 4px;
          background: #E50914;
          color: #fff;
          font-size: 7.5px;
          font-weight: 900;
          border-radius: 4px;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          line-height: 1.4;
        }

        /* Responsive grid */
        .ug-games-grid {
          display: grid;
          gap: 10px;
          grid-template-columns: repeat(3, 1fr);
        }
        @media (min-width: 400px) {
          .ug-games-grid { grid-template-columns: repeat(4, 1fr); gap: 10px; }
        }
        @media (min-width: 640px) {
          .ug-games-grid { grid-template-columns: repeat(4, 1fr); gap: 12px; }
          .ug-game-icon { width: 62px; height: 62px; }
        }
        @media (min-width: 768px) {
          .ug-games-grid { grid-template-columns: repeat(5, 1fr); gap: 12px; }
        }
        @media (min-width: 1024px) {
          .ug-games-grid { grid-template-columns: repeat(6, 1fr); gap: 14px; }
        }
        @media (max-width: 359px) {
          .ug-games-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
          .ug-game-icon { width: 54px; height: 54px; }
        }
      `}</style>

      {/* Section header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-6 bg-red-600 rounded-full" />
          <h2 className="text-xl sm:text-2xl font-black text-zinc-900 tracking-tight">
            Select Items
          </h2>
          <span className="text-xs font-bold text-zinc-500 bg-zinc-100 px-3 py-1 rounded-full border border-zinc-200 hidden sm:inline-block">
            Instant Top Up
          </span>
        </div>
      </div>

      {/* Category filter tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2.5 mb-3.5 scrollbar-none no-scrollbar border-b border-zinc-100">
        {STANDARD_CATEGORIES.map((cat) => {
          const isCatSelected = selectedCategoryId === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategoryId(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex-shrink-0 border flex items-center gap-2 ${
                isCatSelected
                  ? 'bg-red-600 text-white border-red-600 shadow-sm shadow-red-200'
                  : 'bg-zinc-100 text-zinc-700 border-zinc-200 hover:bg-zinc-200 hover:text-zinc-900'
              }`}
            >
              {cat.icon && <span className="text-sm">{cat.icon}</span>}
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Game cards grid */}
      {filteredGames.length > 0 ? (
        <div className="ug-games-grid">
          {filteredGames.map((game) => {
            const isSelected = game.id === selectedGameId;
            const hasError = imageErrors[game.id];

            return (
              <button
                key={game.id}
                onClick={() => onSelectGame(game.id)}
                title={game.name}
                className={`ug-game-card${isSelected ? ' selected' : ''}`}
              >
                {/* Icon */}
                <div className="ug-game-icon">
                  {/* Top-left corner check badge */}
                  {isSelected && (
                    <div className="ug-game-check">
                      <Check style={{ width: 10, height: 10, strokeWidth: 4, color: '#fff' }} />
                    </div>
                  )}

                  {!hasError && game.iconUrl ? (
                    <img
                      src={game.iconUrl}
                      alt={game.name}
                      onError={() => handleImageError(game.id)}
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div
                      style={{
                        width: '100%',
                        height: '100%',
                        background: 'linear-gradient(135deg, #E50914, #18181b)',
                        borderRadius: 13,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff',
                        gap: 2,
                      }}
                    >
                      <Gamepad2 style={{ width: 20, height: 20, color: '#fca5a5' }} />
                      <span style={{ fontSize: 9, fontWeight: 900, letterSpacing: '-0.02em' }}>
                        {getInitials(game.name)}
                      </span>
                    </div>
                  )}

                  {/* Per-game badge (FF, ML, etc.) */}
                  {game.id === 'freefire' && (
                    <span className="ug-game-badge">FF</span>
                  )}
                </div>

                {/* Name */}
                <span className="ug-game-name">{game.name}</span>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-10 px-4 bg-zinc-50 rounded-2xl border border-zinc-200 text-zinc-500 text-xs font-semibold flex flex-col items-center justify-center gap-2">
          <Gamepad2 className="w-8 h-8 text-zinc-400" />
          <p className="font-bold text-zinc-800 text-sm">No games or packages currently available</p>
          <p className="text-zinc-500 text-xs max-w-md">
            {games.length === 0
              ? 'No active games or package listings were found. You can manually add games and packages from the Admin Panel.'
              : `No games or packages listed under "${STANDARD_CATEGORIES.find((c) => c.id === selectedCategoryId)?.name || 'selected'}" category.`}
          </p>
        </div>
      )}
    </section>
  );
};
