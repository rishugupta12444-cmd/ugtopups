import React, { useState } from 'react';
import {
  ShieldCheck,
  Headphones,
  Mail,
  Shield,
  Award,
  Landmark,
  X,
  FileText,
  HelpCircle,
  Lock,
} from 'lucide-react';
import { UGLogo } from './UGLogo';
import { SOCIAL_LINKS } from '../config/socialLinks';

// Custom Brand Icons with high-contrast vector glyphs
const WhatsAppIcon = ({ className = "w-4 h-4 text-emerald-600" }: { className?: string }) => (
  <svg className={`${className} fill-current`} viewBox="0 0 24 24">
    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-1.143 4.174 4.286-1.123z"/>
  </svg>
);

const FacebookIcon = ({ className = "w-4 h-4 text-white" }: { className?: string }) => (
  <svg className={`${className} fill-current`} viewBox="0 0 24 24">
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
  </svg>
);

const TikTokIcon = ({ className = "w-4 h-4 text-white" }: { className?: string }) => (
  <svg className={`${className} fill-current`} viewBox="0 0 24 24">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.85.12V9.4a6.27 6.27 0 0 0-1-.08A6.26 6.26 0 0 0 3 15.57a6.26 6.26 0 0 0 6.26 6.26c3.45 0 6.26-2.8 6.26-6.25V9.13a8.16 8.16 0 0 0 4.07 1.56v-4a4.83 4.83 0 0 1-3-.12z"/>
  </svg>
);

const InstagramIcon = ({ className = "w-4 h-4 text-white" }: { className?: string }) => (
  <svg className={`${className} stroke-current fill-none stroke-[2]`} viewBox="0 0 24 24">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
  </svg>
);

const YouTubeIcon = ({ className = "w-4 h-4 text-white" }: { className?: string }) => (
  <svg className={`${className}`} viewBox="0 0 24 24">
    <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z" fill="none" stroke="currentColor" strokeWidth="2"/>
    <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" fill="currentColor"/>
  </svg>
);

const DiscordIcon = ({ className = "w-4 h-4 text-white" }: { className?: string }) => (
  <svg className={`${className} fill-current`} viewBox="0 0 24 24">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
  </svg>
);

// ── REAL PAYMENT LOGOS (official brand images) ─────────────────────────────
const PAYMENT_LOGOS = {
  esewa: '/assets/payments/esewa.png',
  khalti: '/assets/payments/khalti.png',
  mypay: '/assets/payments/mypay.png',
  mobileBanking: '/assets/payments/mobile-banking.png',
};

interface FooterProps {
  onNavigate?: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const socialLinks = SOCIAL_LINKS;
  const [modalType, setModalType] = useState<'terms' | 'privacy' | null>(null);

  const handleOpenFaq = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (onNavigate) {
      onNavigate('/faq');
    } else {
      window.history.pushState({}, '', '/faq');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  const handleOpenTerms = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (onNavigate) {
      onNavigate('/terms');
    } else {
      window.history.pushState({}, '', '/terms');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  const handleOpenPrivacy = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (onNavigate) {
      onNavigate('/privacy');
    } else {
      window.history.pushState({}, '', '/privacy');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  return (
    <footer className="bg-white border-t border-zinc-200 text-zinc-700 pt-12 pb-28 sm:pb-16 px-4 sm:px-6 lg:px-8 font-sans relative">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* ── 1. BRAND / ABOUT SECTION & SOCIAL MEDIA SECTION ── */}
        <div className="space-y-5">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <UGLogo size="md" />
              <div className="flex items-center gap-2">
                <span className="font-black text-xl sm:text-2xl text-zinc-900 tracking-tight">
                  UG TOP UP
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-red-100 text-red-600 border border-red-200">
                  OFFICIAL
                </span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-zinc-600 font-medium max-w-lg leading-relaxed">
              Nepal's #1 Digital Gaming Marketplace. Direct In-Game Top-Up & Gift Cards. Fast, secure, and reliable service always.
            </p>
          </div>

          {/* Social Media Rounded Buttons (Facebook, YouTube, TikTok) */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <a
              href={socialLinks.facebook}
              target="_blank"
              rel="noopener noreferrer"
              className="w-11 h-11 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-700 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 flex items-center justify-center hover:-translate-y-0.5 shadow-2xs group cursor-pointer"
              title="Facebook"
            >
              <FacebookIcon className="w-5 h-5 text-zinc-600 group-hover:text-blue-600 transition-colors" />
            </a>
            <a
              href={socialLinks.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="w-11 h-11 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-700 hover:text-red-600 hover:border-red-300 hover:bg-red-50 transition-all duration-200 flex items-center justify-center hover:-translate-y-0.5 shadow-2xs group cursor-pointer"
              title="YouTube"
            >
              <YouTubeIcon className="w-5 h-5 text-zinc-600 group-hover:text-red-600 transition-colors" />
            </a>
            <a
              href={socialLinks.tiktok}
              target="_blank"
              rel="noopener noreferrer"
              className="w-11 h-11 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-700 hover:text-zinc-900 hover:border-zinc-400 hover:bg-zinc-100 transition-all duration-200 flex items-center justify-center hover:-translate-y-0.5 shadow-2xs group cursor-pointer"
              title="TikTok"
            >
              <TikTokIcon className="w-5 h-5 text-zinc-600 group-hover:text-zinc-900 transition-colors" />
            </a>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-zinc-200/80 w-full" />

        {/* ── 2. CONTACT / SUPPORT SECTION ("Get in Touch") ── */}
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-red-50/40 border border-red-100 max-w-md shadow-2xs">
          <div className="w-11 h-11 rounded-xl bg-red-600 text-white flex items-center justify-center flex-shrink-0 shadow-2xs">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-extrabold text-sm text-red-600 tracking-tight">Get in Touch</h4>
            <a href={socialLinks.email} className="font-bold text-xs text-zinc-900 hover:text-red-600 transition-colors block mt-0.5">
              support@ugtopups.com
            </a>
            <p className="text-[11px] text-zinc-500 font-medium">We're here to help you 24/7</p>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-zinc-200/80 w-full" />

        {/* ── 3. PAYMENT METHODS SECTION ("PAY SECURELY WITH") ── */}
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <span className="w-1.5 h-5 bg-red-600 rounded-full inline-block" />
            <h4 className="font-extrabold text-sm sm:text-base text-zinc-900 tracking-wide uppercase">
              PAY SECURELY WITH
            </h4>
          </div>

          {/* Seamless, unboxed logo strip with large prominent brand logos */}
          <div className="grid grid-cols-2 sm:grid-cols-4 items-center gap-4 py-4 px-4 sm:px-8 bg-zinc-100/60 rounded-2xl border border-zinc-200/60">

            {/* eSewa */}
            <div className="flex items-center justify-center p-3 transition-transform duration-200 hover:scale-105 cursor-pointer">
              <img
                src={PAYMENT_LOGOS.esewa}
                alt="eSewa"
                className="h-10 sm:h-16 max-h-[70px] w-auto max-w-full object-contain drop-shadow-2xs"
              />
            </div>

            {/* Khalti */}
            <div className="flex items-center justify-center p-3 transition-transform duration-200 hover:scale-105 cursor-pointer">
              <img
                src={PAYMENT_LOGOS.khalti}
                alt="Khalti by IME"
                className="h-10 sm:h-16 max-h-[70px] w-auto max-w-full object-contain drop-shadow-2xs"
              />
            </div>

            {/* MyPay */}
            <div className="flex items-center justify-center p-3 transition-transform duration-200 hover:scale-105 cursor-pointer">
              <img
                src={PAYMENT_LOGOS.mypay}
                alt="MyPay"
                className="h-10 sm:h-16 max-h-[70px] w-auto max-w-full object-contain drop-shadow-2xs"
              />
            </div>

            {/* Mobile Banking */}
            <div className="flex items-center justify-center p-3 transition-transform duration-200 hover:scale-105 cursor-pointer">
              <img
                src={PAYMENT_LOGOS.mobileBanking}
                alt="Mobile Banking"
                className="h-10 sm:h-16 max-h-[70px] w-auto max-w-full object-contain drop-shadow-2xs"
              />
            </div>

          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-zinc-200/80 w-full" />

        {/* ── 4. TRUST / SECURITY FEATURES ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
          {/* Feature 1 */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-zinc-50/80 border border-zinc-200/70">
            <div className="w-10 h-10 rounded-xl bg-red-100/80 border border-red-200 text-red-600 flex items-center justify-center flex-shrink-0 mt-0.5">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h5 className="font-bold text-sm text-zinc-900">100% Secure Payments</h5>
              <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">
                Your payments are protected with advanced security.
              </p>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-zinc-50/80 border border-zinc-200/70">
            <div className="w-10 h-10 rounded-xl bg-red-100/80 border border-red-200 text-red-600 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h5 className="font-bold text-sm text-zinc-900">Trusted by Thousands</h5>
              <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">
                Serving gamers across Nepal with instant top-ups.
              </p>
            </div>
          </div>

          {/* Feature 3 */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-zinc-50/80 border border-zinc-200/70">
            <div className="w-10 h-10 rounded-xl bg-red-100/80 border border-red-200 text-red-600 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h5 className="font-bold text-sm text-zinc-900">24/7 Customer Support</h5>
              <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">
                Our support team is always available to help you.
              </p>
            </div>
          </div>

          {/* Feature 4 */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-zinc-50/80 border border-zinc-200/70">
            <div className="w-10 h-10 rounded-xl bg-red-100/80 border border-red-200 text-red-600 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h5 className="font-bold text-sm text-zinc-900">Safe & Reliable</h5>
              <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">
                Official partner for direct in-game auto delivery.
              </p>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-zinc-200/80 w-full" />

        {/* ── 5. BOTTOM FOOTER (Copyright & Legal Links) ── */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-semibold text-zinc-500 pt-1">
          <div>
            COPYRIGHT © {new Date().getFullYear()} UG TOP UP. ALL RIGHTS RESERVED.
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleOpenTerms}
              className="hover:text-red-600 transition-colors cursor-pointer"
            >
              Terms
            </button>
            <span className="text-zinc-300">•</span>
            <button
              onClick={handleOpenPrivacy}
              className="hover:text-red-600 transition-colors cursor-pointer"
            >
              Privacy
            </button>
            <span className="text-zinc-300">•</span>
            <button
              onClick={handleOpenFaq}
              className="hover:text-red-600 transition-colors cursor-pointer"
            >
              FAQ
            </button>
          </div>
        </div>

      </div>

      {/* Legal Info Modals */}
      {modalType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white border border-zinc-200 rounded-3xl p-6 max-w-md w-full shadow-2xl text-zinc-700 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2">
                {modalType === 'terms' && <FileText className="w-5 h-5 text-red-600" />}
                {modalType === 'privacy' && <Lock className="w-5 h-5 text-red-600" />}
                <h3 className="text-base font-bold text-zinc-900 capitalize">
                  {modalType === 'terms' && 'Terms & Conditions'}
                  {modalType === 'privacy' && 'Privacy Policy'}
                </h3>
              </div>
              <button
                onClick={() => setModalType(null)}
                className="w-8 h-8 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-500 hover:text-zinc-900 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-zinc-600 space-y-3 max-h-72 overflow-y-auto pr-1 leading-relaxed">
              {modalType === 'terms' && (
                <>
                  <p>Welcome to <strong>UG TOP UP</strong>. By placing orders or using our gaming marketplace, you agree to comply with our service terms.</p>
                  <p><strong>1. Account Security:</strong> Users are responsible for providing correct Game ID / User ID when requesting top-ups.</p>
                  <p><strong>2. Delivery Time:</strong> In-game items and wallet credits are fulfilled instantly via automated processing upon payment confirmation.</p>
                  <p><strong>3. Refunds:</strong> Purchases are final once digital items have been successfully delivered to the provided User ID.</p>
                </>
              )}

              {modalType === 'privacy' && (
                <>
                  <p>At <strong>UG TOP UP</strong>, we prioritize the confidentiality and security of your personal information.</p>
                  <p><strong>1. Data Collection:</strong> We only collect necessary information such as email address, display username, and Player UID to process your game top-ups.</p>
                  <p><strong>2. Security:</strong> All financial payment proof submissions are transmitted securely and verified with strictly protected systems.</p>
                  <p><strong>3. No Third-Party Sharing:</strong> We do not sell or lease your personal credentials to third-party advertisers.</p>
                </>
              )}
            </div>

            <button
              onClick={() => setModalType(null)}
              className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Understand & Close
            </button>
          </div>
        </div>
      )}
    </footer>
  );
};
