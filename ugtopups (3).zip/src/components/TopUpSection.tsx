import React, { useState, useEffect } from 'react';
import { Game, GamePackage, PaymentMethodChoice } from '../types';
import { supabase } from '../lib/supabase';
import { getRedeemStock } from '../lib/store';
import { isMlbbBrazilGame, getMlbbProductId, isFreeFireGame } from '../lib/mlbbVariations';
import { Check, User, ShieldCheck, Zap, Plus, Minus, Wallet, AlertCircle, Loader2, Sparkles, Trophy, ShoppingCart, CreditCard, Building2, Smartphone, Gamepad2, Mail, Globe, Key, MessageSquare, Sliders, RefreshCw, X } from 'lucide-react';

interface TopUpSectionProps {
  game: Game | null;
  walletBalance: number;
  isLoggedIn?: boolean;
  userAvatarUrl?: string;
  user?: any;
  onInitiatePayment: (params: {
    game: Game;
    playerUid: string;
    playerName: string;
    zoneId?: string;
    userEmail?: string;
    userPassword?: string;
    userWhatsapp?: string;
    userField1Val?: string;
    userField2Val?: string;
    customFieldValues?: { id: string; label: string; value: string }[];
    selectedPackage: GamePackage;
    quantity: number;
    totalPriceNpr: number;
    paymentMethodChoice: PaymentMethodChoice;
    uidVerified?: boolean;
    uidVerifiedAt?: string;
  }) => void;
  onOpenWalletAdd: () => void;
}

export const TopUpSection: React.FC<TopUpSectionProps> = ({
  game,
  walletBalance,
  isLoggedIn = false,
  userAvatarUrl,
  user,
  onInitiatePayment,
  onOpenWalletAdd,
}) => {
  const [playerUid, setPlayerUid] = useState<string>('');
  const [zoneId, setZoneId] = useState<string>('');
  const [userEmail, setUserEmail] = useState<string>('');
  const [userPassword, setUserPassword] = useState<string>('');
  const [userWhatsapp, setUserWhatsapp] = useState<string>('');
  const [customField1Val, setCustomField1Val] = useState<string>('');
  const [customField2Val, setCustomField2Val] = useState<string>('');
  const [dynamicFieldValues, setDynamicFieldValues] = useState<Record<string, string>>({});

  const buildCustomFieldValues = () => {
    if (!Array.isArray(game?.customFields)) return undefined;
    const vals = game!.customFields!
      .map((f) => ({ id: f.id, label: f.label, value: (dynamicFieldValues[f.id] || '').trim() }))
      .filter((f) => f.value);
    return vals.length > 0 ? vals : undefined;
  };

  // Default selected package
  const [selectedPackage, setSelectedPackage] = useState<GamePackage | null>(game?.packages?.[0] || null);
  const [quantity, setQuantity] = useState<number>(1);
  const [paymentMethodChoice, setPaymentMethodChoice] = useState<PaymentMethodChoice>('wallet');
  const [packageStockMap, setPackageStockMap] = useState<Record<string, number>>({});

  // Fetch live voucher stock for redeem packages
  useEffect(() => {
    if (!game || !game.packages || game.packages.length === 0) return;
    let active = true;
    const fetchStock = async () => {
      const map: Record<string, number> = {};
      for (const pkg of game.packages) {
        if (pkg.requiresRedeemCode) {
          try {
            const count = await getRedeemStock(game.id, pkg.id);
            map[pkg.id] = count;
          } catch {
            map[pkg.id] = 0;
          }
        }
      }
      if (active) setPackageStockMap(map);
    };
    fetchStock();
    return () => { active = false; };
  }, [game?.id, game?.packages]);

  // UID Verification State
  const [isVerifyingUid, setIsVerifyingUid] = useState<boolean>(false);
  const [verifiedPlayerName, setVerifiedPlayerName] = useState<string | null>(null);
  const [verifiedRegion, setVerifiedRegion] = useState<string | null>(null);
  const [uidError, setUidError] = useState<string | null>(null);

  // MLBB Verification Modal State
  const [isMlbbModalOpen, setIsMlbbModalOpen] = useState<boolean>(false);
  const [mlbbStep, setMlbbStep] = useState<'verifying' | 'confirm' | 'error'>('verifying');
  const [mlbbVerifiedIGN, setMlbbVerifiedIGN] = useState<string>('');
  const [mlbbErrorMsg, setMlbbErrorMsg] = useState<string>('');
  const [isMlbbLoading, setIsMlbbLoading] = useState<boolean>(false);

  // Free Fire and PUBG orders must have a successful server-side UID verification before checkout.
  const isPubgGame = /pubg|bgmi/i.test(game?.name || '');
  const requiresUidVerification = /free\s*fire/i.test(game?.name || '') || isPubgGame;
  const isMlbbGame = /mobile\s*legends|mlbb/i.test(game?.name || '');
  const isZoneIdRequired = Boolean(
    game?.requiresZoneId || 
    game?.requireZoneId || 
    (game as any)?.require_zone_id || 
    (game as any)?.requires_zone_id ||
    (isMlbbGame && (game as any)?.productType !== 'voucher' && (game?.category !== 'Voucher'))
  );

  // Check if current product/package is a digital redeem code / voucher
  const isExplicitVoucher = (game as any)?.productType === 'voucher' || (game as any)?.product_type === 'voucher';
  const isExplicitTopup = (game as any)?.productType === 'topup' || (game as any)?.product_type === 'topup';

  const isRedeemOrVoucherProduct = isExplicitVoucher || (!isExplicitTopup && Boolean(
    selectedPackage?.requiresRedeemCode ||
    (selectedPackage as any)?.isRedeemCode ||
    (game as any)?.requiresRedeemCode ||
    (game as any)?.isVoucher ||
    (game as any)?.isRedeemCode ||
    (game?.category === 'Voucher') ||
    (game?.packages && game.packages.length > 0 && game.packages.every((p: any) => p.requiresRedeemCode))
  ));

  // UID is required ONLY when explicitly enabled by Admin / Supabase (requireUid: true) OR if Zone ID / FF verification is required
  const isUidRequired = !isRedeemOrVoucherProduct && Boolean(
    game?.requireUid === true ||
    (game as any)?.require_uid === true ||
    isZoneIdRequired ||
    (requiresUidVerification && !isRedeemOrVoucherProduct)
  );

  // Check if any customer account input fields should be shown in Step 1
  const hasVisibleAccountFields = !isRedeemOrVoucherProduct && Boolean(
    isUidRequired ||
    isZoneIdRequired ||
    game?.requireEmail ||
    game?.requirePassword ||
    game?.requireWhatsapp ||
    game?.userField1 ||
    game?.userField2 ||
    (Array.isArray(game?.customFields) && game!.customFields!.length > 0)
  );

  const uidVerified = isRedeemOrVoucherProduct || !requiresUidVerification || !isUidRequired || (!!verifiedPlayerName && playerUid.trim().length > 0);

  // Sync selected package AND clear all verification state when game changes
  useEffect(() => {
    if (game?.packages && game.packages.length > 0) {
      if (!selectedPackage || !game.packages.some((p) => p.id === selectedPackage?.id)) {
        setSelectedPackage(game.packages[0]);
      }
    } else {
      setSelectedPackage(null);
    }
    // Clear all user input & verification state on game switch
    setPlayerUid('');
    setZoneId('');
    setVerifiedPlayerName(null);
    setVerifiedRegion(null);
    setUidError(null);
    setMlbbVerifiedIGN('');
    setMlbbErrorMsg('');
    setIsMlbbModalOpen(false);
    setIsMlbbLoading(false);
  }, [game?.id]); // only fire when game ID actually changes

  const handleVerifyUid = async (overrideUid?: unknown) => {
    if (!game) return;
    const rawUid = typeof overrideUid === 'string' ? overrideUid : playerUid;
    const targetUid = String(rawUid || '').trim();
    if (!targetUid) {
      setUidError('Please enter a valid Game UID');
      setVerifiedPlayerName(null);
      setVerifiedRegion(null);
      return;
    }
    setUidError(null);
    setIsVerifyingUid(true);

    try {
      let result: { success: boolean; playerName?: string; region?: string; error?: string } | null = null;
      let lastError = '';

      try {
        // IMPORTANT: verification endpoint selection must use a canonical game key,
        // not the database game.id. Admin-created games can have arbitrary IDs/UUIDs,
        // so a PUBG page could otherwise be sent to the Free Fire verifier.
        const verificationGameId = isPubgGame
          ? 'pubg'
          : (/free\s*fire/i.test(game.name || '') ? 'free-fire' : game.id);

        const response = await fetch(`/api/game/check-uid?uid=${encodeURIComponent(targetUid)}&gameId=${encodeURIComponent(verificationGameId)}&gameName=${encodeURIComponent(game.name || '')}`, {
          method: 'GET',
          headers: { Accept: 'application/json' },
        });
        const body = await response.json().catch(() => null);
        if (body && typeof body === 'object') {
          result = body as typeof result;
          if (result?.success && result.playerName) {
            setVerifiedPlayerName(result.playerName);
            setVerifiedRegion(result.region || null);
            setUidError(null);
            return;
          }
          lastError = result?.error || '';
        }
      } catch (serverErr: any) {
        lastError = serverErr?.message || '';
      }

      const { data: edgeData, error: fnError } = await supabase.functions.invoke('check-uid', {
        method: 'POST',
        // Use the same canonical verification key as the serverless route.
        // The real database game.id is preserved for orders; it is NOT used to
        // choose between Ez2Topup's freefire.php and pubg.php endpoints.
        body: {
          uid: targetUid,
          gameName: game.name || '',
          gameId: isPubgGame
            ? 'pubg'
            : (/free\s*fire/i.test(game.name || '') ? 'free-fire' : game.id),
          zoneId,
        },
      });

      if (edgeData) {
        result = edgeData as typeof result;
      }
      if (fnError) {
        lastError = fnError.message || lastError;
      }

      if (result && result.success && result.playerName) {
        setVerifiedPlayerName(result.playerName);
        setVerifiedRegion(result.region || null);
        setUidError(null);
      } else {
        setVerifiedPlayerName(null);
        setVerifiedRegion(null);
        setUidError((result && result.error) || lastError || 'Player ID not found or verification failed');
      }
    } catch (err: any) {
      setVerifiedPlayerName(null);
      setVerifiedRegion(null);
      setUidError(err?.message || 'Verification service is temporarily unavailable. Please try again.');
    } finally {
      setIsVerifyingUid(false);
    }
  };

  // Auto-verify Player ID when user types 7+ characters for Free Fire/PUBG
  useEffect(() => {
    if (!requiresUidVerification) return;
    const clean = playerUid.trim();
    if (clean.length >= 7) {
      const timer = setTimeout(() => {
        handleVerifyUid(clean);
      }, 700);
      return () => clearTimeout(timer);
    } else {
      setVerifiedPlayerName(null);
      setVerifiedRegion(null);
      setUidError(null);
    }
  }, [playerUid, game?.id, requiresUidVerification]);

  // ── MLBB Brazil Verification Call Handler ──
  // ── MLBB Verification — Supabase Edge Function ONLY (no /api fallback) ──
  const triggerMlbbVerification = async () => {
    if (!game || !selectedPackage) return;
    if (isMlbbLoading) return;

    setIsMlbbLoading(true);
    setMlbbErrorMsg('');
    setMlbbStep('verifying');

    const productId = getMlbbProductId(selectedPackage);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('check-uid', {
        body: {
          product_id: productId,
          uid: playerUid.trim(),
          zone_id: zoneId.trim(),
          gameId: 'mlbb',
        },
      });

      if (fnError) throw new Error(fnError.message || 'Verification service error.');

      // Liana returns: playerName / display / provider.display
      const ign =
        data?.playerName ||
        data?.display ||
        data?.provider?.display ||
        data?.ign;

      if ((data?.success || data?.verified) && ign) {
        setMlbbVerifiedIGN(ign);
        setVerifiedPlayerName(ign);
        setMlbbStep('confirm');
      } else {
        throw new Error(
          data?.error ||
          data?.message ||
          "We couldn't verify this Mobile Legends account. Please check your Game ID and Zone ID."
        );
      }
    } catch (err: any) {
      setMlbbErrorMsg(
        err?.message || 'Unable to verify. Please check your connection and try again.'
      );
      setMlbbStep('error');
    } finally {
      setIsMlbbLoading(false);
    }
  };

  const handleMlbbConfirmAndContinue = () => {
    setIsMlbbModalOpen(false);

    const basePrice = (selectedPackage?.priceNpr || 0) * quantity;
    const totalPriceNpr = basePrice;

    const effectivePaymentMethod: PaymentMethodChoice = paymentMethodChoice;

    onInitiatePayment({
      game: game!,
      playerUid: playerUid.trim(),
      playerName: mlbbVerifiedIGN || verifiedPlayerName || playerUid.trim(),
      zoneId: zoneId.trim(),
      userEmail: game?.requireEmail ? userEmail.trim() : undefined,
      userPassword: game?.requirePassword ? userPassword.trim() : undefined,
      userWhatsapp: game?.requireWhatsapp ? userWhatsapp.trim() : undefined,
      userField1Val: game?.userField1 ? customField1Val.trim() : undefined,
      userField2Val: game?.userField2 ? customField2Val.trim() : undefined,
      customFieldValues: buildCustomFieldValues(),
      selectedPackage: selectedPackage!,
      quantity,
      totalPriceNpr,
      paymentMethodChoice: effectivePaymentMethod,
      uidVerified: true,
      uidVerifiedAt: new Date().toISOString(),
    });
  };

  const handleMlbbCancel = () => {
    setIsMlbbModalOpen(false);
    setIsMlbbLoading(false);
  };

  const handlePackageSelect = (pkg: GamePackage) => {
    setSelectedPackage(pkg);
    setTimeout(() => {
      const payEl = document.getElementById('payment-method-section');
      if (payEl) {
        payEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  const totalPriceNpr = (selectedPackage?.priceNpr || 0) * quantity;
  const isWalletInsufficient = walletBalance < totalPriceNpr;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) {
      alert('Please select a package first!');
      return;
    }

    const effectivePaymentMethod: PaymentMethodChoice = paymentMethodChoice;

    // ── VOUCHER / REDEEM CODE PRODUCTS: IMMEDIATE CHECKOUT WITHOUT ANY UID CHECKS ──
    if (isRedeemOrVoucherProduct) {
      const voucherUid = playerUid.trim() || userEmail.trim() || user?.email || 'VOUCHER_CUSTOMER';
      onInitiatePayment({
        game,
        playerUid: voucherUid,
        playerName: 'Voucher Customer',
        zoneId: undefined,
        userEmail: userEmail.trim() || user?.email || undefined,
        userPassword: undefined,
        userWhatsapp: userWhatsapp.trim() || undefined,
        userField1Val: undefined,
        userField2Val: undefined,
        selectedPackage,
        quantity,
        totalPriceNpr,
        paymentMethodChoice: effectivePaymentMethod,
        uidVerified: true,
        uidVerifiedAt: new Date().toISOString(),
      });
      return;
    }

    // Special verification flow for Mobile Legends Brazil
    if (isMlbbBrazilGame(game)) {
      if (!playerUid.trim()) {
        setUidError('Please enter your Game ID first!');
        return;
      }
      if (!zoneId.trim()) {
        setUidError('Please enter your Zone ID!');
        return;
      }
      setUidError(null);
      // Reset modal state cleanly before opening
      setMlbbStep('verifying');
      setMlbbVerifiedIGN('');
      setMlbbErrorMsg('');
      setIsMlbbLoading(false);
      setIsMlbbModalOpen(true);
      triggerMlbbVerification();
      return;
    }

    if (isUidRequired && !playerUid.trim()) {
      setUidError('Please enter your Game UID first!');
      return;
    }

    if (isZoneIdRequired && !zoneId.trim()) {
      setUidError('Please enter your Zone ID!');
      return;
    }

    if (game?.requireEmail && !userEmail.trim()) {
      setUidError('Please enter your Email Address!');
      return;
    }

    if (game?.requirePassword && !userPassword.trim()) {
      setUidError('Please enter your Account Password/PIN!');
      return;
    }

    if (game?.requireWhatsapp && !userWhatsapp.trim()) {
      setUidError('Please enter your WhatsApp link or phone number!');
      return;
    }

    if (game?.userField1 && !customField1Val.trim()) {
      setUidError(`Please enter ${game.userField1}!`);
      return;
    }

    if (game?.userField2 && !customField2Val.trim()) {
      setUidError(`Please enter ${game.userField2}!`);
      return;
    }

    if (Array.isArray(game?.customFields)) {
      for (const f of game!.customFields!) {
        if (!(dynamicFieldValues[f.id] || '').trim()) {
          setUidError(`Please enter ${f.label}!`);
          return;
        }
      }
    }

    if (requiresUidVerification && !uidVerified) {
      setUidError(`Please verify your ${isPubgGame ? 'PUBG' : 'Free Fire'} UID before placing the order.`);
      return;
    }

    const effectiveUid = playerUid.trim() || userEmail.trim() || userWhatsapp.trim() || 'USER_' + Math.floor(1000 + Math.random() * 9000);
    const playerName = verifiedPlayerName || effectiveUid;

    onInitiatePayment({
      game,
      playerUid: effectiveUid,
      playerName,
      zoneId: isZoneIdRequired ? zoneId.trim() : undefined,
      userEmail: game?.requireEmail ? userEmail.trim() : undefined,
      userPassword: game?.requirePassword ? userPassword.trim() : undefined,
      userWhatsapp: game?.requireWhatsapp ? userWhatsapp.trim() : undefined,
      userField1Val: game?.userField1 ? customField1Val.trim() : undefined,
      userField2Val: game?.userField2 ? customField2Val.trim() : undefined,
      customFieldValues: buildCustomFieldValues(),
      selectedPackage,
      quantity,
      totalPriceNpr,
      paymentMethodChoice: effectivePaymentMethod,
      uidVerified,
      uidVerifiedAt: uidVerified ? new Date().toISOString() : undefined,
    });
  };

  if (!game) {
    return (
      <div id="topup-section" className="bg-white py-12 px-4 text-center border-t border-zinc-100">
        <div className="max-w-md mx-auto p-6 rounded-3xl bg-zinc-50 border border-zinc-200/80 shadow-sm">
          <Gamepad2 className="w-12 h-12 text-zinc-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-zinc-900 mb-1">No Game Selected</h3>
          <p className="text-xs text-zinc-500 mb-4">
            Please select a game from above to top up.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div id="topup-section" className="bg-white py-4 sm:py-6 px-4 sm:px-6 lg:px-8 border-t border-zinc-100">
      <div className="max-w-7xl mx-auto">
        
        {/* Active Game Header Banner Card - Hidden on Mobile */}
        <div className="hidden sm:block relative rounded-3xl overflow-hidden bg-gradient-to-r from-zinc-900 via-zinc-950 to-red-950 text-white p-4 sm:p-5 mb-5 shadow-lg border border-zinc-800">
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-5 relative z-10">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden shadow-xl border-2 border-red-500 flex-shrink-0 bg-zinc-800">
              <img
                src={game.iconUrl}
                alt={game.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="text-center sm:text-left flex-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
                <span className="px-3 py-0.5 rounded-full text-[10px] font-black bg-red-600 text-white uppercase tracking-wider">
                  100% SECURE PAYMENT
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 text-zinc-300 border border-zinc-700">
                  {game.category}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {game.name}
              </h2>
              <p className="text-xs text-zinc-300 mt-0.5 max-w-xl">
                {game.description}
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmitOrder}>
          
          {/* Two Column Layout on Desktop */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 items-start">
            
            {/* LEFT COLUMN: Steps 1, 2, 3 */}
            <div className="lg:col-span-2 space-y-4 sm:space-y-5">
              
              {/* STEP 1: USER ACCOUNT / GAME DETAILS (Only shown if at least one input field is required) */}
              {!isRedeemOrVoucherProduct && hasVisibleAccountFields && (
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 sm:p-5 shadow-xs">
                  <div className="flex items-center gap-3 mb-3.5">
                    <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-extrabold flex items-center justify-center text-xs shadow-xs">
                      1
                    </div>
                    <div>
                      <h3 className="text-base font-black text-zinc-900 tracking-tight">CUSTOMER & ACCOUNT DETAILS</h3>
                      <p className="text-[11px] text-zinc-500">Enter required account info for processing this item</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                      
                      {/* Game UID / User ID Input */}
                      {isUidRequired && (
                        <div className={`space-y-1 ${isZoneIdRequired ? 'sm:col-span-1' : 'sm:col-span-2'}`}>
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <User className="w-3.5 h-3.5 text-red-600" />
                            {isZoneIdRequired ? 'USER ID' : 'PLAYER ID'} <span className="text-red-600">*</span>
                          </label>
                          <div className="relative">
                            <input
                              type="text"
                              value={playerUid}
                              onChange={(e) => {
                                setPlayerUid(e.target.value);
                                setVerifiedPlayerName(null);
                                setUidError(null);
                              }}
                              placeholder={isZoneIdRequired ? 'Enter User ID' : (game.uidPlaceholder || "Enter Player ID")}
                              className="w-full bg-white border border-zinc-300 focus:border-red-600 focus:ring-2 focus:ring-red-100 rounded-xl px-3.5 py-2.5 text-zinc-900 font-mono text-xs sm:text-sm outline-none transition-all shadow-xs"
                              required
                            />
                            {verifiedPlayerName && (
                              <span className="absolute right-2.5 top-2.5 px-2 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-md text-[10px] font-extrabold flex items-center gap-1">
                                <ShieldCheck className="w-3 h-3 text-emerald-600" /> Verified
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Zone ID */}
                      {isZoneIdRequired && (
                        <div className="space-y-1 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Globe className="w-3.5 h-3.5 text-blue-600" />
                            ZONE ID <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="text"
                            value={zoneId}
                            onChange={(e) => setZoneId(e.target.value)}
                            placeholder="Enter Zone ID"
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-mono text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      )}

                      {/* Email Address Input */}
                      {game.requireEmail && (
                        <div className="space-y-1 col-span-2 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Mail className="w-3.5 h-3.5 text-emerald-600" />
                            EMAIL ADDRESS <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="email"
                            value={userEmail}
                            onChange={(e) => setUserEmail(e.target.value)}
                            placeholder="e.g. user@gmail.com"
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-sans text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      )}

                      {/* Password Input */}
                      {game.requirePassword && (
                        <div className="space-y-1 col-span-2 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Key className="w-3.5 h-3.5 text-amber-600" />
                            PASSWORD / PIN <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="password"
                            value={userPassword}
                            onChange={(e) => setUserPassword(e.target.value)}
                            placeholder="Account password or login pin"
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-sans text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      )}

                      {/* WhatsApp Link/No Input */}
                      {game.requireWhatsapp && (
                        <div className="space-y-1 col-span-2 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                            WHATSAPP NO / LINK <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="text"
                            value={userWhatsapp}
                            onChange={(e) => setUserWhatsapp(e.target.value)}
                            placeholder="e.g. +977 9800000000 or chat link"
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-sans text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      )}

                      {/* Custom User Field 1 */}
                      {game.userField1 && (
                        <div className="space-y-1 col-span-2 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-purple-600" />
                            {game.userField1.toUpperCase()} <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="text"
                            value={customField1Val}
                            onChange={(e) => setCustomField1Val(e.target.value)}
                            placeholder={`Enter ${game.userField1}`}
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-sans text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      )}

                      {/* Custom User Field 2 */}
                      {game.userField2 && (
                        <div className="space-y-1 col-span-2 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-purple-600" />
                            {game.userField2.toUpperCase()} <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="text"
                            value={customField2Val}
                            onChange={(e) => setCustomField2Val(e.target.value)}
                            placeholder={`Enter ${game.userField2}`}
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-sans text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      )}

                      {/* Dynamic Admin-Added Custom Fields */}
                      {Array.isArray(game.customFields) && game.customFields.map((field) => (
                        <div key={field.id} className="space-y-1 col-span-2 sm:col-span-1">
                          <label className="text-[11px] font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-purple-600" />
                            {field.label.toUpperCase()} <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="text"
                            value={dynamicFieldValues[field.id] || ''}
                            onChange={(e) => setDynamicFieldValues({ ...dynamicFieldValues, [field.id]: e.target.value })}
                            placeholder={`Enter ${field.label}`}
                            className="w-full bg-white border border-zinc-300 focus:border-red-600 rounded-xl px-3.5 py-2.5 text-zinc-900 font-sans text-xs sm:text-sm outline-none transition-all"
                            required
                          />
                        </div>
                      ))}

                    </div>

                    {/* Auto Verified Free Fire Player Name Display */}
                    {requiresUidVerification && (
                      <div className="pt-1">
                        {isVerifyingUid && (
                          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-zinc-100 border border-zinc-200 text-zinc-700 text-xs font-semibold animate-pulse">
                            <Loader2 className="w-3.5 h-3.5 animate-spin text-red-600 flex-shrink-0" />
                            <span>Fetching {isPubgGame ? 'PUBG' : 'Free Fire'} In-Game Name...</span>
                          </div>
                        )}

                        {!isVerifyingUid && verifiedPlayerName && (
                          <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold animate-fade-in">
                            <Trophy className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                            <span>
                              {isPubgGame ? 'PUBG' : 'Free Fire'} Player Name: <strong className="text-zinc-900 font-black">{verifiedPlayerName}</strong>
                              {verifiedRegion && (
                                <span className="text-[10px] text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded ml-1.5 font-semibold">
                                  {verifiedRegion}
                                </span>
                              )}
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* MLBB: show a small hint that verification happens on Buy Now */}
                    {isUidRequired && isMlbbBrazilGame(game) && (
                      <p className="text-[11px] text-zinc-400 font-medium flex items-center gap-1.5 pt-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
                        Your account will be verified securely when you click Buy Now.
                      </p>
                    )}

                    {uidError && (
                      <p className="text-xs text-red-600 font-bold flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> {uidError}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* PACKAGE SELECTION (Step 1 if no account fields, Step 2 if account fields present) */}
              <div id="package-selection-section" className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 sm:p-5 shadow-xs scroll-mt-20">
                <div className="flex items-center gap-3 mb-3.5">
                  <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-extrabold flex items-center justify-center text-xs shadow-xs">
                    {hasVisibleAccountFields ? 2 : 1}
                  </div>
                  <div>
                    <h3 className="text-base font-black text-zinc-900 tracking-tight">PACKAGE SELECTION</h3>
                    <p className="text-[11px] text-zinc-500">
                      {isRedeemOrVoucherProduct ? 'Select voucher package quantity' : 'Select package quantity'}
                    </p>
                  </div>
                </div>

                {/* Package Selection Cards: simple 2-column diamond-only layout */}
                <div className="grid grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3 mb-3">
                  {game.packages.map((pkg) => {
                    const isSelected = selectedPackage?.id === pkg.id;
                    const isVoucherProduct = isRedeemOrVoucherProduct || (game as any).productType === 'voucher' || (game.category && game.category.toLowerCase().includes('voucher')) || /voucher|redeem/i.test(game.name || '');
                    const isRedeem = pkg.requiresRedeemCode === true || isVoucherProduct;
                    const stockCount = isRedeem ? packageStockMap[pkg.id] : undefined;
                    const isOutOfStock = pkg.inStock === false || (isRedeem && stockCount !== undefined && stockCount === 0);
                    const packageDisplayLabel = (isVoucherProduct || pkg.requiresRedeemCode || !pkg.diamonds || (pkg.name && !/^\d+\s*diamonds?$/i.test(pkg.name) && !isMlbbBrazilGame(game) && !isFreeFireGame(game)))
                      ? pkg.name
                      : `${Number(pkg.diamonds || 0).toLocaleString('en-IN')} Diamonds`;

                    return (
                      <button
                        key={pkg.id}
                        type="button"
                        onClick={() => handlePackageSelect(pkg)}
                        aria-pressed={isSelected}
                        className={`relative h-[68px] sm:h-[78px] flex flex-col items-center justify-center rounded-2xl text-center transition-all duration-150 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 ${
                          isOutOfStock ? 'opacity-60 bg-zinc-100 border border-zinc-300' :
                          isSelected
                            ? 'bg-white border-2 border-red-600 shadow-sm'
                            : 'bg-white border border-zinc-200 shadow-sm hover:border-zinc-300 hover:shadow-md'
                        }`}
                      >
                        {isSelected && !isOutOfStock && (
                          <span className="absolute top-0 left-0 w-5 h-5 bg-red-600 text-white flex items-center justify-center rounded-tl-2xl rounded-br-lg" aria-hidden="true">
                            <Check className="w-3 h-3 stroke-[4]" />
                          </span>
                        )}
                        <span className={`text-[11px] sm:text-sm font-semibold tracking-tight ${isSelected && !isOutOfStock ? 'text-red-600' : 'text-zinc-900'}`}>
                          {packageDisplayLabel}
                        </span>
                        {isOutOfStock ? (
                          <span className="text-[9px] font-black text-red-600 uppercase tracking-wide bg-red-100 px-1.5 py-0.5 rounded mt-0.5">
                            Out of Stock
                          </span>
                        ) : isRedeem && stockCount !== undefined && stockCount <= 5 ? (
                          <span className="text-[9px] font-bold text-amber-600">
                            {stockCount} Left
                          </span>
                        ) : null}
                      </button>
                    );
                  })}
                </div>

                {/* Quantity Selector */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 bg-white p-2.5 rounded-xl border border-zinc-200">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-zinc-900">Quantity</span>
                    <span className="text-[11px] text-zinc-500">(Order multiple sets at once)</span>
                  </div>

                  <div className="flex items-center gap-2 bg-zinc-100 border border-zinc-200 rounded-full px-2.5 py-1 shadow-inner">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-6 h-6 rounded-full bg-white border border-zinc-200 hover:bg-zinc-200 text-zinc-900 flex items-center justify-center font-bold transition-colors cursor-pointer active:scale-90 text-xs"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center font-black text-xs sm:text-sm text-zinc-900 font-mono">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-6 h-6 rounded-full bg-white border border-zinc-200 hover:bg-zinc-200 text-zinc-900 flex items-center justify-center font-bold transition-colors cursor-pointer active:scale-90 text-xs"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>

              {/* PAYMENT METHOD (Step 2 if no account fields, Step 3 if account fields present) */}
              <div id="payment-method-section" className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 sm:p-5 shadow-xs scroll-mt-20">
                <div className="flex items-center gap-3 mb-3.5">
                  <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-extrabold flex items-center justify-center text-xs shadow-xs">
                    {hasVisibleAccountFields ? 3 : 2}
                  </div>
                  <div>
                    <h3 className="text-base font-black text-zinc-900 tracking-tight">PAYMENT METHOD</h3>
                    <p className="text-[11px] text-zinc-500">Pay from your wallet or scan a live Fonepay QR</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-0">
                  
                  {/* Method 1: Wallet */}
                  <div
                    onClick={() => setPaymentMethodChoice('wallet')}
                    className={`p-3.5 sm:p-4 rounded-xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                      paymentMethodChoice === 'wallet'
                        ? 'bg-red-50/60 border-2 border-red-600 shadow-sm shadow-red-100'
                        : 'bg-white border-zinc-200 hover:border-zinc-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                            paymentMethodChoice === 'wallet' ? 'bg-red-600 text-white' : 'bg-red-100 text-red-600'
                          }`}>
                            <Wallet className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="font-black text-zinc-900 text-xs sm:text-sm leading-tight">Wallet</h4>
                            {isLoggedIn ? (
                              <p className="text-[11px] font-bold text-emerald-700 mt-0.5">
                                NPR {walletBalance.toLocaleString('en-IN')}
                              </p>
                            ) : (
                              <p className="text-[11px] font-medium text-zinc-500 italic mt-0.5">
                                Must Login For This
                              </p>
                            )}
                          </div>
                        </div>
                        {paymentMethodChoice === 'wallet' && (
                          <div className="w-4 h-4 rounded-full bg-red-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>

                      {isLoggedIn && (
                        <div className="mt-2.5 pt-2 border-t border-zinc-200/80 flex items-center justify-between text-xs">
                          <span className="text-zinc-500 font-semibold text-[11px]">Wallet Balance</span>
                          <strong className="font-['Poppins',sans-serif] text-emerald-700 text-xs sm:text-sm font-black">
                            NPR {walletBalance.toLocaleString('en-IN')}
                          </strong>
                        </div>
                      )}
                    </div>

                    {isLoggedIn && !isWalletInsufficient && (
                      <div className="mt-2.5 p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] sm:text-[11px] font-bold flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                        <span>Sufficient Balance (Pay NPR {totalPriceNpr.toLocaleString('en-IN')} instantly)</span>
                      </div>
                    )}

                    {isLoggedIn && isWalletInsufficient && paymentMethodChoice === 'wallet' && (
                      <div className="mt-2.5 p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[10px] sm:text-[11px] leading-relaxed space-y-1">
                        <div className="font-extrabold flex items-center gap-1.5 text-amber-900">
                          <AlertCircle className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                          <span>Insufficient Wallet Balance</span>
                        </div>
                        <p className="text-amber-800">
                          Your balance is <strong>NPR {walletBalance.toLocaleString('en-IN')}</strong>, package costs <strong>NPR {totalPriceNpr.toLocaleString('en-IN')}</strong>. Please use <strong>Load Wallet</strong> to add balance before placing this order.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Method 2: Fonepay Hub */}
                  <div
                    onClick={() => setPaymentMethodChoice('fonepay_hub')}
                    className={`p-3.5 sm:p-4 rounded-xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                      paymentMethodChoice === 'fonepay_hub'
                        ? 'bg-red-50/60 border-2 border-red-600 shadow-sm shadow-red-100'
                        : 'bg-white border-zinc-200 hover:border-zinc-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          paymentMethodChoice === 'fonepay_hub' ? 'bg-red-600 text-white' : 'bg-red-100 text-red-600'
                        }`}>
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-black text-zinc-900 text-xs sm:text-sm leading-tight">Fonepay QR</h4>
                          <p className="text-[11px] font-medium text-zinc-500 mt-0.5">Mobile banking & Fonepay</p>
                        </div>
                      </div>
                      {paymentMethodChoice === 'fonepay_hub' && (
                        <div className="w-4 h-4 rounded-full bg-red-600 text-white flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </div>
                    <div className="mt-2.5 p-2 rounded-lg bg-zinc-50 border border-zinc-200 text-zinc-600 text-[10px] sm:text-[11px] font-semibold">
                      QR opens securely on this website. Remarks: your Order ID.
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* RIGHT COLUMN: Sticky Order Summary */}
            <div className="lg:col-span-1 lg:sticky lg:top-24 lg:self-start z-20">
              <div className="bg-white border border-zinc-200/90 rounded-2xl p-5 sm:p-6 shadow-sm transition-all space-y-4">
                {/* Header */}
                <h3 className="font-extrabold text-lg sm:text-xl text-zinc-900 tracking-tight border-b border-zinc-100 pb-3">
                  Order Summary
                </h3>

                {/* Field List */}
                <div className="divide-y divide-zinc-100 text-xs sm:text-sm">
                  
                  {/* Game Page */}
                  <div className="flex items-center justify-between py-2.5 gap-2">
                    <span className="text-zinc-500 font-medium">Game Page</span>
                    <strong className="text-zinc-900 font-extrabold text-right truncate max-w-[190px]">
                      {game.name}
                    </strong>
                  </div>

                  {/* Selected Item */}
                  <div className="flex items-center justify-between py-2.5 gap-2">
                    <span className="text-zinc-500 font-medium">Selected Item</span>
                    <strong className="text-zinc-900 font-extrabold text-right truncate max-w-[190px]">
                      {selectedPackage?.name || 'None'}{quantity > 1 ? ` (x${quantity})` : ''}
                    </strong>
                  </div>

                  {/* Product-specific input fields (Only for Non-Redeem Packages) */}
                  {!isRedeemOrVoucherProduct ? (
                    <>
                      {requiresUidVerification ? (
                        <>
                          {/* User ID (Free Fire only) */}
                          <div className="flex items-center justify-between py-2.5 gap-2">
                            <span className="text-zinc-500 font-medium">User ID</span>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-mono font-bold text-xs">
                              {playerUid || 'Not set'}
                            </span>
                          </div>

                          {/* Verified Name (Free Fire only) */}
                          <div className="flex items-center justify-between py-2.5 gap-2">
                            <span className="text-zinc-500 font-medium">Verified Name</span>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-xs truncate max-w-[180px]">
                              {verifiedPlayerName || 'Not verified'}
                            </span>
                          </div>
                        </>
                      ) : (
                        <>
                          {/* User ID (only if this product actually uses a player UID field) */}
                          {isUidRequired && (
                            <div className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">User ID</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-mono font-bold text-xs">
                                {playerUid || 'Not set'}
                              </span>
                            </div>
                          )}

                          {/* Zone ID */}
                          {isZoneIdRequired && (
                            <div className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">Zone ID</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-mono font-bold text-xs">
                                {zoneId || 'Not set'}
                              </span>
                            </div>
                          )}

                          {/* Email */}
                          {Boolean(game?.requireEmail) && (
                            <div className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">Email</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-bold text-xs truncate max-w-[180px]">
                                {userEmail || 'Not set'}
                              </span>
                            </div>
                          )}

                          {/* WhatsApp */}
                          {Boolean(game?.requireWhatsapp) && (
                            <div className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">WhatsApp</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-mono font-bold text-xs">
                                {userWhatsapp || 'Not set'}
                              </span>
                            </div>
                          )}

                          {/* Custom Field 1 */}
                          {Boolean(game?.userField1) && (
                            <div className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">{game?.userField1}</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-bold text-xs truncate max-w-[180px]">
                                {customField1Val || 'Not set'}
                              </span>
                            </div>
                          )}

                          {/* Custom Field 2 */}
                          {Boolean(game?.userField2) && (
                            <div className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">{game?.userField2}</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-bold text-xs truncate max-w-[180px]">
                                {customField2Val || 'Not set'}
                              </span>
                            </div>
                          )}

                          {/* Dynamic Admin-Added Custom Fields — hide password fields for security */}
                          {Array.isArray(game?.customFields) && game!.customFields!
                            .filter((field) => !/password|passwd|pwd/i.test(field.label))
                            .map((field) => (
                            <div key={field.id} className="flex items-center justify-between py-2.5 gap-2">
                              <span className="text-zinc-500 font-medium">{field.label}</span>
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-bold text-xs truncate max-w-[180px]">
                                {dynamicFieldValues[field.id] || 'Not set'}
                              </span>
                            </div>
                          ))}
                        </>
                      )}
                    </>
                  ) : (
                    <div className="flex items-center justify-between py-2.5 gap-2">
                      <span className="text-zinc-500 font-medium">Package Type</span>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 border border-amber-500/20 font-bold text-xs">
                        Digital Redeem Voucher
                      </span>
                    </div>
                  )}

                  {/* Payment Method */}
                  <div className="flex items-center justify-between py-2.5 gap-2">
                    <span className="text-zinc-500 font-medium">Payment Method</span>
                    <strong className="text-zinc-900 font-extrabold text-right text-xs sm:text-sm">
                      Instant Wallet
                    </strong>
                  </div>

                </div>

                {/* Section Divider */}
                <div className="border-t border-zinc-200 pt-1"></div>

                {/* TOTAL PRICE Section */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
                    TOTAL PRICE
                  </span>
                  <div className="text-2xl sm:text-3xl font-black text-zinc-900 font-['Poppins',sans-serif] tracking-normal">
                    NPR {totalPriceNpr.toLocaleString('en-IN')}
                  </div>
                </div>

                {/* BUY NOW PRIMARY ACTION BUTTON */}
                {(() => {
                  const isSelectedRedeem = selectedPackage?.requiresRedeemCode === true || isRedeemOrVoucherProduct;
                  const selectedStockCount = isSelectedRedeem && selectedPackage ? packageStockMap[selectedPackage.id] : undefined;
                  const selectedIsOutOfStock = selectedPackage?.inStock === false || (isSelectedRedeem && selectedStockCount !== undefined && selectedStockCount === 0);
                  const selectedStockInsufficient = isSelectedRedeem && selectedStockCount !== undefined && quantity > selectedStockCount;
                  const isButtonDisabled = (!isRedeemOrVoucherProduct && requiresUidVerification && !uidVerified) || selectedIsOutOfStock || selectedStockInsufficient;

                  let buttonText = 'Buy Now';
                  if (selectedIsOutOfStock) {
                    buttonText = 'Currently Out of Stock';
                  } else if (selectedStockInsufficient) {
                    buttonText = `Only ${selectedStockCount} Vouchers Available`;
                  } else if (!isRedeemOrVoucherProduct && requiresUidVerification && !uidVerified) {
                    buttonText = 'Verify UID to Continue';
                  } else if (paymentMethodChoice === 'fonepay_hub') {
                    buttonText = `Pay NPR ${totalPriceNpr.toLocaleString('en-IN')} with Fonepay`;
                  }

                  return (
                    <button
                      type="submit"
                      disabled={isButtonDisabled}
                      className={`w-full py-3.5 px-4 rounded-xl font-extrabold text-base tracking-wide shadow-xs transition-all flex items-center justify-center ${
                        isButtonDisabled
                          ? 'bg-zinc-200 text-zinc-400 cursor-not-allowed border border-zinc-300/50'
                          : 'bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white hover:shadow-md cursor-pointer'
                      }`}
                    >
                      {buttonText}
                    </button>
                  );
                })()}

                {/* 100% Direct Top Up / Instant Delivery Badge */}
                <div className="text-xs text-zinc-500 text-center flex items-center justify-center gap-1.5 pt-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span>{isRedeemOrVoucherProduct ? 'Instant Voucher Code Delivery' : '100% Direct Top Up'}</span>
                </div>

              </div>

            </div>

          </div>

        </form>
      </div>

      {/* ── MOBILE LEGENDS BRAZIL VERIFICATION & CONFIRMATION MODAL ── */}
      {isMlbbModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(0,0,0,0.82)', backdropFilter: 'blur(6px)' }}
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Legends Player Verification"
        >
          <div
            className="relative w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden"
            style={{
              background: 'linear-gradient(160deg, #1a1a1a 0%, #111111 60%, #1c0a0a 100%)',
              border: '1px solid rgba(255,255,255,0.08)',
            }}
          >
            {/* Red glow accent top bar */}
            <div className="h-0.5 w-full" style={{ background: 'linear-gradient(90deg, transparent, #dc2626, transparent)' }} />

            <div className="p-6 sm:p-7">

              {/* ── STATE 1: VERIFYING / PROCESSING ── */}
              {mlbbStep === 'verifying' && (
                <div className="text-center space-y-4 py-2">
                  {/* Clean spinner — matches reference image exactly */}
                  <div className="flex items-center justify-center mx-auto" style={{ width: 64, height: 64 }}>
                    <svg
                      className="animate-spin"
                      width="56"
                      height="56"
                      viewBox="0 0 56 56"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <circle
                        cx="28" cy="28" r="22"
                        stroke="rgba(220,38,38,0.18)"
                        strokeWidth="4"
                        fill="none"
                      />
                      <path
                        d="M28 6 A22 22 0 0 1 50 28"
                        stroke="#dc2626"
                        strokeWidth="4"
                        strokeLinecap="round"
                        fill="none"
                      />
                    </svg>
                  </div>

                  <div>
                    <h3 className="font-extrabold text-xl text-white tracking-tight">Verifying Account...</h3>
                    <p className="text-xs text-zinc-400 mt-1 font-medium">
                      Checking Game ID: {playerUid.trim()} (Zone: {zoneId.trim()})
                    </p>
                  </div>
                </div>
              )}

              {/* ── STATE 2: CONFIRM ACCOUNT ── */}
              {mlbbStep === 'confirm' && (
                <div className="space-y-5">
                  {/* Avatar with red ring + green tick */}
                  <div className="flex flex-col items-center">
                    <div className="relative">
                      {/* Red glow ring */}
                      <div
                        className="absolute inset-0 rounded-full"
                        style={{
                          background: 'conic-gradient(from 0deg, #dc2626, #ef4444, #dc2626)',
                          padding: 3,
                          borderRadius: '50%',
                          boxShadow: '0 0 20px rgba(220,38,38,0.5)',
                        }}
                      />
                      <div
                        className="relative"
                        style={{ padding: 3, borderRadius: '50%', background: 'conic-gradient(from 0deg, #dc2626, #ef4444, #dc2626)' }}
                      >
                        <div style={{ background: '#111', borderRadius: '50%', padding: 2 }}>
                          {userAvatarUrl ? (
                            <img
                              src={userAvatarUrl}
                              alt="Player Profile"
                              className="w-20 h-20 rounded-full object-cover block"
                              onError={(e) => {
                                const img = e.target as HTMLImageElement;
                                img.style.display = 'none';
                                const parent = img.parentElement;
                                if (parent) {
                                  parent.innerHTML = `<div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#1a1a1a,#2a2a2a);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:900;color:#dc2626;font-family:monospace">${(mlbbVerifiedIGN || playerUid || 'P')[0].toUpperCase()}</div>`;
                                }
                              }}
                            />
                          ) : (
                            <div
                              className="w-20 h-20 rounded-full flex items-center justify-center font-black text-3xl font-mono"
                              style={{ background: 'linear-gradient(135deg,#1a1a1a,#2a2a2a)', color: '#dc2626' }}
                            >
                              {(mlbbVerifiedIGN || playerUid || 'P')[0].toUpperCase()}
                            </div>
                          )}
                        </div>
                      </div>
                      {/* Green verification check */}
                      <div
                        className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-white"
                        style={{
                          background: '#22c55e',
                          border: '2.5px solid #111',
                          boxShadow: '0 2px 8px rgba(34,197,94,0.5)',
                        }}
                      >
                        <Check className="w-4 h-4 stroke-[3.5]" />
                      </div>
                    </div>
                  </div>

                  {/* Header */}
                  <div className="text-center">
                    <h3 className="font-extrabold text-2xl text-white tracking-tight">
                      Confirm <span className="text-red-500">Account</span>
                    </h3>
                    <p className="text-xs text-zinc-400 mt-1 font-medium">
                      Please verify the player details before continuing.
                    </p>
                  </div>

                  {/* Player info rows */}
                  <div
                    className="rounded-2xl overflow-hidden text-sm"
                    style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
                  >
                    {/* Player Name */}
                    <div className="flex items-center gap-3 px-4 py-3">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: 'rgba(220,38,38,0.15)', border: '1px solid rgba(220,38,38,0.25)' }}
                      >
                        <User className="w-4 h-4 text-red-500" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Player Name</p>
                      </div>
                      <span className="font-extrabold text-white text-sm truncate max-w-[140px]">{mlbbVerifiedIGN}</span>
                    </div>

                    {/* Game ID */}
                    <div className="flex items-center gap-3 px-4 py-3" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}
                      >
                        <Gamepad2 className="w-4 h-4 text-zinc-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Game ID</p>
                      </div>
                      <span className="font-mono font-bold text-zinc-200 text-sm">{playerUid.trim()}</span>
                    </div>

                    {/* Zone ID */}
                    <div className="flex items-center gap-3 px-4 py-3" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}
                      >
                        <Globe className="w-4 h-4 text-zinc-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Zone ID</p>
                      </div>
                      <span className="font-mono font-bold text-zinc-200 text-sm">{zoneId.trim()}</span>
                    </div>
                  </div>

                  {/* Warning notice */}
                  <div
                    className="flex items-start gap-2.5 rounded-xl px-3.5 py-3 text-xs"
                    style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
                  >
                    <ShieldCheck className="w-4 h-4 text-zinc-400 flex-shrink-0 mt-0.5" />
                    <p className="text-zinc-400 font-medium leading-relaxed">
                      Make sure the above details are correct.{' '}
                      <span className="text-zinc-300 font-semibold">You won't be able to change them later.</span>
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={handleMlbbCancel}
                      className="w-full py-3.5 px-4 rounded-xl font-extrabold text-sm transition-all cursor-pointer active:scale-[0.98]"
                      style={{
                        background: 'rgba(255,255,255,0.07)',
                        border: '1px solid rgba(255,255,255,0.12)',
                        color: '#e4e4e7',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.12)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.07)')}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleMlbbConfirmAndContinue}
                      className="w-full py-3.5 px-4 rounded-xl font-extrabold text-white text-sm transition-all cursor-pointer active:scale-[0.98] flex items-center justify-center gap-1.5"
                      style={{
                        background: 'linear-gradient(135deg, #dc2626, #b91c1c)',
                        boxShadow: '0 4px 16px rgba(220,38,38,0.35)',
                        border: '1px solid rgba(239,68,68,0.3)',
                      }}
                    >
                      Continue
                      <span className="text-base">→</span>
                    </button>
                  </div>
                </div>
              )}

              {/* ── STATE 3: VERIFICATION FAILED ── */}
              {mlbbStep === 'error' && (
                <div className="text-center space-y-5">
                  {/* Error icon */}
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto"
                    style={{
                      background: 'rgba(220,38,38,0.1)',
                      border: '2px solid rgba(220,38,38,0.3)',
                      boxShadow: '0 0 20px rgba(220,38,38,0.15)',
                    }}
                  >
                    <X className="w-8 h-8 text-red-500" />
                  </div>

                  <div>
                    <h3 className="font-extrabold text-xl text-white tracking-tight">Verification Failed</h3>
                    <p className="text-xs text-zinc-400 mt-2 leading-relaxed px-2">
                      {mlbbErrorMsg || "We couldn't verify this Mobile Legends account. Please check your Game ID and Zone ID and try again."}
                    </p>
                  </div>

                  {/* Entered info */}
                  <div
                    className="rounded-2xl p-4 text-xs text-left space-y-2"
                    style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
                  >
                    <div className="flex justify-between">
                      <span className="text-zinc-500 font-medium">Entered Game ID</span>
                      <span className="font-mono font-bold text-zinc-200">{playerUid.trim()}</span>
                    </div>
                    <div className="flex justify-between" style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: 8 }}>
                      <span className="text-zinc-500 font-medium">Entered Zone ID</span>
                      <span className="font-mono font-bold text-zinc-200">{zoneId.trim()}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={handleMlbbCancel}
                      className="w-full py-3.5 px-4 rounded-xl font-extrabold text-sm transition-all cursor-pointer active:scale-[0.98]"
                      style={{
                        background: 'rgba(255,255,255,0.07)',
                        border: '1px solid rgba(255,255,255,0.12)',
                        color: '#e4e4e7',
                      }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.12)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.07)')}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={triggerMlbbVerification}
                      disabled={isMlbbLoading}
                      className="w-full py-3.5 px-4 rounded-xl font-extrabold text-white text-sm transition-all cursor-pointer active:scale-[0.98] flex items-center justify-center gap-1.5 disabled:opacity-50"
                      style={{
                        background: 'linear-gradient(135deg, #dc2626, #b91c1c)',
                        boxShadow: '0 4px 16px rgba(220,38,38,0.35)',
                        border: '1px solid rgba(239,68,68,0.3)',
                      }}
                    >
                      {isMlbbLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <RefreshCw className="w-3.5 h-3.5" />
                          Try Again
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

            </div>

            {/* Bottom accent bar */}
            <div className="h-0.5 w-full" style={{ background: 'linear-gradient(90deg, transparent, rgba(220,38,38,0.4), transparent)' }} />
          </div>
        </div>
      )}
    </div>
  );
};
