import React from 'react';

interface UserAvatarIconProps {
  className?: string;
  size?: number;
  avatarUrl?: string;
}

export const UserAvatarIcon: React.FC<UserAvatarIconProps> = ({
  className = 'w-7 h-7 sm:w-8 sm:h-8',
  avatarUrl,
}) => {
  if (avatarUrl && avatarUrl.trim() !== '') {
    return (
      <img
        src={avatarUrl}
        alt="User Profile"
        className={`${className} rounded-full object-cover flex-shrink-0 transition-transform active:scale-95 border border-zinc-200/80`}
      />
    );
  }

  return (
    <svg
      className={`${className} flex-shrink-0 transition-transform active:scale-95`}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="16" cy="16" r="16" fill="#D1D5DB" />
      <circle cx="16" cy="11" r="5" fill="#FFFFFF" />
      <path
        d="M16 18C10.4772 18 6 22.4772 6 28C6 28.5523 6.44772 29 7 29H25C25.5523 29 26 28.5523 26 28C26 22.4772 21.5228 18 16 18Z"
        fill="#FFFFFF"
      />
    </svg>
  );
};
