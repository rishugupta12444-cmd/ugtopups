import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, ShieldCheck, QrCode, Copy, Clock, Loader2, AlertCircle, ExternalLink } from 'lucide-react';
import { Order } from '../types';
import { supabase } from '../lib/supabase';
import { isRedeemCodeOrder } from '../lib/store';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  pendingOrder: Order | null;
  qrPayload?: string;
  paymentUrl?: string;
  qrImage?: string;
  onPaymentSuccess: (order: Order) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  pendingOrder,
  qrPayload,
  paymentUrl,
  qrImage,
  onPaymentSuccess,
}) => {
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [copiedRef, setCopiedRef] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(300); // 5 minutes countdown
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string>('PENDING PAYMENT');

  useEffect(() => {
    if (!isOpen || !pendingOrder) return;
    setTimeLeft(300);
    setErrorMsg(null);
    setPaymentStatus('PENDING PAYMENT');

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Background polling every 4 seconds for automatic payment verification via Fonepay Hub / IPN
    const pollInterval = setInterval(() => {
      supabase.functions.invoke('fonepay-hub-status', {
        body: { orderId: pendingOrder.orderId, checkGateway: false },
      })
        .then(({ data }) => {
          if (data?.verified && data.order) {
            clearInterval(pollInterval);
            clearInterval(interval);
            setPaymentStatus('SUCCESS');
            onPaymentSuccess(data.order);
          }
        })
        .catch(() => {});
    }, 4000);

    return () => {
      clearInterval(interval);
      clearInterval(pollInterval);
    };
  }, [isOpen, pendingOrder?.orderId]);

  if (!isOpen || !pendingOrder) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const isWalletDeposit = pendingOrder?.gameId === 'ug_wallet';

  const effectivePaymentUrl = paymentUrl || '';
  const effectiveQrValue = qrPayload || '';
  const effectiveQrImage = qrImage || '';

  const handleVerifyPayment = async () => {
    setErrorMsg(null);
    setIsVerifying(true);

    try {
      const { data, error } = await supabase.functions.invoke('fonepay-hub-status', {
        body: {
          orderId: pendingOrder.orderId,
          checkGateway: true,
          transactionRef: transactionRef.trim() || undefined,
        },
      });

      if (error) throw new Error(error.message || 'Payment verification failed.');
      if (data?.verified && data.order) {
        setPaymentStatus('SUCCESS');
        onPaymentSuccess(data.order);
      } else {
        setPaymentStatus('PENDING PAYMENT');
        setErrorMsg(data?.message || 'Payment not completed on Fonepay Hub QR yet. Please complete the QR payment first.');
      }
    } catch {
      setPaymentStatus('PENDING PAYMENT');
      setErrorMsg('Payment not completed on Fonepay Hub QR yet. Please complete the QR payment first.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleCopyOrderId = () => {
    navigator.clipboard.writeText(pendingOrder.orderId);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-white border border-zinc-200 rounded-3xl shadow-2xl overflow-hidden text-zinc-900 my-auto max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 bg-zinc-900 text-white border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-red-600 text-white">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">
                {isWalletDeposit ? 'Fonepay Hub Wallet Recharge' : 'Fonepay Hub Payment Gateway'}
              </h3>
              <p className="text-xs text-zinc-300">
                {isWalletDeposit ? 'Scan QR code to add funds to UG Wallet' : 'Scan Fonepay Hub QR or pay full package amount'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* Order Amount & Package Summary Box */}
          <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-center space-y-1.5">
            <span className="text-[11px] font-extrabold text-red-600 uppercase tracking-widest">
              {isWalletDeposit ? 'FULL RECHARGE AMOUNT TO PAY' : 'FULL PACKAGE AMOUNT TO PAY'}
            </span>
            <div className="text-3xl sm:text-4xl font-black text-red-600 font-['Poppins',sans-serif] tracking-normal">
              NPR {pendingOrder.totalPriceNpr.toLocaleString('en-IN')}
            </div>
            
            <div className="pt-2 text-xs text-zinc-700 font-semibold space-y-1 border-t border-red-200/60 mt-2">
              <div className="flex justify-between items-center px-1">
                <span className="text-zinc-500">Package:</span>
                <strong className="text-zinc-900">{pendingOrder.packageName}</strong>
              </div>
              {!isRedeemCodeOrder(pendingOrder) && (
                <div className="flex justify-between items-center px-1">
                  <span className="text-zinc-500">{isWalletDeposit ? 'Account:' : 'Player UID:'}</span>
                  <strong className="font-mono text-zinc-900">{pendingOrder.playerUid}</strong>
                </div>
              )}
              <div className="flex justify-between items-center px-1">
                <span className="text-zinc-500">Wallet Deduction:</span>
                <strong className="font-mono text-zinc-900">NPR {pendingOrder.walletDeductionNpr || 0}</strong>
              </div>
            </div>
          </div>

          {/* QR Code Container & Payment Link */}
          <div className="flex flex-col items-center justify-center p-5 rounded-2xl bg-zinc-50 border border-zinc-200 shadow-inner space-y-4">
            
            {/* Prominent QR Code */}
            <div className="p-3.5 bg-white border border-zinc-200 rounded-2xl shadow-sm flex flex-col items-center justify-center">
              {effectiveQrImage ? (
                <img
                  src={effectiveQrImage}
                  alt="Fonepay Hub Payment QR Code"
                  className="w-48 h-48 sm:w-52 sm:h-52 object-contain"
                  onError={(e) => {
                    // Fallback to SVG rendering if image fails
                    const img = e.target as HTMLImageElement;
                    img.onerror = null;
                    img.style.display = 'none';
                  }}
                />
              ) : null}
              {(!effectiveQrImage || effectiveQrValue) && (
                <div className={effectiveQrImage ? 'hidden' : 'block'}>
                  <QRCodeSVG
                    value={effectiveQrValue}
                    size={200}
                    level="H"
                    includeMargin={true}
                  />
                </div>
              )}
            </div>

            <div className="text-center space-y-1">
              <p className="text-xs font-extrabold text-zinc-800">
                Scan the QR using your mobile banking app
              </p>
              <p className="text-[11px] text-zinc-500 font-semibold">
                (Supports eSewa, Khalti, Fonepay, IME Pay & Nepal Mobile Banking)
              </p>
            </div>

            {/* OR Separator */}
            <div className="flex items-center gap-3 w-full max-w-xs">
              <div className="flex-1 h-px bg-zinc-300" />
              <span className="text-xs font-extrabold text-zinc-400 uppercase">OR</span>
              <div className="flex-1 h-px bg-zinc-300" />
            </div>

            {/* Open Fonepay Hub Payment Gateway Button */}
            {effectivePaymentUrl ? <a
              href={effectivePaymentUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full max-w-xs py-3 px-4 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black text-center transition-all shadow-md shadow-red-200 flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider active:scale-95"
            >
              <ExternalLink className="w-4 h-4" />
              <span>OPEN FONEPAY HUB PAYMENT</span>
            </a> : null}

            {/* Fonepay Hub Badge & Supported Gateways */}
            <div className="text-center space-y-1 pt-1">
              <div className="text-[10px] font-extrabold text-zinc-500 uppercase tracking-wider">
                Fonepay Hub Unified Gateway
              </div>
              <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold text-zinc-600 uppercase">
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">eSewa</span>
                <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800">Khalti</span>
                <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800">Fonepay</span>
                <span className="px-2 py-0.5 rounded bg-orange-100 text-orange-800">IME Pay</span>
              </div>
            </div>
          </div>

          {/* Reference, Timer & Status */}
          <div className="space-y-2 p-3.5 rounded-2xl bg-zinc-100 border border-zinc-200 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-zinc-600">Payment Reference:</span>
              <button
                onClick={handleCopyOrderId}
                className="flex items-center gap-1 font-mono font-bold text-zinc-900 bg-white border border-zinc-200 px-2 py-1 rounded-lg transition-colors cursor-pointer shadow-sm hover:border-zinc-400"
              >
                <Copy className="w-3.5 h-3.5 text-zinc-500" />
                <span>{copiedRef ? 'Copied!' : pendingOrder.orderId}</span>
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="font-semibold text-zinc-600">QR/Payment expires in:</span>
              <span className="font-mono font-extrabold text-amber-700 flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                {formattedTime}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="font-semibold text-zinc-600">Payment Status:</span>
              <span className={`font-extrabold px-2.5 py-0.5 rounded-full text-[11px] uppercase tracking-wider ${
                paymentStatus === 'SUCCESS'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : paymentStatus === 'FAILED'
                  ? 'bg-red-100 text-red-800 border border-red-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300 animate-pulse'
              }`}>
                {paymentStatus}
              </span>
            </div>
          </div>

          {/* Optional Transaction Reference Input */}
          <div className="space-y-1.5 text-xs">
            <label className="font-bold text-zinc-800 block">
              Transaction Reference / UTR Number (Optional)
            </label>
            <input
              type="text"
              value={transactionRef}
              onChange={(e) => setTransactionRef(e.target.value)}
              placeholder="e.g. 984019284210"
              className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-4 py-2.5 text-zinc-900 font-mono text-xs outline-none focus:border-red-600 transition-colors"
            />
            <p className="text-[11px] text-zinc-500">
              * After completing payment on Fonepay Hub, click "Check Payment Status" to verify with server.
            </p>
          </div>

          {/* Order Processing Notice */}
          <div className="p-3 bg-zinc-100 border border-zinc-200 rounded-xl text-[11px] text-zinc-700 font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
            <span>Order will NOT be processed or confirmed until payment is completed on the Fonepay Hub QR code.</span>
          </div>

          {/* Unverified Payment Error Warning */}
          {errorMsg && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-semibold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-extrabold text-amber-900">We could not verify your payment yet.</div>
                <div className="text-[11px] mt-0.5 text-amber-800">{errorMsg}</div>
              </div>
            </div>
          )}

        </div>

        {/* Footer Action Buttons */}
        <div className="p-4 bg-zinc-50 border-t border-zinc-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-zinc-200 hover:bg-zinc-300 text-zinc-800 font-extrabold text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleVerifyPayment}
            disabled={isVerifying}
            className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs flex items-center gap-2 shadow-md shadow-red-200 transition-all cursor-pointer active:scale-95 disabled:opacity-50 uppercase tracking-wider"
          >
            {isVerifying ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Checking Status...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>CHECK PAYMENT STATUS</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
