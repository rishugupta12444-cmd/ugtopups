import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
import { Header } from '../Header';

interface Crumb {
  label: string;
  path?: string;
}

interface AccountLayoutProps {
  title: string;
  subtitle?: string;
  icon?: React.ElementType;
  breadcrumbs: Crumb[];
  onNavigate: (path: string) => void;
  backPath?: string;
  children: React.ReactNode;
  headerAction?: React.ReactNode;
  walletBalance?: number;
  userName?: string;
  avatarUrl?: string;
}

export const AccountLayout: React.FC<AccountLayoutProps> = ({
  title,
  subtitle,
  icon: Icon,
  breadcrumbs,
  onNavigate,
  children,
  headerAction,
  walletBalance = 0,
  userName,
  avatarUrl,
}) => {
  return (
    <div
      key={title}
      className="min-h-screen font-sans bg-zinc-50 text-zinc-900"
    >
      {/* ── Single Global Header ── */}
      <Header
        walletBalance={walletBalance}
        isLoggedIn={true}
        userName={userName}
        onOpenProfile={() => onNavigate('/account')}
        onOpenWalletAdd={() => onNavigate('/account/wallet')}
        onOpenHelp={() => onNavigate('/account/support')}
        onOpenNotifications={() => onNavigate('/notifications')}
        onNavigate={onNavigate}
        authChecked={true}
      />

      {/* ── Page Header Strip / Breadcrumbs (Page Content) ── */}
      <div className="bg-white border-b border-zinc-200/80 shadow-2xs">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4">
          <nav className="flex items-center gap-1.5 text-xs font-semibold mb-2 overflow-x-auto scrollbar-none whitespace-nowrap text-zinc-500">
            <button
              onClick={() => onNavigate('/')}
              className="flex items-center gap-1 transition-colors cursor-pointer hover:text-red-600"
            >
              <Home className="w-3.5 h-3.5" />
              Home
            </button>
            {breadcrumbs.map((crumb) => (
              <React.Fragment key={crumb.label}>
                <ChevronRight className="w-3.5 h-3.5 flex-shrink-0 text-zinc-300" />
                {crumb.path ? (
                  <button
                    onClick={() => onNavigate(crumb.path!)}
                    className="transition-colors cursor-pointer hover:text-red-600 flex-shrink-0"
                  >
                    {crumb.label}
                  </button>
                ) : (
                  <span className="flex-shrink-0 text-red-600 font-bold">{crumb.label}</span>
                )}
              </React.Fragment>
            ))}
          </nav>

          <div className="flex items-center justify-between gap-3">
            <div>
              <h1 className="text-xl sm:text-2xl font-black flex items-center gap-2 text-zinc-900 tracking-tight">
                {Icon && <Icon className="w-5 h-5 flex-shrink-0 text-red-600" />}
                {title}
              </h1>
              {subtitle && (
                <p className="text-xs sm:text-sm text-zinc-500 mt-0.5 font-medium">{subtitle}</p>
              )}
            </div>
            {headerAction && <div className="flex-shrink-0">{headerAction}</div>}
          </div>
        </div>
      </div>

      {/* ── Page Content ── */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-20">
        {children}
      </div>
    </div>
  );
};
