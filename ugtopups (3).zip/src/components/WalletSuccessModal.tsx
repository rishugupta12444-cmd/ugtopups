import React from 'react';
import { motion } from 'motion/react';
import { Check, Wallet, ArrowRight } from 'lucide-react';
import { Order, UserProfile } from '../types';

interface WalletSuccessModalProps {
  order: Order;
  user?: UserProfile;
  onClose: () => void;
  onGoToDashboard: () => void;
}

export const WalletSuccessModal: React.FC<WalletSuccessModalProps> = ({
  order,
  user,
  onClose,
  onGoToDashboard,
}) => {
  const amountPaid = order.totalPriceNpr || 0;
  const newBalance = user?.walletBalanceNpr ?? amountPaid;
  const transactionId = order.transactionRef || order.orderId || 'ORD--';

  return (
    <div className="fixed inset-0 z-[99990] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92, y: 20 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-white border border-zinc-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl text-zinc-900 text-center space-y-6 my-auto relative overflow-hidden"
      >
        {/* Subtle Decorative Background Light */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-24 bg-red-500/5 blur-3xl pointer-events-none rounded-full" />

        {/* 1. Large Green Circle Checkmark */}
        <div className="flex justify-center pt-2">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-emerald-50 border-2 border-emerald-500 flex items-center justify-center text-emerald-600 shadow-md shadow-emerald-500/15">
            <Check className="w-9 h-9 sm:w-11 sm:h-11 stroke-[3]" />
          </div>
        </div>

        {/* 2. Heading */}
        <div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-zinc-900">
            Payment Successful!
          </h2>
        </div>

        {/* 3. Amount Paid Box (White + Red accent) */}
        <div className="bg-zinc-50 border border-zinc-200/80 rounded-2xl p-4 sm:p-5 text-center shadow-xs">
          <p className="text-zinc-500 text-xs sm:text-sm font-bold uppercase tracking-wider">
            Amount Paid
          </p>
          <p className="text-red-600 text-3xl sm:text-4xl font-black tracking-tight mt-1">
            Rs. {amountPaid.toLocaleString()}
          </p>
        </div>

        {/* 4. Credits Added Box (Clean Light Emerald Accent) */}
        <div className="bg-emerald-50/80 border border-emerald-200/90 rounded-2xl p-4 sm:p-5 text-center shadow-xs">
          <p className="text-emerald-700 text-xs sm:text-sm font-bold uppercase tracking-wider">
            Credits Added
          </p>
          <p className="text-emerald-600 text-3xl sm:text-4xl font-black tracking-tight mt-1">
            +{amountPaid.toLocaleString()} Credits
          </p>
        </div>

        {/* 5. New Balance & Transaction ID Info */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-center gap-2 text-zinc-700 text-sm font-medium">
            <Wallet className="w-4.5 h-4.5 text-red-600" />
            <span>
              New Balance:{' '}
              <strong className="text-zinc-900 font-black text-base sm:text-lg">
                {newBalance.toLocaleString()} Credits
              </strong>
            </span>
          </div>

          <p className="text-zinc-500 text-xs font-mono tracking-wide">
            Transaction ID: <span className="text-zinc-800 font-bold">{transactionId}</span>
          </p>
        </div>

        {/* 6. Action Buttons */}
        <div className="space-y-3 pt-2">
          <button
            type="button"
            onClick={onGoToDashboard}
            className="w-full py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-700 active:scale-98 text-white font-black text-sm sm:text-base shadow-lg shadow-red-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Go to Dashboard</span>
            <ArrowRight className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-3.5 px-6 rounded-2xl bg-white border-2 border-red-600 hover:bg-red-50 active:scale-98 text-red-600 font-black text-sm sm:text-base transition-all flex items-center justify-center cursor-pointer"
          >
            <span>Continue Shopping</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};

