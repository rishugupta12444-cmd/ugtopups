import React from 'react';
import { Home, Package, Wallet, Bell, User } from 'lucide-react';
import { UserAvatarIcon } from './UserAvatarIcon';

interface BottomNavProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  isLoggedIn: boolean;
  onOpenAuth?: () => void;
  unreadNotificationsCount?: number;
}

interface NavTab {
  id: string;
  label: string;
  path: string;
  icon: React.ElementType;
  filled: React.ElementType;
}

const tabs: NavTab[] = [
  { id: 'home', label: 'Home', path: '/', icon: Home, filled: Home },
  { id: 'orders', label: 'Orders', path: '/account/orders', icon: Package, filled: Package },
  { id: 'wallet', label: 'Wallet', path: '/account/wallet', icon: Wallet, filled: Wallet },
  { id: 'notifications', label: 'Notifications', path: '/notifications', icon: Bell, filled: Bell },
  { id: 'profile', label: 'Profile', path: '/account', icon: User, filled: User },
];

export const BottomNav: React.FC<BottomNavProps> = ({
  currentPath,
  onNavigate,
  isLoggedIn,
  onOpenAuth,
  unreadNotificationsCount = 0,
}) => {
  const isActive = (path: string) => {
    if (path === '/') return currentPath === '/';
    return currentPath.startsWith(path);
  };

  const handleTabClick = (path: string) => {
    if (!isLoggedIn && path !== '/') {
      onOpenAuth?.();
      return;
    }
    onNavigate(path);
  };

  const leftTabs = tabs.slice(0, 2);
  const rightTabs = tabs.slice(3, 5);
  const centerTab = tabs[2]; // Wallet

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 md:hidden"
      style={{
        background: 'rgba(15,15,15,0.96)',
        backdropFilter: 'blur(20px)',
        borderTop: '1px solid rgba(255,255,255,0.06)',
        boxShadow: '0 -4px 30px rgba(0,0,0,0.5)',
      }}
    >
      <div className="flex items-end justify-around px-2 pt-2 pb-safe" style={{ paddingBottom: 'max(8px, env(safe-area-inset-bottom))' }}>
        {/* Left tabs */}
        {leftTabs.map((tab) => {
          const active = isActive(tab.path);
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.path)}
              className="flex-1 flex flex-col items-center gap-0.5 py-1 transition-all duration-200 active:scale-90 cursor-pointer group"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <div
                className="relative w-8 h-8 flex items-center justify-center rounded-xl transition-all duration-200"
                style={active ? {
                  background: 'rgba(230,0,18,0.15)',
                } : {}}
              >
                <Icon
                  className="w-5 h-5 transition-all duration-200"
                  style={{
                    color: active ? '#E60012' : '#555',
                    strokeWidth: active ? 2.5 : 1.5,
                  }}
                />
                {active && (
                  <span
                    className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
                    style={{ background: '#E60012' }}
                  />
                )}
              </div>
              <span
                className="text-[10px] font-bold transition-all duration-200"
                style={{ color: active ? '#E60012' : '#555' }}
              >
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* Center Wallet FAB */}
        <div className="flex-1 flex flex-col items-center" style={{ marginTop: -20 }}>
          <button
            onClick={() => handleTabClick(centerTab.path)}
            className="flex flex-col items-center gap-0.5 cursor-pointer"
            style={{ WebkitTapHighlightColor: 'transparent' }}
          >
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 active:scale-90"
              style={{
                background: isActive(centerTab.path)
                  ? 'linear-gradient(135deg, #CC0010, #E60012)'
                  : 'linear-gradient(135deg, #E60012, #FF3333)',
                boxShadow: isActive(centerTab.path)
                  ? '0 4px 20px rgba(230,0,18,0.6)'
                  : '0 4px 20px rgba(230,0,18,0.4)',
                border: '3px solid rgba(15,15,15,0.96)',
              }}
            >
              <Wallet className="w-6 h-6 text-white" strokeWidth={isActive(centerTab.path) ? 2.5 : 2} />
            </div>
            <span
              className="text-[10px] font-bold"
              style={{ color: isActive(centerTab.path) ? '#E60012' : '#666' }}
            >
              {centerTab.label}
            </span>
          </button>
        </div>

        {/* Right tabs */}
        {rightTabs.map((tab) => {
          const active = isActive(tab.path);
          const Icon = tab.icon;
          const showNotificationBadge = tab.id === 'notifications' && unreadNotificationsCount > 0;
          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.path)}
              className="flex-1 flex flex-col items-center gap-0.5 py-1 transition-all duration-200 active:scale-90 cursor-pointer"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <div
                className="relative w-8 h-8 flex items-center justify-center rounded-xl transition-all duration-200"
                style={active ? { background: 'rgba(230,0,18,0.15)' } : {}}
              >
                {tab.id === 'profile' ? (
                  <UserAvatarIcon className="w-5 h-5" />
                ) : (
                  <Icon
                    className="w-5 h-5 transition-all duration-200"
                    style={{
                      color: active ? '#E60012' : '#555',
                      strokeWidth: active ? 2.5 : 1.5,
                    }}
                  />
                )}
                {showNotificationBadge && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-[16px] px-0.5 bg-red-600 text-white text-[9px] font-bold rounded-full ring-2 ring-zinc-900 flex items-center justify-center leading-none pointer-events-none animate-smooth-badge">
                    {unreadNotificationsCount > 99 ? '99+' : unreadNotificationsCount}
                  </span>
                )}
                {active && (
                  <span
                    className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
                    style={{ background: '#E60012' }}
                  />
                )}
              </div>
              <span
                className="text-[10px] font-bold transition-all duration-200"
                style={{ color: active ? '#E60012' : '#555' }}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
