import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import { UGLogo } from './UGLogo';

export const WhatsAppButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [msg, setMsg] = useState<string>('');

  const handleSendSupportMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msg.trim()) return;
    const encoded = encodeURIComponent(`Hello UG Support! I need help: ${msg}`);
    window.open(`https://wa.me/9779708562001?text=${encoded}`, '_blank');
    setMsg('');
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-24 right-4 sm:bottom-24 sm:right-8 z-40 flex flex-col items-end">
      
      {/* Quick Chat Drawer Popup - Black + Red Theme */}
      {isOpen && (
        <div className="mb-3 w-80 bg-zinc-950 border border-red-900/40 rounded-3xl p-5 shadow-2xl text-white animate-fade-in relative backdrop-blur-md">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80">
            <div className="flex items-center gap-2.5">
              <UGLogo size="sm" />
              <div>
                <h4 className="font-extrabold text-sm text-white tracking-tight">UG Live Support</h4>
                <p className="text-[10px] text-red-500 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" /> Online 24/7
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="py-3 text-xs text-zinc-300 leading-relaxed space-y-1">
            <p className="font-bold text-white text-xs">Welcome to ugtopups.com !! 😊</p>
            <p className="text-zinc-300 text-xs">Need help? Message us on What'sapp — we're always here for you 💬</p>
          </div>

          <form onSubmit={handleSendSupportMsg} className="space-y-2.5">
            <input
              type="text"
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              placeholder="Type your UID or question..."
              className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-white text-xs outline-none focus:border-red-600 transition-colors"
            />
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs uppercase flex items-center justify-center gap-2 shadow-lg shadow-red-950/60 cursor-pointer transition-all active:scale-[0.98]"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Chat on WhatsApp</span>
            </button>
          </form>
        </div>
      )}

      {/* Semi-transparent Floating WhatsApp Icon Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-13 h-13 rounded-full bg-[#25D366]/85 hover:bg-[#25D366] text-white backdrop-blur-xs border-2 border-white/80 shadow-[0_4px_20px_rgba(37,211,102,0.45)] flex items-center justify-center transition-all hover:scale-110 active:scale-95 cursor-pointer"
        title="WhatsApp Support"
      >
        <svg className="w-7 h-7 fill-white" viewBox="0 0 24 24">
          <path d="M12.012 2c-5.506 0-9.989 4.478-9.99 9.984 0 1.763.459 3.486 1.332 5.003l-1.416 5.167 5.291-1.387c1.462.797 3.11 1.216 4.78 1.218h.004c5.503 0 9.986-4.478 9.987-9.985 0-2.667-1.037-5.176-2.924-7.062a9.92 9.92 0 0 0-7.064-2.939zm5.952 14.126c-.25.703-1.464 1.341-2.025 1.425-.522.079-1.202.112-1.942-.125-.453-.144-1.038-.338-1.785-.662-3.141-1.362-5.184-4.542-5.342-4.752-.158-.211-1.284-1.708-1.284-3.259 0-1.55.811-2.313 1.099-2.61.288-.297.629-.371.838-.371.21 0 .42.002.604.011.196.01.46-.074.72.551.27.649.918 2.241.998 2.404.08.163.133.353.026.566-.107.213-.16.346-.318.532-.158.187-.333.418-.476.561-.158.158-.323.329-.139.645.184.316.817 1.348 1.752 2.181 1.203 1.072 2.217 1.405 2.533 1.563.316.158.501.132.686-.08.185-.212.791-.922 1.002-1.238.21-.316.421-.264.711-.158.29.106 1.843.869 2.159 1.027.316.158.527.237.606.369.079.132.079.765-.171 1.468z"/>
        </svg>
      </button>

    </div>
  );
};
