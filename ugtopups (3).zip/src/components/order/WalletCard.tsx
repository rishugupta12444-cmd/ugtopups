import React from 'react';
import { Wallet, ChevronRight } from 'lucide-react';
import { UserProfile } from '../../types';

interface WalletCardProps {
  user?: UserProfile;
  onClick?: () => void;
}

export const WalletCard: React.FC<WalletCardProps> = ({ user, onClick }) => {
  const balance = user ? user.walletBalanceNpr : 525.0;

  return (
    <div 
      onClick={onClick}
      className="p-4 rounded-2xl border border-emerald-200/90 bg-emerald-50/50 flex items-center justify-between shadow-2xs hover:bg-emerald-50/80 transition-colors cursor-pointer group"
    >
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-200 group-hover:scale-105 transition-transform">
          <Wallet className="w-5 h-5" />
        </div>
        <div>
          <span className="text-[10px] font-extrabold uppercase text-emerald-700 tracking-wider">
            UG WALLET BALANCE
          </span>
          <h5 className="font-black text-sm text-zinc-900 font-mono">
            NPR {balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </h5>
          <p className="text-[10px] text-emerald-800/80">Use wallet for fast top-ups</p>
        </div>
      </div>
      <ChevronRight className="w-4 h-4 text-emerald-600 group-hover:translate-x-0.5 transition-transform" />
    </div>
  );
};
