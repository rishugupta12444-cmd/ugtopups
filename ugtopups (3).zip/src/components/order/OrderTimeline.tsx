import React from 'react';
import { Check, Clock, RefreshCw, AlertCircle, Wallet } from 'lucide-react';
import { Order } from '../../types';
import { isRedeemCodeOrder } from '../../lib/store';

interface OrderTimelineProps {
  order: Order;
}

export const OrderTimeline: React.FC<OrderTimelineProps> = ({ order }) => {
  const isPaymentSuccess = ['SUCCESS','Paid','Completed','paid','success','completed'].includes(order.paymentStatus || '');
  const isTopUpCompleted = ['COMPLETED','Completed','completed'].includes(order.topUpStatus || '');
  const isTopUpFailed = ['FAILED','Failed','failed'].includes(order.topUpStatus || '');

  const steps = [
    {
      id: 'created',
      title: 'Order Created',
      desc: 'Order placed in system',
      completed: true,
      active: false,
    },
    {
      id: 'payment',
      title: 'Payment Verified',
      desc: isPaymentSuccess ? 'Payment received successfully' : 'Awaiting payment verification',
      completed: isPaymentSuccess,
      active: ['PENDING','Pending','pending'].includes(order.paymentStatus || '') || (!isPaymentSuccess && !['FAILED','Failed','failed','Cancelled'].includes(order.paymentStatus || '')),
    },
    {
      id: 'processing',
      title: 'Top-Up Processing',
      desc: isTopUpCompleted
        ? 'Credits sent to game server'
        : isTopUpFailed
        ? 'Top-up failed'
        : 'Delivering in 2-5 minutes',
      completed: isTopUpCompleted,
      active: isPaymentSuccess && !isTopUpCompleted && !isTopUpFailed,
      failed: isTopUpFailed,
    },
    {
      id: 'completed',
      title: 'Order Completed',
      desc: isTopUpCompleted ? 'Diamonds added to in-game UID' : 'Final delivery pending',
      completed: isTopUpCompleted,
      active: false,
    },
  ];

  return (
    <div className="py-2 px-1">
      <div className="relative space-y-6 before:absolute before:inset-0 before:left-4 before:h-full before:w-0.5 before:bg-zinc-200">
        {steps.map((step, idx) => {
          return (
            <div key={step.id} className="relative flex items-start gap-4">
              {/* Step Circle */}
              <div
                className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center font-mono text-xs font-bold transition-all shadow-sm ${
                  step.completed
                    ? 'bg-emerald-600 text-white shadow-emerald-200'
                    : step.failed
                    ? 'bg-red-600 text-white shadow-red-200'
                    : step.active
                    ? 'bg-amber-500 text-white shadow-amber-200 animate-pulse'
                    : 'bg-zinc-100 text-zinc-400 border border-zinc-200'
                }`}
              >
                {step.completed ? (
                  <Check className="w-4 h-4 stroke-[3]" />
                ) : step.failed ? (
                  <AlertCircle className="w-4 h-4" />
                ) : step.active ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <span>{idx + 1}</span>
                )}
              </div>

              {/* Step Content */}
              <div className="flex-1 min-w-0 pt-0.5">
                <div className="flex items-center justify-between">
                  <h5
                    className={`text-xs font-bold ${
                      step.completed || step.active ? 'text-zinc-900' : 'text-zinc-400'
                    }`}
                  >
                    {step.title}
                  </h5>
                  {step.completed && (
                    <span className="text-[10px] font-mono font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                      Done
                    </span>
                  )}
                  {step.active && (
                    <span className="text-[10px] font-mono font-semibold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded animate-pulse">
                      In Progress
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-zinc-500 mt-0.5">{step.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
