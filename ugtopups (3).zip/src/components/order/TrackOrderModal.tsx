import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, ShieldCheck, Gift } from 'lucide-react';
import { Order } from '../../types';
import { OrderTimeline } from './OrderTimeline';
import { isRedeemCodeOrder } from '../../lib/store';

interface TrackOrderModalProps {
  isOpen: boolean;
  order: Order;
  onClose: () => void;
}

export const TrackOrderModal: React.FC<TrackOrderModalProps> = ({ isOpen, order, onClose }) => {
  const isRedeem = isRedeemCodeOrder(order);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
      >
        <motion.div
          onClick={(e) => e.stopPropagation()}
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="relative w-full max-w-md bg-white border border-zinc-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-5 text-zinc-900 overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center font-black text-xs shadow-md shadow-red-200">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-zinc-900">Track Order Status</h3>
                <p className="text-[11px] font-mono text-zinc-400">Order ID: {order.orderId}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600 transition-colors cursor-pointer"
              title="Close Modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Item Summary Badge */}
          <div className="p-3 bg-zinc-50 border border-zinc-200/80 rounded-2xl flex items-center justify-between text-xs font-mono">
            <div>
              <span className="font-extrabold text-zinc-900 block">{order.gameName}</span>
              <span className="text-red-600 font-bold">💎 {order.packageName}</span>
            </div>
            <div className="text-right">
              {isRedeem ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                  <Gift className="w-3 h-3 text-amber-600" /> Voucher
                </span>
              ) : (
                <>
                  <span className="text-[10px] font-sans text-zinc-400 block">Player UID</span>
                  <span className="font-bold text-zinc-800">{order.playerUid}</span>
                </>
              )}
            </div>
          </div>

          {/* Order Timeline Component */}
          <OrderTimeline order={order} />

          {/* Bottom Security Note */}
          <div className="pt-2 text-center text-[11px] text-zinc-400 flex items-center justify-center gap-1.5 border-t border-zinc-100">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Encrypted automated top-up processing by UG API</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
