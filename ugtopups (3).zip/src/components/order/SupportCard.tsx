import React from 'react';
import { MessageCircle } from 'lucide-react';
import { Order } from '../../types';

interface SupportCardProps {
  order?: Order;
}

export const SupportCard: React.FC<SupportCardProps> = ({ order }) => {
  const supportPhone = '9779708562001';
  const orderRef = order ? order.orderId : 'General';
  const gameRef = order ? order.gameName : 'UG Top Up';

  const whatsappMessage = encodeURIComponent(
    `Hello UG Support! I need assistance regarding my Order ID: ${orderRef} (${gameRef}).`
  );

  const whatsappUrl = `https://wa.me/${supportPhone}?text=${whatsappMessage}`;

  return (
    <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left shadow-2xs">
      <div>
        <h4 className="font-extrabold text-xs text-zinc-900">Need Help?</h4>
        <p className="text-xs text-zinc-600">Our support team is always here to help you.</p>
      </div>

      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-md shadow-emerald-200 transition-all cursor-pointer flex-shrink-0 active:scale-95 w-full sm:w-auto"
      >
        <MessageCircle className="w-4 h-4 fill-white stroke-none" />
        <span>WhatsApp Support</span>
      </a>
    </div>
  );
};
