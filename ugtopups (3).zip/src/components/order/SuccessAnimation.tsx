import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { motion } from 'motion/react';
import { CheckCircle2, Zap, Clock, XCircle } from 'lucide-react';
import { Order } from '../../types';
import { isRedeemCodeOrder } from '../../lib/store';

interface SuccessAnimationProps {
  order: Order;
}

/** Normalise any paymentStatus / topUpStatus variant to a canonical value. */
function resolveStatus(order: Order): 'success' | 'pending' | 'failed' {
  const ps = (order.paymentStatus ?? '').toLowerCase().trim();
  const ts = (order.topUpStatus ?? '').toLowerCase().trim();

  // Explicit failure wins first
  if (
    ps === 'failed' || ps === 'cancelled' || ps === 'failure' ||
    ts === 'failed' || ts === 'cancelled'
  ) {
    return 'failed';
  }

  // Any success/paid/completed variant
  if (
    ps === 'success' || ps === 'paid' || ps === 'completed' ||
    ts === 'completed'
  ) {
    return 'success';
  }

  // Everything else is pending
  return 'pending';
}

export const SuccessAnimation: React.FC<SuccessAnimationProps> = ({ order }) => {
  const [sparkles, setSparkles] = useState<
    Array<{ id: number; top: string; left: string; size: number; delay: number }>
  >([]);

  const status   = resolveStatus(order);
  const isSuccess = status === 'success';
  const isPending = status === 'pending';

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.5 },
      colors: ['#dc2626', '#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899'],
    });
  };

  useEffect(() => {
    if (isSuccess) {
      triggerConfetti();
      const generated = Array.from({ length: 8 }, (_, i) => ({
        id: i,
        top: `${15 + Math.random() * 70}%`,
        left: `${10 + Math.random() * 80}%`,
        size: Math.floor(Math.random() * 8) + 4,
        delay: Math.random() * 2,
      }));
      setSparkles(generated);
    }
  }, [order.orderId, isSuccess]);

  const isTopUpDone = (order.topUpStatus ?? '').toLowerCase() === 'completed';
  const isVoucherOrder = isRedeemCodeOrder(order);

  // For voucher orders that are completed: "Order Completed"
  // For regular topup orders with payment success: "Payment Successful" (delivery is pending)
  // For pending/failed: show appropriate states
  const title =
    isSuccess && isVoucherOrder && isTopUpDone ? 'Order Completed' :
    isSuccess ? 'Payment Successful' :
    isPending ? 'Payment Pending' :
                'Payment Failed';

  const subtitle =
    isSuccess && isVoucherOrder && isTopUpDone
      ? 'Your voucher code has been delivered. Check your order receipt!'
      : isSuccess && isVoucherOrder
      ? 'Payment confirmed! Your voucher code is being assigned.'
      : isSuccess
      ? 'Your payment was successful! Your order is pending delivery.'
      : isPending
      ? 'Waiting for payment verification from the gateway.'
      : 'Your payment or order could not be processed successfully.';

  const iconRing =
    isSuccess ? 'bg-emerald-50 border-emerald-500 text-emerald-600 shadow-emerald-100' :
    isPending ? 'bg-amber-50  border-amber-500  text-amber-600  shadow-amber-100'  :
                'bg-red-50    border-red-500    text-red-600    shadow-red-100';

  const titleColor =
    isSuccess ? 'text-zinc-900'  :
    isPending ? 'text-amber-700' :
                'text-red-700';

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className="relative text-center space-y-3 pt-2"
    >
      {/* Floating sparkles — success only */}
      {isSuccess && sparkles.map((sp) => (
        <motion.span
          key={sp.id}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: [0, 1, 0], scale: [0, 1.2, 0], y: [-5, -20] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: sp.delay }}
          style={{ top: sp.top, left: sp.left, width: sp.size, height: sp.size }}
          className="absolute rounded-full bg-emerald-400 shadow-sm pointer-events-none"
        />
      ))}

      {/* Status icon */}
      <div
        className="relative mx-auto w-20 h-20 flex items-center justify-center"
      >
        {/* Ping ring — success only */}
        {isSuccess && (
          <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping opacity-75" />
        )}

        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 260, damping: 20 }}
          className={`relative w-20 h-20 rounded-full flex items-center justify-center shadow-xl border-4 ${iconRing}`}
        >
          {isSuccess ? (
            <CheckCircle2 className="w-11 h-11 stroke-[2.5]" />
          ) : isPending ? (
            <Clock className="w-11 h-11 stroke-[2.5] animate-spin-slow" />
          ) : (
            <XCircle className="w-11 h-11 stroke-[2.5]" />
          )}
        </motion.div>
      </div>

      {/* Title & subtitle */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="space-y-1"
      >
        <h2 className={`text-2xl sm:text-3xl font-black tracking-tight ${titleColor}`}>
          {title}
        </h2>
        <p className="text-xs sm:text-sm text-zinc-500 max-w-md mx-auto leading-relaxed">
          {subtitle}
        </p>
      </motion.div>

      {/* Delivery badge — not shown on failure */}
      {status !== 'failed' && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.22 }}
          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-xs border ${
            isSuccess
              ? 'bg-emerald-50 border-emerald-200/90 text-emerald-700'
              : 'bg-amber-50  border-amber-200/90  text-amber-700'
          }`}
        >
          <Zap className={`w-3.5 h-3.5 ${isSuccess ? 'fill-emerald-600 text-emerald-600' : 'fill-amber-600 text-amber-600'}`} />
          <span>We'll deliver within 2–5 min</span>
        </motion.div>
      )}
    </motion.div>
  );
};
