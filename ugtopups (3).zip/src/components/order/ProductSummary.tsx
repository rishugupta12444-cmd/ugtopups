import React from 'react';
import { ShieldCheck, Copy, Gift } from 'lucide-react';
import { Order } from '../../types';
import { isRedeemCodeOrder } from '../../lib/store';

interface ProductSummaryProps {
  order: Order;
  onCopy: (text: string, label: string) => void;
}

export const ProductSummary: React.FC<ProductSummaryProps> = ({ order, onCopy }) => {
  const isRedeem = isRedeemCodeOrder(order);

  const getGameInitials = (id: string, name: string) => {
    if (id === 'freefire') return 'FF';
    if (id === 'mlbb') return 'ML';
    if (id === 'pubg') return 'UC';
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <div className="p-4 sm:p-5 rounded-2xl bg-zinc-50/80 border border-zinc-200/90 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
      {/* Left side: Game & Package Details */}
      <div className="flex items-center gap-3.5 min-w-0">
        <div className="w-14 h-14 rounded-2xl bg-red-600 text-white border border-red-700 overflow-hidden flex-shrink-0 flex items-center justify-center font-black text-lg shadow-md shadow-red-200">
          {getGameInitials(order.gameId, order.gameName)}
        </div>

        <div className="min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h3 className="font-extrabold text-base text-zinc-900 truncate">{order.gameName}</h3>
            <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black">
              <ShieldCheck className="w-3 h-3 text-emerald-600" /> Verified
            </span>
          </div>

          <p className="text-xs font-bold text-red-600 mt-1 flex items-center gap-1.5">
            <span>💎 {order.packageName}</span>
            <span className="text-zinc-400 font-mono text-[11px] bg-zinc-200/60 px-1.5 py-0.5 rounded">
              x{order.quantity || 1}
            </span>
          </p>
        </div>
      </div>

      {/* Right side: Credentials or Redeem Voucher Badge */}
      {isRedeem ? (
        <div className="w-full md:w-auto flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 text-amber-800 px-3 py-2 rounded-xl text-xs font-bold shadow-2xs">
          <Gift className="w-4 h-4 text-amber-600 flex-shrink-0" />
          <span>Digital Voucher Package (Instant Code Delivery)</span>
        </div>
      ) : (
        <div className="w-full md:w-auto flex flex-col sm:flex-row md:flex-col gap-2 pt-3 md:pt-0 border-t md:border-t-0 border-zinc-200/80 text-xs font-mono">
          {/* Player ID */}
          <div className="flex items-center justify-between md:justify-end gap-2 bg-white px-3 py-1.5 rounded-xl border border-zinc-200/90 flex-1 md:flex-none shadow-2xs">
            <span className="text-zinc-400 font-sans text-[11px]">Player ID:</span>
            <span className="font-bold text-zinc-900">{order.playerUid}</span>
            <button
              onClick={() => onCopy(order.playerUid, 'Player ID')}
              className="p-1 hover:bg-zinc-100 rounded text-zinc-400 hover:text-zinc-800 transition-colors cursor-pointer"
              title="Copy Player ID"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Zone ID if present (MLBB) */}
          {order.zoneId && (
            <div className="flex items-center justify-between md:justify-end gap-2 bg-white px-3 py-1.5 rounded-xl border border-zinc-200/90 flex-1 md:flex-none shadow-2xs">
              <span className="text-zinc-400 font-sans text-[11px]">Zone ID:</span>
              <span className="font-bold text-zinc-900">{order.zoneId}</span>
              <button
                onClick={() => onCopy(order.zoneId!, 'Zone ID')}
                className="p-1 hover:bg-zinc-100 rounded text-zinc-400 hover:text-zinc-800 transition-colors cursor-pointer"
                title="Copy Zone ID"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Nickname / IGN */}
          {order.playerName && (
            <div className="flex items-center justify-between md:justify-end gap-2 bg-white px-3 py-1.5 rounded-xl border border-zinc-200/90 flex-1 md:flex-none shadow-2xs">
              <span className="text-zinc-400 font-sans text-[11px]">Nickname:</span>
              <span className="font-bold text-emerald-700">{order.playerName}</span>
              <button
                onClick={() => onCopy(order.playerName, 'Player Name')}
                className="p-1 hover:bg-zinc-100 rounded text-zinc-400 hover:text-zinc-800 transition-colors cursor-pointer"
                title="Copy Player Name"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
