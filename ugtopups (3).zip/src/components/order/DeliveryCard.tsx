import React from 'react';
import { Clock } from 'lucide-react';

export const DeliveryCard: React.FC = () => {
  return (
    <div className="p-4 rounded-2xl bg-gradient-to-r from-red-50/80 via-amber-50/50 to-emerald-50/80 border border-red-100 flex items-center justify-between gap-3 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-200 flex-shrink-0">
          <Clock className="w-5 h-5 animate-pulse" />
        </div>
        <div>
          <h4 className="font-extrabold text-xs text-zinc-900 uppercase tracking-wider">
            Estimated Delivery Time
          </h4>
          <p className="text-xs text-zinc-600 mt-0.5">Most orders are completed instantly!</p>
        </div>
      </div>
      <div className="text-right flex-shrink-0">
        <span className="text-lg font-black text-red-600 font-mono block">2 - 5 min</span>
      </div>
    </div>
  );
};
