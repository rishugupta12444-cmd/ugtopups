import React from 'react';
import { Coins, ChevronRight } from 'lucide-react';
import { UserProfile } from '../../types';

interface CoinsCardProps {
  user?: UserProfile;
  /** Coins just earned from this specific order (shown as a "+N" badge). */
  earnedCoins?: number;
  onClick?: () => void;
}

export const CoinsCard: React.FC<CoinsCardProps> = ({ user, earnedCoins, onClick }) => {
  const coins = Math.floor(user?.coinBalance || 0);

  return (
    <button
      type="button"
      onClick={onClick}
      className="p-4 rounded-2xl border border-amber-200/90 bg-amber-50/50 flex items-center justify-between shadow-2xs text-left w-full cursor-pointer hover:border-amber-300 hover:bg-amber-50 transition-all"
    >
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-200">
          <Coins className="w-5 h-5" />
        </div>
        <div>
          <span className="text-[10px] font-extrabold uppercase text-amber-700 tracking-wider">
            UG COINS BALANCE
          </span>
          <div className="flex items-center gap-1.5">
            <h5 className="font-black text-sm text-zinc-900 font-mono">{coins} Coins</h5>
            {!!earnedCoins && (
              <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-emerald-500 text-white">
                +{earnedCoins}
              </span>
            )}
          </div>
          <p className="text-[10px] text-amber-800/80">
            {earnedCoins ? 'Earned on this order · Tap to exchange' : 'Exchange coins for wallet credit'}
          </p>
        </div>
      </div>
      <ChevronRight className="w-4 h-4 text-amber-600 flex-shrink-0" />
    </button>
  );
};
