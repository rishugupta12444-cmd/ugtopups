import React from 'react';
import { Copy } from 'lucide-react';
import { Order } from '../../types';
import { getMyRedeemCodes, isRedeemCodeOrder } from '../../lib/store';
import { useEffect, useState } from 'react';
import { Gift, Loader2 } from 'lucide-react';

interface OrderDetailsProps {
  order: Order;
  onCopy: (text: string, label: string) => void;
}

export const OrderDetails: React.FC<OrderDetailsProps> = ({ order, onCopy }) => {
  const [voucherCodes, setVoucherCodes] = useState<string[]>([]);
  const [voucherLoading, setVoucherLoading] = useState(false);
  const [voucherCopied, setVoucherCopied] = useState<string | null>(null);
  const isPaymentSuccess = order.paymentStatus === 'SUCCESS' || order.paymentStatus === 'Paid' || order.paymentStatus === 'Completed';
  const isPaymentPending = order.paymentStatus === 'PENDING' || order.paymentStatus === 'Pending';
  const looksLikeVoucher = isRedeemCodeOrder(order);
  // Order Status logic:
  // - Voucher/redeem-code orders: show real status (COMPLETED when delivered)
  // - Game top-up orders (MLBB, Free Fire, etc.): always show PENDING to customer
  //   because diamond delivery happens separately after payment confirmation
  const isTopUpCompleted = looksLikeVoucher && (order.topUpStatus === 'COMPLETED' || order.status === 'Completed');
  useEffect(() => {
    let active = true;
    if (!looksLikeVoucher || !order.orderId || !isPaymentSuccess) return () => { active=false; };
    setVoucherLoading(true);
    getMyRedeemCodes(order.orderId).then(codes => { if (active) setVoucherCodes(codes.map((c:any) => c.code).filter(Boolean)); }).finally(() => { if (active) setVoucherLoading(false); });
    return () => { active=false; };
  }, [order.orderId, looksLikeVoucher, isPaymentSuccess]);
  return (
    <div className="p-4 sm:p-5 rounded-2xl border border-zinc-200/90 bg-white space-y-3 shadow-sm">
      <div className="flex items-center justify-between border-b border-zinc-100 pb-2.5">
        <h4 className="font-extrabold text-xs uppercase tracking-wider text-zinc-500">
          Order Details
        </h4>
        <span className="text-[11px] font-mono text-zinc-400 bg-zinc-100 px-2 py-0.5 rounded">
          {order.orderId}
        </span>
      </div>

      <div className="space-y-2 text-xs font-mono">
        {/* Order ID */}
        <div className="flex justify-between items-center py-1 border-b border-zinc-100/80">
          <span className="text-zinc-500 font-sans">Order ID</span>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-zinc-900">{order.orderId}</span>
            <button
              onClick={() => onCopy(order.orderId, 'Order ID')}
              className="p-1 text-zinc-400 hover:text-zinc-800 transition-colors"
              title="Copy Order ID"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Custom fields from admin — shown for all order types */}
        {Array.isArray(order.customFieldValues) && order.customFieldValues.length > 0 && (
          <>
            {order.customFieldValues
              .filter((f) => f.value && !/password|passwd|pwd/i.test(f.label))
              .map((field) => (
                <div key={field.id} className="flex justify-between items-center py-1 border-b border-zinc-100/80">
                  <span className="text-zinc-500 font-sans">{field.label}</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-zinc-900">{field.value}</span>
                    <button
                      onClick={() => onCopy(field.value, field.label)}
                      className="p-1 text-zinc-400 hover:text-zinc-800 transition-colors"
                      title={`Copy ${field.label}`}
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
          </>
        )}

        {/* Date */}
        <div className="flex justify-between items-center py-1 border-b border-zinc-100/80">
          <span className="text-zinc-500 font-sans">Date</span>
          <span className="font-bold text-zinc-800">
            {new Date(order.createdAt).toLocaleString('en-US', {
              day: '2-digit',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </span>
        </div>

        {looksLikeVoucher && isPaymentSuccess && (
          <div className="my-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 space-y-3 font-sans">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-emerald-600" />
              <div>
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700">Voucher Code</p>
                <p className="text-xs font-bold text-emerald-800">Delivered Successfully ✓</p>
              </div>
            </div>
            {voucherLoading ? (
              <div className="flex items-center gap-2 text-xs text-emerald-700">
                <Loader2 className="w-4 h-4 animate-spin" /> Loading voucher code…
              </div>
            ) : voucherCodes.length > 0 ? (
              <div className="space-y-2">
                {voucherCodes.map((code, index) => (
                  <div key={`${code}-${index}`} className="flex items-center gap-2">
                    <div className="flex-1 min-w-0 rounded-xl bg-white border border-emerald-200 px-3 py-2 font-mono text-sm font-black text-zinc-900 break-all">{code}</div>
                    <button type="button" onClick={() => { onCopy(code, 'Voucher Code'); setVoucherCopied(code); window.setTimeout(() => setVoucherCopied(v => v === code ? null : v), 1500); }} className="shrink-0 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-extrabold text-white hover:bg-emerald-700 transition-colors">
                      {voucherCopied === code ? 'Copied ✓' : 'Copy Code'}
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-zinc-500">Voucher delivery is being finalized. Refresh this order after a moment.</p>
            )}
          </div>
        )}

        {/* Payment Method */}
        <div className="flex justify-between items-center py-1 border-b border-zinc-100/80">
          <span className="text-zinc-500 font-sans">Payment Method</span>
          <span className="font-bold text-zinc-900">{order.paymentMethod || 'UG Wallet / Fonepay Hub'}</span>
        </div>

        {/* Payment Status */}
        <div className="flex justify-between items-center py-1 border-b border-zinc-100/80">
          <span className="text-zinc-500 font-sans">Payment Status</span>
          <span className={`px-2 py-0.5 rounded-md font-extrabold text-[11px] uppercase ${
            isPaymentSuccess
              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
              : isPaymentPending
              ? 'bg-amber-100 text-amber-800 border border-amber-200'
              : 'bg-red-100 text-red-800 border border-red-200'
          }`}>
            {order.paymentStatus || 'SUCCESS'}
          </span>
        </div>

        {/* Order Status */}
        <div className="flex justify-between items-center py-1 border-b border-zinc-100/80">
          <span className="text-zinc-500 font-sans">Order Status</span>
          <span className={`px-2 py-0.5 rounded-md font-extrabold text-[11px] uppercase ${
            isTopUpCompleted
              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
              : (order as any).deliveryStatus === 'delivering'
              ? 'bg-blue-100 text-blue-800 border border-blue-200'
              : 'bg-amber-100 text-amber-800 border border-amber-200'
          }`}>
            {isTopUpCompleted
              ? '✓ DELIVERED'
              : (order as any).deliveryStatus === 'delivering'
              ? '⏳ DELIVERING...'
              : 'PENDING'}
          </span>
        </div>



        {/* Total Paid */}
        <div className="flex justify-between items-center pt-2 text-sm font-sans font-black">
          <span className="text-zinc-700">Total Paid</span>
          <span className="text-lg text-red-600 font-mono">
            NPR {order.totalPriceNpr.toLocaleString('en-IN')}
          </span>
        </div>
      </div>
    </div>
  );
};
