import React from 'react';
import { FileDown } from 'lucide-react';
import { Order } from '../../types';
import { generateOrderPdf } from '../../utils/generatePdfReceipt';

interface ReceiptCardProps {
  order: Order;
  onToast: (msg: string) => void;
}

export const ReceiptCard: React.FC<ReceiptCardProps> = ({ order, onToast }) => {
  const handleDownload = () => {
    generateOrderPdf(order);
    onToast('PDF Receipt Downloaded!');
  };

  return (
    <div className="p-4 rounded-2xl border border-zinc-200 bg-zinc-50/90 flex items-center justify-between gap-3 shadow-xs">
      <div>
        <h4 className="font-extrabold text-xs text-zinc-900">Download Receipt</h4>
        <p className="text-xs text-zinc-500 mt-0.5">Download your official order receipt PDF</p>
      </div>
      <button
        onClick={handleDownload}
        className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-black flex items-center gap-2 shadow-md transition-all cursor-pointer flex-shrink-0 active:scale-95"
      >
        <FileDown className="w-4 h-4 text-red-400" />
        <span>Download PDF</span>
      </button>
    </div>
  );
};
