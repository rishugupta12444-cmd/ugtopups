import React from 'react';
import { GamePackage } from '../../types';
import { Check, Sparkles, Gem, ShieldCheck, Zap } from 'lucide-react';

interface MLPackageCardProps {
  pkg: GamePackage;
  isSelected: boolean;
  onSelect: (pkg: GamePackage) => void;
}

export const MLPackageCard: React.FC<MLPackageCardProps> = ({ pkg, isSelected, onSelect }) => {
  const isPass = pkg.name.toLowerCase().includes('pass');
  const isSpecial = isPass || (pkg.diamonds && pkg.diamonds >= 1000);

  return (
    <button
      type="button"
      onClick={() => onSelect(pkg)}
      className={`relative group p-4 rounded-2xl text-left transition-all duration-200 cursor-pointer flex flex-col justify-between overflow-hidden select-none ${
        isSelected
          ? 'bg-[#1e1414] border-2 border-red-600 shadow-[0_0_20px_rgba(220,38,38,0.3)] scale-[1.02]'
          : 'bg-[#1a1a1a] border border-white/10 hover:border-red-500/50 hover:bg-[#221818] active:scale-[0.98]'
      }`}
    >
      {/* Background Subtle Gradient Accent */}
      {isSelected && (
        <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent pointer-events-none" />
      )}

      {/* Top right checkmark badge if selected */}
      {isSelected && (
        <div className="absolute top-2.5 right-2.5 w-5 h-5 bg-red-600 rounded-full flex items-center justify-center text-white shadow-md z-10 animate-in zoom-in duration-150">
          <Check className="w-3.5 h-3.5 stroke-[3]" />
        </div>
      )}

      {/* Badge e.g. HOT / BEST VALUE */}
      {pkg.badge && (
        <div className="mb-2">
          <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-red-600/20 text-red-400 border border-red-500/30">
            {pkg.badge}
          </span>
        </div>
      )}

      <div className="space-y-2 relative z-0">
        {/* Diamond / Pass Icon */}
        <div className="flex items-center gap-2">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
              isSelected
                ? 'bg-red-600 text-white shadow-md shadow-red-600/40'
                : 'bg-white/5 border border-white/10 text-red-500 group-hover:bg-red-600/20 group-hover:text-red-400'
            }`}
          >
            {isPass ? (
              <Zap className="w-5 h-5 fill-current" />
            ) : (
              <Gem className="w-5 h-5 fill-current" />
            )}
          </div>
          {pkg.bonus ? (
            <span className="text-[10px] font-extrabold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              +{pkg.bonus} Bonus
            </span>
          ) : null}
        </div>

        {/* Package Title / Amount */}
        <div>
          <h4 className="font-extrabold text-sm sm:text-base text-white tracking-tight group-hover:text-red-400 transition-colors">
            {pkg.name}
          </h4>
          <p className="text-[11px] text-zinc-400 font-medium">
            {isPass ? 'Special Event Item' : 'Instant Top-Up'}
          </p>
        </div>
      </div>

      {/* Price tag */}
      <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between relative z-0">
        <span className="text-xs text-zinc-400 font-semibold">Price:</span>
        <span className="text-sm sm:text-base font-black text-red-500">
          Rs. {pkg.priceNpr.toLocaleString('en-IN')}
        </span>
      </div>
    </button>
  );
};
