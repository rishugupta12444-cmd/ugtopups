import React, { useState, useRef, useEffect } from 'react';
import { UGLogo } from './UGLogo';
import { User, ShieldCheck, Bell, Wallet, ChevronDown, Menu } from 'lucide-react';
import { AdminNotification, UserProfile, NotificationItem } from '../types';
import { UserAvatarIcon } from './UserAvatarIcon';
import { subscribeNotifications } from '../lib/store';

interface HeaderProps {
  walletBalance: number;
  isLoggedIn?: boolean;
  /** Set to true once Supabase has resolved the initial auth state. */
  authChecked?: boolean;
  userName?: string;
  avatarUrl?: string;
  user?: UserProfile;
  onOpenProfile: () => void;
  onOpenWalletAdd: () => void;
  onOpenHelp: () => void;
  onOpenAdmin?: () => void;
  onOpenNotifications?: () => void;
  apiConnected?: boolean;
  adminNotification?: AdminNotification | null;
  onClearNotification?: () => void;
  onOpenAuth?: () => void;
  onLogout?: () => void;
  onNavigate?: (path: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  walletBalance,
  isLoggedIn,
  authChecked = true,
  userName,
  avatarUrl,
  user,
  onOpenProfile,
  onOpenWalletAdd,
  onOpenHelp,
  onOpenAdmin,
  onOpenNotifications,
  apiConnected,
  adminNotification,
  onClearNotification,
  onOpenAuth,
  onLogout,
  onNavigate,
}) => {
  const [activeNav, setActiveNav] = useState<string>('Home');
  const [isBellRinging, setIsBellRinging] = useState(false);
  const [userUnreadCount, setUserUnreadCount] = useState<number>(0);
  const prevUnread = useRef<boolean>(false);

  useEffect(() => {
    if (!user?.id) {
      setUserUnreadCount(0);
      return;
    }
    const unsub = subscribeNotifications(user?.email, user?.id, (notifs: NotificationItem[]) => {
      const count = (notifs || []).filter((n) => n.unread).length;
      setUserUnreadCount(count);
    });
    return unsub;
  }, [user?.id, user?.email]);

  const hasUnreadNotification = Boolean(adminNotification?.unread) || userUnreadCount > 0;
  const unreadCount = (adminNotification?.unread ? 1 : 0) + userUnreadCount;

  // Trigger one-shot ring animation when a new unread notification arrives
  useEffect(() => {
    const currentUnread = hasUnreadNotification;
    if (currentUnread && !prevUnread.current) {
      setIsBellRinging(true);
      const timer = setTimeout(() => setIsBellRinging(false), 700);
      prevUnread.current = currentUnread;
      return () => clearTimeout(timer);
    }
    prevUnread.current = currentUnread;
  }, [hasUnreadNotification]);

  const effectiveAvatarUrl = avatarUrl || user?.avatarUrl;

  const navItems = [
    { name: 'Home', id: 'hero-section' },
    { name: 'Games', id: 'games-section' },
    { name: 'Top Up', id: 'topup-section' },
    { name: 'Offers', id: 'offers-section' },
    { name: 'How It Works', id: 'how-it-works-section' },
    { name: 'Contact', id: 'contact-section' },
  ];

  const handleNavClick = (name: string, id: string) => {
    setActiveNav(name);
    if (onNavigate) {
      onNavigate('/');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        } else if (name === 'Contact' || name === 'How It Works') {
          onOpenHelp();
        }
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else if (name === 'Contact' || name === 'How It Works') {
        onOpenHelp();
      }
    }
  };

  const handleLogoClick = () => {
    if (window.location.pathname === '/') {
      window.location.reload();
    } else {
      window.location.href = '/';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-zinc-200/80 shadow-[0_1px_8px_rgba(0,0,0,0.03)] text-zinc-900 transition-all w-full">
      <div className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 h-14 sm:h-16 lg:h-18 flex items-center justify-between gap-2.5 sm:gap-4 lg:gap-6 w-full box-border">

        {/* ── LEFT: Logo + Brand Name + Official Badge ── */}
        <div className="flex items-center gap-2 sm:gap-3.5 flex-shrink-0">
          <div
            className="flex items-center gap-2 sm:gap-3 cursor-pointer group active:scale-95 transition-transform duration-200"
            onClick={handleLogoClick}
            title="UGTOPUPS - Go to Home"
          >
            <div className="relative flex items-center justify-center">
              <UGLogo size="md" />
            </div>

            <div className="flex flex-col justify-center">
              <span className="font-black text-base sm:text-lg lg:text-xl tracking-tight text-zinc-900 group-hover:text-red-600 transition-colors duration-200 whitespace-nowrap leading-tight">
                UGTOPUPS
              </span>
              <span className="text-[10px] sm:text-[11px] font-normal text-zinc-500 tracking-tight leading-tight select-none">
                Gaming Top-Up & Digital Services
              </span>
            </div>
          </div>
        </div>

        {/* ── CENTER: Navigation Menu (Desktop) ── */}
        <nav
          aria-label="Main Navigation"
          className="hidden lg:flex items-center gap-1 bg-zinc-100/90 p-1.5 rounded-full border border-zinc-200/70 shadow-2xs"
        >
          {navItems.map((item) => {
            const isActive = activeNav === item.name;
            return (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.name, item.id)}
                className={`relative px-3.5 xl:px-4 py-1.5 rounded-full text-xs font-bold transition-all duration-200 cursor-pointer whitespace-nowrap select-none ${
                  isActive
                    ? 'bg-red-600 text-white shadow-md shadow-red-500/25 scale-[1.02]'
                    : 'text-zinc-700 hover:text-red-600 hover:bg-zinc-200/60'
                }`}
              >
                {item.name}
              </button>
            );
          })}
        </nav>

        {/* ── RIGHT: Wallet, Notification, Profile / Auth ── */}
        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">

          {/* WALLET BUTTON — Compact Red Pill */}
          {authChecked && isLoggedIn && (
            <button
              onClick={onOpenWalletAdd}
              className="h-9 sm:h-10 px-3 sm:px-4.5 rounded-full bg-red-600 hover:bg-red-700 active:scale-95 transition-all duration-200 shadow-md shadow-red-600/25 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer whitespace-nowrap flex-shrink-0 select-none border-none group"
              title="Wallet Balance — Click to Load Wallet"
            >
              <div className="w-5 sm:w-6 h-5 sm:h-6 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors flex-shrink-0">
                <Wallet className="w-3 sm:w-3.5 h-3 sm:h-3.5 text-white stroke-[2.5]" />
              </div>
              <span className="tracking-tight">{walletBalance.toLocaleString('en-IN')}/-</span>
            </button>
          )}

          {/* NOTIFICATION BUTTON — Desktop/Tablet only (sm+). On mobile replaced by hamburger below. */}
          {authChecked && isLoggedIn && (
            <div className="relative flex-shrink-0 hidden sm:flex">
              <button
                onClick={() => {
                  if (onOpenNotifications) {
                    onOpenNotifications();
                  } else if (onNavigate) {
                    onNavigate('/notifications');
                  }
                }}
                className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full border transition-all duration-200 cursor-pointer relative flex items-center justify-center shadow-2xs active:scale-95 ${
                  hasUnreadNotification
                    ? 'bg-zinc-900 text-white border-zinc-800 hover:bg-zinc-800'
                    : 'bg-zinc-100 hover:bg-zinc-200/80 border-zinc-200/80 text-zinc-700 hover:text-red-600'
                }`}
                title="Notifications"
                aria-label="View Notifications"
              >
                <Bell className={`w-4 h-4 sm:w-4.5 sm:h-4.5 stroke-[2.2]${isBellRinging ? ' animate-bell-ring' : ''}`} />
                {unreadCount > 0 && (
                  <span
                    className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-red-600 text-white text-[9px] font-black rounded-full ring-2 ring-white flex items-center justify-center shadow-md animate-smooth-badge select-none z-10 leading-none"
                    title={`${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}`}
                  >
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </button>
            </div>
          )}

          {/* MOBILE HAMBURGER — visible only on mobile (< sm), opens ProfileDrawer */}
          {authChecked && isLoggedIn && (
            <button
              onClick={onOpenProfile}
              className="sm:hidden relative w-9 h-9 rounded-full bg-zinc-100 hover:bg-zinc-200/80 border border-zinc-200/80 text-zinc-700 hover:text-red-600 flex items-center justify-center shadow-2xs active:scale-95 transition-all duration-200 cursor-pointer flex-shrink-0"
              title="Menu"
              aria-label="Open Menu"
            >
              <Menu className="w-4.5 h-4.5 stroke-[2.2]" />
              {unreadCount > 0 && (
                <span
                  className="absolute -top-1 -right-1 min-w-[16px] h-[16px] px-0.5 bg-red-600 text-white text-[8px] font-black rounded-full ring-2 ring-white flex items-center justify-center shadow-md select-none z-10 leading-none"
                >
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>
          )}

          {/* AUTH / PROFILE BUTTON (Hidden on mobile UI, accessible via bottom nav/drawer) */}
          {authChecked && (
            isLoggedIn ? (
              <div className="hidden sm:flex items-center gap-1 flex-shrink-0">
                <button
                  onClick={onOpenProfile}
                  className="relative p-0.5 rounded-full hover:ring-2 hover:ring-red-500/80 transition-all duration-200 cursor-pointer flex items-center gap-1 group flex-shrink-0"
                  title="Open Account Profile Drawer"
                  aria-label="User Profile Menu"
                >
                  <div className="relative rounded-full shadow-2xs overflow-hidden transform group-hover:scale-105 transition-transform duration-200">
                    <UserAvatarIcon avatarUrl={effectiveAvatarUrl} className="w-8 h-8 sm:w-9 sm:h-9" />
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-zinc-400 group-hover:text-zinc-700 transition-colors" />
                </button>
              </div>
            ) : (
              onOpenAuth && (
                <button
                  onClick={onOpenAuth}
                  className="h-9 sm:h-10 px-3 sm:px-4.5 rounded-full bg-red-600 hover:bg-red-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md shadow-red-500/20 active:scale-95 transition-all duration-200 cursor-pointer whitespace-nowrap flex-shrink-0"
                  title="Sign In to UG TOP UP"
                >
                  <User className="w-4 h-4 stroke-[2.5]" />
                  <span>Sign In</span>
                </button>
              )
            )
          )}
        </div>
      </div>
    </header>
  );
};

