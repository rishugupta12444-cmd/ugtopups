import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, X, CheckCircle2, Smartphone } from 'lucide-react';
import { UGLogo } from './UGLogo';

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
};

declare global {
  interface Window {
    __ugDeferredPrompt?: BeforeInstallPromptEvent | null;
  }
}

let dismissedThisSession = false;

const capturePrompt = (event: Event) => {
  event.preventDefault();
  window.__ugDeferredPrompt = event as BeforeInstallPromptEvent;
  window.dispatchEvent(new Event('ug-pwa-prompt'));
};

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', capturePrompt);
}

const getPrompt = () => window.__ugDeferredPrompt || null;

const waitForPrompt = (ms: number) =>
  new Promise<BeforeInstallPromptEvent | null>((resolve) => {
    const existing = getPrompt();
    if (existing) {
      resolve(existing);
      return;
    }

    const timer = window.setTimeout(() => {
      window.removeEventListener('ug-pwa-prompt', onReady);
      window.removeEventListener('beforeinstallprompt', onReady);
      resolve(getPrompt());
    }, ms);

    const onReady = () => {
      window.clearTimeout(timer);
      window.removeEventListener('ug-pwa-prompt', onReady);
      window.removeEventListener('beforeinstallprompt', onReady);
      resolve(getPrompt());
    };

    window.addEventListener('ug-pwa-prompt', onReady);
    window.addEventListener('beforeinstallprompt', onReady);
  });

const isRunningAsInstalledApp = () =>
  window.matchMedia('(display-mode: standalone)').matches ||
  window.matchMedia('(display-mode: fullscreen)').matches ||
  (navigator as Navigator & { standalone?: boolean }).standalone === true;

export const InstallAppPopup: React.FC<{ show?: boolean }> = ({ show = true }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [canInstall, setCanInstall] = useState(false);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    if (isRunningAsInstalledApp()) {
      setIsInstalled(true);
      return;
    }

    if (dismissedThisSession) return;

    const syncPrompt = () => setCanInstall(Boolean(getPrompt()));
    syncPrompt();

    const handleAppInstalled = () => {
      window.__ugDeferredPrompt = null;
      setCanInstall(false);
      setIsInstalled(true);
      setIsVisible(false);
    };

    window.addEventListener('ug-pwa-prompt', syncPrompt);
    window.addEventListener('beforeinstallprompt', syncPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    const timer = window.setTimeout(() => {
      if (!dismissedThisSession && !isRunningAsInstalledApp()) {
        setIsVisible(true);
        syncPrompt();
      }
    }, 800);

    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('ug-pwa-prompt', syncPrompt);
      window.removeEventListener('beforeinstallprompt', syncPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleClose = () => {
    dismissedThisSession = true;
    setIsVisible(false);
  };

  const handleInstall = async () => {
    if (installing) return;
    setInstalling(true);

    try {
      const promptEvent = getPrompt() || (await waitForPrompt(2000));

      if (!promptEvent) {
        setShowInstructions(true);
        return;
      }

      await promptEvent.prompt();
      const { outcome } = await promptEvent.userChoice;

      window.__ugDeferredPrompt = null;
      setCanInstall(false);

      if (outcome === 'accepted') {
        setIsVisible(false);
      } else {
        setShowInstructions(true);
      }
    } catch (error) {
      console.error('PWA install prompt failed:', error);
      setShowInstructions(true);
    } finally {
      setInstalling(false);
    }
  };

  const shouldShow = show && isVisible && !isInstalled;

  return (
    <AnimatePresence>
      {shouldShow && (
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-[72px] md:bottom-6 left-0 right-0 mx-auto z-[9990] w-[92%] max-w-sm pointer-events-auto"
        >
          <div className="bg-white border-2 border-red-100 rounded-2xl p-4 shadow-2xl shadow-black/20 relative">
            <button
              type="button"
              onClick={handleClose}
              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-zinc-100 hover:bg-red-50 text-zinc-400 hover:text-red-600 flex items-center justify-center transition cursor-pointer border border-zinc-200"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-start gap-3 pr-8 mb-3.5">
              <UGLogo size="md" className="flex-shrink-0" />
              <div>
                <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase text-red-600 bg-red-50 px-2 py-0.5 rounded-full border border-red-200 tracking-wider mb-1">
                  <Smartphone className="w-3 h-3" />
                  APP INSTALL
                </span>
                <h3 className="font-extrabold text-sm text-zinc-900 leading-tight">
                  Install UGTOPUPS App
                </h3>
                <p className="text-[11px] text-zinc-500 mt-0.5 leading-snug">
                  Get instant fast access directly from your home screen with a full app experience.
                </p>
              </div>
            </div>

            {!showInstructions ? (
              <button
                type="button"
                id="install-btn"
                onClick={handleInstall}
                disabled={installing}
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white font-extrabold rounded-xl text-xs shadow-lg shadow-red-600/25 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-80"
              >
                <Download className="w-4 h-4" />
                {installing ? 'Opening install…' : 'Install App'}
              </button>
            ) : (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-xs space-y-2.5">
                <div className="flex items-center gap-2 text-red-700 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-red-600" />
                  How to Install on Mobile / PC:
                </div>
                <div className="space-y-1.5">
                  <p className="text-[11px] text-zinc-700 font-semibold">📱 Android (Chrome):</p>
                  <p className="text-[11px] text-zinc-600 leading-relaxed">
                    Tap the <strong>⋮</strong> menu → <strong>"Add to Home Screen"</strong> or <strong>"Install App"</strong>
                  </p>
                </div>
                <div className="space-y-1.5">
                  <p className="text-[11px] text-zinc-700 font-semibold">🍎 iPhone / iPad (Safari):</p>
                  <p className="text-[11px] text-zinc-600 leading-relaxed">
                    Tap the <strong>Share</strong> button (□↑) → <strong>"Add to Home Screen"</strong>
                  </p>
                </div>
                <div className="space-y-1.5">
                  <p className="text-[11px] text-zinc-700 font-semibold">💻 PC (Chrome/Edge):</p>
                  <p className="text-[11px] text-zinc-600 leading-relaxed">
                    Click the <strong>⊕</strong> icon in the address bar → <strong>"Install"</strong>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowInstructions(false);
                    void handleInstall();
                  }}
                  className="w-full py-1.5 text-center text-[11px] font-bold text-red-600 hover:text-red-700 underline cursor-pointer"
                >
                  Try Install Popup Again
                </button>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
