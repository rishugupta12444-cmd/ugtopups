import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ArrowRight, Megaphone } from 'lucide-react';
import { Announcement } from '../types';

// ── Safe URL handling ────────────────────────────────────────────────────
// Only allow protocols that can't be used for script injection / unsafe
// redirects. Relative internal routes ("/wallet", "#promo") are allowed too.
export function isSafeAnnouncementUrl(url?: string | null): boolean {
  if (!url) return false;
  const trimmed = url.trim();
  if (!trimmed) return false;
  if (trimmed.startsWith('/') || trimmed.startsWith('#')) return true;
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

const DISMISS_KEY_PREFIX = 'ug_announcement_dismissed_';

// Returns true if this announcement was dismissed ("Don't show again today")
// earlier today. Storage key is scoped per-announcement so dismissing one
// never hides a different announcement, and it auto-expires the next day.
export function isAnnouncementDismissedToday(announcementId: string): boolean {
  try {
    const stored = localStorage.getItem(DISMISS_KEY_PREFIX + announcementId);
    if (!stored) return false;
    const todayKey = new Date().toDateString();
    return stored === todayKey;
  } catch {
    return false;
  }
}

export function dismissAnnouncementForToday(announcementId: string): void {
  try {
    localStorage.setItem(DISMISS_KEY_PREFIX + announcementId, new Date().toDateString());
  } catch {
    // localStorage unavailable (private mode etc.) — fail silently, modal
    // will simply be able to reappear, which is the safe default.
  }
}

interface AnnouncementCardProps {
  announcement: Announcement;
  onClose: () => void;
  dontShowAgain: boolean;
  onToggleDontShowAgain: (value: boolean) => void;
  variant?: 'live' | 'preview';
}

// The visual card itself — reused by both the real live modal (with overlay,
// animations, close-on-backdrop-click) and the admin's live preview panel
// (rendered inline, no overlay).
const AnnouncementCard: React.FC<AnnouncementCardProps> = ({
  announcement,
  onClose,
  dontShowAgain,
  onToggleDontShowAgain,
  variant = 'live',
}) => {
  const handleButtonClick = () => {
    if (variant === 'preview') return;
    if (!announcement.buttonEnabled || !announcement.buttonUrl) return;
    if (!isSafeAnnouncementUrl(announcement.buttonUrl)) return;

    const url = announcement.buttonUrl.trim();
    if (announcement.openInNewTab) {
      window.open(url, '_blank', 'noopener,noreferrer');
    } else if (url.startsWith('/') || url.startsWith('#')) {
      window.location.href = url;
    } else {
      window.location.assign(url);
    }
  };

  return (
    <div className="w-full max-w-md rounded-3xl bg-gradient-to-b from-[#151a29] to-[#0c0f18] border border-red-600/20 shadow-2xl shadow-black/60 text-center relative overflow-hidden">
      {/* Decorative glow */}
      <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-64 h-40 bg-red-600/10 blur-3xl pointer-events-none rounded-full" />

      {/* Close button */}
      {variant === 'live' && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Close announcement"
          className="absolute top-3.5 right-3.5 z-10 p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      <div className="relative px-6 sm:px-8 pt-9 pb-6 space-y-4">
        {/* Icon */}
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center text-white shadow-lg shadow-red-600/25 text-3xl leading-none">
            {announcement.icon ? (
              <span aria-hidden="true">{announcement.icon}</span>
            ) : (
              <Megaphone className="w-8 h-8" />
            )}
          </div>
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-snug break-words">
          {announcement.title || 'Announcement Title'}
        </h2>

        {/* Description */}
        <p className="text-sm text-zinc-400 leading-relaxed break-words whitespace-pre-wrap">
          {announcement.description || 'Your announcement description will appear here.'}
        </p>

        {/* Button */}
        {announcement.buttonEnabled && (
          <div className="pt-2">
            <button
              type="button"
              onClick={handleButtonClick}
              disabled={variant === 'preview'}
              className="w-full py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-500 active:scale-[0.98] text-white font-black text-sm sm:text-base shadow-lg shadow-red-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:cursor-default"
            >
              {announcement.buttonIcon && (
                <span aria-hidden="true">{announcement.buttonIcon}</span>
              )}
              <span>{announcement.buttonText || 'Learn More'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Footer */}
      {announcement.allowDontShowAgain && (
        <div className="border-t border-white/5 px-6 sm:px-8 py-4">
          <label className="flex items-center justify-center gap-2.5 text-xs text-zinc-500 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={dontShowAgain}
              onChange={(e) => onToggleDontShowAgain(e.target.checked)}
              className="w-4 h-4 rounded accent-red-600 cursor-pointer"
            />
            <span>Don't show again today</span>
          </label>
        </div>
      )}
    </div>
  );
};

interface AnnouncementModalProps {
  announcement: Announcement;
  onClose: () => void;
}

// Live, user-facing modal: dark overlay + backdrop blur, entrance/exit
// animation, and the "don't show again today" persistence logic.
export const AnnouncementModal: React.FC<AnnouncementModalProps> = ({ announcement, onClose }) => {
  const [dontShowAgain, setDontShowAgain] = useState(false);

  const handleClose = () => {
    if (dontShowAgain) {
      dismissAnnouncementForToday(announcement.id);
    }
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        key="announcement-overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 z-[99995] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md overflow-y-auto"
        onClick={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 16 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="my-auto"
        >
          <AnnouncementCard
            announcement={announcement}
            onClose={handleClose}
            dontShowAgain={dontShowAgain}
            onToggleDontShowAgain={setDontShowAgain}
            variant="live"
          />
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// Static inline preview used inside the admin editor's "Live Preview" panel.
// No overlay, no click behavior — purely visual, updates as the admin types.
export const AnnouncementPreview: React.FC<{ announcement: Announcement }> = ({ announcement }) => {
  return (
    <div className="flex items-center justify-center p-6 rounded-2xl bg-[#05070c] border border-zinc-800">
      <AnnouncementCard
        announcement={announcement}
        onClose={() => {}}
        dontShowAgain={false}
        onToggleDontShowAgain={() => {}}
        variant="preview"
      />
    </div>
  );
};
