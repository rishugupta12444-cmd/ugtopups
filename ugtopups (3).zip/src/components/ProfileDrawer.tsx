import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  User, ShoppingBag, ArrowLeftRight, Coins,
  Headset, ChevronRight, LogOut, Copy, Check, Plus, Info, Bell,
} from 'lucide-react';
import { UserProfile, Order, WalletTransaction } from '../types';

interface ProfileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  orders: Order[];
  walletHistory: WalletTransaction[];
  onNavigate: (path: string) => void;
  onLogout?: () => void;
  currentPath: string;
}

const HEADER_H = 68;

export const ProfileDrawer: React.FC<ProfileDrawerProps> = ({
  isOpen, onClose, user, orders, onNavigate, onLogout,
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Contain scroll inside drawer — prevent page scroll
  useEffect(() => {
    if (!isOpen) return;

    const preventPageScroll = (e: WheelEvent) => {
      const el = scrollRef.current;
      if (!el) { e.preventDefault(); return; }
      const atTop    = el.scrollTop === 0 && e.deltaY < 0;
      const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 1 && e.deltaY > 0;
      if (atTop || atBottom) e.preventDefault();
      else e.stopPropagation();
    };

    const preventTouch = (e: TouchEvent) => { e.preventDefault(); };

    document.addEventListener('wheel',     preventPageScroll, { passive: false, capture: true });
    document.addEventListener('touchmove', preventTouch,      { passive: false });
    return () => {
      document.removeEventListener('wheel',     preventPageScroll, true);
      document.removeEventListener('touchmove', preventTouch);
    };
  }, [isOpen]);

  const handleCopyId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(user.userCode || user.id).catch(() => {});
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const goTo = (path: string) => { onNavigate(path); onClose(); };

  const menuItems = [
    { id: 'account',       label: 'Account Center',      icon: User,           path: '/account',               badge: null as string | null },
    { id: 'orders',        label: 'Order History',        icon: ShoppingBag,    path: '/account/orders',        badge: orders.length > 0 ? String(orders.length) : null },
    { id: 'transactions',  label: 'Transactions',         icon: ArrowLeftRight, path: '/account/transactions',  badge: null },
    { id: 'coins',         label: 'Reward Coin Exchange', icon: Coins,          path: '/account/coins',         badge: 'NEW' },
    { id: 'notifications', label: 'Notifications',        icon: Bell,           path: '/notifications',         badge: null },
  ];

  const displayName = user.username || 'User';
  const initial     = displayName.charAt(0).toUpperCase();
  const displayId   = user.userCode || user.id;
  const balance     = user.walletBalanceNpr ?? 0;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            key="profile-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[998] bg-black/40 backdrop-blur-[2px]"
            onClick={onClose}
          />

          {/* Floating card, right-aligned, works on all screen sizes */}
          <motion.div
            key="profile-drawer"
            initial={{ opacity: 0, y: -16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.97 }}
            transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
            style={{ top: HEADER_H + 4 }}
            className="fixed right-2 z-[999] select-none w-[92vw] max-w-[360px] sm:right-4 sm:w-[360px]"
          >
            <div
              className="relative flex flex-col bg-white rounded-[24px] shadow-[0_20px_60px_rgba(0,0,0,0.2)] border border-black/5 overflow-hidden text-neutral-900"
              style={{ maxHeight: `min(calc(100vh - ${HEADER_H + 16}px), 82vh)` }}
            >
              {/* Ambient glows */}
              <div className="absolute -top-20 -left-20 w-44 h-44 bg-red-500/15 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-20 -right-20 w-44 h-44 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

              {/* Scrollable area */}
              <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto overscroll-contain"
              >
                {/* Header */}
                <div className="p-5 pb-4 border-b border-black/5">
                  {/* Avatar row */}
                  <div
                    onClick={() => goTo('/account')}
                    className="flex items-center gap-4 mb-4 cursor-pointer group"
                  >
                    <div className="relative flex-shrink-0">
                      <div className="w-16 h-16 rounded-full border-2 border-red-600 p-0.5 group-hover:scale-105 transition-transform bg-white shadow-md">
                        {user.avatarUrl ? (
                          <img src={user.avatarUrl} alt={displayName} referrerPolicy="no-referrer"
                            className="w-full h-full object-cover rounded-full bg-neutral-200" loading="lazy" />
                        ) : (
                          <div className="w-full h-full rounded-full bg-red-100 flex items-center justify-center">
                            <span className="text-red-600 font-bold text-xl">{initial}</span>
                          </div>
                        )}
                      </div>
                      <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h2 className="text-lg font-bold text-neutral-900 leading-tight group-hover:text-red-600 transition-colors truncate">
                        {displayName}
                      </h2>
                    </div>
                  </div>

                  {/* Wallet card */}
                  <div className="bg-red-600 rounded-2xl p-4 text-white shadow-lg shadow-red-500/25 relative overflow-hidden">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] uppercase font-bold tracking-widest opacity-80">Total Balance</span>
                      <Info className="w-3.5 h-3.5 opacity-70" />
                    </div>
                    <div className="flex items-baseline gap-1.5 mb-3">
                      <span className="text-2xl font-bold tracking-tight">
                        Rs. {balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                      <span className="text-[10px] font-bold opacity-80">NPR</span>
                    </div>
                    <button onClick={() => goTo('/account/wallet')}
                      className="w-full bg-white text-red-600 font-bold text-xs py-2.5 rounded-xl hover:bg-white/95 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]">
                      <Plus className="w-4 h-4" />
                      Deposit Wallet
                    </button>
                  </div>
                </div>

                {/* Menu */}
                <div className="py-2 px-2 space-y-0.5">
                  {menuItems.map(({ id, label, icon: Icon, path, badge }) => (
                    <div key={id} onClick={() => goTo(path)}
                      className="flex items-center justify-between p-3 rounded-xl hover:bg-red-50 cursor-pointer group transition-all active:scale-[0.98]">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-black/5 flex items-center justify-center text-neutral-600 group-hover:bg-red-100 group-hover:text-red-600 transition-colors">
                          <Icon className="w-5 h-5" />
                        </div>
                        <span className="font-semibold text-[14px] text-neutral-800 group-hover:text-red-600 transition-colors">
                          {label}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {badge && (
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${badge === 'NEW' ? 'bg-red-600 text-white' : 'bg-red-100 text-red-600'}`}>
                            {badge}
                          </span>
                        )}
                        <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-neutral-500 transition-colors" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Footer — always visible */}
              <div className="flex-shrink-0 p-4 border-t border-black/5 bg-white">
                <button
                  onClick={() => { onLogout?.(); onClose(); }}
                  className="w-full flex items-center justify-center gap-3 p-3.5 rounded-2xl bg-black/5 hover:bg-red-50 transition-colors font-bold text-[14px] text-neutral-800 hover:text-red-600 active:scale-[0.99]"
                >
                  <LogOut className="w-5 h-5 text-red-600" />
                  <span>Sign Out</span>
                </button>
                <p className="text-center text-[10px] text-neutral-400 mt-3 font-medium">
                  © 2026 UG Gaming Store Pvt. Ltd.
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
