/**
 * =========================================================================
 * 🌐 SOCIAL MEDIA & SUPPORT LINKS CONFIGURATION
 * =========================================================================
 * Enter your social media profile URLs and support contact links below.
 * Simply replace the placeholder URLs with your official page links!
 */

export const SOCIAL_LINKS = {
  // 🔵 Facebook Page URL
  facebook: "https://www.facebook.com/profile.php?id=100077323161949",

  // 🎵 TikTok Profile URL
  tiktok: "https://www.tiktok.com/@myuggamingstore",

  // 📸 Instagram Profile URL
  instagram: "https://instagram.com/yourprofile",

  // ▶️ YouTube Channel URL
  youtube: "https://www.youtube.com/@ugtopups",

  // 🎮 Discord Server Invite URL
  discord: "https://discord.gg/yourserver",

  // 💬 WhatsApp Support Chat URL (e.g. https://wa.me/9779708562001)
  whatsapp: "https://wa.me/9779708562001",

  // ✉️ Support Email Link
  email: "mailto:support@ugtopups.com",

  // 📍 Location Map Link
  location: "https://maps.google.com/?q=Kathmandu,Nepal",
};
