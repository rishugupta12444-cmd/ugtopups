import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { CheckCircle2, Loader2, FileText, ArrowLeft } from 'lucide-react';
import { Order } from '../types';
import { supabase } from '../lib/supabase';
import {
  PaymentPageSettings,
  DEFAULT_PAYMENT_PAGE_SETTINGS,
  subscribePaymentPageSettings,
} from '../lib/paymentPageSettings';

interface BillingPageProps {
  orderId: string;
  /** Passed straight from the initiate response so the QR paints with no round-trip. */
  qrPayload?: string;
  qrImage?: string;
  order?: Order | null;
  onNavigate: (path: string) => void;
  onPaymentSuccess: (order: Order) => void;
}

type PayState = 'loading' | 'waiting' | 'checking' | 'success' | 'expired' | 'error';

const QR_CACHE_PREFIX = 'ug_billing_qr_';

/** Survives a page refresh without putting the QR blob in the database. */
export const cacheBillingQr = (
  orderId: string,
  payload?: string | null,
  image?: string | null,
  expiresAt?: string | null
) => {
  if (!orderId) return;
  try {
    sessionStorage.setItem(
      QR_CACHE_PREFIX + orderId,
      JSON.stringify({ payload: payload || '', image: image || '', expiresAt: expiresAt || '' })
    );
  } catch { /* storage full or blocked — the DB copy still covers refresh */ }
};

const readBillingQr = (orderId: string) => {
  try {
    const raw = sessionStorage.getItem(QR_CACHE_PREFIX + orderId);
    return raw ? JSON.parse(raw) as { payload?: string; image?: string; expiresAt?: string } : null;
  } catch { return null; }
};

const formatClock = (totalSeconds: number) => {
  const s = Math.max(0, Math.floor(totalSeconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

const formatCreatedAt = (iso?: string) => {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: 'numeric', minute: '2-digit', hour12: true,
  }).replace(' at ', ' ');
};

const formatAmount = (n: number) =>
  Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const BillingPage: React.FC<BillingPageProps> = ({
  orderId,
  qrPayload,
  qrImage,
  order: initialOrder,
  onNavigate,
  onPaymentSuccess,
}) => {
  const [cfg, setCfg] = useState<PaymentPageSettings>(DEFAULT_PAYMENT_PAGE_SETTINGS);
  const [order, setOrder] = useState<Order | null>(initialOrder || null);
  const [qr, setQr] = useState<{ payload: string; image: string }>(() => {
    const cached = readBillingQr(orderId);
    return { payload: qrPayload || cached?.payload || '', image: qrImage || cached?.image || '' };
  });
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number>(0);
  const [state, setState] = useState<PayState>(initialOrder ? 'waiting' : 'loading');
  const [notice, setNotice] = useState<string>('');
  const settledRef = useRef(false);

  useEffect(() => subscribePaymentPageSettings(setCfg), []);

  /* ── Load the order (also covers a hard refresh on /billing) ───────────── */
  useEffect(() => {
    let alive = true;
    if (!orderId) { setState('error'); setNotice('No order was supplied.'); return; }

    (async () => {
      const { data } = await supabase
        .from('orders')
        .select('*')
        .eq('orderId', orderId)
        .maybeSingle();

      if (!alive) return;

      if (!data) {
        if (!initialOrder) { setState('error'); setNotice('This order could not be found.'); }
        return;
      }

      setOrder(data as Order);
      setQr((prev) => ({
        payload: prev.payload || data.qrPayload || '',
        image: prev.image || '',
      }));

      const cached = readBillingQr(orderId);
      const rawExpiry = data.qrExpiresAt || cached?.expiresAt || '';
      const parsed = rawExpiry ? new Date(rawExpiry).getTime() : NaN;
      const base = data.createdAt ? new Date(data.createdAt).getTime() : Date.now();
      setExpiresAt(Number.isFinite(parsed) ? parsed : base + cfg.expiryMinutes * 60_000);

      if (String(data.paymentStatus).toUpperCase() === 'SUCCESS') {
        settledRef.current = true;
        setState('success');
      } else {
        setState('waiting');
      }
    })();

    return () => { alive = false; };
    // cfg.expiryMinutes only seeds the fallback deadline; re-running on config
    // changes would restart the clock mid-payment.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  /* ── Countdown ─────────────────────────────────────────────────────────── */
  useEffect(() => {
    if (!expiresAt || settledRef.current) return;
    const tick = () => {
      const left = Math.round((expiresAt - Date.now()) / 1000);
      setSecondsLeft(left);
      if (left <= 0 && !settledRef.current) setState((s) => (s === 'success' ? s : 'expired'));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiresAt]);

/* ── Verification ──────────────────────────────────────────────────────── */
const checkingRef = useRef(false);

const verify = useCallback(async (manual: boolean) => {
  if (settledRef.current || !orderId) return;

  // Prevent multiple status requests from running at the same time.
  if (checkingRef.current) return;

  checkingRef.current = true;

  if (manual) {
    setState('checking');
    setNotice('');
  }

  try {
    const { data, error } = await supabase.functions.invoke(
      'fonepay-hub-status',
      {
        body: {
          orderId,

          // IMPORTANT:
          // Both automatic and manual checks must ask Fonepay Hub
          // to verify the payment.
          checkGateway: true,

          manual,
        },
      }
    );

    if (error) {
      throw error;
    }

    console.log('[Fonepay] Payment check:', data);

    if (data?.verified === true && data?.order) {
      settledRef.current = true;

      setState('success');
      setOrder(data.order as Order);

      try {
        sessionStorage.removeItem(
          QR_CACHE_PREFIX + orderId
        );
      } catch {
        /* ignore */
      }

      setTimeout(() => {
        onPaymentSuccess(data.order as Order);
      }, 900);

      return;
    }

    // Gateway says the payment is still pending.
    if (
      data?.verified === false &&
      String(data?.gatewayStatus || '').toLowerCase() === 'pending'
    ) {
      if (manual) {
        setState(
          secondsLeft <= 0
            ? 'expired'
            : 'waiting'
        );

        setNotice(
          'Payment is still pending. If you have already paid, please wait a few seconds and we will check again.'
        );
      }

      return;
    }

    // Gateway says QR expired.
    if (
      String(data?.gatewayStatus || '').toLowerCase() === 'expired'
    ) {
      setState('expired');

      if (manual) {
        setNotice(
          data?.message ||
          cfg.expiredText
        );
      }

      return;
    }

    // Any other response.
    if (manual) {
      setState(
        secondsLeft <= 0
          ? 'expired'
          : 'waiting'
      );

      setNotice(
        data?.message ||
        cfg.failedText
      );
    }

  } catch (error) {
    console.error(
      '[Fonepay] Payment verification failed:',
      error
    );

    if (manual) {
      setState(
        secondsLeft <= 0
          ? 'expired'
          : 'waiting'
      );

      setNotice(
        'Could not reach the payment server. Try again.'
      );
    }

  } finally {
    checkingRef.current = false;
  }
}, [
  orderId,
  secondsLeft,
  cfg.failedText,
  cfg.expiredText,
  onPaymentSuccess,
]);

/* ── Background polling while the QR is alive ──────────────────────────── */
useEffect(() => {
  if (
    state !== 'waiting' ||
    settledRef.current ||
    !orderId
  ) {
    return;
  }

  const intervalSeconds = Math.max(
    2,
    Number(cfg.pollSeconds) || 5
  );

  console.log(
    `[Fonepay] Auto-checker started: every ${intervalSeconds}s`
  );

  // Check immediately instead of making the user wait
  // for the first interval.
  verify(false);

  const id = window.setInterval(() => {
    if (
      !settledRef.current
    ) {
      verify(false);
    }
  }, intervalSeconds * 1000);

  return () => {
    console.log(
      '[Fonepay] Auto-checker stopped'
    );

    window.clearInterval(id);
  };
}, [
  state,
  orderId,
  cfg.pollSeconds,
  verify,
]);

  const handleCancel = async () => {
    try {
      await supabase.functions.invoke('fonepay-hub-status', {
        body: { orderId, payment: 'cancel', status: 'cancelled' },
      });
    } catch { /* the order stays pending; admin can clear it */ }
    try { sessionStorage.removeItem(QR_CACHE_PREFIX + orderId); } catch { /* ignore */ }
    onNavigate('/account/orders');
  };

  /* ── Derived view data ─────────────────────────────────────────────────── */
  const statusView = useMemo(() => {
    switch (state) {
      case 'success':  return { text: cfg.successText, color: '#22c55e', pulse: false };
      case 'checking': return { text: 'Checking payment…', color: cfg.mutedTextColor, pulse: true };
      case 'expired':  return { text: cfg.expiredText, color: cfg.mutedTextColor, pulse: false };
      case 'error':    return { text: notice || 'Something went wrong', color: cfg.mutedTextColor, pulse: false };
      default:         return { text: cfg.waitingText, color: cfg.accentColor, pulse: true };
    }
  }, [state, cfg, notice]);

  const scanParts = useMemo(() => {
    const template = cfg.scanTitle.includes('{highlight}')
      ? cfg.scanTitle
      : `${cfg.scanTitle} {highlight}`;
    const [before, after = ''] = template.split('{highlight}');
    return { before, after };
  }, [cfg.scanTitle]);

  const amount = formatAmount(order?.totalPriceNpr ?? 0);
  const qrDead = state === 'expired' || state === 'success';

  const detailRows: Array<{ label: string; value: string; accent?: boolean }> = [];
  if (cfg.showOrderId) detailRows.push({ label: cfg.orderIdLabel, value: `#${orderId}` });
  if (cfg.showCreatedAt) detailRows.push({ label: cfg.createdAtLabel, value: formatCreatedAt(order?.createdAt) });
  if (cfg.showPackage && order?.packageName) detailRows.push({ label: cfg.packageLabel, value: order.packageName });
  if (cfg.showPlayerUid && order?.playerUid) detailRows.push({ label: cfg.playerUidLabel, value: order.playerUid });
  if (cfg.showExpiry) {
    detailRows.push({
      label: cfg.expiryLabel,
      value: state === 'success' ? '—' : secondsLeft > 0 ? formatClock(secondsLeft) : 'Expired',
      accent: true,
    });
  }

  return (
    <div
      className="min-h-screen w-full px-5 py-7 sm:px-8 sm:py-10"
      style={{
        backgroundColor: cfg.pageBgColor,
        color: cfg.textColor,
        fontFamily: cfg.bodyFont,
        backgroundImage: cfg.glowEnabled
          ? `radial-gradient(680px 380px at 8% -6%, ${cfg.accentColor}2e, transparent 70%)`
          : undefined,
      }}
    >
      <div className="mx-auto w-full max-w-[560px]">

        {/* ── Brand row ─────────────────────────────────────────────────── */}
        <div className="mb-6 flex items-center gap-3">
          {cfg.showLogo && cfg.logoUrl ? (
            <img
              src={cfg.logoUrl}
              alt={cfg.brandName}
              className="h-9 w-9 rounded-lg object-cover"
              onError={(e) => { (e.currentTarget.style.display = 'none'); }}
            />
          ) : null}
          <span className="text-xl font-extrabold tracking-tight">{cfg.brandName}</span>
        </div>

        {/* ── Payment card ──────────────────────────────────────────────── */}
        <section
          className="rounded-[20px] px-5 py-7 sm:px-8"
          style={{ backgroundColor: cfg.cardBgColor, border: `1px solid ${cfg.borderColor}` }}
        >
          <p
            className="text-center text-[15px] uppercase tracking-[0.14em]"
            style={{ fontFamily: cfg.displayFont, fontWeight: 700 }}
          >
            {cfg.billLabel}
          </p>

          <p
            className="mt-1 text-center leading-none"
            style={{ fontFamily: cfg.displayFont, fontWeight: 800, fontSize: 'clamp(38px, 12vw, 62px)' }}
          >
            <span style={{ color: cfg.accentColor }}>{cfg.currencyLabel}</span>{' '}
            <span>{amount}</span>
          </p>

          {/* QR */}
          <div className="mt-7 flex justify-center">
            <div
              className="relative rounded-[22px] bg-white p-3.5"
              style={{ opacity: qrDead ? 0.25 : 1, transition: 'opacity .3s' }}
            >
              {state === 'loading' || (!qr.payload && !qr.image) ? (
                <div className="flex h-[248px] w-[248px] items-center justify-center">
                  <Loader2 className="h-7 w-7 animate-spin text-zinc-400" />
                </div>
              ) : qr.image ? (
                <img src={qr.image} alt="Payment QR" className="h-[248px] w-[248px] object-contain" />
              ) : (
                <QRCodeSVG value={qr.payload} size={248} level="M" marginSize={0} />
              )}
            </div>
          </div>

          <p className="mt-6 text-center text-[17px] font-bold leading-snug">
            {scanParts.before}
            <span style={{ color: cfg.accentColor }}>{cfg.scanHighlight}</span>
            {scanParts.after}
          </p>
          <p className="mt-1 text-center text-[15px]" style={{ color: cfg.mutedTextColor }}>
            {cfg.scanSubtitle}
          </p>

          {/* Status strip */}
          <div
            className="mt-6 flex items-center justify-center gap-2.5 rounded-xl px-4 py-3.5"
            style={{ border: `1px solid ${cfg.borderColor}66` }}
          >
            <span
              className={`h-2.5 w-2.5 rounded-full ${statusView.pulse ? 'animate-pulse' : ''}`}
              style={{ backgroundColor: statusView.color }}
            />
            <span
              className="text-[17px]"
              style={{ fontFamily: cfg.displayFont, fontWeight: 600, color: statusView.color }}
            >
              {statusView.text}
            </span>
          </div>

          {/* Primary action */}
          <button
            type="button"
            onClick={() => (state === 'success' ? order && onPaymentSuccess(order) : verify(true))}
            disabled={state === 'checking' || state === 'loading'}
            className="mt-3.5 flex w-full items-center justify-center gap-3 rounded-xl px-4 py-4 transition-transform active:scale-[0.985] disabled:opacity-70"
            style={{ backgroundColor: cfg.accentColor, color: '#ffffff' }}
          >
            {state === 'checking'
              ? <Loader2 className="h-6 w-6 animate-spin" />
              : <CheckCircle2 className="h-6 w-6" strokeWidth={2.2} />}
            <span className="text-[19px]" style={{ fontFamily: cfg.displayFont, fontWeight: 700 }}>
              {state === 'success' ? 'Continue' : cfg.checkButtonText}
            </span>
          </button>

          {notice && state !== 'success' ? (
            <p className="mt-3 text-center text-[13px]" style={{ color: cfg.mutedTextColor }}>{notice}</p>
          ) : null}
        </section>

        {/* ── Payment details ───────────────────────────────────────────── */}
        <section
          className="mt-5 rounded-2xl px-5 py-5"
          style={{ backgroundColor: cfg.cardBgColor, border: `1px solid ${cfg.borderColor}40` }}
        >
          <div className="flex items-center gap-3">
            <span
              className="flex h-9 w-9 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${cfg.accentColor}1f`, color: cfg.accentColor }}
            >
              <FileText className="h-[18px] w-[18px]" />
            </span>
            <h2 className="text-[15px] font-semibold uppercase tracking-[0.1em]">{cfg.detailsTitle}</h2>
          </div>

          <div className="mt-3 h-[2px] w-10 rounded-full" style={{ backgroundColor: cfg.accentColor }} />

          <dl className="mt-4 space-y-3.5">
            {detailRows.map((row) => (
              <div key={row.label} className="flex items-center justify-between gap-4 text-[15px]">
                <dt style={{ color: cfg.mutedTextColor }}>{row.label}</dt>
                <dd
                  className="text-right font-medium"
                  style={{ color: row.accent ? cfg.accentColor : cfg.textColor }}
                >
                  {row.value}
                </dd>
              </div>
            ))}
          </dl>

          {cfg.footerNote ? (
            <p className="mt-5 text-[13px] leading-relaxed" style={{ color: cfg.mutedTextColor }}>
              {cfg.footerNote}
            </p>
          ) : null}

          {cfg.supportText ? (
  <a
    href={cfg.supportUrl || '#'}
    target={cfg.supportUrl ? '_blank' : undefined}
    rel="noopener noreferrer"
    className="mt-3 inline-block text-[13px] underline underline-offset-4"
    style={{ color: cfg.accentColor }}
  >
    {cfg.supportText}
  </a>
) : null}
        </section>

        {/* ── Secondary actions ─────────────────────────────────────────── */}
        <div className="mt-5 flex items-center justify-between">
          <button
            type="button"
            onClick={() => onNavigate('/')}
            className="inline-flex items-center gap-1.5 text-[13px]"
            style={{ color: cfg.mutedTextColor }}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to store
          </button>

          {cfg.showCancelButton && state !== 'success' ? (
            <button
              type="button"
              onClick={handleCancel}
              className="text-[13px] underline underline-offset-4"
              style={{ color: cfg.mutedTextColor }}
            >
              {cfg.cancelButtonText}
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
};
