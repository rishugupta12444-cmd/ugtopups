import React, { useState, useEffect, useRef } from 'react';
import { subscribeNotifications, markNotificationRead, togglePinNotification, deleteNotificationRecord } from '../lib/store';
import {
  Bell,
  CheckCheck,
  Trash2,
  Pin,
  Search,
  Copy,
  Check,
  Tag,
  Gift,
  Megaphone,
  ShoppingBag,
  Wallet,
  ShieldAlert,
  ArrowLeft,
  Sparkles,
  SlidersHorizontal,
  Clock,
  ExternalLink,
  ChevronRight,
  Filter
} from 'lucide-react';
import { NotificationItem, AdminNotification, UserProfile } from '../types';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';

interface NotificationsPageProps {
  onNavigate: (path: string) => void;
  adminNotification?: AdminNotification | null;
  user?: UserProfile;
  isLoggedIn?: boolean;
  onOpenAuth?: () => void;
  onOpenWalletAdd?: () => void;
  onOpenProfile?: () => void;
  onOpenAdmin?: () => void;
  onLogout?: () => void;
}

const DEFAULT_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    category: 'Promo Code',
    title: 'Free Fire 100% Bonus Diamond Promo Code!',
    message: 'Use this exclusive promo code on your next Free Fire diamond top-up to claim up to 100 bonus diamonds instantly.',
    date: '10 mins ago',
    unread: true,
    isPinned: true,
    code: 'FFA7-KK92-XXXX',
    expiresIn: 'Expires in 7 days',
  },
  {
    id: 'notif-2',
    category: 'Announcement',
    title: 'Important System Announcement: Double Rewards Weekend',
    message: 'All top-ups completed between Friday and Sunday will earn double UG Loyalty Points. Direct top-ups for Free Fire, PUBG Mobile, and MLBB are eligible.',
    date: '2 hours ago',
    unread: true,
    isPinned: true,
  },
  {
    id: 'notif-4',
    category: 'Order',
    title: 'Order Completed — Free Fire 110 Diamonds',
    message: 'Your order #UG-99824 for Free Fire (UID: 4616595271) has been processed and credited to your game account successfully.',
    date: '2 days ago',
    unread: false,
  },
  {
    id: 'notif-5',
    category: 'Wallet',
    title: 'Wallet Recharged Successfully',
    message: 'NPR 500.00 has been credited to your UG Wallet Balance via Fonepay Hub QR Payment.',
    date: '3 days ago',
    unread: false,
  },
  {
    id: 'notif-6',
    category: 'System',
    title: 'Scheduled System Maintenance Notice',
    message: 'Our top-up gateway will undergo brief maintenance on Sunday at 2:00 AM NPT. Service downtime will be under 15 minutes.',
    date: '5 days ago',
    unread: false,
    isExpired: true,
  },
];

export const NotificationsPage: React.FC<NotificationsPageProps> = ({
  onNavigate,
  adminNotification,
  user,
  isLoggedIn = false,
  onOpenAuth,
  onOpenWalletAdd,
  onOpenProfile,
  onOpenAdmin,
  onLogout,
}) => {
  // Supabase is the source of truth; start empty and let subscribeNotifications
  // populate this from the user's own rows (never from another browser session's cache).
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const [activeTab, setActiveTab] = useState<'All' | 'Coupon Codes' | 'Alerts'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<{ type: 'single'; id: string; title: string } | { type: 'bulk' } | null>(null);

  // Subscribe to real-time notifications for this user only
  useEffect(() => {
    const unsub = subscribeNotifications(user?.email, user?.id, (notifs) => {
      setNotifications(notifs || []);
    });
    return unsub;
  }, [user?.email, user?.id]);

  // Mark all currently-loaded notifications as read in Supabase, once, the
  // first time this page's data finishes loading (not on every re-render).
  const hasMarkedReadRef = useRef(false);
  useEffect(() => {
    if (hasMarkedReadRef.current || notifications.length === 0) return;
    hasMarkedReadRef.current = true;
    const unreadIds = notifications.filter(n => n.unread).map(n => n.id);
    if (unreadIds.length === 0) return;
    setNotifications(prev => prev.map(n => (unreadIds.includes(n.id) ? { ...n, unread: false } : n)));
    unreadIds.forEach(id => { markNotificationRead(id, false); });
  }, [notifications]);

  const handleCopyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2500);
  };

  const toggleReadStatus = (id: string) => {
    const target = notifications.find((n) => n.id === id);
    if (!target) return;
    const nextUnread = !target.unread;
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, unread: nextUnread } : n)));
    markNotificationRead(id, nextUnread).then((ok) => {
      if (!ok) setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, unread: !nextUnread } : n)));
    });
  };

  const togglePinStatus = (id: string) => {
    const target = notifications.find((n) => n.id === id);
    if (!target) return;
    const nextPinned = !target.isPinned;
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isPinned: nextPinned } : n)));
    togglePinNotification(id, nextPinned).then((ok) => {
      if (!ok) setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isPinned: !nextPinned } : n)));
    });
  };

  const deleteNotification = (id: string) => {
    const target = notifications.find(n => n.id === id);
    setDeleteConfirmTarget({ type: 'single', id, title: target?.title || 'Notification' });
  };

  const confirmDeleteNotification = async () => {
    if (!deleteConfirmTarget) return;
    if (deleteConfirmTarget.type === 'single') {
      const id = deleteConfirmTarget.id;
      const ok = await deleteNotificationRecord(id);
      if (ok) {
        setNotifications((prev) => prev.filter((n) => n.id !== id));
        setSelectedIds((prev) => prev.filter((i) => i !== id));
      }
    } else if (deleteConfirmTarget.type === 'bulk') {
      const ids = selectedIds;
      const results = await Promise.all(ids.map((id) => deleteNotificationRecord(id)));
      const deletedIds = ids.filter((_, i) => results[i]);
      setNotifications((prev) => prev.filter((n) => !deletedIds.includes(n.id)));
      setSelectedIds([]);
      setIsSelectMode(false);
    }
    setDeleteConfirmTarget(null);
  };

  const markAllAsRead = () => {
    const unreadIds = notifications.filter((n) => n.unread).map((n) => n.id);
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
    unreadIds.forEach((id) => { markNotificationRead(id, false); });
  };

  const clearReadNotifications = () => {
    const toDelete = notifications.filter((n) => !n.unread && !n.isPinned).map((n) => n.id);
    setNotifications((prev) => prev.filter((n) => n.unread || n.isPinned));
    toDelete.forEach((id) => { deleteNotificationRecord(id); });
  };

  // Bulk selection handling
  const toggleSelectId = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const deleteSelected = () => {
    if (selectedIds.length === 0) return;
    setDeleteConfirmTarget({ type: 'bulk' });
  };

  const markSelectedRead = () => {
    const ids = selectedIds;
    setNotifications((prev) => prev.map((n) => (ids.includes(n.id) ? { ...n, unread: false } : n)));
    setSelectedIds([]);
    setIsSelectMode(false);
    ids.forEach((id) => { markNotificationRead(id, false); });
  };

  // Filtered and Sorted Notifications
  const filteredNotifications = notifications.filter((n) => {
    // Tab category filter
    if (activeTab === 'Coupon Codes') {
      const isCoupon = n.category === 'Promo Code' || n.category.toLowerCase().includes('coupon') || n.category.toLowerCase().includes('promo');
      if (!isCoupon) return false;
    }
    if (activeTab === 'Alerts') {
      const isAlert = n.category === 'Announcement' || n.category === 'System' || n.category === 'Order' || n.category === 'Wallet';
      if (!isAlert) return false;
    }

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = n.title.toLowerCase().includes(q);
      const matchMsg = n.message.toLowerCase().includes(q);
      const matchCat = n.category.toLowerCase().includes(q);
      const matchCode = n.code ? n.code.toLowerCase().includes(q) : false;
      return matchTitle || matchMsg || matchCat || matchCode;
    }
    return true;
  });

  // Sort
  const sortedNotifications = [...filteredNotifications].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    if (sortOrder === 'newest') return 0; // Maintain default order
    return -1;
  });

  // Counts
  const totalCount = notifications.length;
  const unreadCount = notifications.filter((n) => n.unread).length;
  const couponCodesCount = notifications.filter(
    (n) => n.category === 'Promo Code' || n.category.toLowerCase().includes('coupon') || n.category.toLowerCase().includes('promo')
  ).length;
  const alertsCount = notifications.filter(
    (n) => n.category === 'Announcement' || n.category === 'System' || n.category === 'Order' || n.category === 'Wallet'
  ).length;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Promo Code':
        return <Gift className="w-5 h-5 text-red-600" />;
      case 'Announcement':
        return <Megaphone className="w-5 h-5 text-amber-600" />;
      case 'Order':
        return <ShoppingBag className="w-5 h-5 text-blue-600" />;
      case 'Wallet':
        return <Wallet className="w-5 h-5 text-emerald-600" />;
      case 'System':
      default:
        return <ShieldAlert className="w-5 h-5 text-zinc-600" />;
    }
  };

  const getCategoryBadgeClass = (category: string) => {
    switch (category) {
      case 'Promo Code':
        return 'bg-red-50 text-red-600 border-red-200';
      case 'Announcement':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Order':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Wallet':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'System':
      default:
        return 'bg-zinc-100 text-zinc-700 border-zinc-200';
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 flex flex-col justify-between">
      <div>
        {/* Main Store Header */}
        <Header
          walletBalance={user?.walletBalanceNpr || 0}
          isLoggedIn={isLoggedIn}
          userName={user?.username}
          onOpenProfile={onOpenProfile || (() => onNavigate('/account'))}
          onOpenWalletAdd={onOpenWalletAdd || (() => onNavigate('/account/wallet'))}
          onOpenAuth={onOpenAuth}
          onLogout={onLogout}
          onOpenHelp={() => onNavigate('/')}
          onOpenAdmin={onOpenAdmin || (() => onNavigate('/admin'))}
          apiConnected={true}
          adminNotification={adminNotification}
        />

        {/* Dedicated Notifications Container */}
        <main className="max-w-4xl mx-auto px-2.5 sm:px-6 py-3 sm:py-6 space-y-2.5 pb-28 sm:pb-12">
          
          {/* Simple Top Bar with Back Button */}
          <div className="flex items-center justify-between gap-2 sm:gap-3 bg-white px-3 py-2 sm:p-4 rounded-2xl border border-zinc-200/80 shadow-2xs">
            <button
              onClick={() => onNavigate('/')}
              className="px-2.5 py-1 sm:px-3.5 sm:py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 active:scale-95 text-zinc-800 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer flex-shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-red-600" />
              <span>Back</span>
            </button>

            <div className="flex items-center gap-1.5 min-w-0">
              <Bell className="w-4 h-4 text-red-600 fill-red-600/10 flex-shrink-0" />
              <h1 className="text-xs sm:text-base font-black text-zinc-900 tracking-tight truncate">
                Notifications
              </h1>
              {unreadCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white font-extrabold text-[9px] sm:text-[11px] flex-shrink-0 shadow-2xs">
                  {unreadCount} Unread
                </span>
              )}
            </div>

            <button
              onClick={markAllAsRead}
              className="p-1.5 sm:px-3 sm:py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer flex-shrink-0"
              title="Mark all notifications as read"
            >
              <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Mark Read</span>
            </button>
          </div>

          {/* Categories / Filter Tabs Bar */}
          <div className="bg-white p-2 rounded-2xl border border-zinc-200/80 shadow-2xs space-y-2">
            {/* Category Tabs (Horizontal Scroll, Single Line, No Scrollbar) */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar scroll-smooth">
              {[
                { id: 'All', label: 'All', count: totalCount },
                                { id: 'Coupon Codes', label: 'Coupon Codes', count: couponCodesCount },
                { id: 'Alerts', label: 'Alerts', count: alertsCount },
              ].map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-2.5 py-1 rounded-xl text-[11px] sm:text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1 cursor-pointer flex-shrink-0 ${
                      isActive
                        ? 'bg-red-600 text-white shadow-xs shadow-red-200'
                        : 'bg-zinc-50 text-zinc-600 hover:text-red-600 hover:bg-zinc-100 border border-zinc-200/60'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span
                      className={`px-1 py-0.2 rounded-full text-[9px] font-mono ${
                        isActive ? 'bg-white/20 text-white' : 'bg-zinc-200/80 text-zinc-600'
                      }`}
                    >
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Actions: Select & Sort */}
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-zinc-100/80">
              <button
                onClick={() => setIsSelectMode(!isSelectMode)}
                className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all cursor-pointer flex-1 text-center ${
                  isSelectMode
                    ? 'bg-red-50 text-red-600 border-red-200'
                    : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100'
                }`}
              >
                {isSelectMode ? 'Cancel' : 'Select'}
              </button>

              <div className="flex items-center justify-center gap-1 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1 text-[11px] font-bold text-zinc-700 flex-1">
                <SlidersHorizontal className="w-3 h-3 text-zinc-400" />
                <select
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as any)}
                  className="bg-transparent focus:outline-none cursor-pointer"
                >
                  <option value="newest">Sort: Newest</option>
                  <option value="oldest">Sort: Oldest</option>
                </select>
              </div>
            </div>
          </div>

          {/* Bulk Operations Bar */}
          {isSelectMode && (
            <div className="bg-red-50 border border-red-200 p-2.5 rounded-2xl flex items-center justify-between gap-2 animate-fade-in text-xs font-bold text-red-900">
              <span>{selectedIds.length} items selected</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={markSelectedRead}
                  disabled={selectedIds.length === 0}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-xs disabled:opacity-50 cursor-pointer"
                >
                  Mark Read
                </button>
                <button
                  onClick={deleteSelected}
                  disabled={selectedIds.length === 0}
                  className="px-2.5 py-1 rounded-lg bg-red-600 text-white font-bold text-xs disabled:opacity-50 cursor-pointer"
                >
                  Delete Selected
                </button>
              </div>
            </div>
          )}

          {/* Notification List Cards */}
          <div className="space-y-2.5">
            {sortedNotifications.length === 0 ? (
              <div className="bg-white border border-zinc-200 rounded-2xl p-8 text-center space-y-2 shadow-2xs">
                <div className="w-12 h-12 rounded-full bg-zinc-100 text-zinc-400 flex items-center justify-center mx-auto">
                  <Bell className="w-6 h-6" />
                </div>
                <h3 className="font-extrabold text-base text-zinc-800">No Notifications Found</h3>
                <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                  {searchQuery
                    ? `No notifications matched "${searchQuery}". Try clearing your search filter.`
                    : activeTab !== 'All'
                    ? `You don't have any notifications under "${activeTab}".`
                    : "You're all caught up! New announcements and promo codes will appear here."}
                </p>
                {(searchQuery || activeTab !== 'All') && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setActiveTab('All');
                    }}
                    className="mt-1 px-3 py-1.5 rounded-xl bg-red-600 text-white font-bold text-xs shadow-xs cursor-pointer"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            ) : (
              sortedNotifications.map((notif) => {
                const isSelected = selectedIds.includes(notif.id);
                return (
                  <div
                    key={notif.id}
                    className={`group relative bg-white rounded-2xl border transition-all duration-200 overflow-hidden shadow-2xs ${
                      notif.unread
                        ? 'border-l-4 border-l-red-600 border-zinc-200 bg-white'
                        : 'border-zinc-200/80 bg-zinc-50/50'
                    }`}
                  >
                    <div className="p-3 sm:p-4 flex items-start gap-2.5">
                      
                      {/* Select Mode Checkbox */}
                      {isSelectMode && (
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectId(notif.id)}
                          className="mt-1.5 w-4 h-4 accent-red-600 rounded cursor-pointer"
                        />
                      )}

                      {/* Notification Category Icon */}
                      <div className="p-2 rounded-xl bg-zinc-100 border border-zinc-200/80 flex-shrink-0">
                        {getCategoryIcon(notif.category)}
                      </div>

                      {/* Content Area */}
                      <div className="flex-1 min-w-0 space-y-1.5">
                        
                        {/* Meta Header */}
                        <div className="flex items-center justify-between gap-1.5 flex-wrap">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {/* Category Pill */}
                            <span
                              className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider border ${getCategoryBadgeClass(
                                notif.category
                              )}`}
                            >
                              {notif.category}
                            </span>

                            {/* Pinned Tag */}
                            {notif.isPinned && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-500/10 text-amber-700 border border-amber-500/20 text-[9px] font-bold">
                                <Pin className="w-2.5 h-2.5 fill-amber-500" /> Pinned
                              </span>
                            )}

                            {/* NEW Tag */}
                            {notif.unread && (
                              <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white font-extrabold text-[9px] shadow-2xs">
                                NEW
                              </span>
                            )}

                            {/* Expired Tag */}
                            {notif.isExpired && (
                              <span className="px-1.5 py-0.5 rounded-full bg-zinc-200 text-zinc-600 font-extrabold text-[9px]">
                                EXPIRED
                              </span>
                            )}
                          </div>

                          {/* Time */}
                          <span className="text-[10px] font-semibold text-zinc-400 flex items-center gap-1 ml-auto">
                            <Clock className="w-3 h-3" />
                            {notif.date}
                          </span>
                        </div>

                        {/* Title & Message */}
                        <div>
                          <h4 className="font-extrabold text-xs sm:text-sm text-zinc-900 leading-snug">
                            {notif.title}
                          </h4>
                          <p className="mt-0.5 text-[11px] sm:text-xs font-medium text-zinc-600 leading-normal">
                            {notif.message}
                          </p>
                        </div>

                        {/* CODE BOX (If redeem or promo code present) */}
                        {notif.code && (
                          <div className="mt-2 p-2.5 rounded-xl bg-red-50/60 border border-dashed border-red-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center justify-between sm:justify-start gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className="text-[10px] font-bold text-zinc-500">Code:</span>
                                <span className="px-2 py-0.5 rounded-lg bg-white border border-red-200 text-red-600 font-mono font-black text-xs tracking-wider shadow-2xs truncate">
                                  {notif.code}
                                </span>
                              </div>
                              {notif.expiresIn && (
                                <span className="text-[10px] font-bold text-amber-600 sm:hidden">
                                  {notif.expiresIn}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2 justify-between sm:justify-end">
                              {notif.expiresIn && (
                                <span className="text-[10px] font-bold text-amber-600 hidden sm:inline">
                                  {notif.expiresIn}
                                </span>
                              )}
                              <button
                                onClick={() => handleCopyCode(notif.id, notif.code!)}
                                className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs shadow-xs flex items-center justify-center gap-1 transition-all cursor-pointer w-full sm:w-auto"
                              >
                                {copiedCodeId === notif.id ? (
                                  <>
                                    <Check className="w-3 h-3 text-white" />
                                    <span>Copied!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3 text-white" />
                                    <span>Copy Code</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Card Actions */}
                        <div className="pt-1.5 flex items-center justify-end gap-1.5 border-t border-zinc-100">
                          <button
                            onClick={() => togglePinStatus(notif.id)}
                            className={`p-1 rounded-lg border transition-all cursor-pointer ${
                              notif.isPinned
                                ? 'bg-amber-50 text-amber-600 border-amber-200'
                                : 'bg-zinc-100 text-zinc-500 border-zinc-200 hover:text-amber-600'
                            }`}
                            title={notif.isPinned ? 'Unpin notification' : 'Pin notification'}
                          >
                            <Pin className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => toggleReadStatus(notif.id)}
                            className="px-2.5 py-1 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold transition-all cursor-pointer"
                          >
                            {notif.unread ? 'Mark Read' : 'Mark Unread'}
                          </button>

                          <button
                            onClick={() => deleteNotification(notif.id)}
                            className="p-1.5 rounded-xl bg-zinc-100 hover:bg-red-50 hover:text-red-600 text-zinc-400 border border-zinc-200 transition-all cursor-pointer"
                            title="Delete notification"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

        </main>
      </div>

      {/* Confirmation Modal for Deleting Notifications */}
      {deleteConfirmTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-zinc-200 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto border border-red-100 shadow-sm">
              <Trash2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-black text-zinc-900">Confirm Deletion</h3>
              <p className="text-xs text-zinc-500 mt-1 leading-relaxed">
                {deleteConfirmTarget.type === 'bulk'
                  ? `Are you sure you want to delete ${selectedIds.length} selected notifications?`
                  : `Are you sure you want to delete "${deleteConfirmTarget.title}"?`}
                <br />This action cannot be undone.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteNotification}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-all cursor-pointer shadow-md shadow-red-200"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer onNavigate={onNavigate} />
    </div>
  );
};
