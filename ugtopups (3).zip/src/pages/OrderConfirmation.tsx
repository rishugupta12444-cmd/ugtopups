import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, Copy, RefreshCw, Zap, Home, X
} from 'lucide-react';
import { Order, UserProfile } from '../types';
import { isRedeemCodeOrder, COINS_PER_SUCCESSFUL_ORDER } from '../lib/store';
import { SuccessAnimation } from '../components/order/SuccessAnimation';
import { OrderDetails } from '../components/order/OrderDetails';
import { DeliveryCard } from '../components/order/DeliveryCard';
import { ReceiptCard } from '../components/order/ReceiptCard';
import { WalletCard } from '../components/order/WalletCard';
import { CoinsCard } from '../components/order/CoinsCard';
import { SupportCard } from '../components/order/SupportCard';
import { TrackOrderModal } from '../components/order/TrackOrderModal';

interface OrderConfirmationProps {
  order: Order | null;
  user?: UserProfile;
  onClose: () => void;
  onOpenWallet?: () => void;
  onOpenCoins?: () => void;
}

export const OrderConfirmation: React.FC<OrderConfirmationProps> = ({
  order,
  user,
  onClose,
  onOpenWallet,
  onOpenCoins,
}) => {
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [isTrackModalOpen, setIsTrackModalOpen] = useState<boolean>(false);
  const [isCopiedReceipt, setIsCopiedReceipt] = useState<boolean>(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [order?.orderId]);

  if (!order) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleCopyText = (text: string, label: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    showToast(`${label} copied!`);
  };

  const handleCopyFullReceipt = () => {
    const isRedeem = isRedeemCodeOrder(order);
    const playerLine = isRedeem ? 'Type: Digital Redeem Voucher' : `Player UID: ${order.playerUid} (${order.playerName || 'N/A'})`;
    const summary = `=== UGTOPUPS RECEIPT ===\nOrder ID: ${order.orderId}\nGame: ${order.gameName}\nPackage: ${order.packageName}\n${playerLine}\nPayment Method: ${order.paymentMethod}\nPayment Status: ${order.paymentStatus}\nOrder Status: ${isRedeemCodeOrder(order) && order.topUpStatus === 'COMPLETED' ? 'COMPLETED' : 'PENDING'}\nDate: ${new Date(order.createdAt).toLocaleString()}\nTotal Paid: NPR ${order.totalPriceNpr}\n=================================`;
    navigator.clipboard.writeText(summary);
    setIsCopiedReceipt(true);
    showToast('Receipt copied!');
    setTimeout(() => setIsCopiedReceipt(false), 2500);
  };

  return (
    <div className="relative w-full max-w-2xl bg-white border border-zinc-200/90 rounded-3xl p-4 sm:p-8 shadow-2xl text-zinc-900 mx-auto space-y-6">
      
      {/* Floating Toast Notification */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-zinc-900 text-white border border-zinc-700 px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2 text-xs font-bold font-mono"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Close button — top-right only, no branding */}
      <div className="flex justify-end">
        <button
          onClick={onClose}
          className="p-2 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600 transition-colors cursor-pointer"
          title="Close"
        >
          <X className="w-4 h-4 stroke-[2.5]" />
        </button>
      </div>

      {/* 1. Animated Success Section */}
      <SuccessAnimation order={order} />

      {/* Order Details Section */}
      <OrderDetails order={order} onCopy={handleCopyText} />

      {/* 4. Estimated Delivery Time */}
      <DeliveryCard />

      {/* 5. Download Receipt Card */}
      <ReceiptCard order={order} onToast={showToast} />

      {/* 6. Wallet & Coins Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <CoinsCard user={user} earnedCoins={COINS_PER_SUCCESSFUL_ORDER} onClick={onOpenCoins} />
        <WalletCard user={user} onClick={onOpenWallet} />
      </div>

      {/* 7. Action Buttons */}
      <div className="space-y-3 pt-2">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <button
            onClick={handleCopyFullReceipt}
            className="py-3 px-4 rounded-xl bg-zinc-100 hover:bg-zinc-200 active:scale-95 text-zinc-800 text-xs font-extrabold flex items-center justify-center gap-2 border border-zinc-200 transition-all cursor-pointer"
          >
            <Copy className="w-4 h-4 text-zinc-600" />
            <span>{isCopiedReceipt ? 'Receipt Copied!' : 'Copy Receipt'}</span>
          </button>

          <button
            onClick={() => setIsTrackModalOpen(true)}
            className="py-3 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 active:scale-95 text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
          >
            <RefreshCw className="w-4 h-4 text-emerald-400" />
            <span>Track Order</span>
          </button>

          <button
            onClick={onClose}
            className="py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 active:scale-95 text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-md shadow-red-200 transition-all cursor-pointer"
          >
            <Zap className="w-4 h-4 fill-white text-white" />
            <span>Buy Again</span>
          </button>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-white border border-zinc-200 hover:bg-zinc-50 active:scale-98 text-zinc-600 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Home className="w-3.5 h-3.5" />
          <span>Go to Home</span>
        </button>
      </div>

      {/* 8. Support Section */}
      <SupportCard order={order} />

      {/* Track Order Timeline Modal */}
      <TrackOrderModal
        isOpen={isTrackModalOpen}
        order={order}
        onClose={() => setIsTrackModalOpen(false)}
      />
    </div>
  );
};
