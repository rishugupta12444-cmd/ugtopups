import React, { useState, useMemo, useEffect } from 'react';
import {
  FileText,
  Plus,
  Minus,
  Search,
  ArrowLeft,
  MessageCircle,
  ShieldCheck,
  ChevronRight,
  Headphones,
  Lock,
} from 'lucide-react';
import { UserProfile, AdminNotification } from '../types';
import { Header } from '../components/Header';

interface TermsPageProps {
  user: UserProfile;
  isLoggedIn: boolean;
  onNavigate: (path: string) => void;
  onOpenAuth?: () => void;
  onOpenWalletAdd?: () => void;
  onOpenProfile?: () => void;
  onOpenAdmin?: () => void;
  onLogout?: () => void;
  adminNotification?: AdminNotification | null;
}

interface TermItem {
  id: number;
  title: string;
  content: string;
  category?: string;
}

const TERMS_DATA: TermItem[] = [
  {
    id: 1,
    title: '1. Acceptance of Terms',
    content:
      'By accessing or using UGTOPUPS, you agree to follow and be bound by these Terms & Conditions. If you do not agree with any part of these terms, please do not use our website or services.',
    category: 'General',
  },
  {
    id: 2,
    title: '2. Account Responsibility',
    content:
      'Customers are responsible for keeping their account information, login credentials, and other account details secure. Any activity performed through your account may be considered your responsibility.',
    category: 'Account',
  },
  {
    id: 3,
    title: '3. Accurate Information',
    content:
      'Customers must provide accurate and complete information when placing an order. UGTOPUPS is not responsible for delays or failed delivery caused by incorrect, incomplete, or misleading information provided by the customer.',
    category: 'Orders',
  },
  {
    id: 4,
    title: '4. Order Confirmation',
    content:
      'An order is considered successfully placed only after the required payment has been successfully processed and verified by UGTOPUPS. An order may remain pending until payment verification is completed.',
    category: 'Payment',
  },
  {
    id: 5,
    title: '5. Payment',
    content:
      'Customers must provide valid payment information and complete the required payment amount before an order can be processed. Payment status may be subject to verification by the applicable payment provider.',
    category: 'Payment',
  },
  {
    id: 6,
    title: '6. Digital Products and Services',
    content:
      'All digital products, game top-ups, and vouchers purchased through UGTOPUPS are intended for their specified purpose. Customers should verify the product, package, game, and account details before completing a purchase.',
    category: 'Products',
  },
  {
    id: 7,
    title: '7. Delivery',
    content:
      'Digital orders are processed after successful payment verification. Delivery time may vary depending on the product, payment verification, system availability, or other technical circumstances.',
    category: 'Delivery',
  },
  {
    id: 8,
    title: '8. Customer Information and Verification',
    content:
      'Certain products may require information such as Player UID, Zone/Server ID, email address, or other details. Customers are responsible for providing correct information required for successful order processing.',
    category: 'Verification',
  },
  {
    id: 9,
    title: '9. Refunds and Cancellations',
    content:
      'Refunds or cancellations may be subject to the specific circumstances of an order and the nature of the purchased digital product or service. Customers should contact UGTOPUPS support as soon as possible if an issue occurs.',
    category: 'Refunds',
  },
  {
    id: 10,
    title: '10. Prohibited Use',
    content:
      'Customers must not use UGTOPUPS for fraudulent, abusive, illegal, or unauthorized activities. Any suspected misuse, fraud, or suspicious transaction may result in order cancellation or account restrictions.',
    category: 'Security',
  },
  {
    id: 11,
    title: '11. Service Availability',
    content:
      'UGTOPUPS aims to keep its services available and operational, but temporary interruptions may occur due to maintenance, technical issues, payment-provider problems, network failures, or circumstances beyond our control.',
    category: 'Service',
  },
  {
    id: 12,
    title: '12. Changes to These Terms',
    content:
      'UGTOPUPS may update or modify these Terms & Conditions when necessary. Updated terms may be published on the website, and continued use of the service after changes are published constitutes acceptance of the updated terms.',
    category: 'General',
  },
];

export const TermsPage: React.FC<TermsPageProps> = ({
  user,
  isLoggedIn,
  onNavigate,
  onOpenAuth,
  onOpenWalletAdd,
  onOpenProfile,
  onOpenAdmin,
  onLogout,
  adminNotification,
}) => {
  const [openIds, setOpenIds] = useState<number[]>([1, 2, 3]); // open first 3 by default
  const [searchQuery, setSearchQuery] = useState('');

  // Auto scroll to top when visiting Terms page
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const toggleTerm = (id: number) => {
    setOpenIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleExpandAll = () => {
    setOpenIds(TERMS_DATA.map((t) => t.id));
  };

  const handleCollapseAll = () => {
    setOpenIds([]);
  };

  const filteredTerms = useMemo(() => {
    if (!searchQuery.trim()) return TERMS_DATA;
    const q = searchQuery.toLowerCase();
    return TERMS_DATA.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.content.toLowerCase().includes(q) ||
        (item.category && item.category.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans flex flex-col selection:bg-red-500 selection:text-white pb-12 sm:pb-16">
      {/* Universal Header */}
      <Header
        walletBalance={user.walletBalanceNpr}
        isLoggedIn={isLoggedIn}
        userName={user.username}
        avatarUrl={user.avatarUrl}
        user={user}
        onOpenProfile={() => onOpenProfile?.()}
        onOpenWalletAdd={() => onOpenWalletAdd?.()}
        onOpenHelp={() => onNavigate('/faq')}
        onOpenAdmin={onOpenAdmin}
        onOpenNotifications={() => onNavigate('/notifications')}
        adminNotification={adminNotification}
        onOpenAuth={onOpenAuth}
        onLogout={onLogout}
        onNavigate={onNavigate}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-10 space-y-6 sm:space-y-8">
        
        {/* Navigation Breadcrumb & Back */}
        <div className="flex items-center justify-between gap-3">
          <button
            onClick={() => onNavigate('/')}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:text-red-600 hover:border-red-200 hover:shadow-xs transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-red-600" />
            <span>Back to Home</span>
          </button>

          <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-medium">
            <span className="cursor-pointer hover:text-red-600" onClick={() => onNavigate('/')}>
              Home
            </span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-red-600 font-bold">Terms & Conditions</span>
          </div>
        </div>

        {/* Tab Switcher: Terms & Conditions | Privacy Policy */}
        <div className="flex items-center gap-2 bg-zinc-200/80 p-1.5 rounded-2xl w-full sm:w-fit">
          <button
            type="button"
            className="flex-1 sm:flex-initial px-4 sm:px-5 py-2 rounded-xl text-xs font-bold bg-white text-zinc-900 shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <FileText className="w-3.5 h-3.5 text-red-600" />
            <span>Terms & Conditions</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('/privacy')}
            className="flex-1 sm:flex-initial px-4 sm:px-5 py-2 rounded-xl text-xs font-semibold text-zinc-600 hover:text-zinc-900 hover:bg-white/50 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Lock className="w-3.5 h-3.5 text-zinc-400" />
            <span>Privacy Policy</span>
          </button>
        </div>

        {/* Hero Section */}
        <div className="bg-white border border-zinc-200/90 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden space-y-4">
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-50 text-red-600 border border-red-100 flex items-center justify-center shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-red-600 tracking-wider uppercase bg-red-50 px-2.5 py-1 rounded-lg border border-red-100">
              Legal Agreement
            </span>
          </div>

          <div className="space-y-1.5">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-zinc-900 tracking-tight">
              Terms & Conditions
            </h1>
            <p className="text-xs sm:text-sm text-zinc-600 font-medium max-w-2xl leading-relaxed">
              Please read these terms carefully before using UGTOPUPS services, placing digital orders, or funding your account wallet.
            </p>
          </div>

          {/* Search Box & Quick Controls */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-zinc-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search terms, policies, refunds, delivery..."
                className="w-full pl-11 pr-4 py-2.5 sm:py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-xs sm:text-sm text-zinc-900 placeholder:text-zinc-400 font-medium outline-none focus:bg-white focus:border-red-500 focus:ring-2 focus:ring-red-500/10 transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400 hover:text-zinc-700 bg-zinc-200 hover:bg-zinc-300 rounded-full px-2 py-0.5"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 justify-end">
              <button
                type="button"
                onClick={handleExpandAll}
                className="px-3 py-2 text-xs font-semibold text-zinc-600 hover:text-red-600 bg-zinc-100 hover:bg-zinc-200 rounded-xl transition-colors cursor-pointer"
              >
                Expand All
              </button>
              <button
                type="button"
                onClick={handleCollapseAll}
                className="px-3 py-2 text-xs font-semibold text-zinc-600 hover:text-zinc-900 bg-zinc-100 hover:bg-zinc-200 rounded-xl transition-colors cursor-pointer"
              >
                Collapse All
              </button>
            </div>
          </div>
        </div>

        {/* Accordion Terms List */}
        <div className="space-y-3">
          {filteredTerms.length === 0 ? (
            <div className="bg-white border border-zinc-200/90 rounded-2xl p-10 text-center space-y-3">
              <FileText className="w-10 h-10 text-zinc-300 mx-auto" />
              <p className="text-sm font-bold text-zinc-700">No terms match "{searchQuery}"</p>
              <p className="text-xs text-zinc-400">Try searching for a different keyword or view all terms.</p>
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700 transition-colors cursor-pointer"
              >
                Show All Terms
              </button>
            </div>
          ) : (
            filteredTerms.map((term) => {
              const isOpen = openIds.includes(term.id);
              return (
                <div
                  key={term.id}
                  className={`bg-white border rounded-2xl transition-all duration-200 overflow-hidden shadow-xs ${
                    isOpen
                      ? 'border-red-500/60 shadow-md ring-1 ring-red-500/10'
                      : 'border-zinc-200/90 hover:border-zinc-300'
                  }`}
                >
                  {/* Title Row (Clickable) */}
                  <button
                    type="button"
                    onClick={() => toggleTerm(term.id)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer select-none transition-colors"
                  >
                    <div className="flex items-start sm:items-center gap-3 min-w-0">
                      <span className="w-6 h-6 rounded-full bg-red-50 text-red-600 border border-red-200 text-xs font-semibold flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-0">
                        {term.id}
                      </span>
                      <h3 className="font-semibold text-sm sm:text-[15px] text-zinc-900 leading-snug tracking-normal">
                        {term.title}
                      </h3>
                    </div>

                    {/* Plus / Minus Button */}
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-200 ${
                        isOpen
                          ? 'bg-red-600 text-white shadow-xs rotate-180'
                          : 'bg-zinc-100 text-zinc-600 hover:bg-red-50 hover:text-red-600'
                      }`}
                    >
                      {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </div>
                  </button>

                  {/* Content (Normal unbolded font weight) */}
                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-5 pt-1 border-t border-zinc-100">
                      <div className="pl-9 pr-2">
                        <p className="text-xs sm:text-sm text-zinc-600 font-normal leading-relaxed">
                          {term.content}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* 24/7 Red Live Support Card */}
        <div className="bg-gradient-to-r from-red-600 to-red-700 text-white rounded-3xl p-6 sm:p-8 shadow-lg shadow-red-600/15 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/15 text-[11px] font-bold tracking-wider uppercase backdrop-blur-xs">
              <Headphones className="w-3.5 h-3.5" /> Customer Inquiries
            </div>
            <h3 className="text-xl sm:text-2xl font-black tracking-tight">
              Have questions regarding our terms?
            </h3>
            <p className="text-xs sm:text-sm text-red-100 font-normal max-w-md">
              Our support team is available 24/7 to answer any legal, refund, or service-related questions.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            <button
              onClick={() => onNavigate('/account/support')}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-white text-red-600 hover:bg-red-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" /> Contact Support
            </button>
            <button
              onClick={() => onNavigate('/privacy')}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-red-800/80 hover:bg-red-800 text-white font-bold text-xs transition-all border border-white/20 cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" /> View Privacy Policy
            </button>
          </div>
        </div>

      </main>
    </div>
  );
};
