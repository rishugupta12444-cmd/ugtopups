import React, { useState, useMemo } from 'react';
import { ArrowLeft, Wallet, User, Gamepad2, Globe, Phone, ShieldCheck, Sparkles, Gem, AlertCircle, Info, CheckCircle2, QrCode, Loader2, Check } from 'lucide-react';
import { Game, GamePackage, UserProfile, PaymentMethodChoice } from '../types';
import { getMlbbProductId } from '../lib/mlbbVariations';
import { MLPackageCard } from '../components/ml/MLPackageCard';
import { supabase } from '../lib/supabase';
import { Header } from '../components/Header';

interface MobileLegendsPageProps {
  user: UserProfile;
  isLoggedIn: boolean;
  games: Game[];
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
  onOpenWalletAdd: () => void;
  onInitiatePayment: (params: {
    game: Game;
    playerUid: string;
    playerName: string;
    zoneId?: string;
    userEmail?: string;
    userPassword?: string;
    userWhatsapp?: string;
    userField1Val?: string;
    userField2Val?: string;
    selectedPackage: GamePackage;
    quantity: number;
    totalPriceNpr: number;
    paymentMethodChoice: PaymentMethodChoice;
    uidVerified?: boolean;
    uidVerifiedAt?: string;
  }) => void;
}

// Default packages are only UI fallbacks. Product IDs must come from the
// admin-configured package (or be resolved from Liana /products server-side).
const DEFAULT_ML_PACKAGES: GamePackage[] = [
  { id: 'ml_10', name: '10 Diamonds', diamonds: 10, priceNpr: 30 },
  { id: 'ml_22', name: '22 Diamonds', diamonds: 22, priceNpr: 65 },
  { id: 'ml_33', name: '33 Diamonds', diamonds: 33, priceNpr: 95 },
  { id: 'ml_51', name: '51 Diamonds', diamonds: 51, priceNpr: 145 },
  { id: 'ml_55', name: '55 Diamonds', diamonds: 55, priceNpr: 160, badge: 'POPULAR' },
  { id: 'ml_86', name: '86 Diamonds', diamonds: 86, priceNpr: 240 },
  { id: 'ml_102', name: '102 Diamonds', diamonds: 102, priceNpr: 290 },
  { id: 'ml_110', name: '110 Diamonds', diamonds: 110, priceNpr: 310 },
  { id: 'ml_165', name: '165 Diamonds', diamonds: 165, priceNpr: 460 },
  { id: 'ml_172', name: '172 Diamonds', diamonds: 172, priceNpr: 480 },
  { id: 'ml_257', name: '257 Diamonds', diamonds: 257, priceNpr: 720, badge: 'HOT' },
  { id: 'ml_275', name: '275 Diamonds', diamonds: 275, priceNpr: 760 },
  { id: 'ml_343', name: '343 Diamonds', diamonds: 343, priceNpr: 960 },
  { id: 'ml_429', name: '429 Diamonds', diamonds: 429, priceNpr: 1200 },
  { id: 'ml_514', name: '514 Diamonds', diamonds: 514, priceNpr: 1440 },
  { id: 'ml_565', name: '565 Diamonds', diamonds: 565, priceNpr: 1580 },
  { id: 'ml_600', name: '600 Diamonds', diamonds: 600, priceNpr: 1680 },
  { id: 'ml_706', name: '706 Diamonds', diamonds: 706, priceNpr: 1960, badge: 'BEST VALUE' },
  { id: 'ml_878', name: '878 Diamonds', diamonds: 878, priceNpr: 2450 },
  { id: 'ml_1049', name: '1049 Diamonds', diamonds: 1049, priceNpr: 2900 },
  { id: 'ml_1135', name: '1135 Diamonds', diamonds: 1135, priceNpr: 3150 },
  { id: 'ml_1412', name: '1412 Diamonds', diamonds: 1412, priceNpr: 3900 },
  { id: 'ml_2195', name: '2195 Diamonds', diamonds: 2195, priceNpr: 6100 },
  { id: 'ml_3688', name: '3688 Diamonds', diamonds: 3688, priceNpr: 10200 },
  { id: 'ml_5532', name: '5532 Diamonds', diamonds: 5532, priceNpr: 15300 },
  { id: 'ml_9288', name: '9288 Diamonds', diamonds: 9288, priceNpr: 25500, badge: 'MEGA PACK' },
  { id: 'ml_wdp', name: 'Weekly Diamond Pass', diamonds: 210, priceNpr: 220, badge: 'SPECIAL PASS' },
  { id: 'ml_tp', name: 'Twilight Pass', diamonds: 0, priceNpr: 1350, badge: 'EXCLUSIVE' },
  { id: 'ml_svp', name: 'Super Value Pass', diamonds: 0, priceNpr: 650, badge: 'NEW' },
];

export const MobileLegendsPage: React.FC<MobileLegendsPageProps> = ({
  user,
  isLoggedIn,
  games,
  onNavigate,
  onOpenAuth,
  onOpenWalletAdd,
  onInitiatePayment,
}) => {
  // Find Mobile Legends game in store games if present
  const storeMlGame = useMemo(() => {
    return (
      games.find(
        (g) =>
          g.name?.toLowerCase().includes('mobile legends') ||
          g.name?.toLowerCase().includes('mlbb') ||
          g.id?.toLowerCase().includes('mlbb')
      ) || null
    );
  }, [games]);

  // Merge packages with store prices if available
  const packagesList = useMemo(() => {
    if (storeMlGame?.packages && storeMlGame.packages.length > 0) {
      return storeMlGame.packages.map((pkg) => ({
        ...pkg,
        product_id: getMlbbProductId(pkg),
      }));
    }
    return DEFAULT_ML_PACKAGES;
  }, [storeMlGame]);

  // Form State
  const [userId, setUserId] = useState('');
  const [zoneId, setZoneId] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [selectedPkg, setSelectedPkg] = useState<GamePackage | null>(packagesList[4] || packagesList[0]);
  const [paymentMethodChoice, setPaymentMethodChoice] = useState<PaymentMethodChoice>('wallet');

  // Inline UID Verification State (NO MODAL POPUP)
  const [isVerifyingUid, setIsVerifyingUid] = useState(false);
  const [verifiedIGN, setVerifiedIGN] = useState<string | null>(null);
  const [uidError, setUidError] = useState<string | null>(null);

  // Field errors
  const [userIdError, setUserIdError] = useState('');
  const [zoneIdError, setZoneIdError] = useState('');
  const [pkgError, setPkgError] = useState('');
  const [generalError, setGeneralError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Inline Player Verification (NO POPUP)
  const handleVerifyPlayerInline = async () => {
    setUserIdError('');
    setZoneIdError('');
    setUidError(null);

    const u = userId.trim();
    const z = zoneId.trim();

    if (!u) {
      setUserIdError('Please enter your User ID');
      return;
    }
    if (!z) {
      setZoneIdError('Please enter your Zone ID');
      return;
    }

    setIsVerifyingUid(true);
    const productId = selectedPkg ? getMlbbProductId(selectedPkg) : undefined;

    try {
      // 1. Check via Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('check-uid', {
        body: {
          product_id: productId,
          uid: u,
          zone_id: z,
          gameId: 'mlbb',
        },
      });

      if (data && data.success && (data.ign || data.playerName || data.username)) {
        const ign = data.ign || data.playerName || data.username;
        setVerifiedIGN(ign);
        setUidError(null);
        return;
      }

      // 2. Fallback via local proxy endpoint
      const fallbackRes = await fetch('/api/game/check-uid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product_id: productId,
          uid: u,
          zone_id: z,
          gameId: 'mlbb',
        }),
      });

      const fallbackData = await fallbackRes.json();
      if (fallbackData && fallbackData.success && (fallbackData.ign || fallbackData.playerName)) {
        setVerifiedIGN(fallbackData.ign || fallbackData.playerName);
        setUidError(null);
        return;
      }

      throw new Error(fallbackData?.message || data?.message || 'Player not found. Check User ID and Zone ID.');
    } catch (err: any) {
      setVerifiedIGN(null);
      setUidError(err?.message || 'Player verification failed. Please check your IDs.');
    } finally {
      setIsVerifyingUid(false);
    }
  };

  const handleBuyNowClick = async () => {
    setUserIdError('');
    setZoneIdError('');
    setPkgError('');
    setGeneralError('');

    let hasError = false;

    if (!userId.trim()) {
      setUserIdError('Please enter your User ID');
      hasError = true;
    }

    if (!zoneId.trim()) {
      setZoneIdError('Please enter your Zone ID');
      hasError = true;
    }

    if (!selectedPkg) {
      setPkgError('Please select a diamond package');
      hasError = true;
    }

    if (hasError) return;

    if (!isLoggedIn) {
      onOpenAuth();
      return;
    }

    const price = selectedPkg?.priceNpr || 0;

    // Balance check for wallet payment
    if (paymentMethodChoice === 'wallet' && user.walletBalanceNpr < price) {
      setGeneralError(`Insufficient wallet balance. You need Rs. ${price} (Current: Rs. ${user.walletBalanceNpr})`);
      return;
    }

    const mlGameObj: Game = storeMlGame || {
      id: 'mlbb',
      name: 'Mobile Legends',
      category: 'Mobile Games',
      iconUrl: '',
      bannerUrl: '',
      requireUid: true,
      requireZoneId: true,
      packages: packagesList,
    };

    const finalPlayerName = verifiedIGN || `MLBB Player (${userId.trim()})`;

    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      // Send directly to the unified checkout router (NO extra modal popups!)
      await onInitiatePayment({
        game: mlGameObj,
        playerUid: userId.trim(),
        playerName: finalPlayerName,
        zoneId: zoneId.trim(),
        userWhatsapp: whatsapp.trim() || undefined,
        selectedPackage: selectedPkg!,
        quantity: 1,
        totalPriceNpr: price,
        paymentMethodChoice: paymentMethodChoice,
        uidVerified: !!verifiedIGN,
        uidVerifiedAt: verifiedIGN ? new Date().toISOString() : undefined,
      });
    } finally {
      setTimeout(() => setIsSubmitting(false), 1500);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white font-sans selection:bg-red-600 selection:text-white pb-32">
      {/* Global Store Header */}
      <Header
        walletBalance={user.walletBalanceNpr}
        isLoggedIn={isLoggedIn}
        userName={user.username}
        onOpenProfile={() => onNavigate('/account')}
        onOpenWalletAdd={onOpenWalletAdd}
        onOpenHelp={() => onNavigate('/account/support')}
        onOpenNotifications={() => onNavigate('/notifications')}
        onOpenAuth={onOpenAuth}
        onNavigate={onNavigate}
        authChecked={true}
      />

      {/* Sub-header Title Strip (Page Content) */}
      <div className="bg-[#141414] border-b border-white/10 px-4 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('/')}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white transition cursor-pointer"
              title="Back to Store"
            >
              <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <div>
              <h1 className="font-extrabold text-sm sm:text-lg text-white leading-tight flex items-center gap-2">
                <span>Mobile Legends</span>
                <span className="bg-red-600/20 text-red-400 border border-red-500/30 text-[9px] sm:text-[10px] uppercase font-black px-2 py-0.5 rounded-md">
                  BR SERVER
                </span>
              </h1>
              <p className="text-[10px] sm:text-[11px] text-zinc-400 font-medium">Instant Diamond Top-Up</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="max-w-5xl mx-auto px-4 pt-6 space-y-6">
        {/* Banner Notice Card */}
        <section className="bg-gradient-to-r from-red-950/40 via-[#181212] to-[#141414] border border-red-500/30 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-red-600/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/40 text-red-400 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Info className="w-5 h-5" />
            </div>
            <div className="space-y-1 text-xs sm:text-sm">
              <h3 className="font-extrabold text-white text-sm sm:text-base">Top-Up Delivery Policy</h3>
              <ul className="text-zinc-300 space-y-1 list-disc list-inside text-xs leading-relaxed">
                <li>Fonepay Hub QR orders will be processed ONLY after payment is completed on the QR code.</li>
                <li>Diamonds will be credited within a few minutes after verified payment.</li>
                <li>All Mobile Legends purchases are final once processed.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Step 1: Account Details */}
        <section className="bg-[#141414] border border-white/10 rounded-2xl p-5 sm:p-6 shadow-md space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-extrabold text-xs flex items-center justify-center">
                1
              </div>
              <h2 className="font-extrabold text-base text-white">Enter Account Details</h2>
            </div>

            {/* Inline Verified IGN Badge */}
            {verifiedIGN && (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold animate-in fade-in">
                <CheckCircle2 className="w-4 h-4" />
                <span>IGN: {verifiedIGN}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* User ID input */}
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 flex items-center gap-1.5">
                <Gamepad2 className="w-3.5 h-3.5 text-red-500" />
                <span>User ID</span>
                <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. 12345678"
                value={userId}
                onChange={(e) => {
                  setUserId(e.target.value);
                  setVerifiedIGN(null);
                  if (userIdError) setUserIdError('');
                  if (uidError) setUidError(null);
                }}
                className={`w-full bg-[#1c1c1c] border ${
                  userIdError ? 'border-red-500' : 'border-white/10 focus:border-red-500'
                } rounded-xl px-3.5 py-3 text-sm text-white placeholder:text-zinc-600 font-mono focus:outline-none transition`}
              />
              {userIdError && <p className="text-xs text-red-400 mt-1 font-medium">{userIdError}</p>}
            </div>

            {/* Zone ID input */}
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-red-500" />
                <span>Zone ID / Server ID</span>
                <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. 1234"
                value={zoneId}
                onChange={(e) => {
                  setZoneId(e.target.value);
                  setVerifiedIGN(null);
                  if (zoneIdError) setZoneIdError('');
                  if (uidError) setUidError(null);
                }}
                className={`w-full bg-[#1c1c1c] border ${
                  zoneIdError ? 'border-red-500' : 'border-white/10 focus:border-red-500'
                } rounded-xl px-3.5 py-3 text-sm text-white placeholder:text-zinc-600 font-mono focus:outline-none transition`}
              />
              {zoneIdError && <p className="text-xs text-red-400 mt-1 font-medium">{zoneIdError}</p>}
            </div>
          </div>

          {/* Inline Verify Player Button */}
          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={handleVerifyPlayerInline}
              disabled={isVerifyingUid || !userId.trim() || !zoneId.trim()}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 disabled:opacity-40 text-xs font-bold text-zinc-300 hover:text-white rounded-xl transition cursor-pointer flex items-center gap-2"
            >
              {isVerifyingUid ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-red-500" />
                  <span>Checking IGN...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-red-500" />
                  <span>Verify Player Name</span>
                </>
              )}
            </button>

            {uidError && <p className="text-xs text-red-400 font-medium">{uidError}</p>}
          </div>

          {/* Optional WhatsApp Number */}
          <div>
            <label className="block text-xs font-bold text-zinc-400 mb-1.5 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-zinc-500" />
              <span>WhatsApp Number (Optional)</span>
            </label>
            <input
              type="tel"
              placeholder="+977 98XXXXXXXX"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              className="w-full bg-[#1c1c1c] border border-white/10 focus:border-red-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none transition"
            />
          </div>
        </section>

        {/* Step 2: Package Selection */}
        <section className="bg-[#141414] border border-white/10 rounded-2xl p-5 sm:p-6 shadow-md space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-extrabold text-xs flex items-center justify-center">
                2
              </div>
              <h2 className="font-extrabold text-base text-white">Select Diamond Package</h2>
            </div>
            {selectedPkg && (
              <span className="text-xs text-zinc-400">
                Selected: <strong className="text-red-400">{selectedPkg.name}</strong>
              </span>
            )}
          </div>

          {pkgError && (
            <p className="text-xs text-red-400 font-medium bg-red-500/10 border border-red-500/20 p-2.5 rounded-xl">
              {pkgError}
            </p>
          )}

          {/* Package Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
            {packagesList.map((pkg) => (
              <MLPackageCard
                key={pkg.id}
                pkg={pkg}
                isSelected={selectedPkg?.id === pkg.id}
                onSelect={(p) => {
                  setSelectedPkg(p);
                  if (pkgError) setPkgError('');
                  if (generalError) setGeneralError('');
                  setTimeout(() => {
                    const payEl = document.getElementById('mlbb-payment-method-section');
                    if (payEl) {
                      payEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                  }, 100);
                }}
              />
            ))}
          </div>
        </section>

        {/* Step 3: Payment Method Selection */}
        <section id="mlbb-payment-method-section" className="bg-[#141414] border border-white/10 rounded-2xl p-5 sm:p-6 shadow-md space-y-4 scroll-mt-20">
          <div className="flex items-center gap-2.5 pb-3 border-b border-white/10">
            <div className="w-7 h-7 rounded-lg bg-red-600 text-white font-extrabold text-xs flex items-center justify-center">
              3
            </div>
            <h2 className="font-extrabold text-base text-white">Select Payment Method</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {/* Option 1: UG Wallet */}
            <button
              type="button"
              onClick={() => setPaymentMethodChoice('wallet')}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3.5 ${
                paymentMethodChoice === 'wallet'
                  ? 'bg-red-600/10 border-red-600 ring-1 ring-red-600/50'
                  : 'bg-[#1a1a1a] border-white/10 hover:border-white/20'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  paymentMethodChoice === 'wallet' ? 'bg-red-600 text-white' : 'bg-white/5 text-zinc-400'
                }`}
              >
                <Wallet className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-sm text-white">UG Wallet</h4>
                  {paymentMethodChoice === 'wallet' && (
                    <span className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </span>
                  )}
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Instant balance deduction (Current: Rs. {user.walletBalanceNpr.toLocaleString('en-IN')})
                </p>
              </div>
            </button>

            {/* Option 2: Fonepay Hub Gateway */}
            <button
              type="button"
              onClick={() => setPaymentMethodChoice('fonepay_hub')}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3.5 ${
                paymentMethodChoice === 'fonepay_hub'
                  ? 'bg-red-600/10 border-red-600 ring-1 ring-red-600/50'
                  : 'bg-[#1a1a1a] border-white/10 hover:border-white/20'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  paymentMethodChoice === 'fonepay_hub' ? 'bg-red-600 text-white' : 'bg-white/5 text-zinc-400'
                }`}
              >
                <QrCode className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-sm text-white">Fonepay Hub QR Payment</h4>
                  {paymentMethodChoice === 'fonepay_hub' && (
                    <span className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </span>
                  )}
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Scan QR via eSewa, Khalti, IME Pay & Mobile Banking
                </p>
              </div>
            </button>
          </div>
        </section>

        {generalError && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-4 text-xs text-red-400 font-medium flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>{generalError}</span>
            </div>
            <button
              type="button"
              onClick={onOpenWalletAdd}
              className="px-3 py-1 bg-red-600 text-white font-bold rounded-lg text-xs hover:bg-red-500 transition cursor-pointer"
            >
              Add Funds
            </button>
          </div>
        )}
      </main>

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#121212]/95 backdrop-blur-md border-t border-white/10 p-3.5 sm:p-4 shadow-2xl">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">
              TOTAL PRICE
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg sm:text-2xl font-black text-red-500">
                Rs. {selectedPkg?.priceNpr ? selectedPkg.priceNpr.toLocaleString('en-IN') : '0'}
              </span>
              {selectedPkg && (
                <span className="text-xs text-zinc-400 font-medium hidden sm:inline">
                  ({selectedPkg.name})
                </span>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={handleBuyNowClick}
            disabled={!selectedPkg || isSubmitting}
            className="px-6 sm:px-10 py-3.5 rounded-xl font-extrabold text-white text-sm sm:text-base shadow-xl transition-all cursor-pointer disabled:opacity-40 active:scale-[0.98] flex items-center gap-2"
            style={{
              background: selectedPkg && !isSubmitting
                ? 'linear-gradient(135deg, #dc2626, #b91c1c)'
                : '#27272a',
              boxShadow: selectedPkg && !isSubmitting ? '0 4px 20px rgba(220,38,38,0.4)' : 'none',
            }}
          >
            {isSubmitting ? (
              <span>Processing...</span>
            ) : (
              <>
                <span>
                  {paymentMethodChoice === 'fonepay_hub'
                    ? `Scan & Pay Rs. ${selectedPkg?.priceNpr || 0}`
                    : `Pay Rs. ${selectedPkg?.priceNpr || 0} via Wallet`}
                </span>
                <span className="text-lg">→</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
