import React, { useState, useMemo, useEffect } from 'react';
import {
  HelpCircle,
  Plus,
  Minus,
  Search,
  ArrowLeft,
  MessageCircle,
  ShieldCheck,
  ChevronRight,
  Headphones,
} from 'lucide-react';
import { UserProfile, AdminNotification } from '../types';
import { Header } from '../components/Header';

interface FaqPageProps {
  user: UserProfile;
  isLoggedIn: boolean;
  onNavigate: (path: string) => void;
  onOpenAuth?: () => void;
  onOpenWalletAdd?: () => void;
  onOpenProfile?: () => void;
  onOpenAdmin?: () => void;
  onLogout?: () => void;
  adminNotification?: AdminNotification | null;
}

interface FaqItem {
  id: number;
  question: string;
  answer: string;
  category?: string;
}

const FAQ_DATA: FaqItem[] = [
  {
    id: 1,
    question: 'What is UGTOPUPS?',
    answer: 'UGTOPUPS is an online gaming platform where customers can purchase gaming products, top-ups, and digital services through a simple and secure website.',
    category: 'General',
  },
  {
    id: 2,
    question: 'How do I create an account on UGTOPUPS?',
    answer: 'Click Sign Up, enter your required information, verify your account if necessary, and log in to access your dashboard, orders, and other account features.',
    category: 'Account',
  },
  {
    id: 3,
    question: 'Do I need an account to place an order?',
    answer: 'An account is recommended because it allows you to track your orders, manage your profile, view order history, and access your purchase information easily.',
    category: 'Orders',
  },
  {
    id: 4,
    question: 'What payment methods are available?',
    answer: 'UGTOPUPS supports the payment methods currently available on the website, which may include wallet balance, online payment gateways, and other supported payment options.',
    category: 'Payment',
  },
  {
    id: 5,
    question: 'How can I check my order status?',
    answer: 'You can open Order History from your account and select an order to view its current status, payment information, and order details.',
    category: 'Orders',
  },
  {
    id: 6,
    question: 'Where can I manage my account information?',
    answer: 'You can manage your personal information, account settings, and other available preferences through your Profile / Account Settings section.',
    category: 'Account',
  },
  {
    id: 7,
    question: 'Is my account information secure?',
    answer: 'UGTOPUPS uses authentication and secure backend/database systems to protect customer account and order information. Never share your password or login credentials with anyone.',
    category: 'Security',
  },
  {
    id: 8,
    question: 'Can I view my previous orders?',
    answer: 'Yes. Your completed and previous purchases can be viewed through the Order History section of your account.',
    category: 'Orders',
  },
  {
    id: 9,
    question: 'What happens after I complete a payment?',
    answer: 'Once your payment is successfully verified, your order is processed through the website\'s order system and its status is updated accordingly.',
    category: 'Payment',
  },
  {
    id: 10,
    question: 'What should I do if I have a problem with my order?',
    answer: 'Open your order details first to check the current status. If you still need assistance, contact UGTOPUPS support and provide your Order ID and a description of the problem.',
    category: 'Support',
  },
  {
    id: 11,
    question: 'Can I use UGTOPUPS on my mobile phone?',
    answer: 'Yes. The website is designed to work on both desktop and mobile devices, allowing you to browse products, place orders, manage your account, and check your orders from your phone.',
    category: 'General',
  },
  {
    id: 12,
    question: 'How can I contact UGTOPUPS support?',
    answer: 'You can contact the UGTOPUPS support team through the support/contact option available on the website. When contacting support, include your Order ID and relevant details so your issue can be handled faster.',
    category: 'Support',
  },
];

export const FaqPage: React.FC<FaqPageProps> = ({
  user,
  isLoggedIn,
  onNavigate,
  onOpenAuth,
  onOpenWalletAdd,
  onOpenProfile,
  onOpenAdmin,
  onLogout,
  adminNotification,
}) => {
  const [openIds, setOpenIds] = useState<number[]>([1]); // default open first FAQ
  const [searchQuery, setSearchQuery] = useState('');

  // Scroll to top immediately when visiting FAQ page
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const toggleFaq = (id: number) => {
    setOpenIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredFaqs = useMemo(() => {
    if (!searchQuery.trim()) return FAQ_DATA;
    const q = searchQuery.toLowerCase();
    return FAQ_DATA.filter(
      (item) =>
        item.question.toLowerCase().includes(q) ||
        item.answer.toLowerCase().includes(q) ||
        (item.category && item.category.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans flex flex-col selection:bg-red-500 selection:text-white pb-12 sm:pb-16">
      {/* Universal Header */}
      <Header
        walletBalance={user.walletBalanceNpr}
        isLoggedIn={isLoggedIn}
        userName={user.username}
        avatarUrl={user.avatarUrl}
        user={user}
        onOpenProfile={() => onOpenProfile?.()}
        onOpenWalletAdd={() => onOpenWalletAdd?.()}
        onOpenHelp={() => onNavigate('/faq')}
        onOpenAdmin={onOpenAdmin}
        onOpenNotifications={() => onNavigate('/notifications')}
        adminNotification={adminNotification}
        onOpenAuth={onOpenAuth}
        onLogout={onLogout}
        onNavigate={onNavigate}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-10 space-y-6 sm:space-y-8">
        
        {/* Navigation Breadcrumb & Back */}
        <div className="flex items-center justify-between gap-3">
          <button
            onClick={() => onNavigate('/')}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:text-red-600 hover:border-red-200 hover:shadow-xs transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-red-600" />
            <span>Back to Home</span>
          </button>

          <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-medium">
            <span className="cursor-pointer hover:text-red-600" onClick={() => onNavigate('/')}>Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-red-600 font-bold">FAQ</span>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-white border border-zinc-200/90 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden space-y-4">
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-50 text-red-600 border border-red-100 flex items-center justify-center shadow-xs">
              <HelpCircle className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-red-600 tracking-wider uppercase bg-red-50 px-2.5 py-1 rounded-lg border border-red-100">
              Help & Support Center
            </span>
          </div>

          <div className="space-y-1.5">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-zinc-900 tracking-tight">
              UGTOPUPS — Frequently Asked Questions
            </h1>
            <p className="text-xs sm:text-sm text-zinc-600 font-medium max-w-2xl leading-relaxed">
              Find answers to common questions regarding account registration, wallet recharge, top-up delivery, and order tracking.
            </p>
          </div>

          {/* Search Box */}
          <div className="pt-2">
            <div className="relative">
              <Search className="w-4 h-4 text-zinc-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search question, topic, or keyword (e.g. order, payment, account)..."
                className="w-full pl-11 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-xs sm:text-sm text-zinc-900 placeholder:text-zinc-400 font-medium outline-none focus:bg-white focus:border-red-500 focus:ring-2 focus:ring-red-500/10 transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400 hover:text-zinc-700 bg-zinc-200 hover:bg-zinc-300 rounded-full px-2 py-0.5"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Accordion FAQ List */}
        <div className="space-y-3">
          {filteredFaqs.length === 0 ? (
            <div className="bg-white border border-zinc-200/90 rounded-2xl p-10 text-center space-y-3">
              <HelpCircle className="w-10 h-10 text-zinc-300 mx-auto" />
              <p className="text-sm font-bold text-zinc-700">No questions match "{searchQuery}"</p>
              <p className="text-xs text-zinc-400">Try searching for a different keyword or browse all questions.</p>
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700 transition-colors cursor-pointer"
              >
                Show All FAQs
              </button>
            </div>
          ) : (
            filteredFaqs.map((faq) => {
              const isOpen = openIds.includes(faq.id);
              return (
                <div
                  key={faq.id}
                  className={`bg-white border rounded-2xl transition-all duration-200 overflow-hidden shadow-xs ${
                    isOpen
                      ? 'border-red-500/60 shadow-md ring-1 ring-red-500/10'
                      : 'border-zinc-200/90 hover:border-zinc-300'
                  }`}
                >
                  {/* Question Row (Clickable) */}
                  <button
                    type="button"
                    onClick={() => toggleFaq(faq.id)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer select-none transition-colors"
                  >
                    <div className="flex items-start sm:items-center gap-3 min-w-0">
                      <span className="w-6 h-6 rounded-full bg-red-50 text-red-600 border border-red-200 text-xs font-semibold flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-0">
                        {faq.id}
                      </span>
                      <h3 className="font-semibold text-sm sm:text-[15px] text-zinc-900 leading-snug tracking-normal">
                        {faq.question}
                      </h3>
                    </div>

                    {/* Plus / Minus Button */}
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-200 ${
                        isOpen
                          ? 'bg-red-600 text-white shadow-xs rotate-180'
                          : 'bg-zinc-100 text-zinc-600 hover:bg-red-50 hover:text-red-600'
                      }`}
                    >
                      {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </div>
                  </button>

                  {/* Answer (Normal font weight, unbolded as requested) */}
                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-5 pt-1 border-t border-zinc-100">
                      <div className="pl-9 pr-2">
                        <p className="text-xs sm:text-sm text-zinc-600 font-normal leading-relaxed">
                          {faq.answer}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Still Need Help Support Card */}
        <div className="bg-gradient-to-r from-red-600 to-red-700 text-white rounded-3xl p-6 sm:p-8 shadow-lg shadow-red-600/15 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/15 text-[11px] font-bold tracking-wider uppercase backdrop-blur-xs">
              <Headphones className="w-3.5 h-3.5" /> 24/7 Live Support
            </div>
            <h3 className="text-xl sm:text-2xl font-black tracking-tight">
              Still have questions or need assistance?
            </h3>
            <p className="text-xs sm:text-sm text-red-100 font-normal max-w-md">
              Our customer support team is available 24/7 to help resolve order issues, top-up queries, or payment verifications.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            <button
              onClick={() => onNavigate('/account/support')}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-white text-red-600 hover:bg-red-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" /> Contact Support
            </button>
            <button
              onClick={() => onNavigate('/account/orders')}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-red-800/80 hover:bg-red-800 text-white font-bold text-xs transition-all border border-white/20 cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" /> View My Orders
            </button>
          </div>
        </div>

      </main>
    </div>
  );
};
