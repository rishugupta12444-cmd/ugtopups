import React from 'react';
import { Headphones, PhoneCall, Mail, Clock } from 'lucide-react';
import { AccountLayout } from '../../components/account/AccountLayout';
import { UserProfile } from '../../types';

interface SupportPageProps {
  onNavigate: (path: string) => void;
  user?: UserProfile;
}

export const SupportPage: React.FC<SupportPageProps> = ({ onNavigate, user }) => {
  return (
    <AccountLayout
      title="Support"
      subtitle="We're here to help 24/7"
      icon={Headphones}
      breadcrumbs={[{ label: 'My Account', path: '/account' }, { label: 'Support' }]}
      onNavigate={onNavigate}
      walletBalance={user?.walletBalanceNpr}
      userName={user?.username || user?.fullName}
      avatarUrl={user?.avatarUrl}
    >
      <div className="max-w-2xl space-y-4 text-xs font-sans">
        <div className="p-5 sm:p-6 rounded-2xl bg-white border border-zinc-200/90 shadow-sm space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-red-50 border border-red-200 text-red-600 flex items-center justify-center shadow-xs">
              <Headphones className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h4 className="font-black text-zinc-900 text-base tracking-tight">Customer Support</h4>
              <p className="text-zinc-500 text-xs font-medium">We're here to help 24/7</p>
            </div>
          </div>

          <p className="text-zinc-600 leading-relaxed text-xs">
            Have questions about your top-up order, wallet, or account? Our support team in Nepal is here to help you anytime.
          </p>

          <div className="space-y-2.5">
            {[
              {
                label: 'WhatsApp',
                value: '+977 9708562001',
                icon: PhoneCall,
                href: 'https://wa.me/9779708562001',
              },
              {
                label: 'Email',
                value: 'support@ugtopups.com',
                icon: Mail,
                href: 'mailto:support@ugtopups.com',
              },
              {
                label: 'Hours',
                value: '24/7 Auto & Live Support',
                icon: Clock,
                href: undefined,
              },
            ].map(({ label, value, icon: Icon, href }) => {
              const content = (
                <div className="flex items-center gap-3 p-3.5 rounded-xl bg-zinc-50 hover:bg-red-50/40 border border-zinc-200/80 hover:border-red-200 transition-all">
                  <div className="w-7 h-7 rounded-lg bg-white border border-zinc-200 text-red-600 flex items-center justify-center flex-shrink-0 shadow-2xs">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-zinc-500 font-semibold w-20 flex-shrink-0 text-xs">{label}:</span>
                  <span className="text-zinc-900 font-bold truncate text-xs">{value}</span>
                </div>
              );

              return href ? (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block cursor-pointer"
                >
                  {content}
                </a>
              ) : (
                <div key={label}>{content}</div>
              );
            })}
          </div>
        </div>

        <a
          href="https://wa.me/9779708562001"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full py-3.5 bg-red-600 hover:bg-red-700 active:scale-[0.99] text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md shadow-red-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Headphones className="w-4 h-4" />
          Chat with Support on WhatsApp
        </a>

        <button
          onClick={() => onNavigate('/faq')}
          className="w-full py-3 bg-white hover:bg-zinc-50 border border-zinc-200 text-zinc-700 hover:text-red-600 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-2xs"
        >
          Browse Frequently Asked Questions (FAQ)
        </button>
      </div>
    </AccountLayout>
  );
};
