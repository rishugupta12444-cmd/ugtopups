import React, { useEffect, useState } from 'react';
import {
  Wallet, Eye, CheckCircle2, XCircle, Clock, AlertCircle,
  Search, Filter, RefreshCw, User, CreditCard, Calendar,
  Hash, ImageIcon, TrendingUp, CheckCheck, Loader2,
  X, ChevronDown,
} from 'lucide-react';
import { AccountLayout } from '../../components/account/AccountLayout';
import { UserProfile, WalletTransaction } from '../../types';
import {
  subscribeAllWalletRequests,
  approveWalletRequest,
  rejectWalletRequest,
  WalletRequestRecord,
} from '../../lib/store';

/* ─────────────────────────────────────────────────────────────── */
/*  Props                                                           */
/* ─────────────────────────────────────────────────────────────── */
interface InstantWalletLoadProps {
  user: UserProfile;
  walletHistory: WalletTransaction[];
  onNavigate: (path: string) => void;
  /** Legacy prop — kept for backward-compat, unused in new UI */
  onInitiateWalletAdd?: (amount: number) => Promise<void>;
  onManualWalletRequest?: (amount: number, screenshot: File, refNumber?: string) => Promise<void>;
}

/* ─────────────────────────────────────────────────────────────── */
/*  Helpers                                                         */
/* ─────────────────────────────────────────────────────────────── */
type StatusFilter = 'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED';

const statusConfig = {
  PENDING:  { label: 'Pending',  icon: Clock,         color: 'text-amber-400',  bg: 'bg-amber-950/50',  border: 'border-amber-800/50' },
  APPROVED: { label: 'Approved', icon: CheckCircle2,  color: 'text-emerald-400',bg: 'bg-emerald-950/50',border: 'border-emerald-800/50' },
  REJECTED: { label: 'Rejected', icon: XCircle,       color: 'text-red-400',    bg: 'bg-red-950/50',    border: 'border-red-800/50' },
} as const;

/* ─────────────────────────────────────────────────────────────── */
/*  Component                                                       */
/* ─────────────────────────────────────────────────────────────── */
export const InstantWalletLoad: React.FC<InstantWalletLoadProps> = ({
  user, onNavigate,
}) => {
  /* ── data ── */
  const [requests, setRequests] = useState<WalletRequestRecord[]>([]);
  const [loading, setLoading] = useState(true);

  /* ── filters ── */
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('ALL');

  /* ── modals ── */
  const [screenshotModal, setScreenshotModal] = useState<WalletRequestRecord | null>(null);
  const [rejectModal, setRejectModal] = useState<WalletRequestRecord | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  /* ── action states ── */
  const [approvingId, setApprovingId] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ text: string; ok: boolean } | null>(null);

  /* ── real-time subscription ── */
  useEffect(() => {
    const unsub = subscribeAllWalletRequests((list) => {
      setRequests(list);
      setLoading(false);
    });
    return () => { if (typeof unsub === 'function') unsub(); };
  }, []);

  const showToast = (text: string, ok: boolean) => {
    setToast({ text, ok });
    setTimeout(() => setToast(null), 3500);
  };

  /* ── filtered list ── */
  const filtered = requests.filter((r) => {
    if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        r.username?.toLowerCase().includes(q) ||
        r.email?.toLowerCase().includes(q) ||
        r.uid?.toLowerCase().includes(q) ||
        r.paymentMethod?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  /* ── summary stats ── */
  const stats = {
    total:    requests.length,
    pending:  requests.filter(r => r.status === 'PENDING').length,
    approved: requests.filter(r => r.status === 'APPROVED').length,
    rejected: requests.filter(r => r.status === 'REJECTED').length,
    totalNpr: requests.filter(r => r.status === 'APPROVED').reduce((s, r) => s + r.amountNpr, 0),
  };

  /* ── approve handler ── */
  const handleApprove = async (req: WalletRequestRecord) => {
    setApprovingId(req.id);
    try {
      const ok = await approveWalletRequest(req);
      showToast(ok ? `✅ Wallet credited NPR ${req.amountNpr.toLocaleString()} to ${req.username}` : 'Approval failed. Check console.', ok);
    } catch {
      showToast('Unexpected error during approval.', false);
    } finally {
      setApprovingId(null);
    }
  };

  /* ── reject handler ── */
  const handleReject = async () => {
    if (!rejectModal) return;
    setRejectingId(rejectModal.id);
    try {
      const ok = await rejectWalletRequest(rejectModal.id, rejectReason.trim() || 'Rejected by admin');
      showToast(ok ? `Request from ${rejectModal.username} rejected.` : 'Rejection failed. Check console.', ok);
      setRejectModal(null);
      setRejectReason('');
    } catch {
      showToast('Unexpected error during rejection.', false);
    } finally {
      setRejectingId(null);
    }
  };

  /* ══════════════════════════════════════════════════════════════ */
  /*  MAIN RENDER                                                   */
  /* ══════════════════════════════════════════════════════════════ */
  return (
    <AccountLayout
      title="Wallet Load Requests"
      subtitle="Review and approve user payment proofs"
      icon={Wallet}
      breadcrumbs={[{ label: 'Admin', path: '/admin' }, { label: 'Wallet Load Requests' }]}
      onNavigate={onNavigate}
    >
      {/* ── Toast ── */}
      {toast && (
        <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-xs shadow-2xl whitespace-nowrap ${
          toast.ok ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'
        }`}>
          {toast.ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.text}
        </div>
      )}

      {/* ── Screenshot Modal ── */}
      {screenshotModal && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setScreenshotModal(null)}>
          <div
            className="w-full max-w-lg bg-[#0d111d] border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-red-600/10 border border-red-500/20 flex items-center justify-center">
                  <ImageIcon className="w-4 h-4 text-red-400" />
                </div>
                <div>
                  <p className="text-sm font-black text-white">Payment Screenshot</p>
                  <p className="text-[10px] text-zinc-500">{screenshotModal.username}</p>
                </div>
              </div>
              <button
                onClick={() => setScreenshotModal(null)}
                className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Screenshot */}
            <div className="relative bg-zinc-950 flex items-center justify-center min-h-[260px] max-h-[400px] overflow-hidden">
              {screenshotModal.screenshotUrl ? (
                <img
                  src={screenshotModal.screenshotUrl}
                  alt="Payment Proof"
                  className="max-w-full max-h-[400px] object-contain"
                  onError={(e) => {
                    const img = e.target as HTMLImageElement;
                    img.onerror = null;
                    img.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="120" viewBox="0 0 200 120"><rect fill="%23111" width="200" height="120"/><text fill="%23555" x="50%" y="50%" text-anchor="middle" dy=".3em" font-size="12">No preview</text></svg>';
                  }}
                />
              ) : (
                <div className="flex flex-col items-center gap-3 text-zinc-600 py-10">
                  <ImageIcon className="w-10 h-10" />
                  <p className="text-xs">No screenshot on file</p>
                </div>
              )}
            </div>

            {/* Details Grid */}
            <div className="p-5 grid grid-cols-2 gap-3 text-xs">
              {[
                { icon: User,       label: 'User Name',       value: screenshotModal.username },
                { icon: Hash,       label: 'User ID',         value: screenshotModal.uid?.slice(0, 16) + '…' },
                { icon: CreditCard, label: 'Payment Method',  value: screenshotModal.paymentMethod || 'QR Transfer' },
                { icon: TrendingUp, label: 'Amount (NPR)',     value: `NPR ${screenshotModal.amountNpr?.toLocaleString('en-IN')}` },
                { icon: Calendar,   label: 'Request Time',    value: screenshotModal.formattedTime || '—' },
                { icon: CheckCheck, label: 'Status',          value: screenshotModal.status },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-start gap-2 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800">
                  <Icon className="w-3.5 h-3.5 text-zinc-500 mt-0.5 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">{label}</p>
                    <p className="text-white font-bold truncate mt-0.5">{value}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Actions inside modal for PENDING */}
            {screenshotModal.status === 'PENDING' && (
              <div className="px-5 pb-5 flex gap-3">
                <button
                  disabled={approvingId === screenshotModal.id}
                  onClick={async () => { await handleApprove(screenshotModal); setScreenshotModal(null); }}
                  className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
                >
                  {approvingId === screenshotModal.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Approve & Credit Wallet
                </button>
                <button
                  onClick={() => { setRejectModal(screenshotModal); setScreenshotModal(null); }}
                  className="flex-1 py-3 rounded-xl bg-red-600/20 hover:bg-red-600/30 border border-red-800/50 text-red-400 font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <XCircle className="w-4 h-4" />
                  Reject
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Reject Reason Modal ── */}
      {rejectModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4" onClick={() => { setRejectModal(null); setRejectReason(''); }}>
          <div
            className="w-full max-w-sm bg-[#0d111d] border border-zinc-800 rounded-3xl p-6 space-y-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-red-950/60 border border-red-800/40 flex items-center justify-center">
                  <XCircle className="w-4 h-4 text-red-400" />
                </div>
                <div>
                  <p className="text-sm font-black text-white">Reject Request</p>
                  <p className="text-[10px] text-zinc-500">{rejectModal.username} · NPR {rejectModal.amountNpr?.toLocaleString()}</p>
                </div>
              </div>
              <button onClick={() => { setRejectModal(null); setRejectReason(''); }} className="p-1.5 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-extrabold text-zinc-300">Rejection Reason (optional)</label>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="e.g. Screenshot unclear, amount mismatch, duplicate request…"
                rows={3}
                className="w-full bg-[#080b14] border border-zinc-800 rounded-xl px-4 py-3 text-white text-xs outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/30 transition-all placeholder-zinc-600 resize-none"
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => { setRejectModal(null); setRejectReason(''); }}
                className="flex-1 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                disabled={rejectingId === rejectModal.id}
                onClick={handleReject}
                className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-red-600/20"
              >
                {rejectingId === rejectModal.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════ */}
      {/*  PAGE BODY                                               */}
      {/* ════════════════════════════════════════════════════════ */}
      <div className="space-y-6 pb-8">

        {/* ── Stats Row ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Total Requests', value: stats.total,    icon: Filter,       color: 'text-zinc-300',   bg: 'bg-zinc-900',      border: 'border-zinc-800' },
            { label: 'Pending',        value: stats.pending,  icon: Clock,        color: 'text-amber-400',  bg: 'bg-amber-950/40',  border: 'border-amber-800/40' },
            { label: 'Approved',       value: stats.approved, icon: CheckCircle2, color: 'text-emerald-400',bg: 'bg-emerald-950/40',border: 'border-emerald-800/40' },
            { label: 'Rejected',       value: stats.rejected, icon: XCircle,      color: 'text-red-400',    bg: 'bg-red-950/40',    border: 'border-red-800/40' },
          ].map(({ label, value, icon: Icon, color, bg, border }) => (
            <div key={label} className={`${bg} ${border} border rounded-2xl p-4 flex items-center gap-3`}>
              <div className={`w-9 h-9 rounded-xl ${bg} border ${border} flex items-center justify-center flex-shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">{label}</p>
                <p className={`text-xl font-black ${color} font-mono`}>{value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* ── Total Credited ── */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 to-emerald-900/20 border border-emerald-800/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Total Wallet Credits (Approved)</p>
              <p className="font-black text-emerald-400 text-lg font-mono">NPR {stats.totalNpr.toLocaleString('en-IN')}</p>
            </div>
          </div>
          <button
            onClick={() => setLoading(true)}
            className="p-2 rounded-xl bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 hover:bg-emerald-900/40 transition-all cursor-pointer"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* ── Filters ── */}
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, email, user ID…"
              className="w-full bg-[#080b14] border border-zinc-800 rounded-xl pl-9 pr-4 py-2.5 text-white text-xs outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/30 transition-all placeholder-zinc-600"
            />
          </div>

          {/* Status filter */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              className="appearance-none bg-[#080b14] border border-zinc-800 rounded-xl pl-4 pr-8 py-2.5 text-white text-xs outline-none focus:border-red-500 transition-all cursor-pointer"
            >
              <option value="ALL">All Status</option>
              <option value="PENDING">Pending</option>
              <option value="APPROVED">Approved</option>
              <option value="REJECTED">Rejected</option>
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500 pointer-events-none" />
          </div>
        </div>

        {/* ── Table ── */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 gap-4">
            <Loader2 className="w-8 h-8 text-red-500 animate-spin" />
            <p className="text-xs text-zinc-500 font-semibold">Loading wallet requests…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center">
              <Wallet className="w-7 h-7 text-zinc-600" />
            </div>
            <div>
              <p className="text-sm font-black text-white">No requests found</p>
              <p className="text-xs text-zinc-500 mt-1">
                {search || statusFilter !== 'ALL' ? 'Try adjusting your filters.' : 'No wallet load requests have been submitted yet.'}
              </p>
            </div>
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden md:block rounded-2xl border border-zinc-800 overflow-hidden">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-zinc-900/80 border-b border-zinc-800">
                    {['User Name', 'Email Address', 'User ID', 'Payment Method', 'Amount (NPR)', 'Payment Status', 'Request Time', 'Screenshot', 'Actions'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left font-extrabold text-zinc-400 uppercase tracking-wider whitespace-nowrap">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((req, i) => {
                    const sc = statusConfig[req.status] ?? statusConfig.PENDING;
                    const ScIcon = sc.icon;
                    return (
                      <tr
                        key={req.id}
                        className={`border-b border-zinc-800/50 transition-colors hover:bg-zinc-900/40 ${i % 2 === 0 ? 'bg-transparent' : 'bg-zinc-900/20'}`}
                      >
                        {/* User Name */}
                        <td className="px-4 py-3.5 font-bold text-white whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-red-600/10 border border-red-500/20 flex items-center justify-center flex-shrink-0">
                              <User className="w-3.5 h-3.5 text-red-400" />
                            </div>
                            {req.username}
                          </div>
                        </td>

                        {/* Email */}
                        <td className="px-4 py-3.5 text-zinc-300 whitespace-nowrap max-w-[160px] truncate">{req.email || '—'}</td>

                        {/* User ID */}
                        <td className="px-4 py-3.5 font-mono text-zinc-500 whitespace-nowrap">
                          <span title={req.uid}>{req.uid ? req.uid.slice(0, 10) + '…' : '—'}</span>
                        </td>

                        {/* Payment Method */}
                        <td className="px-4 py-3.5 text-zinc-300 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <CreditCard className="w-3.5 h-3.5 text-zinc-500" />
                            {req.paymentMethod || 'QR Transfer'}
                          </div>
                        </td>

                        {/* Amount */}
                        <td className="px-4 py-3.5 font-black text-emerald-400 font-mono whitespace-nowrap">
                          NPR {req.amountNpr?.toLocaleString('en-IN')}
                        </td>

                        {/* Status Badge */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${sc.color} ${sc.bg} ${sc.border}`}>
                            <ScIcon className="w-3 h-3" />
                            {sc.label}
                          </span>
                        </td>

                        {/* Request Time */}
                        <td className="px-4 py-3.5 text-zinc-400 whitespace-nowrap font-mono text-[10px]">
                          {req.formattedTime || '—'}
                        </td>

                        {/* Screenshot */}
                        <td className="px-4 py-3.5">
                          <button
                            onClick={() => setScreenshotModal(req)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white font-bold text-[10px] transition-all cursor-pointer border border-zinc-700 hover:border-zinc-600"
                          >
                            <Eye className="w-3 h-3" />
                            View
                          </button>
                        </td>

                        {/* Actions */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          {req.status === 'PENDING' ? (
                            <div className="flex items-center gap-2">
                              <button
                                disabled={approvingId === req.id}
                                onClick={() => handleApprove(req)}
                                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold text-[10px] transition-all cursor-pointer shadow-md shadow-emerald-600/20"
                              >
                                {approvingId === req.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                                Approve
                              </button>
                              <button
                                onClick={() => { setRejectModal(req); setRejectReason(''); }}
                                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-600/20 hover:bg-red-600/30 border border-red-800/40 text-red-400 hover:text-red-300 font-extrabold text-[10px] transition-all cursor-pointer"
                              >
                                <XCircle className="w-3 h-3" />
                                Reject
                              </button>
                            </div>
                          ) : (
                            <span className="text-zinc-600 text-[10px] font-semibold italic">
                              {req.status === 'APPROVED' ? 'Credited ✓' : 'Rejected ✗'}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="md:hidden space-y-3">
              {filtered.map((req) => {
                const sc = statusConfig[req.status] ?? statusConfig.PENDING;
                const ScIcon = sc.icon;
                return (
                  <div key={req.id} className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4 space-y-3">
                    {/* Header row */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-red-600/10 border border-red-500/20 flex items-center justify-center">
                          <User className="w-4 h-4 text-red-400" />
                        </div>
                        <div>
                          <p className="font-black text-white text-sm">{req.username}</p>
                          <p className="text-[10px] text-zinc-500 font-mono truncate max-w-[160px]">{req.email}</p>
                        </div>
                      </div>
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${sc.color} ${sc.bg} ${sc.border}`}>
                        <ScIcon className="w-3 h-3" />
                        {sc.label}
                      </span>
                    </div>

                    {/* Info grid */}
                    <div className="grid grid-cols-2 gap-2 text-[10px]">
                      <div className="bg-zinc-900 rounded-lg p-2.5 border border-zinc-800">
                        <p className="text-zinc-500 font-semibold">Amount</p>
                        <p className="text-emerald-400 font-black font-mono mt-0.5">NPR {req.amountNpr?.toLocaleString('en-IN')}</p>
                      </div>
                      <div className="bg-zinc-900 rounded-lg p-2.5 border border-zinc-800">
                        <p className="text-zinc-500 font-semibold">Method</p>
                        <p className="text-white font-bold mt-0.5 truncate">{req.paymentMethod || 'QR Transfer'}</p>
                      </div>
                      <div className="col-span-2 bg-zinc-900 rounded-lg p-2.5 border border-zinc-800">
                        <p className="text-zinc-500 font-semibold">Request Time</p>
                        <p className="text-zinc-300 font-mono mt-0.5">{req.formattedTime || '—'}</p>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => setScreenshotModal(req)}
                        className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 border border-zinc-700"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        View Screenshot
                      </button>
                      {req.status === 'PENDING' && (
                        <>
                          <button
                            disabled={approvingId === req.id}
                            onClick={() => handleApprove(req)}
                            className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            {approvingId === req.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                            Approve
                          </button>
                          <button
                            onClick={() => { setRejectModal(req); setRejectReason(''); }}
                            className="flex-1 py-2.5 rounded-xl bg-red-600/20 border border-red-800/40 text-red-400 font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Row count */}
            <p className="text-center text-[10px] text-zinc-600 font-semibold">
              Showing {filtered.length} of {requests.length} request{requests.length !== 1 ? 's' : ''}
            </p>
          </>
        )}
      </div>
    </AccountLayout>
  );
};
