import React, { useRef, useState, useEffect } from 'react';
import {
  User, Camera, Loader2, Check, AlertCircle, Lock, Eye, EyeOff,
  Wallet, ListFilter, PhoneCall, ChevronRight,
  CreditCard, TrendingUp, ArrowDownLeft, ArrowUpRight,
  Package, Headphones, Plus, Coins,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { AccountLayout } from '../../components/account/AccountLayout';

interface AccountPageProps {
  user: UserProfile;
  onNavigate: (path: string) => void;
  onUpdateUsername?: (newUsername: string) => Promise<void>;
  onUpdatePassword?: (newPassword: string) => Promise<void>;
  onUpdateProfilePic?: (file: File) => Promise<void>;
  orders?: import('../../types').Order[];
  walletHistory?: import('../../types').WalletTransaction[];
}

// ── Design tokens ──────────────────────────────────────────────────────────
const T = {
  red:       '#E50914',
  redHover:  '#c0070f',
  redLight:  '#fff5f5',
  redBorder: '#fecaca',
  white:     '#FFFFFF',
  gray:      '#F5F5F5',
  border:    '#E8E8E8',
  text:      '#1a1a1a',
  muted:     '#666666',
  subtle:    '#999999',
  radius:    '20px',
};

const cardStyle: React.CSSProperties = {
  background: T.white,
  borderRadius: T.radius,
  border: `1.5px solid ${T.border}`,
  boxShadow: '0 2px 20px rgba(0,0,0,0.05)',
};

// ── Animated card wrapper ──────────────────────────────────────────────────

interface AnimCardProps {
  children: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
  animType?: 'fadeUp' | 'slideLeft' | 'fadeRight' | 'slideUp';
  delay?: number;
}

const AnimCard: React.FC<AnimCardProps> = ({ children, style, className = '', animType = 'fadeUp', delay = 0 }) => {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  const animations: Record<string, string> = {
    fadeUp:    'ugAnimFadeUp',
    slideLeft: 'ugAnimSlideLeft',
    fadeRight: 'ugAnimFadeRight',
    slideUp:   'ugAnimSlideUp',
  };

  return (
    <div
      ref={ref}
      className={`${className} ug-anim-card ${animations[animType]}`}
      style={{
        ...style,
        opacity: visible ? undefined : 0,
        animationDelay: visible ? `0ms` : `${delay}ms`,
        animationPlayState: visible ? 'running' : 'paused',
      }}
    >
      {children}
    </div>
  );
};

// ── Premium NavItem ────────────────────────────────────────────────────────

interface NavItemProps {
  path: string;
  icon: React.ElementType;
  label: string;
  sublabel?: string;
  active?: boolean;
  onNavigate: (path: string) => void;
  delay?: number;
}

const NavItem: React.FC<NavItemProps> = ({ path, icon: Icon, label, sublabel, active, onNavigate, delay = 0 }) => {
  const [hovered, setHovered] = useState(false);

  const handleClick = () => {
    // Smooth scroll to top then navigate
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => onNavigate(path), 120);
  };

  return (
    <button
      onClick={handleClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="w-full flex items-center gap-3.5 px-4 py-3.5 text-left cursor-pointer ug-nav-item"
      style={{
        background: active
          ? 'linear-gradient(90deg, #fff5f5 0%, #fff9f9 100%)'
          : hovered ? '#fafafa' : 'transparent',
        borderLeft: active ? `3px solid ${T.red}` : '3px solid transparent',
        borderRadius: active || hovered ? '0 12px 12px 0' : '0',
        margin: '1px 0',
        animationDelay: `${delay}ms`,
      }}
    >
      {/* Icon container */}
      <div
        className="flex items-center justify-center w-9 h-9 rounded-2xl flex-shrink-0 ug-nav-icon"
        style={{
          background: active
            ? 'linear-gradient(135deg, #ffe8e8, #ffd0d0)'
            : hovered ? '#fff0f0' : T.gray,
          border: active || hovered ? `1.5px solid ${T.redBorder}` : `1.5px solid ${T.border}`,
          boxShadow: active ? '0 2px 8px rgba(229,9,20,0.15)' : 'none',
        }}
      >
        <Icon
          className="w-4 h-4 ug-nav-icon-svg"
          style={{ color: active || hovered ? T.red : T.muted }}
        />
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <p
          className="text-xs font-bold truncate"
          style={{ color: active ? T.red : hovered ? T.red : T.text }}
        >
          {label}
        </p>
        {sublabel && (
          <p className="text-[10px] truncate mt-0.5" style={{ color: T.subtle }}>{sublabel}</p>
        )}
      </div>

      {/* Arrow */}
      <ChevronRight
        className="w-3.5 h-3.5 flex-shrink-0 ug-nav-arrow"
        style={{ color: active || hovered ? T.red : T.border }}
      />
    </button>
  );
};

interface InfoRowProps {
  icon: React.ElementType;
  label: string;
  value: string;
  valueStyle?: React.CSSProperties;
  mono?: boolean;
}

const InfoRow: React.FC<InfoRowProps> = ({ icon: Icon, label, value, valueStyle, mono }) => (
  <div
    className="flex items-center gap-3 py-3.5 border-b last:border-0 ug-info-row"
    style={{ borderColor: T.border }}
  >
    <div
      className="w-8 h-8 rounded-2xl flex items-center justify-center flex-shrink-0"
      style={{ background: '#fff5f5', border: `1.5px solid ${T.redBorder}` }}
    >
      <Icon className="w-3.5 h-3.5" style={{ color: T.red }} />
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: T.subtle }}>{label}</p>
      <p
        className={`text-xs font-bold mt-0.5 truncate ${mono ? 'font-mono' : ''}`}
        style={{ color: T.text, ...valueStyle }}
      >
        {value}
      </p>
    </div>
  </div>
);

// ── Skeleton loader ────────────────────────────────────────────────────────
const Skeleton: React.FC<{ w?: string; h?: string; rounded?: string }> = ({
  w = '100%', h = '14px', rounded = '8px',
}) => (
  <div
    className="ug-skeleton"
    style={{ width: w, height: h, borderRadius: rounded, background: '#f0f0f0' }}
  />
);

// ── Main Component ──────────────────────────────────────────────────────────

export const AccountPage: React.FC<AccountPageProps> = ({
  user, onNavigate, onUpdateUsername, onUpdatePassword, onUpdateProfilePic,
  orders = [], walletHistory = [],
}) => {
  const [newUsername, setNewUsername]       = useState(user.username);
  const [isSavingUsername, setIsSavingUsername] = useState(false);
  const [usernameMsg, setUsernameMsg]       = useState<{ text: string; ok: boolean } | null>(null);
  const [newPassword, setNewPassword]       = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPw, setShowPw]                 = useState(false);
  const [showConfirmPw, setShowConfirmPw]   = useState(false);
  const [isSavingPw, setIsSavingPw]         = useState(false);
  const [pwMsg, setPwMsg]                   = useState<{ text: string; ok: boolean } | null>(null);
  const [previewPic, setPreviewPic]         = useState<string | null>(null);
  const [isUploadingPic, setIsUploadingPic] = useState(false);
  const [pageReady, setPageReady]           = useState(false);

  // input focus states
  const [usernameFocused, setUsernameFocused] = useState(false);
  const [pwFocused, setPwFocused]             = useState(false);
  const [confirmFocused, setConfirmFocused]   = useState(false);

  // Mobile accordion nav state
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const picInputRef = useRef<HTMLInputElement>(null);
  const initialLetter = user.username ? user.username.charAt(0).toUpperCase() : 'U';

  useEffect(() => {
    const t = setTimeout(() => setPageReady(true), 80);
    return () => clearTimeout(t);
  }, []);

  const handlePicChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPreviewPic(URL.createObjectURL(file));
    if (!onUpdateProfilePic) return;
    setIsUploadingPic(true);
    try { await onUpdateProfilePic(file); } finally { setIsUploadingPic(false); }
  };

  const handleSaveUsername = async () => {
    if (!newUsername.trim() || newUsername.trim() === user.username) return;
    setIsSavingUsername(true); setUsernameMsg(null);
    try {
      if (onUpdateUsername) await onUpdateUsername(newUsername.trim());
      setUsernameMsg({ text: 'Username updated!', ok: true });
    } catch { setUsernameMsg({ text: 'Failed to update username.', ok: false }); }
    finally { setIsSavingUsername(false); setTimeout(() => setUsernameMsg(null), 3000); }
  };

  const handleSavePassword = async () => {
    if (newPassword.length < 6) { setPwMsg({ text: 'Password must be at least 6 characters.', ok: false }); return; }
    if (newPassword !== confirmPassword) { setPwMsg({ text: 'Passwords do not match.', ok: false }); return; }
    setIsSavingPw(true); setPwMsg(null);
    try {
      if (onUpdatePassword) await onUpdatePassword(newPassword);
      setPwMsg({ text: 'Password updated successfully!', ok: true });
      setNewPassword(''); setConfirmPassword('');
    } catch { setPwMsg({ text: 'Failed to update password.', ok: false }); }
    finally { setIsSavingPw(false); setTimeout(() => setPwMsg(null), 3500); }
  };

  const recentOrders  = orders.slice(0, 3);
  const recentWallet  = walletHistory.slice(0, 4);

  const inputStyle = (focused: boolean): React.CSSProperties => ({
    background: T.gray,
    border: `1.5px solid ${focused ? T.red : T.border}`,
    color: T.text,
    boxShadow: focused ? `0 0 0 3px rgba(229,9,20,0.12)` : 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  });

  const navItems = [
    { path: '/account',              icon: User,       label: 'Profile',              sublabel: 'Account Settings' },
    { path: '/account/wallet',       icon: Wallet,     label: 'Wallet Balance',       sublabel: `NPR ${user.walletBalanceNpr.toLocaleString('en-IN')}` },
    { path: '/account/coins',        icon: Coins,      label: 'UG Coins',             sublabel: `${Math.floor(user.coinBalance || 0)} coins` },
    { path: '/account/orders',       icon: Package,    label: 'My Orders',            sublabel: `${user.completedOrdersCount} completed` },
    { path: '/account/transactions', icon: ListFilter, label: 'Transactions',         sublabel: 'Wallet History' },
    { path: '/account/wallet',       icon: Plus,       label: 'Instant Wallet Load',  sublabel: 'Top-up Wallet' },
    { path: '/account/support',      icon: Headphones, label: 'Support',              sublabel: 'Help Center' },
  ];

  return (
    <AccountLayout
      title="My Account"
      subtitle="Manage your profile and security settings"
      icon={User}
      breadcrumbs={[{ label: 'My Account' }]}
      onNavigate={onNavigate}
      backPath="/"
      walletBalance={user.walletBalanceNpr}
      userName={user.username}
      avatarUrl={previewPic || user.avatarUrl}
    >
      {/* ── Global Styles ── */}
      <style>{`
        @keyframes ugAnimFadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes ugAnimSlideLeft {
          from { opacity: 0; transform: translateX(20px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes ugAnimFadeRight {
          from { opacity: 0; transform: translateX(-20px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes ugAnimSlideUp {
          from { opacity: 0; transform: translateY(28px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes ugSkeletonPulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.45; }
        }

        .ug-anim-card { animation-duration: 0.44s; animation-fill-mode: both; animation-timing-function: cubic-bezier(0.22, 1, 0.36, 1); }
        .ugAnimFadeUp    { animation-name: ugAnimFadeUp; }
        .ugAnimSlideLeft { animation-name: ugAnimSlideLeft; }
        .ugAnimFadeRight { animation-name: ugAnimFadeRight; }
        .ugAnimSlideUp   { animation-name: ugAnimSlideUp; }

        .ug-card-hover {
          transition: transform 0.28s cubic-bezier(0.22,1,0.36,1), box-shadow 0.28s ease;
          will-change: transform;
        }
        .ug-card-hover:hover {
          transform: translateY(-4px);
          box-shadow: 0 8px 32px rgba(0,0,0,0.1) !important;
        }

        .ug-btn-primary {
          transition: background 0.22s, transform 0.18s, box-shadow 0.22s;
        }
        .ug-btn-primary:hover:not(:disabled) { transform: scale(1.03); box-shadow: 0 4px 16px rgba(229,9,20,0.3); }
        .ug-btn-primary:active:not(:disabled) { transform: scale(0.97); }

        .ug-nav-item {
          transition: background 0.22s ease, border-color 0.22s ease, border-radius 0.22s ease;
        }
        .ug-nav-icon {
          transition: background 0.22s ease, border-color 0.22s ease, box-shadow 0.22s ease, transform 0.22s ease;
        }
        .ug-nav-item:hover .ug-nav-icon { transform: scale(1.08) rotate(-4deg); }
        .ug-nav-icon-svg {
          transition: color 0.22s ease, transform 0.22s ease;
        }
        .ug-nav-item:hover .ug-nav-icon-svg { transform: scale(1.1); }
        .ug-nav-arrow { transition: color 0.22s ease, transform 0.22s ease; }
        .ug-nav-item:hover .ug-nav-arrow { transform: translateX(2px); }

        .ug-info-row { transition: background 0.18s ease; }
        .ug-info-row:hover { background: #fafafa; border-radius: 12px; }

        .ug-skeleton { animation: ugSkeletonPulse 1.4s ease-in-out infinite; }

        .ug-input-field:focus { outline: none; }

        /* Mobile accordion */
        .ug-mobile-nav-body {
          overflow: hidden;
          transition: max-height 0.35s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.28s ease;
        }
        .ug-mobile-nav-body.open { max-height: 600px; opacity: 1; }
        .ug-mobile-nav-body.closed { max-height: 0; opacity: 0; }

        @media (prefers-reduced-motion: reduce) {
          .ug-anim-card, .ug-card-hover, .ug-btn-primary, .ug-nav-item,
          .ug-nav-icon, .ug-nav-arrow, .ug-skeleton { animation: none !important; transition: none !important; }
        }
      `}</style>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* ═══════════════════════════════════════════════════
            LEFT COLUMN
        ═══════════════════════════════════════════════════ */}
        <div className="space-y-4 lg:col-span-1">

          {/* Profile card — Fade Up */}
          <div
            className="ug-anim-card ugAnimFadeUp ug-card-hover p-6 flex flex-col items-center gap-4 text-center"
            style={{ ...cardStyle, animationDelay: '0ms' }}
          >
            {/* Avatar */}
            <div className="relative cursor-pointer" onClick={() => picInputRef.current?.click()}>
              <div
                className="w-24 h-24 rounded-full flex items-center justify-center font-black text-3xl text-white overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, #E50914 0%, #7f0008 100%)',
                  border: '3px solid #fecaca',
                  boxShadow: '0 4px 24px rgba(229,9,20,0.28)',
                }}
              >
                {previewPic || user.avatarUrl
                  ? <img src={previewPic || user.avatarUrl} alt="Profile" className="w-full h-full object-cover" />
                  : initialLetter
                }
              </div>
              {isUploadingPic ? (
                <div className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-white animate-spin" />
                </div>
              ) : (
                <button
                  className="absolute bottom-0.5 right-0.5 w-7 h-7 rounded-full flex items-center justify-center cursor-pointer shadow-lg ug-btn-primary"
                  style={{ background: T.red, border: '2px solid white' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = T.redHover; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = T.red; }}
                  onClick={e => { e.stopPropagation(); picInputRef.current?.click(); }}
                >
                  <Camera className="w-3.5 h-3.5 text-white" />
                </button>
              )}
              <input ref={picInputRef} type="file" accept="image/*" className="hidden" onChange={handlePicChange} />
            </div>

            <div>
              {pageReady
                ? <h2 className="font-black text-base" style={{ color: T.text }}>{user.username}</h2>
                : <Skeleton w="120px" h="18px" rounded="9px" />
              }
              {pageReady
                ? <p className="text-xs mt-1" style={{ color: T.muted }}>{user.email}</p>
                : <div className="mt-1"><Skeleton w="160px" h="13px" rounded="7px" /></div>
              }
            </div>
          </div>

          {/* Wallet card — Slide Left */}
          <div
            className="ug-anim-card ugAnimSlideLeft ug-card-hover p-5"
            style={{
              ...cardStyle,
              background: 'linear-gradient(135deg, #E50914 0%, #a00610 100%)',
              border: 'none',
              boxShadow: '0 4px 28px rgba(229,9,20,0.32)',
              animationDelay: '60ms',
            }}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-white/80 uppercase tracking-wider">Wallet Balance</span>
              <div className="w-8 h-8 rounded-2xl flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.18)' }}>
                <Wallet className="w-4 h-4 text-white" />
              </div>
            </div>
            {pageReady
              ? (
                <p className="text-2xl font-black text-white font-mono tracking-tight">
                  NPR {user.walletBalanceNpr.toLocaleString('en-IN')}
                </p>
              )
              : <Skeleton w="150px" h="28px" rounded="10px" />
            }
            <button
              onClick={() => { window.scrollTo({ top: 0, behavior: 'smooth' }); setTimeout(() => onNavigate('/account/wallet'), 120); }}
              className="mt-4 w-full py-2.5 rounded-2xl text-xs font-extrabold cursor-pointer ug-btn-primary"
              style={{ background: 'rgba(255,255,255,0.18)', color: 'white', border: '1.5px solid rgba(255,255,255,0.3)' }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.28)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.18)'; }}
            >
              ＋ Instant Wallet Load
            </button>
          </div>

          {/* Navigation menu — Fade Right */}
          {/* Desktop nav */}
          <div
            className="ug-anim-card ugAnimFadeRight hidden lg:block overflow-hidden"
            style={{ ...cardStyle, animationDelay: '100ms' }}
          >
            <div className="px-4 pt-4 pb-1">
              <p className="text-[10px] font-extrabold uppercase tracking-widest" style={{ color: T.subtle }}>
                Navigation
              </p>
            </div>
            <div className="py-1.5">
              {navItems.map((item, i) => (
                <NavItem
                  key={item.path + item.label}
                  {...item}
                  active={item.path === '/account' && item.label === 'Profile'}
                  onNavigate={onNavigate}
                  delay={i * 35}
                />
              ))}
            </div>
          </div>

          {/* Mobile accordion nav */}
          <div
            className="ug-anim-card ugAnimFadeUp lg:hidden overflow-hidden"
            style={{ ...cardStyle, animationDelay: '100ms' }}
          >
            <button
              className="w-full flex items-center justify-between px-4 py-3.5 cursor-pointer"
              onClick={() => setMobileNavOpen(v => !v)}
              style={{ background: 'transparent' }}
            >
              <span className="text-xs font-extrabold uppercase tracking-widest" style={{ color: T.subtle }}>
                Navigation
              </span>
              <ChevronRight
                className="w-4 h-4 transition-transform duration-300"
                style={{ color: T.subtle, transform: mobileNavOpen ? 'rotate(90deg)' : 'rotate(0deg)' }}
              />
            </button>
            <div className={`ug-mobile-nav-body ${mobileNavOpen ? 'open' : 'closed'}`}>
              <div className="pb-2">
                {navItems.map((item) => (
                  <NavItem
                    key={item.path + item.label}
                    {...item}
                    active={item.path === '/account' && item.label === 'Profile'}
                    onNavigate={onNavigate}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ═══════════════════════════════════════════════════
            RIGHT COLUMN
        ═══════════════════════════════════════════════════ */}
        <div className="space-y-5 lg:col-span-2">

          {/* ── Profile Information — Fade Up ── */}
          <div
            className="ug-anim-card ugAnimFadeUp ug-card-hover p-6"
            style={{ ...cardStyle, animationDelay: '80ms' }}
          >
            <div className="flex items-center gap-3 mb-5">
              <div
                className="w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: '#fff5f5', border: `1.5px solid ${T.redBorder}` }}
              >
                <User className="w-4 h-4" style={{ color: T.red }} />
              </div>
              <div>
                <h3 className="text-sm font-black" style={{ color: T.text }}>Profile Information</h3>
                <p className="text-[11px]" style={{ color: T.subtle }}>Your account details</p>
              </div>
            </div>

            {pageReady ? (
              <div className="divide-y" style={{ borderColor: T.border }}>
                <InfoRow icon={User}   label="Email Address"  value={user.email} mono />
                <InfoRow icon={TrendingUp} label="Total Orders" value={`${user.completedOrdersCount} completed`} />
                <InfoRow icon={Wallet} label="Wallet Balance" value={`NPR ${user.walletBalanceNpr.toLocaleString('en-IN')}`} valueStyle={{ color: T.red }} mono />
              </div>
            ) : (
              <div className="space-y-4">
                {[1,2,3].map(i => (
                  <div key={i} className="flex items-center gap-3 py-3 border-b last:border-0" style={{ borderColor: T.border }}>
                    <Skeleton w="32px" h="32px" rounded="12px" />
                    <div className="flex-1 space-y-1.5">
                      <Skeleton w="60px" h="10px" />
                      <Skeleton w="140px" h="13px" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── Change Username — Slide Up ── */}
          <div
            className="ug-anim-card ugAnimSlideUp ug-card-hover p-6"
            style={{ ...cardStyle, animationDelay: '130ms' }}
          >
            <div className="flex items-center gap-3 mb-5">
              <div
                className="w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: '#fff5f5', border: `1.5px solid ${T.redBorder}` }}
              >
                <User className="w-4 h-4" style={{ color: T.red }} />
              </div>
              <div>
                <h3 className="text-sm font-black" style={{ color: T.text }}>Change Username</h3>
                <p className="text-[11px]" style={{ color: T.subtle }}>Update your display name</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={newUsername}
                onChange={e => setNewUsername(e.target.value)}
                onFocus={() => setUsernameFocused(true)}
                onBlur={() => setUsernameFocused(false)}
                placeholder="New username"
                className="flex-1 text-sm rounded-2xl px-4 py-3 ug-input-field"
                style={inputStyle(usernameFocused)}
              />
              <button
                onClick={handleSaveUsername}
                disabled={isSavingUsername}
                className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl text-sm font-extrabold text-white cursor-pointer ug-btn-primary flex-shrink-0 disabled:opacity-50"
                style={{ background: T.red }}
                onMouseEnter={e => { if (!isSavingUsername) (e.currentTarget as HTMLButtonElement).style.background = T.redHover; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = T.red; }}
              >
                {isSavingUsername ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Save
              </button>
            </div>

            {usernameMsg && (
              <div
                className="flex items-center gap-2 px-4 py-3 rounded-2xl mt-3 text-xs font-bold"
                style={{
                  background: usernameMsg.ok ? '#f0fdf4' : '#fff5f5',
                  border: `1.5px solid ${usernameMsg.ok ? '#bbf7d0' : T.redBorder}`,
                  color: usernameMsg.ok ? '#15803d' : T.red,
                }}
              >
                {usernameMsg.ok ? <Check className="w-3.5 h-3.5 flex-shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />}
                {usernameMsg.text}
              </div>
            )}
          </div>

          {/* ── Change Password — Slide Up ── */}
          <div
            className="ug-anim-card ugAnimSlideUp ug-card-hover p-6"
            style={{ ...cardStyle, animationDelay: '170ms' }}
          >
            <div className="flex items-center gap-3 mb-5">
              <div
                className="w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: '#fff5f5', border: `1.5px solid ${T.redBorder}` }}
              >
                <Lock className="w-4 h-4" style={{ color: T.red }} />
              </div>
              <div>
                <h3 className="text-sm font-black" style={{ color: T.text }}>Change Password</h3>
                <p className="text-[11px]" style={{ color: T.subtle }}>Keep your account secure</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  onFocus={() => setPwFocused(true)}
                  onBlur={() => setPwFocused(false)}
                  placeholder="New password (min. 6 characters)"
                  className="w-full text-sm rounded-2xl px-4 py-3 pr-11 ug-input-field"
                  style={inputStyle(pwFocused)}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 cursor-pointer transition-colors"
                  style={{ color: T.subtle }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = T.red; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = T.subtle; }}
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <div className="relative">
                <input
                  type={showConfirmPw ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  onFocus={() => setConfirmFocused(true)}
                  onBlur={() => setConfirmFocused(false)}
                  placeholder="Confirm new password"
                  className="w-full text-sm rounded-2xl px-4 py-3 pr-11 ug-input-field"
                  style={inputStyle(confirmFocused)}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPw(!showConfirmPw)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 cursor-pointer transition-colors"
                  style={{ color: T.subtle }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = T.red; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = T.subtle; }}
                >
                  {showConfirmPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <button
                onClick={handleSavePassword}
                disabled={isSavingPw}
                className="flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-extrabold text-white cursor-pointer ug-btn-primary disabled:opacity-50"
                style={{ background: T.red }}
                onMouseEnter={e => { if (!isSavingPw) (e.currentTarget as HTMLButtonElement).style.background = T.redHover; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = T.red; }}
              >
                {isSavingPw ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                Update Password
              </button>

              {pwMsg && (
                <div
                  className="flex items-center gap-2 px-4 py-3 rounded-2xl text-xs font-bold"
                  style={{
                    background: pwMsg.ok ? '#f0fdf4' : '#fff5f5',
                    border: `1.5px solid ${pwMsg.ok ? '#bbf7d0' : T.redBorder}`,
                    color: pwMsg.ok ? '#15803d' : T.red,
                  }}
                >
                  {pwMsg.ok ? <Check className="w-3.5 h-3.5 flex-shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />}
                  {pwMsg.text}
                </div>
              )}
            </div>
          </div>

          {/* ── Recent Activity — Fade Up ── */}
          <div
            className="ug-anim-card ugAnimFadeUp ug-card-hover p-6"
            style={{ ...cardStyle, animationDelay: '210ms' }}
          >
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{ background: '#fff5f5', border: `1.5px solid ${T.redBorder}` }}
                >
                  <TrendingUp className="w-4 h-4" style={{ color: T.red }} />
                </div>
                <div>
                  <h3 className="text-sm font-black" style={{ color: T.text }}>Recent Activity</h3>
                  <p className="text-[11px]" style={{ color: T.subtle }}>Latest orders &amp; transactions</p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('/account/orders')}
                className="text-xs font-bold cursor-pointer transition-colors"
                style={{ color: T.red }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = T.redHover; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = T.red; }}
              >
                View all →
              </button>
            </div>

            {/* Recent orders */}
            {recentOrders.length > 0 ? (
              <div className="space-y-2.5 mb-4">
                <p className="text-[10px] font-extrabold uppercase tracking-widest mb-2" style={{ color: T.subtle }}>
                  Recent Orders
                </p>
                {recentOrders.map(order => (
                  <div
                    key={order.orderId}
                    className="flex items-center gap-3 p-3 rounded-2xl ug-card-hover"
                    style={{ background: T.gray, border: `1.5px solid ${T.border}`, boxShadow: 'none' }}
                  >
                    <div
                      className="w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{ background: '#fff5f5', border: `1.5px solid ${T.redBorder}` }}
                    >
                      <Package className="w-4 h-4" style={{ color: T.red }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold truncate" style={{ color: T.text }}>{order.packageName}</p>
                      <p className="text-[10px] truncate" style={{ color: T.muted }}>{order.gameName}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-xs font-black font-mono" style={{ color: T.red }}>
                        NPR {order.totalPriceNpr.toLocaleString()}
                      </p>
                      <p className="text-[10px]" style={{ color: T.subtle }}>{order.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div
                className="flex flex-col items-center justify-center py-10 rounded-2xl mb-4"
                style={{ background: T.gray, border: `1.5px dashed ${T.border}` }}
              >
                <Package className="w-9 h-9 mb-2" style={{ color: '#ddd' }} />
                <p className="text-xs font-bold" style={{ color: T.subtle }}>No orders yet</p>
                <button
                  onClick={() => onNavigate('/')}
                  className="mt-2 text-xs font-bold cursor-pointer ug-btn-primary px-3 py-1 rounded-full"
                  style={{ color: T.red }}
                >
                  Browse games →
                </button>
              </div>
            )}

            {/* Wallet activity */}
            {recentWallet.length > 0 && (
              <div className="space-y-2">
                <p className="text-[10px] font-extrabold uppercase tracking-widest mb-2" style={{ color: T.subtle }}>
                  Wallet Activity
                </p>
                {recentWallet.map(txn => (
                  <div
                    key={txn.id}
                    className="flex items-center gap-3 p-3 rounded-2xl ug-card-hover"
                    style={{ background: T.gray, border: `1.5px solid ${T.border}`, boxShadow: 'none' }}
                  >
                    <div
                      className="w-8 h-8 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{
                        background: txn.amount > 0 ? '#f0fdf4' : '#fff5f5',
                        border: `1.5px solid ${txn.amount > 0 ? '#bbf7d0' : T.redBorder}`,
                      }}
                    >
                      {txn.amount > 0
                        ? <ArrowDownLeft className="w-3.5 h-3.5" style={{ color: '#16a34a' }} />
                        : <ArrowUpRight className="w-3.5 h-3.5" style={{ color: T.red }} />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold truncate" style={{ color: T.text }}>
                        {txn.amount > 0 ? 'Wallet Deposit' : 'Top-Up Purchase'}
                      </p>
                      <p className="text-[10px] font-mono truncate" style={{ color: T.subtle }}>{txn.date}</p>
                    </div>
                    <p
                      className="text-xs font-black font-mono flex-shrink-0"
                      style={{ color: txn.amount > 0 ? '#16a34a' : T.red }}
                    >
                      {txn.amount > 0 ? `+${txn.amount}` : `-${Math.abs(txn.amount)}`}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </AccountLayout>
  );
};
