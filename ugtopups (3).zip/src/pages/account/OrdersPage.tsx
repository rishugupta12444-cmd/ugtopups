import React, { useState, useEffect } from 'react';
import {
  ShoppingBag, Search, Filter, Settings, ChevronRight, Copy, Check,
  Clock, CheckCircle2, XCircle, ArrowLeft, Truck, ShieldCheck,
  CreditCard, Package, Gift, User, Tag, Sparkles, X, Loader2
} from 'lucide-react';
import { Order, Game, UserProfile } from '../../types';
import { subscribeUserOrders, subscribeGames, isRedeemCodeOrder } from '../../lib/store';
import { supabase } from '../../lib/supabase';
import { AccountLayout } from '../../components/account/AccountLayout';

interface OrdersPageProps {
  orders?: Order[];
  onNavigate: (path: string) => void;
  user?: UserProfile;
}

// Fallback Game Logos if none provided by admin
const DEFAULT_GAME_LOGOS: Record<string, string> = {
  'pubg mobile': 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=120&auto=format&fit=crop&q=80',
  'free fire': 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=120&auto=format&fit=crop&q=80',
  'mobile legends': 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=120&auto=format&fit=crop&q=80',
  'genshin impact': 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=120&auto=format&fit=crop&q=80',
  'valorant': 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=120&auto=format&fit=crop&q=80',
};

export const OrdersPage: React.FC<OrdersPageProps> = ({ onNavigate, user }) => {
  const [firestoreOrders, setFirestoreOrders] = useState<Order[]>([]);
  const [games, setGames] = useState<Game[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  
  // UI state
  const [activeTab, setActiveTab] = useState<'All' | 'Pending' | 'Success' | 'Cancelled'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Subscribe to real-time User Orders & Admin Games
  useEffect(() => {
    let unsubOrders: (() => void) | null = null;
    let unsubGames: (() => void) | null = null;

    unsubGames = subscribeGames((gamesList) => {
      setGames(gamesList);
    });

    supabase.auth.getUser().then(({ data }) => {
      const uid = data.user?.id;
      if (!uid) {
        setLoadingOrders(false);
        return;
      }
      unsubOrders = subscribeUserOrders(uid, (userOrders) => {
        setFirestoreOrders(userOrders);
        setLoadingOrders(false);
      });
    });

    return () => {
      if (unsubOrders) unsubOrders();
      if (unsubGames) unsubGames();
    };
  }, []);

  const handleCopy = (text: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Helper to map order status to standardized badge categories
  const getNormalizedStatus = (status: string) => {
    const s = (status || '').toLowerCase();
    if (s.includes('completed') || s.includes('success') || s.includes('paid')) return 'Success';
    if (s.includes('cancel') || s.includes('fail') || s.includes('reject')) return 'Cancelled';
    return 'Pending';
  };

  // Helper to get Game Icon / Logo set by admin
  const getGameLogo = (gameName: string, gameId?: string) => {
    // Wallet load orders always use the UG Wallet logo
    if (gameId === 'wallet-load' || gameId === 'ug_wallet' || (gameName || '').toLowerCase().includes('wallet')) {
      return '/assets/wallet_ug.png';
    }
    if (gameId) {
      const match = games.find(g => g.id === gameId);
      if (match && match.iconUrl) return match.iconUrl;
    }
    const nameLower = (gameName || '').toLowerCase().trim();
    const matchByName = games.find(g => g.name.toLowerCase().trim() === nameLower);
    if (matchByName && matchByName.iconUrl) return matchByName.iconUrl;

    // Check defaults
    for (const [key, url] of Object.entries(DEFAULT_GAME_LOGOS)) {
      if (nameLower.includes(key)) return url;
    }
    return '';
  };

  // Count orders by status
  const counts = {
    All: firestoreOrders.length,
    Pending: firestoreOrders.filter(o => getNormalizedStatus(o.status) === 'Pending').length,
    Success: firestoreOrders.filter(o => getNormalizedStatus(o.status) === 'Success').length,
    Cancelled: firestoreOrders.filter(o => getNormalizedStatus(o.status) === 'Cancelled').length,
  };

  // Filtered orders list
  const filteredOrders = firestoreOrders.filter(ord => {
    const norm = getNormalizedStatus(ord.status);
    if (activeTab !== 'All' && norm !== activeTab) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchGame = ord.gameName?.toLowerCase().includes(q);
      const matchPkg = ord.packageName?.toLowerCase().includes(q);
      const matchId = ord.orderId?.toLowerCase().includes(q);
      const matchUid = ord.playerUid?.toLowerCase().includes(q);
      if (!matchGame && !matchPkg && !matchId && !matchUid) return false;
    }
    return true;
  });

  // Calculate coins earned
  const getRewardCoins = (price: number) => {
    return Math.max(1, Math.floor(price * 0.005));
  };

  // Format readable dates
  const formatDateTime = (dateStr?: string) => {
    if (!dateStr) return '30 May 2026 • 9:37 AM';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      const day = d.getDate();
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const month = months[d.getMonth()];
      const year = d.getFullYear();
      let hours = d.getHours();
      const minutes = d.getMinutes().toString().padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;
      return `${day} ${month} ${year} • ${hours}:${minutes} ${ampm}`;
    } catch {
      return dateStr;
    }
  };

  // If an order is selected, show ORDER DETAILS VIEW (Screenshot 2 & 3)
  if (selectedOrder) {
    const normStatus = getNormalizedStatus(selectedOrder.status);
    const rewardCoins = getRewardCoins(selectedOrder.totalPriceNpr);
    const gameLogo = getGameLogo(selectedOrder.gameName, selectedOrder.gameId);

    return (
      <div className="min-h-screen bg-[#F8FAFC] text-slate-800 font-sans pb-24">
        {/* Header Bar */}
        <div className="max-w-xl mx-auto px-4 pt-6 pb-4 flex items-center justify-between">
          <button
            onClick={() => setSelectedOrder(null)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition shadow-sm cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-rose-500" />
            Order History
          </button>

          <button
            onClick={() => setShowTimelineModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition shadow-sm cursor-pointer"
          >
            <Truck className="w-3.5 h-3.5 text-rose-500" />
            Delivery Timeline
          </button>
        </div>

        {/* Order Details Main Card (Screenshot 2) */}
        <div className="max-w-xl mx-auto px-4">
          <div className="bg-white border border-slate-100 rounded-3xl p-5 sm:p-6 shadow-sm space-y-5">
            {/* Top Order Number Row */}
            <div className="border-b border-slate-100 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-0.5">
                    ORDER NUMBER
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-extrabold text-slate-900 tracking-tight font-mono">
                      {(() => {
                        const raw = selectedOrder.orderId || '';
                        if (/^ODR\d{4,6}$/.test(raw)) return raw;
                        const digits = raw.replace(/\D/g, '');
                        return digits.length > 0 ? `ODR${digits.slice(-5)}` : raw;
                      })()}
                    </span>
                    <button
                      onClick={(e) => handleCopy(selectedOrder.orderId, e)}
                      className="p-1 text-slate-400 hover:text-slate-600 transition cursor-pointer"
                      title="Copy Order ID"
                    >
                      {copiedText === selectedOrder.orderId ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Status Badge */}
                <div>
                  {normStatus === 'Success' && (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-50 border border-emerald-200 text-emerald-600">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Success
                    </span>
                  )}
                  {normStatus === 'Pending' && (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-extrabold bg-amber-50 border border-amber-200 text-amber-600">
                      <Clock className="w-3.5 h-3.5" />
                      Pending
                    </span>
                  )}
                  {normStatus === 'Cancelled' && (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-extrabold bg-slate-100 border border-slate-200 text-slate-600">
                      <XCircle className="w-3.5 h-3.5" />
                      Cancelled
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Detailed Table Rows */}
            <div className="space-y-3.5 text-xs text-slate-600">
              {/* Time */}
              <div className="flex items-center justify-between py-1 border-b border-slate-50">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <Clock className="w-4 h-4 text-slate-400" />
                  Time
                </span>
                <span className="font-semibold text-slate-800">
                  {formatDateTime(selectedOrder.createdAt)}
                </span>
              </div>

              {/* Payment Method */}
              <div className="flex items-center justify-between py-1 border-b border-slate-50">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <CreditCard className="w-4 h-4 text-slate-400" />
                  Payment Method
                </span>
                <span className="font-semibold text-slate-800">
                  {selectedOrder.paymentMethod || 'UG Wallet Balance'}
                </span>
              </div>

              {/* Status */}
              <div className="flex items-center justify-between py-1 border-b border-slate-50">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-slate-400" />
                  Status
                </span>
                <span className={`font-bold ${
                  normStatus === 'Success' ? 'text-emerald-600' :
                  normStatus === 'Pending' ? 'text-amber-600' : 'text-slate-600'
                }`}>
                  {normStatus}
                </span>
              </div>

              {/* Product */}
              <div className="flex items-center justify-between py-1 border-b border-slate-50">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <Package className="w-4 h-4 text-slate-400" />
                  Product
                </span>
                <span className="font-extrabold text-slate-900 uppercase">
                  {selectedOrder.gameName}
                </span>
              </div>

              {/* Rewards */}
              <div className="flex items-center justify-between py-1 border-b border-slate-50">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <span className="text-base leading-none">🪙</span>
                  Rewards
                </span>
                <span className="font-semibold text-slate-800">
                  3 Reward Coins
                </span>
              </div>

              {/* Package */}
              <div className="flex items-center justify-between py-1 border-b border-slate-50">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <Tag className="w-4 h-4 text-slate-400" />
                  Package
                </span>
                <span className="font-semibold text-slate-800">
                  {selectedOrder.packageName}
                </span>
              </div>

              {/* Account / Player UID */}
              {!isRedeemCodeOrder(selectedOrder) ? (() => {
                const isDummyUid = !selectedOrder.playerUid || /^USER_\d+$/i.test(selectedOrder.playerUid.trim()) || selectedOrder.playerUid.trim() === 'PLAYER';
                const customFields = Array.isArray((selectedOrder as any).customFieldValues)
                  ? (selectedOrder as any).customFieldValues.filter((f: any) => f.value && !/password|passwd|pwd/i.test(f.label))
                  : [];
                const hasCustomFields = customFields.length > 0;

                if (isDummyUid && hasCustomFields) {
                  // Show each non-password custom field as its own row
                  return (
                    <>
                      {customFields.map((f: any) => (
                        <div key={f.id} className="flex items-center justify-between py-1 border-b border-slate-50">
                          <span className="flex items-center gap-2 text-slate-500 font-medium">
                            <User className="w-4 h-4 text-slate-400" />
                            {f.label}
                          </span>
                          <span className="font-semibold text-slate-800 font-mono text-right truncate max-w-[160px]">
                            {f.value}
                          </span>
                        </div>
                      ))}
                    </>
                  );
                }

                return (
                  <div className="flex items-center justify-between py-1 border-b border-slate-50">
                    <span className="flex items-center gap-2 text-slate-500 font-medium">
                      <User className="w-4 h-4 text-slate-400" />
                      Account
                    </span>
                    <span className="font-semibold text-slate-800 font-mono">
                      {selectedOrder.playerUid} {selectedOrder.playerName && selectedOrder.playerName !== selectedOrder.playerUid ? `(${selectedOrder.playerName})` : ''}
                    </span>
                  </div>
                );
              })() : (
                <div className="flex items-center justify-between py-1 border-b border-slate-50">
                  <span className="flex items-center gap-2 text-slate-500 font-medium">
                    <Gift className="w-4 h-4 text-amber-500" />
                    Delivery Type
                  </span>
                  <span className="font-bold text-amber-600 text-xs bg-amber-50 px-2 py-0.5 rounded">
                    Digital Redeem Voucher
                  </span>
                </div>
              )}

              {/* Price */}
              <div className="flex items-center justify-between pt-1">
                <span className="flex items-center gap-2 text-slate-500 font-medium">
                  <Tag className="w-4 h-4 text-slate-400" />
                  Price
                </span>
                <span className="text-base font-black text-slate-900">
                  NPR {selectedOrder.totalPriceNpr.toLocaleString()}
                </span>
              </div>
            </div>



            {/* Security Warning Notice */}
            <div className="text-center pt-2">
              <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                For your security, please do not share your order details with others.
              </p>
            </div>
          </div>
        </div>

        {/* DELIVERY TIMELINE MODAL (Screenshot 3) */}
        {showTimelineModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fadeIn">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative space-y-5 border border-slate-100">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Truck className="w-5 h-5 text-rose-500" />
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                    Delivery Timeline - {selectedOrder.orderId}
                  </h3>
                </div>
                <button
                  onClick={() => setShowTimelineModal(false)}
                  className="p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Vertical Step Timeline */}
              <div className="space-y-6 relative pl-3 py-2">
                {/* Connecting Line */}
                <div className="absolute left-[21px] top-4 bottom-4 w-0.5 bg-slate-200 -z-0" />

                {/* Step 1: Order Created */}
                <div className="flex items-start gap-3.5 relative z-10">
                  <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 shadow-sm shadow-emerald-500/30">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs">Order Created</h4>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {formatDateTime(selectedOrder.createdAt)}
                    </span>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Order placed on UG Gaming.
                    </p>
                  </div>
                </div>

                {/* Step 2: Payment Confirmed */}
                <div className="flex items-start gap-3.5 relative z-10">
                  <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 shadow-sm shadow-emerald-500/30">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs">Payment Confirmed</h4>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {formatDateTime(selectedOrder.createdAt)}
                    </span>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Deducted NPR {selectedOrder.totalPriceNpr.toLocaleString()} from {selectedOrder.paymentMethod || 'UG Wallet'}.
                    </p>
                  </div>
                </div>

                {/* Step 3: UID Verification & Server Dispatch */}
                <div className="flex items-start gap-3.5 relative z-10">
                  <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 shadow-sm shadow-emerald-500/30">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs">Player Account Verified</h4>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {formatDateTime(selectedOrder.createdAt)}
                    </span>
                    <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                      UID: {selectedOrder.playerUid} verified.
                    </p>
                  </div>
                </div>

                {/* Step 4: Final Status */}
                <div className="flex items-start gap-3.5 relative z-10">
                  {normStatus === 'Success' && (
                    <>
                      <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 shadow-sm shadow-emerald-500/30">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs">Success & Top-Up Delivered</h4>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {formatDateTime(selectedOrder.completedAt || selectedOrder.createdAt)}
                        </span>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {selectedOrder.packageName} added to Player Account.
                        </p>
                      </div>
                    </>
                  )}

                  {normStatus === 'Pending' && (
                    <>
                      <div className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 shadow-sm shadow-amber-500/30">
                        <Clock className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-amber-700 text-xs">Processing Top-Up</h4>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          Estimated time: 2-5 Minutes
                        </span>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Top-Up is in queue and will be credited to your account shortly.
                        </p>
                      </div>
                    </>
                  )}

                  {normStatus === 'Cancelled' && (
                    <>
                      <div className="w-5 h-5 rounded-full bg-slate-400 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">
                        <X className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-700 text-xs">Order Cancelled</h4>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {formatDateTime(selectedOrder.cancelledAt || selectedOrder.createdAt)}
                        </span>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Order was cancelled. Any deducted amount has been refunded to your wallet.
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setShowTimelineModal(false)}
                className="w-full py-3 bg-[#111827] hover:bg-black text-white font-extrabold text-xs rounded-2xl transition cursor-pointer shadow-md"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // DEFAULT MAIN VIEW: ORDER HISTORY LIST
  return (
    <AccountLayout
      title="Order History"
      subtitle="View your previous top-up purchases and their status"
      icon={ShoppingBag}
      breadcrumbs={[{ label: 'My Account', path: '/account' }, { label: 'Orders' }]}
      onNavigate={onNavigate}
      walletBalance={user?.walletBalanceNpr}
      userName={user?.username || user?.fullName}
      avatarUrl={user?.avatarUrl}
    >
      <div className="space-y-4">
        {/* Search & Filter Bar */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 ml-auto">
            <button
              onClick={() => setShowSearch(!showSearch)}
              className={`p-2 rounded-full border text-slate-600 transition cursor-pointer ${
                showSearch ? 'bg-rose-50 border-rose-200 text-rose-600' : 'bg-white border-slate-200 hover:bg-slate-100'
              }`}
              title="Search Orders"
            >
              <Search className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                const orderOfTabs: Array<'All' | 'Pending' | 'Success' | 'Cancelled'> = ['All', 'Pending', 'Success', 'Cancelled'];
                const nextIdx = (orderOfTabs.indexOf(activeTab) + 1) % orderOfTabs.length;
                setActiveTab(orderOfTabs[nextIdx]);
              }}
              className="p-2 rounded-full bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 transition cursor-pointer"
              title="Filter Orders"
            >
              <Filter className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Expandable Search Input */}
        {showSearch && (
          <div className="relative animate-fadeIn">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by game, package, or order ID..."
              className="w-full bg-white border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-rose-500 transition shadow-sm"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Clear
              </button>
            )}
          </div>
        )}

        {/* Status Filter Pills Row (Screenshot 1) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none whitespace-nowrap">
          {/* All */}
          <button
            onClick={() => setActiveTab('All')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'All'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${activeTab === 'All' ? 'bg-white' : 'bg-rose-500'}`} />
            All ({counts.All})
          </button>

          {/* Pending */}
          <button
            onClick={() => setActiveTab('Pending')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'Pending'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${activeTab === 'Pending' ? 'bg-white' : 'bg-amber-500'}`} />
            Pending ({counts.Pending})
          </button>

          {/* Success */}
          <button
            onClick={() => setActiveTab('Success')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'Success'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${activeTab === 'Success' ? 'bg-white' : 'bg-emerald-500'}`} />
            Success ({counts.Success})
          </button>

          {/* Cancelled */}
          <button
            onClick={() => setActiveTab('Cancelled')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'Cancelled'
                ? 'bg-slate-600 text-white shadow-md'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${activeTab === 'Cancelled' ? 'bg-white' : 'bg-slate-400'}`} />
            Cancelled ({counts.Cancelled})
          </button>
        </div>

        {/* Orders Card List */}
        {loadingOrders ? (
          <div className="bg-white border border-slate-100 rounded-3xl p-12 text-center shadow-sm space-y-3">
            <Loader2 className="w-8 h-8 text-rose-500 animate-spin mx-auto" />
            <p className="font-bold text-slate-600 text-xs">Loading order history...</p>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="bg-white border border-slate-100 rounded-3xl p-12 text-center shadow-sm space-y-3">
            <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="font-bold text-slate-800 text-sm">No orders found</h3>
            <p className="text-xs text-slate-400">
              {searchQuery ? 'Try matching another search term' : 'You have not placed any top-up orders yet.'}
            </p>
            <button
              onClick={() => onNavigate('/')}
              className="mt-2 px-5 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs transition cursor-pointer"
            >
              Explore Top-Ups
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredOrders.map((ord) => {
              const normStatus = getNormalizedStatus(ord.status);
              const logo = getGameLogo(ord.gameName, ord.gameId);

              return (
                <div
                  key={ord.orderId}
                  onClick={() => setSelectedOrder(ord)}
                  className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-between gap-3 group"
                >
                  {/* Left Logo + Details */}
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Game Logo Icon set by admin */}
                    <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-900 border border-slate-100 flex items-center justify-center flex-shrink-0 shadow-sm relative">
                      {logo ? (
                        <img
                          src={logo}
                          alt={ord.gameName}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-rose-500 to-amber-500 flex items-center justify-center font-black text-white text-[10px] p-1 text-center leading-tight">
                          {(ord.gameName || 'GAME').toUpperCase().slice(0, 8)}
                        </div>
                      )}
                    </div>

                    {/* Content Details */}
                    <div className="min-w-0 space-y-0.5">
                      {/* Game Name & Status Pill */}
                      <div className="flex items-center gap-2">
                        <span className="font-black text-slate-900 text-sm tracking-tight truncate">
                          {ord.gameName?.toUpperCase()}
                        </span>

                        {normStatus === 'Success' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-600 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" />
                            Success
                          </span>
                        )}

                        {normStatus === 'Pending' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-50 text-amber-600 border border-amber-200">
                            <Clock className="w-3 h-3" />
                            Pending
                          </span>
                        )}

                        {normStatus === 'Cancelled' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-500 border border-slate-200">
                            <XCircle className="w-3 h-3" />
                            Cancelled
                          </span>
                        )}
                      </div>

                      {/* Package Name */}
                      <p className="text-xs font-semibold text-slate-600 truncate">
                        {ord.packageName}
                      </p>

                      {/* Order ID & Copy */}
                      <div className="flex items-center gap-1 text-[11px] text-slate-400">
                        <span>Order ID:</span>
                        <span className="font-mono text-slate-600 font-bold">
                          {/* Show short ID: take last 5 chars of numeric part, prefix with ODR */}
                          {(() => {
                            const raw = ord.orderId || '';
                            // If already short format ODR##### keep as-is
                            if (/^ODR\d{4,6}$/.test(raw)) return raw;
                            // Extract digits and show last 5
                            const digits = raw.replace(/\D/g, '');
                            return digits.length > 0 ? `ODR${digits.slice(-5)}` : raw;
                          })()}
                        </span>
                        <button
                          onClick={(e) => handleCopy(ord.orderId, e)}
                          className="p-0.5 hover:text-slate-700 transition cursor-pointer ml-0.5"
                          title="Copy Full Order ID"
                        >
                          {copiedText === ord.orderId ? (
                            <Check className="w-3 h-3 text-emerald-500" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>

                      {/* Date & Time */}
                      <p className="text-[10px] text-slate-400 flex items-center gap-1">
                        <span>📅</span>
                        <span>{formatDateTime(ord.createdAt)}</span>
                      </p>

                      {/* Pending estimated time badge */}
                      {normStatus === 'Pending' && (
                        <p className="text-[10px] text-amber-600 font-bold flex items-center gap-1 pt-0.5">
                          <Clock className="w-3 h-3 text-amber-500 animate-spin" />
                          Estimated 2-5 Minutes
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right Price & Arrow */}
                  <div className="flex items-center gap-2 flex-shrink-0 pl-2">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-bold block">NPR</span>
                      <span className="text-base font-black text-slate-900 tracking-tight">
                        {ord.totalPriceNpr.toLocaleString()}
                      </span>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-rose-500 transition group-hover:translate-x-0.5" />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AccountLayout>
  );
};
