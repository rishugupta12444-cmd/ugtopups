import React, { useEffect, useRef, useState } from 'react';
import {
  Wallet, CreditCard, QrCode, ChevronLeft, Loader2, Check, AlertCircle,
  Download, ArrowDownLeft, ArrowUpRight, History, ImageIcon, ShieldCheck, ArrowLeft,
} from 'lucide-react';
import { UserProfile, WalletTransaction } from '../../types';
import { AccountLayout } from '../../components/account/AccountLayout';
import {
  ManualPaymentSettings,
  DEFAULT_MANUAL_PAYMENT_SETTINGS,
  subscribeManualPaymentSettings,
} from '../../lib/store';

type WalletStep = 'choose' | 'online' | 'manual';

interface WalletPageProps {
  user: UserProfile;
  walletHistory: WalletTransaction[];
  onNavigate: (path: string) => void;
  onInitiateWalletAdd?: (amount: number) => Promise<void>;
  onManualWalletRequest?: (amount: number, screenshot: File) => Promise<void>;
}

const QUICK_AMOUNTS = [100, 200, 500, 1000, 2000, 5000];

export const WalletPage: React.FC<WalletPageProps> = ({
  user, walletHistory, onNavigate, onInitiateWalletAdd, onManualWalletRequest,
}) => {
  const [walletStep, setWalletStep] = useState<WalletStep>('choose');
  const [walletAmount, setWalletAmount] = useState('500');
  const [isProcessingOnline, setIsProcessingOnline] = useState(false);
  const [manualAmount, setManualAmount] = useState('');
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploadAnimating, setIsUploadAnimating] = useState(false);
  const [isSubmittingManual, setIsSubmittingManual] = useState(false);
  const [manualMsg, setManualMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const [manualSettings, setManualSettings] = useState<ManualPaymentSettings>(DEFAULT_MANUAL_PAYMENT_SETTINGS);
  const screenshotRef = useRef<HTMLInputElement>(null);

  const [historyFilter, setHistoryFilter] = useState<'all' | 'deposits'>('deposits');

  useEffect(() => {
    const unsub = subscribeManualPaymentSettings((settings) => {
      setManualSettings(settings);
      if (settings.paymentMode === 'online') {
        setWalletStep('online');
      } else if (settings.paymentMode === 'manual') {
        setWalletStep('manual');
      } else {
        setWalletStep('choose');
      }
    });
    return unsub;
  }, []);

  const handleOnlinePay = async () => {
    const amt = Number(walletAmount);
    if (isNaN(amt) || amt <= 0) return;
    setIsProcessingOnline(true);
    try { if (onInitiateWalletAdd) await onInitiateWalletAdd(amt); }
    finally { setIsProcessingOnline(false); }
  };

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setScreenshot(file);
    setScreenshotPreview(URL.createObjectURL(file));
    // Animate progress bar 0 → 100% in 1.5s
    setUploadProgress(0);
    setIsUploadAnimating(true);
    const start = performance.now();
    const duration = 1500;
    const tick = (now: number) => {
      const elapsed = now - start;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setUploadProgress(pct);
      if (pct < 100) {
        requestAnimationFrame(tick);
      } else {
        setTimeout(() => setIsUploadAnimating(false), 400);
      }
    };
    requestAnimationFrame(tick);
  };

  const handleManualSubmit = async () => {
    const amt = Number(manualAmount);
    if (isNaN(amt) || amt <= 0) { setManualMsg({ text: 'Enter a valid amount.', ok: false }); return; }
    if (!screenshot) { setManualMsg({ text: 'Please upload the payment screenshot.', ok: false }); return; }
    setIsSubmittingManual(true); setManualMsg(null);
    try {
      if (onManualWalletRequest) await onManualWalletRequest(amt, screenshot);
      setManualMsg({ text: 'Submitted! Admin will verify shortly.', ok: true });
      setManualAmount(''); setScreenshot(null); setScreenshotPreview(null); setUploadProgress(0);
    } catch { setManualMsg({ text: 'Submission failed. Try again.', ok: false }); }
    finally { setIsSubmittingManual(false); setTimeout(() => setManualMsg(null), 4000); }
  };

  return (
    <AccountLayout
      title="Instant Wallet Load"
      subtitle="Top up your UG Wallet balance"
      icon={Wallet}
      breadcrumbs={[{ label: 'My Account', path: '/account' }, { label: 'Instant Wallet Load' }]}
      onNavigate={onNavigate}
      walletBalance={user.walletBalanceNpr}
      userName={user.username}
      avatarUrl={user.avatarUrl}
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: payment flow */}
        <div className="lg:col-span-2 space-y-4 text-xs">

          {/* Choose Method */}
          {walletStep === 'choose' && (
            <>
              <p className="text-center text-zinc-600 font-bold text-xs">Choose your payment method</p>
              <div className={`grid gap-3.5 ${(manualSettings.paymentMode || 'both') === 'both' ? 'grid-cols-2' : 'grid-cols-1 max-w-sm mx-auto'}`}>
                {((manualSettings.paymentMode || 'both') === 'both' || manualSettings.paymentMode === 'online') && (
                  <button
                    type="button"
                    onClick={() => setWalletStep('online')}
                    className="flex flex-col items-center gap-3 p-6 rounded-2xl bg-white border border-zinc-200 hover:border-zinc-400 hover:shadow-xs transition-all cursor-pointer group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-red-600 group-hover:bg-red-100/80 transition-colors">
                      <CreditCard className="w-6 h-6 stroke-[2.2]" />
                    </div>
                    <div className="text-center">
                      <p className="font-black text-zinc-900 text-sm">Pay Online</p>
                      <p className="text-zinc-500 text-xs mt-1 font-medium leading-tight">eSewa · Khalti · FonePay</p>
                    </div>
                    <span className="text-[10px] font-black px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                      Instant Credit
                    </span>
                  </button>
                )}

                {((manualSettings.paymentMode || 'both') === 'both' || manualSettings.paymentMode === 'manual') && (
                  <button
                    type="button"
                    onClick={() => setWalletStep('manual')}
                    className="flex flex-col items-center gap-3 p-6 rounded-2xl bg-white border border-zinc-200 hover:border-zinc-400 hover:shadow-xs transition-all cursor-pointer group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-red-600 group-hover:bg-red-100/80 transition-colors">
                      <QrCode className="w-6 h-6 stroke-[2.2]" />
                    </div>
                    <div className="text-center">
                      <p className="font-black text-zinc-900 text-sm">Manual Payment</p>
                      <p className="text-zinc-500 text-xs mt-1 font-medium leading-tight">Scan QR & upload proof</p>
                    </div>
                    <span className="text-[10px] font-black px-3 py-1 rounded-full bg-red-50 text-red-600 border border-red-200">
                      Admin Verified
                    </span>
                  </button>
                )}
              </div>
            </>
          )}

          {/* Online Payment */}
          {walletStep === 'online' && (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => setWalletStep('choose')}
                className="px-3.5 py-1.5 rounded-full bg-zinc-100 hover:bg-zinc-200 border border-zinc-200/80 text-zinc-900 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs w-fit"
              >
                <ArrowLeft className="w-3.5 h-3.5 text-red-600 stroke-[2.5]" />
                <span>Back</span>
              </button>

              <div className="p-5 rounded-2xl bg-white border border-zinc-200/90 shadow-xs space-y-3.5">
                <label className="font-extrabold text-zinc-800 text-xs">Custom Amount</label>
                <input
                  type="number"
                  value={walletAmount}
                  onChange={(e) => setWalletAmount(e.target.value)}
                  placeholder="Enter amount"
                  min="1"
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-3 text-zinc-900 font-mono font-bold text-sm outline-none focus:border-red-600 focus:bg-white focus:ring-2 focus:ring-red-600/15 transition-all"
                />
                <label className="font-extrabold text-zinc-800 text-xs block pt-1">Quick Amounts</label>
                <div className="grid grid-cols-3 gap-2">
                  {QUICK_AMOUNTS.map(amt => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setWalletAmount(String(amt))}
                      className={`py-2.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                        walletAmount === String(amt)
                          ? 'bg-red-600 text-white shadow-xs'
                          : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                      }`}
                    >
                      NPR {amt}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-zinc-500 font-mono font-medium">NPR 1 = 1 Wallet Credit</p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setWalletStep('choose')}
                  className="flex-1 py-3.5 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700 font-extrabold text-xs transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleOnlinePay}
                  disabled={isProcessingOnline}
                  className="flex-1 py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-red-600/20 active:scale-98 disabled:opacity-50"
                >
                  {isProcessingOnline ? <Loader2 className="w-4 h-4 animate-spin" /> : <><CreditCard className="w-4 h-4" /> Pay Now</>}
                </button>
              </div>
            </div>
          )}

          {/* ── MANUAL PAYMENT ── */}
          {walletStep === 'manual' && (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => setWalletStep('choose')}
                className="px-3.5 py-1.5 rounded-full bg-zinc-100 hover:bg-zinc-200 border border-zinc-200/80 text-zinc-900 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs w-fit"
              >
                <ArrowLeft className="w-3.5 h-3.5 text-red-600 stroke-[2.5]" />
                <span>Back</span>
              </button>

              {/* QR Card — White + Red Theme */}
              <div className="rounded-2xl bg-white border border-zinc-200/90 shadow-xs overflow-hidden p-5 space-y-4">
                {/* Title bar */}
                <div className="flex items-center gap-2">
                  <QrCode className="w-4.5 h-4.5 text-red-600" />
                  <span className="text-xs font-black text-zinc-900 uppercase tracking-wider">Scan to Pay</span>
                </div>

                {/* QR image */}
                <div className="flex flex-col items-center gap-3">
                  <div className="p-2.5 rounded-2xl border-2 border-red-600 bg-white shadow-md shadow-red-500/10">
                    <img
                      src={manualSettings.qrImageUrl}
                      alt="Payment QR Code"
                      className="w-52 h-52 object-contain rounded-xl"
                      onError={(e) => {
                        const img = e.target as HTMLImageElement;
                        img.onerror = null;
                        img.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect width="200" height="200" fill="%23f4f4f5"/><text x="50%" y="50%" fill="%2371717a" font-size="13" text-anchor="middle" dy=".3em">UG QR Code</text></svg>';
                      }}
                    />
                  </div>

                  {/* Download button — red, full width */}
                  <a
                    href={manualSettings.qrImageUrl}
                    download="UG_Gaming_QR.png"
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs transition-all cursor-pointer shadow-md shadow-red-600/20 active:scale-98"
                  >
                    <Download className="w-4 h-4" /> Download QR Code
                  </a>

                  {/* Remark hint — user's own username */}
                  <p className="text-xs text-zinc-600 text-center leading-relaxed">
                    Add your name{' '}
                    <strong className="text-zinc-900 font-extrabold">({user.username})</strong>{' '}
                    on the remarks registered on the website of payment
                  </p>
                </div>
              </div>

              {/* Credits to Top-Up */}
              <div className="space-y-1.5">
                <label className="font-extrabold text-zinc-800 text-xs">Credits to Top-Up</label>
                <input
                  type="number"
                  value={manualAmount}
                  onChange={(e) => setManualAmount(e.target.value)}
                  placeholder="Enter amount"
                  min="1"
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-3 text-zinc-900 font-mono font-bold text-xs outline-none focus:border-red-600 focus:bg-white focus:ring-2 focus:ring-red-600/15 transition-all placeholder-zinc-400"
                />
                <p className="text-[10px] text-zinc-500 font-mono font-medium">Rs.1 = 1 Credit</p>
              </div>

              {/* Payment Screenshot */}
              <div className="space-y-2">
                <label className="font-extrabold text-zinc-800 text-xs">Payment Screenshot</label>

                <button
                  type="button"
                  onClick={() => screenshotRef.current?.click()}
                  className={`w-full rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer transition-all overflow-hidden ${
                    screenshotPreview
                      ? 'border-red-600 bg-red-50/20 p-2'
                      : 'border-zinc-300 bg-zinc-50 hover:border-red-500 hover:bg-red-50/30 py-8'
                  }`}
                >
                  {screenshotPreview ? (
                    <img src={screenshotPreview} alt="Screenshot" className="w-full max-h-52 object-contain rounded-xl" />
                  ) : (
                    <>
                      <div className="w-11 h-11 rounded-full bg-red-50 border border-red-200 flex items-center justify-center text-red-600">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <span className="text-xs text-zinc-700 font-bold">Click to upload payment screenshot</span>
                      <span className="text-[10px] text-zinc-500">PNG or JPG (max 3MB)</span>
                    </>
                  )}
                </button>

                {/* Progress bar */}
                {screenshotPreview && (
                  <div className="space-y-1">
                    <div className="w-full h-1.5 rounded-full bg-zinc-200 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-red-600 transition-none"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {uploadProgress < 100 ? 'Uploading...' : 'Ready'}
                      </span>
                      <span className="text-[10px] text-zinc-500 font-mono font-bold">
                        {uploadProgress}%
                      </span>
                    </div>
                  </div>
                )}

                {/* Hidden file input */}
                <input
                  ref={screenshotRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleScreenshotChange}
                />
              </div>

              {/* Submit button */}
              <button
                type="button"
                onClick={handleManualSubmit}
                disabled={isSubmittingManual || isUploadAnimating}
                className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-red-600/20 disabled:opacity-50 active:scale-98 uppercase tracking-wider"
              >
                {isSubmittingManual ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Submitting...</>
                ) : (
                  <><ShieldCheck className="w-4 h-4" /> Submit for Verification</>
                )}
              </button>

              {manualMsg && (
                <div className={`p-3 rounded-xl border font-bold flex items-center gap-2 text-xs ${
                  manualMsg.ok
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                    : 'bg-red-50 border-red-200 text-red-600'
                }`}>
                  {manualMsg.ok
                    ? <Check className="w-4 h-4 flex-shrink-0 text-emerald-600" />
                    : <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />}
                  {manualMsg.text}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Transaction History */}
        <div className="lg:col-span-1 space-y-3 text-xs">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h4 className="font-black text-zinc-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <History className="w-4 h-4 text-red-600" /> Transaction History
            </h4>
            <div className="flex items-center bg-zinc-100 p-0.5 rounded-lg border border-zinc-200 text-[10px] font-extrabold">
              <button
                type="button"
                onClick={() => setHistoryFilter('deposits')}
                className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                  historyFilter === 'deposits'
                    ? 'bg-red-600 text-white shadow-2xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Deposits Only
              </button>
              <button
                type="button"
                onClick={() => setHistoryFilter('all')}
                className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                  historyFilter === 'all'
                    ? 'bg-red-600 text-white shadow-2xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                All Activity
              </button>
            </div>
          </div>

          {(() => {
            const displayedHistory = walletHistory.filter((txn) => {
              if (historyFilter === 'deposits') {
                return (
                  txn.amount > 0 ||
                  txn.type === 'RECHARGE' ||
                  txn.type === 'CREDIT' ||
                  (txn.packageName && txn.packageName.toLowerCase().includes('top-up'))
                );
              }
              return true;
            });

            if (displayedHistory.length === 0) {
              return (
                <div className="p-8 text-center bg-white border border-zinc-200/90 rounded-2xl flex flex-col items-center gap-2 shadow-xs">
                  <History className="w-8 h-8 text-zinc-400" />
                  <p className="font-bold text-zinc-500 text-xs">
                    {historyFilter === 'deposits' ? 'No deposit records found' : 'No transactions yet'}
                  </p>
                </div>
              );
            }

            return (
              <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
                {displayedHistory.map((txn) => {
                  const status = (txn.status || 'SUCCESS').toUpperCase();
                  const isPending = status === 'PENDING';
                  const isRejected = status === 'REJECTED';
                  const isSuccess = status === 'SUCCESS' || status === 'APPROVED';

                  return (
                    <div key={txn.id} className="p-3 rounded-xl bg-white border border-zinc-200/80 flex items-center gap-2.5 shadow-2xs">
                      <div className={`p-2 rounded-lg flex-shrink-0 ${
                        isPending ? 'bg-amber-50 border border-amber-200' :
                        isRejected ? 'bg-red-50 border border-red-200' :
                        txn.amount > 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-red-50 border border-red-200'
                      }`}>
                        {txn.amount > 0
                          ? <ArrowDownLeft className={`w-3.5 h-3.5 ${isPending ? 'text-amber-600' : isRejected ? 'text-red-600' : 'text-emerald-600'}`} />
                          : <ArrowUpRight className="w-3.5 h-3.5 text-red-600" />
                        }
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-zinc-900 text-xs truncate">
                          {txn.packageName || (txn.amount > 0 ? 'Wallet Top-Up' : 'Game Purchase')}
                        </p>
                        <p className="text-[10px] text-zinc-500 font-mono truncate">{txn.paymentMethod || 'UG Wallet'} · {txn.date}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className={`font-black font-mono text-xs ${isPending ? 'text-amber-600' : isRejected ? 'text-red-500 line-through' : txn.amount > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                          {txn.amount > 0 ? `+NPR ${txn.amount}` : `-NPR ${Math.abs(txn.amount)}`}
                        </p>
                        <span className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full border ${
                          isPending ? 'bg-amber-50 text-amber-700 border-amber-200' :
                          isRejected ? 'bg-red-50 text-red-600 border-red-200' :
                          'bg-emerald-50 text-emerald-700 border-emerald-200'
                        }`}>
                          {isPending ? 'PENDING' : isRejected ? 'REJECTED' : 'SUCCESS'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      </div>
    </AccountLayout>
  );
};
