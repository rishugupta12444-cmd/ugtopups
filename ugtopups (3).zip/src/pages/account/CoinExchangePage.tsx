import React, { useState } from 'react';
import {
  Coins, ArrowLeftRight, History, ArrowDownLeft, ArrowUpRight,
  Loader2, Check, AlertCircle, ShoppingBag, Info, PlusCircle,
} from 'lucide-react';
import { UserProfile, WalletTransaction } from '../../types';
import { AccountLayout } from '../../components/account/AccountLayout';
import { COIN_EXCHANGE_RATE_COINS, COIN_EXCHANGE_RATE_NPR, MIN_COIN_EXCHANGE, coinsToNpr } from '../../lib/store';

interface CoinExchangePageProps {
  user: UserProfile;
  walletHistory: WalletTransaction[];
  onNavigate: (path: string) => void;
  onExchangeCoins: (coins: number) => Promise<void>;
}

const QUICK_COIN_AMOUNTS = [30, 50, 100, 300];

export const CoinExchangePage: React.FC<CoinExchangePageProps> = ({
  user, walletHistory, onNavigate, onExchangeCoins,
}) => {
  const coinBalance = Math.floor(user.coinBalance || 0);
  const [coinAmount, setCoinAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const parsedAmount = Math.floor(Number(coinAmount) || 0);
  const creditPreview = parsedAmount > 0 ? coinsToNpr(parsedAmount) : 0;
  const isValid = parsedAmount >= MIN_COIN_EXCHANGE && parsedAmount <= coinBalance;

  const handleExchange = async () => {
    if (parsedAmount < MIN_COIN_EXCHANGE) {
      setMsg({ text: `Minimum ${MIN_COIN_EXCHANGE} UG Coins required to exchange.`, ok: false });
      return;
    }
    if (parsedAmount > coinBalance) {
      setMsg({ text: 'You don\u2019t have enough UG Coins.', ok: false });
      return;
    }
    setIsSubmitting(true);
    setMsg(null);
    try {
      await onExchangeCoins(parsedAmount);
      setMsg({ text: `Exchanged ${parsedAmount} coins for NPR ${coinsToNpr(parsedAmount)} wallet credit!`, ok: true });
      setCoinAmount('');
    } catch (err: any) {
      setMsg({ text: err?.message || 'Exchange failed. Please try again.', ok: false });
    } finally {
      setIsSubmitting(false);
      setTimeout(() => setMsg(null), 4000);
    }
  };

  // Filter transactions for any coin activity (earned from orders or exchanged)
  const coinHistory = walletHistory.filter((txn) =>
    (txn.paymentMethod || '').toLowerCase().includes('coin') ||
    (txn.packageName || '').toLowerCase().includes('coin') ||
    (txn.id || '').startsWith('COIN-') ||
    (txn.id || '').startsWith('TXN-COIN-')
  );

  return (
    <AccountLayout
      title="UG Coins"
      subtitle="Earn coins on every order, exchange them for wallet credit"
      icon={Coins}
      breadcrumbs={[{ label: 'My Account', path: '/account' }, { label: 'UG Coins' }]}
      onNavigate={onNavigate}
      walletBalance={user.walletBalanceNpr}
      userName={user.username}
      avatarUrl={user.avatarUrl}
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column: balance + exchange */}
        <div className="lg:col-span-2 space-y-4 text-xs">

          {/* Coin balance hero card */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 p-5 sm:p-6 shadow-lg shadow-amber-500/20">
            <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-white/10" />
            <div className="absolute -right-2 bottom-2 w-16 h-16 rounded-full bg-white/10" />
            <div className="relative flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center flex-shrink-0">
                <Coins className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase text-amber-50 tracking-wider">
                  Total UG Coins Earned
                </span>
                <h2 className="font-black text-2xl sm:text-3xl text-white font-mono leading-tight">
                  {coinBalance.toLocaleString('en-IN')}
                </h2>
                <p className="text-[11px] text-amber-50/90 font-medium mt-0.5">
                  ≈ NPR {coinsToNpr(coinBalance).toLocaleString('en-IN')} if exchanged today
                </p>
              </div>
            </div>
          </div>

          {/* How you earn coins */}
          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center flex-shrink-0">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-zinc-900 text-xs">Earn 3 UG Coins on every order</p>
              <p className="text-[11px] text-amber-800/80 font-medium mt-0.5 leading-relaxed">
                Every time an order is completed successfully — any game, any payment method — you get +3 UG Coins automatically.
              </p>
            </div>
          </div>

          {/* Exchange form */}
          <div className="p-5 rounded-2xl bg-white border border-zinc-200/90 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ArrowLeftRight className="w-4 h-4 text-red-600" />
                <span className="text-xs font-black text-zinc-900 uppercase tracking-wider">Exchange Coins for Credit</span>
              </div>
              <span className="text-[10px] font-bold text-zinc-500 bg-zinc-100 px-2 py-0.5 rounded-md">
                Min. {MIN_COIN_EXCHANGE} Coins
              </span>
            </div>

            <label className="font-extrabold text-zinc-800 text-xs block">Coins to Exchange</label>
            <input
              type="number"
              value={coinAmount}
              onChange={(e) => setCoinAmount(e.target.value)}
              placeholder={`Enter coins (min ${MIN_COIN_EXCHANGE}, max ${coinBalance})`}
              min={MIN_COIN_EXCHANGE}
              max={coinBalance}
              className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-3 text-zinc-900 font-mono font-bold text-sm outline-none focus:border-red-600 focus:bg-white focus:ring-2 focus:ring-red-600/15 transition-all"
            />

            <label className="font-extrabold text-zinc-800 text-xs block pt-1">Quick Amounts</label>
            <div className="grid grid-cols-4 gap-2">
              {QUICK_COIN_AMOUNTS.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  disabled={amt > coinBalance}
                  onClick={() => setCoinAmount(String(amt))}
                  className={`py-2.5 rounded-xl text-[11px] font-extrabold transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                    coinAmount === String(amt)
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setCoinAmount(String(coinBalance))}
              disabled={coinBalance < MIN_COIN_EXCHANGE}
              className="text-[10px] font-bold text-red-600 hover:text-red-700 disabled:opacity-40 disabled:cursor-not-allowed w-fit"
            >
              Use all {coinBalance} coins
            </button>

            <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-200/80 flex items-center justify-between">
              <span className="text-[10px] text-zinc-500 font-mono font-medium flex items-center gap-1.5">
                <Info className="w-3 h-3" /> {COIN_EXCHANGE_RATE_COINS} Coins = NPR {COIN_EXCHANGE_RATE_NPR} (Min. {MIN_COIN_EXCHANGE} Coins = NPR {coinsToNpr(MIN_COIN_EXCHANGE)})
              </span>
              <span className="font-black font-mono text-emerald-600 text-sm">
                + NPR {creditPreview.toLocaleString('en-IN')}
              </span>
            </div>

            <button
              type="button"
              onClick={handleExchange}
              disabled={isSubmitting || !isValid}
              className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-red-600/20 disabled:opacity-50 active:scale-98 uppercase tracking-wider"
            >
              {isSubmitting ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Exchanging...</>
              ) : (
                <><ArrowLeftRight className="w-4 h-4" /> Exchange for Wallet Credit</>
              )}
            </button>

            {msg && (
              <div className={`p-3 rounded-xl border font-bold flex items-center gap-2 text-xs ${
                msg.ok
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                  : 'bg-red-50 border-red-200 text-red-600'
              }`}>
                {msg.ok
                  ? <Check className="w-4 h-4 flex-shrink-0 text-emerald-600" />
                  : <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600" />}
                {msg.text}
              </div>
            )}
          </div>
        </div>

        {/* Right: coin activity history */}
        <div className="lg:col-span-1 space-y-3 text-xs">
          <h4 className="font-black text-zinc-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
            <History className="w-4 h-4 text-red-600" /> Coin Activity
          </h4>

          {coinHistory.length === 0 ? (
            <div className="p-8 text-center bg-white border border-zinc-200/90 rounded-2xl flex flex-col items-center gap-2 shadow-xs">
              <Coins className="w-8 h-8 text-zinc-400" />
              <p className="font-bold text-zinc-500 text-xs">No coin activity yet</p>
              <p className="text-[10px] text-zinc-400">Complete an order to earn 3 UG Coins</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
              {coinHistory.map((txn) => {
                const isEarned = (txn.paymentMethod || '').includes('Reward') || (txn.id || '').startsWith('COIN-REW');
                const title = txn.packageName || (isEarned ? 'Earned +3 UG Coins' : 'Coin Exchange');
                const dateStr = txn.date ? new Date(txn.date).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';

                return (
                  <div key={txn.id} className="p-3 rounded-xl bg-white border border-zinc-200/80 flex items-center gap-2.5 shadow-2xs">
                    <div className={`p-2 rounded-lg flex-shrink-0 ${isEarned ? 'bg-emerald-50 border border-emerald-200 text-emerald-600' : 'bg-amber-50 border border-amber-200 text-amber-600'}`}>
                      {isEarned ? <PlusCircle className="w-3.5 h-3.5" /> : <ArrowDownLeft className="w-3.5 h-3.5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-zinc-900 text-xs truncate">{title}</p>
                      <p className="text-[10px] text-zinc-500 font-mono truncate">{dateStr}</p>
                    </div>
                    <p className={`font-black font-mono text-xs flex-shrink-0 ${isEarned ? 'text-amber-600' : 'text-emerald-600'}`}>
                      {isEarned ? '+3 Coins' : `+NPR ${Math.abs(txn.amount)}`}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </AccountLayout>
  );
};
