import React, { useState } from 'react';
import { ListFilter, History, Search, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { WalletTransaction, UserProfile } from '../../types';
import { AccountLayout } from '../../components/account/AccountLayout';

interface TransactionsPageProps {
  walletHistory: WalletTransaction[];
  onNavigate: (path: string) => void;
  user?: UserProfile;
}

export const TransactionsPage: React.FC<TransactionsPageProps> = ({ walletHistory, onNavigate, user }) => {
  const [txnSearch, setTxnSearch] = useState('');

  const filteredTxns = walletHistory.filter(t =>
    !txnSearch || t.paymentMethod.toLowerCase().includes(txnSearch.toLowerCase()) || (t.orderId || '').toLowerCase().includes(txnSearch.toLowerCase())
  );

  return (
    <AccountLayout
      title="Transactions"
      subtitle="Your wallet activity"
      icon={ListFilter}
      breadcrumbs={[{ label: 'My Account', path: '/account' }, { label: 'Transactions' }]}
      onNavigate={onNavigate}
      walletBalance={user?.walletBalanceNpr}
      userName={user?.username || user?.fullName}
      avatarUrl={user?.avatarUrl}
    >
      <div className="space-y-4 text-xs max-w-2xl">
        <h4 className="font-black text-white text-[13px] flex items-center gap-2">
          <History className="w-4 h-4 text-amber-400" /> Wallet Transactions
        </h4>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-600 pointer-events-none" />
          <input
            type="text"
            value={txnSearch}
            onChange={(e) => setTxnSearch(e.target.value)}
            placeholder="Search transactions…"
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2.5 text-white text-xs outline-none focus:border-zinc-600 transition-all placeholder-zinc-600"
          />
        </div>

        {filteredTxns.length === 0 ? (
          <div className="p-12 text-center bg-zinc-900 border border-zinc-800 rounded-2xl flex flex-col items-center gap-3">
            <ListFilter className="w-10 h-10 text-zinc-700" />
            <p className="font-bold text-zinc-400">No transactions yet</p>
            <p className="text-[11px] text-zinc-600">Your wallet history will appear here</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredTxns.map((txn) => {
              const status = (txn.status || 'SUCCESS').toUpperCase();
              const isPending = status === 'PENDING';
              const isRejected = status === 'REJECTED';

              return (
                <div key={txn.id} className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center gap-3 hover:border-zinc-700 transition-all">
                  <div className={`p-2.5 rounded-xl flex-shrink-0 ${
                    isPending ? 'bg-amber-500/10 border border-amber-500/20' :
                    isRejected ? 'bg-red-500/10 border border-red-500/20' :
                    txn.amount > 0 ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-red-500/10 border border-red-500/20'
                  }`}>
                    {txn.amount > 0
                      ? <ArrowDownLeft className={`w-4 h-4 ${isPending ? 'text-amber-400' : isRejected ? 'text-red-400' : 'text-emerald-400'}`} />
                      : <ArrowUpRight className="w-4 h-4 text-red-400" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-white text-[12px] truncate">
                      {txn.packageName || (txn.amount > 0 ? 'Wallet Top-Up' : 'Game Purchase')}
                    </p>
                    <p className="text-[10px] text-zinc-400 font-mono mt-0.5 truncate">{txn.paymentMethod || 'UG Wallet'} · {txn.date}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={`font-black font-mono text-sm ${isPending ? 'text-amber-400' : isRejected ? 'text-red-400 line-through' : txn.amount > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {txn.amount > 0 ? `+NPR ${txn.amount}` : `-NPR ${Math.abs(txn.amount)}`}
                    </p>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      isPending ? 'bg-amber-950/60 text-amber-400 border-amber-800/80' :
                      isRejected ? 'bg-red-950/60 text-red-400 border-red-800/80' :
                      'bg-emerald-950/60 text-emerald-400 border-emerald-800/80'
                    }`}>
                      {isPending ? 'PENDING' : isRejected ? 'REJECTED' : 'SUCCESS'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AccountLayout>
  );
};
