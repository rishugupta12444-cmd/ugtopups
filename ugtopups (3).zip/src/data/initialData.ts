import { Game, Review, UserProfile, BannerItem, GameCategory, ProductItem } from '../types';

export const INITIAL_PRODUCTS: ProductItem[] = [];

export const INITIAL_CATEGORIES: GameCategory[] = [
  { id: 'cat-all', name: 'All Games', enabled: true, order: 0 },
  { id: 'cat-games', name: 'Games', enabled: true, order: 1 },
  { id: 'cat-subscription', name: 'Subscription', enabled: true, order: 2 },
  { id: 'cat-voucher', name: 'Voucher', enabled: true, order: 3 },
  { id: 'cat-other', name: 'Other', enabled: true, order: 4 },
];

export const INITIAL_BANNERS: BannerItem[] = [
  {
    id: 'banner-1',
    imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    title: "NEPAL'S #1 UG TOP UP MARKETPLACE",
    subtitle: 'Direct in-game top-up and digital gift card delivery. Official API Partner.',
    badge: 'OFFICIAL PORTAL',
    actionText: 'EXPLORE TOP UP',
    gameId: '',
    active: true,
  },
  {
    id: 'banner-2',
    imageUrl: 'https://www.image2url.com/r2/default/images/1783255352194-faa04ba5-3fed-4b18-b0b1-5df6b1304a4b.png',
    title: 'INSTANT GAME TOP UP & PASSES',
    subtitle: 'Fast and reliable gaming top-ups with instant delivery via Zone ID or User ID.',
    badge: 'BEST VALUE',
    actionText: 'VIEW PACKAGES',
    gameId: '',
    active: true,
  },
  {
    id: 'banner-3',
    imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80',
    title: 'EASY PAYMENTS WITH UG WALLET',
    subtitle: 'Pay via eSewa, Khalti, Fonepay or UG Wallet with instant confirmation.',
    badge: 'INSTANT CREDIT',
    actionText: 'TOP UP NOW',
    gameId: '',
    active: true,
  },
  {
    id: 'banner-4',
    imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
    title: '5% EXTRA BONUS WITH UG WALLET',
    subtitle: 'Recharge your UG Wallet using Fonepay Hub QR for instant 1-click checkout on all games!',
    badge: 'WALLET BONUS',
    actionText: 'RECHARGE WALLET',
    linkUrl: '#wallet',
    active: true,
  },
];

// Guest/default user state — id is intentionally empty string.
// The real Supabase Auth UID is set in onAuthStateChange (App.tsx) after login.
// NEVER seed this into Supabase — it has no valid Auth UID.
export const INITIAL_USER: UserProfile = {
  id: '',
  username: '',
  email: '',
  gameUid: '',
  avatarUrl: '',
  walletBalanceNpr: 0,
  level: 'Regular Member',
  totalTopupsNpr: 0,
  completedOrdersCount: 0,
  coinBalance: 0,
  registrationDate: '',
};

export const GAMES_DATA: Game[] = [];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    userName: 'sujan sorali',
    rating: 5,
    date: 'Jun 26, 2026',
    game: 'Free Fire',
    comment: 'Good service ',
    verified: true,
  },
  {
    id: 'rev-2',
    userName: 'Prateek',
    rating: 5,
    date: 'Jun 26, 2026',
    game: 'Free Fire',
    comment: 'Great service! Purchased 520 Diamonds without any issues. Quick response and reliable seller. Will buy again!',
    verified: true,
  },
  {
    id: 'rev-3',
    userName: 'Sudip Thapa',
    rating: 5,
    date: 'Jun 25, 2026',
    game: 'Free Fire',
    comment: 'The Gamers trust platform and secure website instant delivery... gameshopnepal... 😎',
    verified: true,
  },
  {
    id: 'rev-4',
    userName: 'Sulav',
    rating: 5,
    date: 'Jun 24, 2026',
    game: 'Mobile Legends',
    comment: 'Best online topup portal in Nepal. MLBB diamonds came within 15 seconds after eSewa payment!',
    verified: true,
  },
  {
    id: 'rev-5',
    userName: 'Aayush BK',
    rating: 5,
    date: 'Jun 22, 2026',
    game: 'Free Fire',
    comment: 'Wallet payment balance option is super fast! UG Top Up is 100% genuine and fast.',
    verified: true,
  },
  {
    id: 'rev-6',
    userName: 'Kiran Shrestha',
    rating: 5,
    date: 'Jun 20, 2026',
    game: 'PUBG Mobile',
    comment: '660 UC topup delivered automatically. Very happy with instant customer service on WhatsApp.',
    verified: true,
  },
  {
    id: 'rev-7',
    userName: 'Rohan Gurung',
    rating: 5,
    date: 'Jun 18, 2026',
    game: 'Free Fire',
    comment: 'Level up pass and Weekly membership added instantly to my UID. Highly recommended top up center!',
    verified: true,
  },
];
