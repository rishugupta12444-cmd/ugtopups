import { jsPDF } from 'jspdf';
import { Order } from '../types';
import { isRedeemCodeOrder } from '../lib/store';

export function generateOrderPdf(order: Order) {
  const isRedeem = isRedeemCodeOrder(order);

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Header Box - UG Red
  doc.setFillColor(220, 38, 38);
  doc.rect(0, 0, 210, 34, 'F');

  // Title in Header
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text('UG TOP UP CENTER', 15, 18);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Official Gaming Top-Up Receipt', 15, 26);

  doc.setFontSize(9);
  doc.text('https://ugtopup.com', 195, 26, { align: 'right' });

  // Receipt Title
  let y = 46;
  doc.setTextColor(24, 24, 27);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('ORDER CONFIRMATION & RECEIPT', 15, y);

  y += 5;
  doc.setDrawColor(228, 228, 231);
  doc.line(15, y, 195, y);

  // Details Container Box
  y += 8;
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(15, y, 180, 115, 3, 3, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(15, y, 180, 115, 3, 3, 'D');

  const rawRows: [string, string][] = [
    ['Order Reference ID', order.orderId],
    ['Game Title', order.gameName],
    ['Package Selected', order.packageName],
    ['Package Type', isRedeem ? 'Digital Redeem Voucher (Auto Delivered)' : 'Direct In-Game Top-Up'],
    ...(!isRedeem ? [
      ['Player UID', order.playerUid] as [string, string],
      ['Player Nickname', order.playerName || 'N/A'] as [string, string],
      ...(order.zoneId ? [['Zone / Server ID', order.zoneId] as [string, string]] : []),
    ] : []),
    ['Payment Method', order.paymentMethod || 'UG Wallet / Fonepay Hub'],
    ['Transaction Reference', order.transactionRef || order.orderId],
    ['Payment Status', order.paymentStatus || 'SUCCESS'],
    ['Order Status', order.topUpStatus === 'COMPLETED' ? 'COMPLETED' : 'PROCESSING (2-5 Min)'],
    ['Order Date & Time', new Date(order.createdAt).toLocaleString()],
    ['Total Amount Paid', `NPR ${order.totalPriceNpr.toLocaleString('en-IN')}`],
  ];

  let currentY = y + 10;
  rawRows.forEach(([label, value], idx) => {
    const isTotal = idx === rawRows.length - 1;
    doc.setFont('helvetica', isTotal ? 'bold' : 'bold');
    doc.setFontSize(isTotal ? 11 : 9.5);
    doc.setTextColor(100, 116, 139);
    doc.text(label, 22, currentY);

    doc.setFont('helvetica', isTotal ? 'bold' : 'normal');
    doc.setTextColor(isTotal ? 220 : 24, isTotal ? 38 : 24, isTotal ? 38 : 27);
    doc.setFontSize(isTotal ? 12 : 9.5);
    doc.text(String(value), 188, currentY, { align: 'right' });

    currentY += 8.5;
  });

  // Support / Footer Section
  currentY += 15;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(24, 24, 27);
  doc.text('Need Assistance With Your Order?', 15, currentY);

  currentY += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('WhatsApp Support: +977 9708562001 (Available 24/7)', 15, currentY);

  currentY += 5;
  doc.text('Thank you for choosing UG Top Up Center for instant in-game top-ups!', 15, currentY);

  // Save the PDF
  doc.save(`UG_Receipt_${order.orderId}.pdf`);
}
