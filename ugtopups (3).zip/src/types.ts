export interface ProductItem {
  id: string;
  name: string;
  code: string; // e.g., PRD-9041
  category: string; // Audio, Wearables, Accessories, Gaming, Top-Up, Games, Subscription, Voucher, Other, etc.
  productType?: 'voucher' | 'topup'; // 'voucher' for digital redeem code, 'topup' for in-game direct UID top-up
  status: 'Active' | 'Inactive';
  availability: 'In Stock' | 'Out Of Stock' | 'Pre-Order';
  priceNpr: number;
  stockCount?: number;
  imageUrl: string;
  description?: string;
  descriptionTitle?: string;
  requireUid?: boolean;
  requireZoneId?: boolean;
  requireEmail?: boolean;
  requirePassword?: boolean;
  requireWhatsapp?: boolean;
  userField1?: string;
  userField2?: string;
  customFields?: CustomInputField[];
  gameId?: string;
  createdAt?: string;
  updatedAt?: string;
}

/** Admin-defined extra checkout field with a custom title (unlimited, added via "+ Add New"). */
export interface CustomInputField {
  id: string;
  label: string;
}

export interface BannerItem {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  badge?: string;
  actionText?: string;
  gameId?: string;
  linkUrl?: string;
  active?: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  description: string;
  icon?: string;
  status: 'active' | 'inactive';
  buttonEnabled: boolean;
  buttonText?: string;
  buttonUrl?: string;
  buttonIcon?: string;
  openInNewTab: boolean;
  startAt?: string | null;
  endAt?: string | null;
  priority: number;
  autoDisplay: boolean;
  allowDontShowAgain: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface GameCategory {
  id: string;
  name: string;
  enabled: boolean;
  order: number;
}

export interface GamePackage {
  id: string;
  name: string;
  diamonds: number;
  bonus?: number;
  priceNpr: number;
  badge?: string; // e.g., 'HOT', 'BEST VALUE', 'POPULAR', '100% SECURE'
  iconType?: 'diamond' | 'membership' | 'pass' | 'coin';
  category?: 'purchase' | 'redeem';
  active?: boolean;
  requiresRedeemCode?: boolean;
  /** Liana Store product ID for Mobile Legends automated delivery. Set from Admin Panel. */
  product_id?: number;
  /** @deprecated Legacy field kept for backward compatibility with older saved packages. Treat as product_id only when product_id is absent. */
  variation_id?: number;
}

export interface Game {
  id: string;
  name: string;
  category: string;
  productType?: 'voucher' | 'topup';
  iconUrl: string;
  bannerUrl: string;
  requireUid?: boolean;
  requiresZoneId?: boolean;
  requireZoneId?: boolean;
  requireEmail?: boolean;
  requirePassword?: boolean;
  requireWhatsapp?: boolean;
  userField1?: string;
  userField2?: string;
  customFields?: CustomInputField[];
  uidPlaceholder: string;
  packages: GamePackage[];
  description: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Review {
  id: string;
  userName: string;
  avatarUrl?: string;
  rating: number;
  date: string;
  game: string;
  comment: string;
  verified: boolean;
  status?: 'PENDING' | 'APPROVED' | 'REJECTED';
}

export interface UserProfile {
  id: string;            // Supabase Auth UID — ALWAYS the table record ID
  userCode?: string;     // Display code only (e.g. "UG-USR-8829") — stored as field, never as doc ID
  username: string;
  email: string;
  gameUid: string;
  avatarUrl?: string;
  walletBalanceNpr: number;
  level: string; // e.g. 'VIP Diamond Member'
  totalTopupsNpr: number;
  completedOrdersCount: number;
  coinBalance?: number; // UG Coins — earned 3 per successful order, exchangeable for wallet credit
  registrationDate?: string;
}

export interface AdminNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  unread: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  unread: boolean;
  category: 'Announcement' | 'Promo Code' | 'Order' | 'Wallet' | 'System';
  isPinned?: boolean;
  isExpired?: boolean;
  expiresIn?: string;
  linkUrl?: string;
  orderId?: string;
  productId?: string;
  packageId?: string;
  code?: string;
}

export interface WalletTransaction {
  id: string;
  orderId?: string;
  packageName?: string;
  amount: number;
  type: 'RECHARGE' | 'DEDUCTION' | 'PURCHASE';
  date: string;
  paymentMethod: string;
  status: 'SUCCESS' | 'FAILED';
}

export type PaymentMethodChoice = 'wallet' | 'fonepay_hub';

export interface Order {
  orderId: string;
  userId?: string;        // Supabase Auth UID of the user who placed the order
  gameId: string;
  gameName: string;
  playerUid: string;
  playerName: string;
  /** True only after the UID was successfully verified by the server verification flow. */
  uidVerified?: boolean;
  uidVerifiedAt?: string;
  zoneId?: string;
  userEmail?: string;
  userPassword?: string;
  userWhatsapp?: string;
  userField1Val?: string;
  userField2Val?: string;
  /** Values for any admin-added dynamic custom fields (from Game.customFields). */
  customFieldValues?: { id: string; label: string; value: string }[];
  packageName: string;
  diamonds: number;
  quantity: number;
  totalPriceNpr: number;
  walletDeductionNpr: number;
  paymentMethod: string;
  transactionRef: string;
  paymentStatus: 'Paid' | 'Pending' | 'Failed' | 'SUCCESS' | 'PENDING' | 'CANCELLED';
  topUpStatus?: 'PENDING' | 'COMPLETED' | 'CANCELLED' | 'PENDING_API_INTEGRATION' | string;
  status: 'Pending' | 'Completed' | 'Cancelled' | string;
  createdAt: string;
  completedAt?: string;
  completedBy?: string;
  cancelledAt?: string;
  cancelledBy?: string;
}

export interface SocialLinks {
  facebook: string;
  tiktok: string;
  instagram: string;
  youtube: string;
  discord: string;
  whatsapp: string;
  email: string;
  location: string;
}

export interface RedeemCodeRecord {
  id: string;
  productId?: string;
  gameId: string;
  gameName: string;
  packageId: string;
  packageName: string;
  code: string;
  status: 'AVAILABLE' | 'RESERVED' | 'DELIVERED' | 'REDEEMED' | 'CANCELLED' | 'USED';
  usedByOrder?: string;
  usedByEmail?: string;
  usedByUid?: string;
  createdAt: string;
  assignedAt?: string;
  deliveredAt?: string;
  redeemedAt?: string;
  usedAt?: string;
}
