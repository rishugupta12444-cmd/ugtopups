import type { IncomingMessage, ServerResponse } from 'http';
import { handleFreeFireVerification } from '../server/verifyApiMiddleware';

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-API-Key, X-Signature');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  const url = req.url || '';
  if (
    url.includes('/api/game/check-uid') ||
    url.includes('/api/v1/verify/freefire') ||
    url.includes('/api/v1/verify/pubg') ||
    url.includes('/api/verify-freefire') ||
    url.includes('/api/verify-pubg')
  ) {
    await handleFreeFireVerification(req, res);
    return;
  }

  res.statusCode = 200;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({ status: 'ok', message: 'UG Top Up Serverless Endpoint Active' }));
}
