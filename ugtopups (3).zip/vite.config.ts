import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// NOTE: The /api/game/check-uid server middleware has been removed.
// UID verification is now handled by the Supabase Edge Function `check-uid`.
// The frontend calls supabase.functions.invoke('check-uid') — no server middleware needed.

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
  ],
  server: {
    port: 3000,
    host: true,
  },
  preview: {
    port: 3000,
    host: true,
  },
  build: {
    rollupOptions: {
      // Exclude server-only files from the browser bundle
      external: [],
    },
  },
});
