# Redeem Code Inventory + Automatic Voucher Delivery

This project now uses the existing Products/Packages/Orders/Payments/Notifications architecture with a secure Supabase redeem-code inventory.

## Database

Apply `supabase/redeem_codes_secure.sql` to the existing Supabase project. The same SQL is appended to `supabase/migration.sql` for fresh deployments.

The migration creates/updates:

- `redeem_codes` — protected inventory table
- `redeem_code_audit` — audit history
- RLS policies so customers cannot list the inventory
- secure functions for stock, reservation, delivery, release, and owner-only code retrieval
- `requiresRedeemCode` support through the existing `products.packages` JSONB
- notification ownership fields/policies
- an atomic wallet voucher checkout function

## Edge Functions

Deploy the three new functions and redeploy the modified payment functions:

```bash
supabase functions deploy redeem-code-admin
supabase functions deploy redeem-code-delivery
supabase functions deploy wallet-voucher-checkout
supabase functions deploy api-nepal-initiate
supabase functions deploy api-nepal-ipn
supabase functions deploy api-nepal-status
```

The functions use the existing Supabase service-role environment and the existing API Nepal secrets already used by the payment functions. No redeem-code secret is placed in the frontend.

## Package configuration

In Admin Panel → Products/Packages, enable **Requires Redeem Code** only for voucher packages. Normal top-up packages remain unchanged.

## Admin workflow

Admin Panel → Redeem Code → select Product → select Package → paste one code per line → Save Codes.

Imports are sent to the admin-only Edge Function. Codes are never stored in localStorage or settings backups.

## Customer delivery

Voucher delivery occurs only after the payment flow verifies success. Reservation is atomic and package-specific, so concurrent purchases cannot receive the same code. The customer can retrieve only the codes belonging to their own authenticated order.

## Cancellation/refund behavior

Pre-payment reservations are released on explicit payment cancellation/failure. Once a voucher has been delivered, it remains attached to the order for audit/history and is not automatically returned to stock.


## Voucher Email Delivery

Voucher orders are delivered by email instead of automatic in-app notifications.

Set these Supabase Edge Function secrets:

```bash
supabase secrets set RESEND_API_KEY=YOUR_RESEND_API_KEY
supabase secrets set VOUCHER_EMAIL_FROM="UGTOPUPS <noreply@your-verified-domain.com>"
```

The sender address/domain must be verified in Resend.

Deploy:

```bash
supabase functions deploy send-voucher-email
supabase functions deploy redeem-code-delivery
supabase functions deploy wallet-voucher-checkout
supabase functions deploy api-nepal-ipn
supabase functions deploy api-nepal-status
```

Voucher emails are tracked in `voucher_email_deliveries` so the same order is not emailed twice.

## Voucher In-App Notification (in addition to email)

Apply `supabase/notification_voucher_code_column.sql` (adds a `code` column to `notifications`).

`send-voucher-email` now also inserts a notification (title "Voucher Delivered 🎟️") with the
game/package name, order ID, and the redeem code(s), independent of whether the email itself
succeeds. It uses a deterministic id (`voucher-<orderId>`) so re-invoking the function for the
same order never creates a duplicate notification. No extra deploy step is needed beyond
redeploying `send-voucher-email` — just apply the SQL column first.
