-- ============================================================
-- CRITICAL BUG FIX — Run this in Supabase SQL Editor
-- Fixes: Orders not showing in Admin Panel
-- Fixes: Orders disappearing after Complete action
-- ============================================================

-- ── FIX 1: Orders table UPDATE policy missing ────────────────
-- The migration.sql only created INSERT + SELECT for orders.
-- Without an UPDATE policy, adminUpdateOrderStatus() silently
-- fails when trying to mark an order Completed/Cancelled,
-- which also explains why the order seems to "vanish" — the
-- update fails but the UI optimistically closes the drawer.
DROP POLICY IF EXISTS "Orders: update own"  ON public.orders;
DROP POLICY IF EXISTS "Orders: update admin" ON public.orders;

-- Users can update their own orders (for Fonepay QR payment flow)
CREATE POLICY "Orders: update own" ON public.orders FOR UPDATE
    USING (auth.uid()::text = "userId");

-- Admin can update any order (Complete / Cancel)
CREATE POLICY "Orders: update admin" ON public.orders FOR UPDATE
    USING (public.is_admin())
    WITH CHECK (public.is_admin());

-- ── FIX 2: Also ensure admin DELETE policy exists ────────────
-- (Not strictly needed but prevents silent failures)
DROP POLICY IF EXISTS "Orders: delete admin" ON public.orders;
CREATE POLICY "Orders: delete admin" ON public.orders FOR DELETE
    USING (public.is_admin());

-- ── FIX 3: Verify is_admin() function works correctly ────────
-- Re-create the function to ensure it's up to date
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admins
    WHERE id = auth.uid()::text AND active = true
  ) OR EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()::text AND role = 'admin'
  );
$$;

-- ── FIX 4: Transactions UPDATE policy for admin ──────────────
DROP POLICY IF EXISTS "Transactions: update admin" ON public.transactions;
CREATE POLICY "Transactions: update admin" ON public.transactions FOR ALL
    USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ── VERIFY: Check your orders table has RLS enabled ──────────
-- If this returns false, run: ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
SELECT schemaname, tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public' AND tablename = 'orders';

-- ── VERIFY: List all order policies ──────────────────────────
SELECT policyname, cmd, qual
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'orders'
ORDER BY policyname;
