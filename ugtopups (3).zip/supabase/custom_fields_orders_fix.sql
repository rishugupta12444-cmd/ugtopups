-- ============================================================
-- Fix: Add missing columns to orders table for custom fields
-- Run this in Supabase SQL Editor
-- ============================================================

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS "userField1Val"    TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "userField2Val"    TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "userEmail"        TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "userPassword"     TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "userWhatsapp"     TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "customFieldValues" JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS "uidVerified"      BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS "uidVerifiedAt"    TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "refunded"         BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS "refundedAt"       TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS "refundedAmount"   NUMERIC DEFAULT 0;

-- Refresh schema cache so PostgREST picks up new columns immediately
NOTIFY pgrst, 'reload schema';
