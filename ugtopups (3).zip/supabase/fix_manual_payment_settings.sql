-- ============================================================
-- FIX: Manual Payment QR Settings not saving to Supabase
--
-- Root cause: the app writes { id, qrImageUrl, accountName, accountNote,
-- paymentMode } into public.settings, but that table never had those
-- columns — so every upsert() from Admin → Settings → "Manual Payment QR
-- Code & Deposit Options" was silently rejected by PostgREST (caught by
-- a try/catch in the app, so the UI still said "Saved successfully!").
--
-- Run this once in Supabase Dashboard → SQL Editor → New Query → Run.
-- ============================================================

ALTER TABLE public.settings
  ADD COLUMN IF NOT EXISTS "qrImageUrl"  TEXT,
  ADD COLUMN IF NOT EXISTS "accountName" TEXT,
  ADD COLUMN IF NOT EXISTS "accountNote" TEXT,
  ADD COLUMN IF NOT EXISTS "paymentMode" TEXT DEFAULT 'both';

-- Seed the row so the very first read (before any admin save) returns
-- consistent defaults instead of falling back to hardcoded client values.
INSERT INTO public.settings (id, "qrImageUrl", "accountName", "accountNote", "paymentMode")
VALUES ('manual_payment_settings', '/assets/wallet_ug.png', 'bibek', 'Write your name on remarks when paying', 'both')
ON CONFLICT (id) DO NOTHING;
