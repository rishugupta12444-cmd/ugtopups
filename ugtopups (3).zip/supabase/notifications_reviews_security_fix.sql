-- ============================================================
-- NOTIFICATIONS + REVIEWS SECURITY & PERSISTENCE FIX
-- Run this once in the Supabase SQL Editor, AFTER migration.sql,
-- redeem_codes_secure.sql and redeem_codes_security_patch.sql.
-- Safe to re-run (idempotent).
-- ============================================================

-- ------------------------------------------------------------
-- 1. NOTIFICATIONS: remove the leaked global backup
-- ------------------------------------------------------------
-- The old client code copied every user's notification list into a single
-- shared row (settings.id = 'ug_notifications_store'). Because `settings`
-- has "Public read settings FOR SELECT USING (true)", ANY visitor — logged
-- in or not — could read that row and see every user's notifications
-- (titles, order IDs, promo codes). The application code no longer writes
-- this row (see store.ts); this purges whatever is already there.
DELETE FROM public.settings WHERE id = 'ug_notifications_store';

-- ------------------------------------------------------------
-- 2. NOTIFICATIONS: lock down direct client writes for good
-- ------------------------------------------------------------
-- Only the service-role (Edge Functions) should ever insert a notification.
-- Re-assert this even if it was already applied, and drop the old
-- "Users insert own notifications" policy — customers must never be able to
-- write a notification row for themselves (that would let anyone fabricate
-- a fake "Voucher Delivered" / "Payment Successful" notification).
DROP POLICY IF EXISTS "Users insert own notifications" ON public.notifications;
REVOKE INSERT ON public.notifications FROM anon, authenticated;

-- Customers may still update (mark read / pin) and delete their own rows.
DROP POLICY IF EXISTS "Users update own notifications" ON public.notifications;
CREATE POLICY "Users update own notifications" ON public.notifications FOR UPDATE USING (
  public.is_admin() OR target_uid = auth.uid()::text
) WITH CHECK (
  public.is_admin() OR target_uid = auth.uid()::text
);

DROP POLICY IF EXISTS "Users delete own notifications" ON public.notifications;
CREATE POLICY "Users delete own notifications" ON public.notifications FOR DELETE USING (
  public.is_admin() OR target_uid = auth.uid()::text
);

DROP POLICY IF EXISTS "Users read own notifications" ON public.notifications;
CREATE POLICY "Users read own notifications" ON public.notifications FOR SELECT USING (
  target_uid = auth.uid()::text
  OR target_uid = 'ALL'
  OR target_uid IS NULL
  OR coalesce(lower(target_email), '') = lower(coalesce((SELECT email FROM public.users WHERE id = auth.uid()::text), ''))
);

CREATE INDEX IF NOT EXISTS idx_notifications_target_uid_created
  ON public.notifications (target_uid, created_at DESC);

-- ------------------------------------------------------------
-- 3. REVIEWS: the table was never defined in migration.sql, so it either
--    doesn't exist yet or was created ad-hoc without RLS. Create it if
--    missing and (re)apply the correct policies either way.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.reviews (
    id         TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    user_id    TEXT REFERENCES public.users(id) ON DELETE SET NULL,
    user_name  TEXT NOT NULL,
    avatar_url TEXT,
    rating     INT NOT NULL DEFAULT 5,
    date       TEXT,
    game       TEXT,
    comment    TEXT NOT NULL,
    verified   BOOLEAN DEFAULT true,
    status     TEXT DEFAULT 'PENDING',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- If the table already existed under the old ad-hoc schema, make sure the
-- columns the app now uses are present.
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS user_name TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'PENDING';
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- Anyone can read approved reviews (public marquee); admins can read all.
DROP POLICY IF EXISTS "Public read approved reviews" ON public.reviews;
CREATE POLICY "Public read approved reviews" ON public.reviews FOR SELECT USING (
  status = 'APPROVED' OR public.is_admin() OR (user_id IS NOT NULL AND user_id = auth.uid()::text)
);

-- A logged-in user may only submit a review tagged with their own uid;
-- a guest (no session) may only submit one with user_id left null.
-- Frontend-supplied user_id is never trusted on its own.
DROP POLICY IF EXISTS "Users insert own reviews" ON public.reviews;
CREATE POLICY "Users insert own reviews" ON public.reviews FOR INSERT WITH CHECK (
  public.is_admin()
  OR (auth.uid() IS NOT NULL AND user_id = auth.uid()::text)
  OR (auth.uid() IS NULL AND user_id IS NULL)
);

DROP POLICY IF EXISTS "Users update own reviews" ON public.reviews;
CREATE POLICY "Users update own reviews" ON public.reviews FOR UPDATE USING (
  public.is_admin() OR (user_id IS NOT NULL AND user_id = auth.uid()::text)
) WITH CHECK (
  public.is_admin() OR (user_id IS NOT NULL AND user_id = auth.uid()::text)
);

DROP POLICY IF EXISTS "Users delete own reviews" ON public.reviews;
CREATE POLICY "Users delete own reviews" ON public.reviews FOR DELETE USING (
  public.is_admin() OR (user_id IS NOT NULL AND user_id = auth.uid()::text)
);

-- Moderation status changes (APPROVED/REJECTED) are only meaningful from
-- the admin dashboard, which is already covered by public.is_admin() above.

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='reviews') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.reviews;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_reviews_status_created ON public.reviews (status, created_at DESC);
