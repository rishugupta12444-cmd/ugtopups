-- ============================================================
-- Order Refund System Migration
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New query)
-- ============================================================

-- 1. Add refund tracking columns to orders table
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS refunded        boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS "refundedAt"    timestamptz,
  ADD COLUMN IF NOT EXISTS "refundedAmount" numeric(12,2);

-- 2. Index for quick refund lookups
CREATE INDEX IF NOT EXISTS idx_orders_refunded ON orders (refunded) WHERE refunded = true;

-- 3. (Optional) View: cancelled orders with refund status for admin reporting
CREATE OR REPLACE VIEW cancelled_orders_refund_status AS
SELECT
  "orderId",
  "userId",
  "gameName",
  "packageName",
  "totalPriceNpr",
  "paymentMethod",
  status,
  "cancelledAt",
  "cancelledBy",
  refunded,
  "refundedAt",
  "refundedAmount"
FROM orders
WHERE status = 'Cancelled'
ORDER BY "cancelledAt" DESC;

-- ============================================================
-- NOTE: Order ID format changed from ODR<timestamp><random4>
--       to ODR<random5digits> e.g. ODR84729
--       No DB migration needed — orderId is stored as text.
-- ============================================================
