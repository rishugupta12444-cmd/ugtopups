-- ============================================================
-- UG TOP UP CENTER — CHECKOUT & DATABASE LATENCY OPTIMIZATION INDEXES
-- Optimizes queries for orders, wallets, transactions, and voucher checkout
-- ============================================================

-- 1. ORDERS TABLE INDEXES
-- Optimizes order lookup by orderId, user order history sorted by creation date, and status queries
CREATE INDEX IF NOT EXISTS idx_orders_orderid_lookup 
  ON public.orders ("orderId");

CREATE INDEX IF NOT EXISTS idx_orders_user_created_desc 
  ON public.orders ("userId", "createdAt" DESC);

CREATE INDEX IF NOT EXISTS idx_orders_user_status 
  ON public.orders ("userId", status, "createdAt" DESC);

CREATE INDEX IF NOT EXISTS idx_orders_payment_lookup 
  ON public.orders ("paymentStatus", "topUpStatus", "createdAt" DESC);

CREATE INDEX IF NOT EXISTS idx_orders_game_package 
  ON public.orders ("gameId", "packageId");

-- 2. USERS (WALLETS) TABLE INDEXES
-- Optimizes wallet balance retrieval and atomic deduction queries
CREATE INDEX IF NOT EXISTS idx_users_wallet_balance 
  ON public.users (id, "walletBalanceNpr");

CREATE INDEX IF NOT EXISTS idx_users_email_wallet 
  ON public.users (email, "walletBalanceNpr");

-- 3. TRANSACTIONS TABLE INDEXES
-- Optimizes transaction history retrieval and wallet ledger verification
CREATE INDEX IF NOT EXISTS idx_transactions_user_created_desc 
  ON public.transactions (uid, "createdAt" DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_userId_created_desc 
  ON public.transactions ("userId", "createdAt" DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_orderid_lookup 
  ON public.transactions ("orderId");

CREATE INDEX IF NOT EXISTS idx_transactions_type_status 
  ON public.transactions (type, status, "createdAt" DESC);

-- 4. REDEEM CODES & VOUCHERS INVENTORY INDEXES
-- Optimizes FIFO code retrieval for instant automated voucher delivery
CREATE INDEX IF NOT EXISTS idx_redeem_codes_avail_fifo 
  ON public.redeem_codes (product_id, package_id, status, created_at ASC);

CREATE INDEX IF NOT EXISTS idx_redeem_codes_order_status 
  ON public.redeem_codes (order_id, status);

CREATE INDEX IF NOT EXISTS idx_redeem_codes_user_delivered 
  ON public.redeem_codes (user_id, status, delivered_at DESC);

-- 5. WALLET REQUESTS TABLE INDEXES
CREATE INDEX IF NOT EXISTS idx_wallet_requests_uid_status 
  ON public."walletRequests" (uid, status, "createdAt" DESC);
