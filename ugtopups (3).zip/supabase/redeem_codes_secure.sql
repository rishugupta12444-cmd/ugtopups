-- UG TOP UP CENTER - Secure Redeem/Voucher Inventory
create table if not exists public.redeem_codes (
  id text primary key default gen_random_uuid()::text,
  product_id text not null,
  package_id text not null,
  code text not null,
  status text not null default 'available' check (status in ('available','reserved','delivered','redeemed','cancelled')),
  order_id text,
  user_id text,
  created_at timestamptz not null default now(),
  assigned_at timestamptz,
  delivered_at timestamptz,
  redeemed_at timestamptz,
  reservation_expires_at timestamptz
);

create unique index if not exists uq_redeem_codes_code_ci on public.redeem_codes ((lower(code)));
create index if not exists idx_redeem_codes_package_status on public.redeem_codes(product_id, package_id, status);
create index if not exists idx_redeem_codes_order on public.redeem_codes(order_id);
create index if not exists idx_redeem_codes_user on public.redeem_codes(user_id);

create table if not exists public.redeem_code_audit (
  id bigint generated always as identity primary key,
  redeem_code_id text not null references public.redeem_codes(id) on delete cascade,
  action text not null,
  order_id text,
  user_id text,
  created_at timestamptz not null default now()
);
create index if not exists idx_redeem_audit_code on public.redeem_code_audit(redeem_code_id, created_at desc);

alter table public.redeem_codes enable row level security;
alter table public.redeem_code_audit enable row level security;

drop policy if exists "redeem_codes_admin_all" on public.redeem_codes;
create policy "redeem_codes_admin_all" on public.redeem_codes for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "redeem_audit_admin_read" on public.redeem_code_audit;
create policy "redeem_audit_admin_read" on public.redeem_code_audit for select using (public.is_admin());

-- Never allow end users to query the inventory table directly.
revoke all on public.redeem_codes from anon, authenticated;
grant select, insert, update, delete on public.redeem_codes to authenticated;
-- RLS still limits those operations to admins.

create or replace function public.package_requires_redeem(p_product_id text, p_package_id text)
returns boolean
language sql stable security definer set search_path = public
as $$
  select coalesce((
    select bool_or(coalesce((pkg->>'requiresRedeemCode')::boolean, false))
    from public.products p
    cross join lateral jsonb_array_elements(coalesce(p.packages, '[]'::jsonb)) pkg
    where p.id = p_product_id and pkg->>'id' = p_package_id
  ), false);
$$;

grant execute on function public.package_requires_redeem(text,text) to anon, authenticated;

create or replace function public.get_redeem_stock(p_product_id text, p_package_id text)
returns integer
language plpgsql volatile security definer set search_path = public
as $$
begin
  update public.redeem_codes
     set status = 'available', order_id = null, user_id = null, assigned_at = null, reservation_expires_at = null
   where status = 'reserved' and reservation_expires_at is not null and reservation_expires_at < now();
  return (select count(*)::int from public.redeem_codes where product_id = p_product_id and package_id = p_package_id and status = 'available');
end;
$$;
grant execute on function public.get_redeem_stock(text,text) to anon, authenticated;

create or replace function public.reserve_redeem_codes(p_product_id text, p_package_id text, p_order_id text, p_user_id text, p_quantity integer)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  ids text[] := '{}';
  rec record;
  expires_at timestamptz := now() + interval '15 minutes';
  needed integer := greatest(coalesce(p_quantity,1),1);
  got integer := 0;
begin
  if not public.package_requires_redeem(p_product_id,p_package_id) then return jsonb_build_object('requires_redeem',false,'count',0,'ids',jsonb_build_array()); end if;
  if p_order_id is null or p_user_id is null then raise exception 'order/user is required'; end if;

  -- Release stale reservations first.
  update public.redeem_codes
     set status='available', order_id=null, user_id=null, assigned_at=null, reservation_expires_at=null
   where status='reserved' and reservation_expires_at is not null and reservation_expires_at < now();

  for rec in
    select id from public.redeem_codes
    where product_id=p_product_id and package_id=p_package_id and status='available'
    order by created_at asc
    for update skip locked
    limit needed
  loop
    update public.redeem_codes
       set status='reserved', order_id=p_order_id, user_id=p_user_id, assigned_at=now(), reservation_expires_at=expires_at
     where id=rec.id;
    insert into public.redeem_code_audit(redeem_code_id,action,order_id,user_id) values(rec.id,'reserved',p_order_id,p_user_id);
    ids := array_append(ids, rec.id);
    got := got + 1;
  end loop;

  if got <> needed then
    update public.redeem_codes set status='available', order_id=null, user_id=null, assigned_at=null, reservation_expires_at=null where id = any(ids);
    delete from public.redeem_code_audit where redeem_code_id = any(ids) and order_id=p_order_id and action='reserved';
    raise exception 'INSUFFICIENT_VOUCHER_STOCK';
  end if;

  return jsonb_build_object('requires_redeem',true,'count',got,'ids',to_jsonb(ids));
end;
$$;
grant execute on function public.reserve_redeem_codes(text,text,text,text,integer) to service_role;
grant execute on function public.reserve_redeem_codes(text,text,text,text,integer) to authenticated;

create or replace function public.deliver_reserved_redeem_codes(p_order_id text)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  result jsonb;
begin
  update public.redeem_codes
     set status='delivered', delivered_at=coalesce(delivered_at,now()), reservation_expires_at=null
   where order_id=p_order_id and status='reserved';

  insert into public.redeem_code_audit(redeem_code_id,action,order_id,user_id)
  select id,'delivered',order_id,user_id from public.redeem_codes
  where order_id=p_order_id and status='delivered'
    and not exists(select 1 from public.redeem_code_audit a where a.redeem_code_id=redeem_codes.id and a.action='delivered' and a.order_id=p_order_id);

  select coalesce(jsonb_agg(jsonb_build_object('id',id,'product_id',product_id,'package_id',package_id,'code',code,'status',status) order by created_at), '[]'::jsonb)
    into result
    from public.redeem_codes where order_id=p_order_id and status='delivered';
  return result;
end;
$$;
grant execute on function public.deliver_reserved_redeem_codes(text) to service_role;
grant execute on function public.deliver_reserved_redeem_codes(text) to authenticated;

create or replace function public.release_reserved_redeem_codes(p_order_id text)
returns integer
language plpgsql security definer set search_path = public
as $$
declare n integer;
begin
  with changed as (
    update public.redeem_codes
       set status='available', order_id=null, user_id=null, assigned_at=null, reservation_expires_at=null
     where order_id=p_order_id and status='reserved'
     returning id, order_id, user_id
  )
  insert into public.redeem_code_audit(redeem_code_id,action,order_id,user_id)
  select id,'cancelled',order_id,user_id from changed;
  get diagnostics n = row_count;
  return coalesce(n,0);
end;
$$;
grant execute on function public.release_reserved_redeem_codes(text) to service_role;
grant execute on function public.release_reserved_redeem_codes(text) to authenticated;

-- Secure customer-only read: the full code is returned only for the authenticated order owner.
create or replace function public.get_my_redeem_codes(p_order_id text)
returns table(id text, product_id text, package_id text, code text, status text, delivered_at timestamptz, order_id text)
language sql security definer set search_path = public
as $$
  select r.id,r.product_id,r.package_id,r.code,r.status,r.delivered_at,r.order_id
  from public.redeem_codes r
  join public.orders o on o."orderId" = r.order_id
  where r.order_id=p_order_id and o."userId"=auth.uid()::text and r.status in ('delivered','redeemed');
$$;
grant execute on function public.get_my_redeem_codes(text) to authenticated;

-- Realtime is safe because RLS blocks non-admin reads.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='redeem_codes') then
    alter publication supabase_realtime add table public.redeem_codes;
  end if;
end $$;

-- Notification hardening: user-specific rows, no public read of voucher data.
alter table public.notifications add column if not exists target_uid text;
alter table public.notifications add column if not exists target_email text;
alter table public.notifications add column if not exists order_id text;
alter table public.notifications add column if not exists product_id text;
alter table public.notifications add column if not exists package_id text;

drop policy if exists "Public read notifications" on public.notifications;
drop policy if exists "Users read own notifications" on public.notifications;
create policy "Users read own notifications" on public.notifications for select
using (target_uid = auth.uid()::text or coalesce(lower(target_email),'') = lower(coalesce((select email from public.users where id=auth.uid()::text),'')) or target_uid = 'ALL' or target_uid is null);

drop policy if exists "Admin full access notifications" on public.notifications;
create policy "Admin full access notifications" on public.notifications for all using (public.is_admin()) with check (public.is_admin());

-- Revoke direct client insert/update/delete on notifications; normal/admin notifications should use existing server-side admin routes.
revoke insert, update, delete on public.notifications from anon, authenticated;

-- Atomic wallet checkout for voucher packages. Uses auth.uid(), validates package price server-side,
-- locks wallet + voucher rows, creates the order and delivers the codes in one DB transaction.
create or replace function public.create_wallet_voucher_order(
  p_game_id text,
  p_game_name text,
  p_player_uid text,
  p_player_name text,
  p_zone_id text,
  p_package_id text,
  p_package_name text,
  p_quantity integer,
  p_diamonds integer,
  p_user_email text,
  p_user_password text,
  p_user_whatsapp text,
  p_user_field1 text,
  p_user_field2 text,
  p_client_order_id text
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  uid text := auth.uid()::text;
  qty integer := greatest(coalesce(p_quantity,1),1);
  pkg jsonb;
  unit_price numeric;
  total_price numeric;
  balance numeric;
  order_id text := coalesce(nullif(p_client_order_id,''), public.next_order_id());
  now_iso timestamptz := now();
  reservation jsonb;
  delivered jsonb;
  new_balance numeric;
begin
  if uid is null then raise exception 'AUTH_REQUIRED'; end if;
  select u."walletBalanceNpr" into balance from public.users u where u.id=uid for update;
  if balance is null then raise exception 'USER_NOT_FOUND'; end if;

  select pkg_item into pkg
  from public.products p
  cross join lateral jsonb_array_elements(coalesce(p.packages,'[]'::jsonb)) pkg_item
  where p.id=p_game_id and pkg_item->>'id'=p_package_id;
  if pkg is null then raise exception 'PACKAGE_NOT_FOUND'; end if;
  if coalesce((pkg->>'requiresRedeemCode')::boolean,false) is not true then raise exception 'PACKAGE_NOT_VOUCHER'; end if;

  unit_price := coalesce((pkg->>'priceNpr')::numeric,0);
  if unit_price <= 0 then raise exception 'INVALID_PACKAGE_PRICE'; end if;
  total_price := unit_price * qty;
  if balance < total_price then raise exception 'INSUFFICIENT_WALLET_BALANCE'; end if;

  reservation := public.reserve_redeem_codes(p_game_id,p_package_id,order_id,uid,qty);

  new_balance := balance - total_price;
  update public.users set "walletBalanceNpr"=new_balance where id=uid;

  insert into public.orders(
    "orderId","userId","gameId","gameName","playerUid","playerName","zoneId","packageId","packageName",
    diamonds,quantity,"totalPriceNpr","walletDeductionNpr","paymentMethod","transactionRef","paymentStatus","topUpStatus",status,
    "createdAt","completedAt","completedBy"
  ) values (
    order_id,uid,p_game_id,p_game_name,p_player_uid,p_player_name,coalesce(p_zone_id,''),p_package_id,
    p_package_name,coalesce(p_diamonds,0),qty,total_price,total_price,'UG Wallet','TXN-WLT-'||substr(md5(order_id||clock_timestamp()::text),1,12),
    'Paid','COMPLETED','Completed',to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),'AUTO_REDEEM_SYSTEM'
  );

  insert into public.transactions(id,"orderId",uid,"userId","packageName","gameName",amount,type,"paymentMethod",status,date,"createdAt", "previousBalance","newBalance")
  values (gen_random_uuid()::text,order_id,uid,uid,p_package_name,p_game_name,total_price,'DEDUCTION','UG Wallet','SUCCESS',to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),now_iso,balance,new_balance);

  delivered := public.deliver_reserved_redeem_codes(order_id);

  return jsonb_build_object(
    'orderId',order_id,'paymentStatus','Paid','topUpStatus','COMPLETED','status','Completed',
    'totalPriceNpr',total_price,'walletBalanceNpr',new_balance,
    'codes',delivered
  );
exception
  when others then
    raise;
end;
$$;
grant execute on function public.create_wallet_voucher_order(text,text,text,text,text,text,text,integer,integer,text,text,text,text,text,text) to authenticated;

-- Admin-only bulk import through Edge Function; direct table access remains admin-only by RLS.

-- Notification security: customers may read/update/delete their own notifications,
-- but may NEVER create arbitrary notifications. System/admin code creates delivery notifications server-side.
grant select, update, delete on public.notifications to authenticated;
revoke insert on public.notifications from anon, authenticated;
drop policy if exists "Users insert own notifications" on public.notifications;
drop policy if exists "Users update own notifications" on public.notifications;
create policy "Users update own notifications" on public.notifications for update using (
  public.is_admin() or target_uid = auth.uid()::text
) with check (
  public.is_admin() or target_uid = auth.uid()::text
);
drop policy if exists "Users delete own notifications" on public.notifications;
create policy "Users delete own notifications" on public.notifications for delete using (
  public.is_admin() or target_uid = auth.uid()::text
);

-- Tighten privileged inventory mutations: end users never call these directly.
revoke execute on function public.reserve_redeem_codes(text,text,text,text,integer) from authenticated;
revoke execute on function public.deliver_reserved_redeem_codes(text) from authenticated;
revoke execute on function public.release_reserved_redeem_codes(text) from authenticated;


-- VOUCHER EMAIL DELIVERY TRACKING
-- Voucher email delivery tracking. This replaces automatic voucher notifications.
create table if not exists public.voucher_email_deliveries (
  order_id text primary key,
  user_id text,
  recipient_email text not null,
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  code_count integer not null default 0,
  message_id text,
  error_message text,
  sent_at timestamptz,
  updated_at timestamptz not null default now()
);

create index if not exists voucher_email_deliveries_user_id_idx
  on public.voucher_email_deliveries(user_id);

alter table public.voucher_email_deliveries enable row level security;

drop policy if exists "No customer access to voucher email delivery records" on public.voucher_email_deliveries;
create policy "No customer access to voucher email delivery records"
  on public.voucher_email_deliveries
  for all
  using (false)
  with check (false);

revoke all on public.voucher_email_deliveries from anon, authenticated;
grant all on public.voucher_email_deliveries to service_role;
