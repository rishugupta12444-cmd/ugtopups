-- ============================================================
-- ADMIN ORDER CANCELLATION FIX
-- Allows an authenticated admin to cancel ANY order, including
-- orders that are already marked Completed.
-- The existing cancellation/refund logic in the frontend remains
-- unchanged after this status update succeeds.
-- ============================================================

CREATE OR REPLACE FUNCTION public.admin_cancel_order_status(
  p_order_id text,
  p_admin_uid text DEFAULT NULL,
  p_rejection_reason text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_admin boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  -- Match the same admin rules used by the application. The explicit
  -- email check also covers the existing hard-coded primary admin account
  -- when an older database has not yet populated admins/users.role.
  v_is_admin := public.is_admin()
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com';

  IF NOT v_is_admin THEN
    RETURN false;
  END IF;

  IF nullif(trim(coalesce(p_order_id, '')), '') IS NULL THEN
    RETURN false;
  END IF;

  UPDATE public.orders
  SET
    status = 'Cancelled',
    "topUpStatus" = 'CANCELLED',
    "cancelledAt" = now()::text,
    "cancelledBy" = coalesce(nullif(trim(p_admin_uid), ''), auth.uid()::text),
    "rejectionReason" = CASE
      WHEN nullif(trim(coalesce(p_rejection_reason, '')), '') IS NOT NULL
        THEN p_rejection_reason
      ELSE "rejectionReason"
    END
  WHERE "orderId" = trim(p_order_id);

  RETURN FOUND;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_cancel_order_status(text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_cancel_order_status(text, text, text) TO authenticated;

-- Keep the normal UPDATE path available as a fallback as well.
DROP POLICY IF EXISTS "Orders: update admin" ON public.orders;
CREATE POLICY "Orders: update admin" ON public.orders
  FOR UPDATE
  USING (
    public.is_admin()
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
  )
  WITH CHECK (
    public.is_admin()
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
  );

COMMENT ON FUNCTION public.admin_cancel_order_status(text, text, text)
IS 'Allows authenticated admins to cancel any order, including completed orders, without changing the existing refund flow.';
