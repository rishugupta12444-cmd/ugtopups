-- ============================================================
-- UG COINS REWARD SYSTEM
-- Run this once on your Supabase project (SQL Editor → New Query → Run).
--
-- What this adds:
--   1. "coinBalance" column on public.users (defaults to 0 for everyone).
--   2. increment_user_coins(uid, amount)  → atomically adds coins
--      (called automatically by the app every time an order completes
--      successfully — 3 coins per order, any payment method).
--   3. exchange_coins_for_wallet(uid, coins) → atomically converts coins
--      into UG Wallet credit at the rate 100 Coins = NPR 10, and logs a
--      transaction row so it shows up in Transaction History.
-- ============================================================

-- 1. Add coin balance column
ALTER TABLE public.users
  ADD COLUMN IF NOT EXISTS "coinBalance" NUMERIC NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_users_coin_balance ON public.users (id, "coinBalance");

-- 2. Atomic coin increment (used after every successful order)
CREATE OR REPLACE FUNCTION public.increment_user_coins(p_uid TEXT, p_amount NUMERIC)
RETURNS NUMERIC
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_balance NUMERIC;
BEGIN
  IF p_uid IS NULL OR p_amount IS NULL THEN
    RETURN NULL;
  END IF;

  UPDATE public.users
  SET "coinBalance" = GREATEST(0, COALESCE("coinBalance", 0) + p_amount)
  WHERE id = p_uid
  RETURNING "coinBalance" INTO new_balance;

  RETURN new_balance;
END;
$$;

GRANT EXECUTE ON FUNCTION public.increment_user_coins(TEXT, NUMERIC) TO authenticated, anon, service_role;

-- 3. Atomic coin → wallet exchange (100 Coins = NPR 10)
CREATE OR REPLACE FUNCTION public.exchange_coins_for_wallet(p_uid TEXT, p_coins NUMERIC)
RETURNS TABLE(new_coin_balance NUMERIC, new_wallet_balance NUMERIC)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  cur_coins NUMERIC;
  cur_wallet NUMERIC;
  credit_npr NUMERIC;
  now_iso TEXT := to_char(now(), 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"');
BEGIN
  IF p_uid IS NULL THEN
    RAISE EXCEPTION 'AUTH_REQUIRED';
  END IF;

  IF p_coins IS NULL OR p_coins <= 0 THEN
    RAISE EXCEPTION 'INVALID_COIN_AMOUNT';
  END IF;

  SELECT "coinBalance", "walletBalanceNpr" INTO cur_coins, cur_wallet
  FROM public.users WHERE id = p_uid FOR UPDATE;

  IF cur_coins IS NULL THEN
    RAISE EXCEPTION 'USER_NOT_FOUND';
  END IF;

  IF p_coins > cur_coins THEN
    RAISE EXCEPTION 'INSUFFICIENT_COINS';
  END IF;

  -- 100 coins = NPR 10  →  1 coin = NPR 0.10
  credit_npr := ROUND((p_coins / 100.0) * 10.0, 2);

  UPDATE public.users
  SET "coinBalance" = "coinBalance" - p_coins,
      "walletBalanceNpr" = COALESCE("walletBalanceNpr", 0) + credit_npr
  WHERE id = p_uid
  RETURNING "coinBalance", "walletBalanceNpr" INTO cur_coins, cur_wallet;

  INSERT INTO public.transactions (
    id, uid, "userId", "packageName", amount, type, "paymentMethod", status, date, "createdAt"
  ) VALUES (
    'TXN-COIN-' || substr(md5(p_uid || clock_timestamp()::text), 1, 12),
    p_uid, p_uid, p_coins::text || ' UG Coins Exchanged', credit_npr, 'RECHARGE', 'UG Coins', 'SUCCESS', now_iso, now()
  );

  RETURN QUERY SELECT cur_coins, cur_wallet;
END;
$$;

GRANT EXECUTE ON FUNCTION public.exchange_coins_for_wallet(TEXT, NUMERIC) TO authenticated;
