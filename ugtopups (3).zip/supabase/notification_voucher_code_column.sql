-- Adds a dedicated `code` column so voucher-delivery notifications can show
-- the redeem code inline (with the existing copy-to-clipboard UI) instead of
-- only inside the message text. Service role writes this; customers never
-- get direct INSERT/UPDATE access to notifications (see
-- notifications_reviews_security_fix.sql), so this does not reopen the
-- "fake Voucher Delivered notification" issue that email-only delivery
-- was built to close.
alter table public.notifications add column if not exists code text;
