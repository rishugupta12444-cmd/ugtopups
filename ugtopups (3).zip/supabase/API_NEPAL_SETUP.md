# API NEPAL setup

This version moves API NEPAL payment initiation, status verification, and IPN handling into Supabase Edge Functions. API NEPAL keys are never bundled into the browser.

Required Supabase Edge Function secrets:
- API_NEPAL_PUBLIC_KEY
- API_NEPAL_SECRET_KEY
- SITE_URL

Existing Free Fire secrets remain server-side:
- EZ2TOPUP_API_KEY
- EZ2TOPUP_SECRET_KEY

Deploy:
- supabase functions deploy api-nepal-initiate --use-api
- supabase functions deploy api-nepal-ipn --use-api
- supabase functions deploy api-nepal-status --use-api

Webhook URL:
https://YOUR_PROJECT_REF.supabase.co/functions/v1/api-nepal-ipn
