-- ==============================================================================
-- COMPLETE FIX: WALLET VOUCHER CHECKOUT, TIMESTAMPS, AND UID VERIFICATION BYPASS
-- ==============================================================================
-- Run this script in the Supabase SQL Editor.

-- 1. Ensure required columns exist on public.orders with proper types
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS "uidVerified" BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS "uidVerifiedAt" TIMESTAMPTZ;

-- 2. Create/Update helper to detect voucher/redeem-code packages
CREATE OR REPLACE FUNCTION public.package_requires_redeem(p_product_id text, p_package_id text)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_req boolean := false;
BEGIN
  -- Check products table
  SELECT COALESCE(bool_or(
    COALESCE((pkg->>'requiresRedeemCode')::boolean, false)
    OR COALESCE((pkg->>'isRedeemCode')::boolean, false)
  ), false) INTO is_req
  FROM public.products p
  CROSS JOIN LATERAL jsonb_array_elements(COALESCE(p.packages, '[]'::jsonb)) pkg
  WHERE (p.id = p_product_id OR p."gameId" = p_product_id OR p.code = p_product_id)
    AND (p_package_id IS NULL OR p_package_id = '' OR pkg->>'id' = p_package_id);

  IF is_req THEN RETURN true; END IF;

  -- Check games table
  SELECT COALESCE(bool_or(
    COALESCE((pkg->>'requiresRedeemCode')::boolean, false)
    OR COALESCE((pkg->>'isRedeemCode')::boolean, false)
  ), false) INTO is_req
  FROM public.games g
  CROSS JOIN LATERAL jsonb_array_elements(COALESCE(g.packages, '[]'::jsonb)) pkg
  WHERE g.id = p_product_id
    AND (p_package_id IS NULL OR p_package_id = '' OR pkg->>'id' = p_package_id);

  IF is_req THEN RETURN true; END IF;

  -- Check deliveryType or category or name
  IF EXISTS (
    SELECT 1 FROM public.products p
    WHERE (p.id = p_product_id OR p."gameId" = p_product_id OR p.code = p_product_id)
      AND (
        p."deliveryType" IN ('INSTANT_CODE', 'AUTO_REDEEM', 'VOUCHER')
        OR p.category ~* '(voucher|redeem|gift[\s_-]?card|digital_code)'
        OR p.name ~* '(voucher|redeem|gift[\s_-]?card|unipin)'
        OR p.title ~* '(voucher|redeem|gift[\s_-]?card|unipin)'
      )
  ) THEN
    RETURN true;
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.games g
    WHERE g.id = p_product_id
      AND (
        g.category ~* '(voucher|redeem|gift[\s_-]?card|digital_code)'
        OR g.name ~* '(voucher|redeem|gift[\s_-]?card|unipin)'
      )
  ) THEN
    RETURN true;
  END IF;

  RETURN false;
END;
$$;

-- 3. Trigger that distinguishes voucher orders (skips UID verification) from game top-ups (enforces UID verification)
CREATE OR REPLACE FUNCTION public.prevent_unverified_order_completion()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.status = 'Completed' AND COALESCE(NEW."uidVerified", FALSE) = FALSE THEN
    -- If it's a voucher or redeem-code product, allow completion without player UID verification
    IF COALESCE(NEW."requiresRedeemCode", FALSE) = TRUE
       OR public.package_requires_redeem(NEW."gameId", NEW."packageId") = TRUE
       OR LOWER(COALESCE(NEW."gameName", '') || ' ' || COALESCE(NEW."packageName", '')) ~* '(voucher|redeem|gift[\s_-]?card|unipin)' THEN
      NEW."uidVerified" := TRUE;
      NEW."uidVerifiedAt" := COALESCE(NEW."uidVerifiedAt", NOW());
      RETURN NEW;
    END IF;

    RAISE EXCEPTION 'ORDER_UID_NOT_VERIFIED: This order cannot be completed until the player UID is successfully verified.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prevent_unverified_order_completion ON public.orders;

CREATE TRIGGER trg_prevent_unverified_order_completion
BEFORE INSERT OR UPDATE OF status, "uidVerified" ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.prevent_unverified_order_completion();

-- 4. Atomic Wallet Voucher Checkout RPC Function
-- Fixes timestamp insertion (uses TIMESTAMPTZ now_iso / NOW()), sets uidVerified=true, and delivers codes securely.
CREATE OR REPLACE FUNCTION public.create_wallet_voucher_order(
  p_game_id text,
  p_game_name text,
  p_player_uid text,
  p_player_name text,
  p_zone_id text,
  p_package_id text,
  p_package_name text,
  p_quantity integer,
  p_diamonds integer,
  p_user_email text,
  p_user_password text,
  p_user_whatsapp text,
  p_user_field1 text,
  p_user_field2 text,
  p_client_order_id text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid text := auth.uid()::text;
  qty integer := greatest(coalesce(p_quantity, 1), 1);
  pkg jsonb;
  unit_price numeric;
  total_price numeric;
  balance numeric;
  order_id text := coalesce(nullif(p_client_order_id, ''), public.next_order_id());
  now_iso timestamptz := now();
  reservation jsonb;
  delivered jsonb;
  new_balance numeric;
  is_voucher boolean := false;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'AUTH_REQUIRED';
  END IF;

  SELECT u."walletBalanceNpr" INTO balance FROM public.users u WHERE u.id = uid FOR UPDATE;
  IF balance IS NULL THEN
    RAISE EXCEPTION 'USER_NOT_FOUND';
  END IF;

  -- Locate package from products
  SELECT pkg_item INTO pkg
  FROM public.products p
  CROSS JOIN LATERAL jsonb_array_elements(COALESCE(p.packages, '[]'::jsonb)) pkg_item
  WHERE (p.id = p_game_id OR p."gameId" = p_game_id OR p.code = p_game_id) AND pkg_item->>'id' = p_package_id;

  -- Locate package from games if not found in products
  IF pkg IS NULL THEN
    SELECT pkg_item INTO pkg
    FROM public.games g
    CROSS JOIN LATERAL jsonb_array_elements(COALESCE(g.packages, '[]'::jsonb)) pkg_item
    WHERE g.id = p_game_id AND pkg_item->>'id' = p_package_id;
  END IF;

  IF pkg IS NULL THEN
    RAISE EXCEPTION 'PACKAGE_NOT_FOUND';
  END IF;

  -- Determine if voucher product
  is_voucher := COALESCE((pkg->>'requiresRedeemCode')::boolean, false)
                OR COALESCE((pkg->>'isRedeemCode')::boolean, false)
                OR public.package_requires_redeem(p_game_id, p_package_id)
                OR (COALESCE(p_game_name, '') || ' ' || COALESCE(p_package_name, '')) ~* '(voucher|redeem|gift[\s_-]?card|unipin)';

  IF NOT is_voucher THEN
    RAISE EXCEPTION 'PACKAGE_NOT_VOUCHER';
  END IF;

  unit_price := COALESCE((pkg->>'priceNpr')::numeric, 0);
  IF unit_price <= 0 THEN
    RAISE EXCEPTION 'INVALID_PACKAGE_PRICE';
  END IF;

  total_price := unit_price * qty;
  IF balance < total_price THEN
    RAISE EXCEPTION 'INSUFFICIENT_WALLET_BALANCE';
  END IF;

  -- Atomically reserve redeem codes
  reservation := public.reserve_redeem_codes(p_game_id, p_package_id, order_id, uid, qty);

  new_balance := balance - total_price;
  UPDATE public.users SET "walletBalanceNpr" = new_balance WHERE id = uid;

  -- Insert order with proper TIMESTAMPTZ values and uidVerified=true
  INSERT INTO public.orders (
    "orderId", "userId", "gameId", "gameName", "playerUid", "playerName", "zoneId", "packageId", "packageName",
    diamonds, quantity, "totalPriceNpr", "walletDeductionNpr", "paymentMethod", "transactionRef", "paymentStatus", "topUpStatus", status,
    "uidVerified", "uidVerifiedAt", "createdAt", "completedAt", "completedBy", created_at
  ) VALUES (
    order_id, uid, p_game_id, p_game_name, p_player_uid, p_player_name, COALESCE(p_zone_id, ''), p_package_id, p_package_name,
    COALESCE(p_diamonds, 0), qty, total_price, total_price, 'UG Wallet', 'TXN-WLT-' || substr(md5(order_id || clock_timestamp()::text), 1, 12),
    'Paid', 'COMPLETED', 'Completed',
    true, now_iso, now_iso, to_char(now_iso, 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'), 'AUTO_REDEEM_SYSTEM', now_iso
  );

  -- Insert transaction with proper TIMESTAMPTZ values
  INSERT INTO public.transactions (
    id, "orderId", uid, "userId", "packageName", "gameName", amount, type, "paymentMethod", status, date, "createdAt", created_at, "previousBalance", "newBalance"
  ) VALUES (
    gen_random_uuid()::text, order_id, uid, uid, p_package_name, p_game_name, total_price, 'DEDUCTION', 'UG Wallet', 'SUCCESS',
    to_char(now_iso, 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'), now_iso, now_iso, balance, new_balance
  );

  -- Mark reserved codes as delivered
  delivered := public.deliver_reserved_redeem_codes(order_id);

  RETURN jsonb_build_object(
    'orderId', order_id,
    'paymentStatus', 'Paid',
    'topUpStatus', 'COMPLETED',
    'status', 'Completed',
    'totalPriceNpr', total_price,
    'walletBalanceNpr', new_balance,
    'deliveredCount', jsonb_array_length(COALESCE(delivered, '[]'::jsonb))
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_wallet_voucher_order(text, text, text, text, text, text, text, integer, integer, text, text, text, text, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_wallet_voucher_order(text, text, text, text, text, text, text, integer, integer, text, text, text, text, text, text) TO service_role;
