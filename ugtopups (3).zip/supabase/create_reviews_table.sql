-- ============================================================
-- SQL TO CREATE THE REVIEWS TABLE IN SUPABASE
-- Run this in your Supabase SQL Editor:
-- ============================================================

CREATE TABLE IF NOT EXISTS public.reviews (
    id         TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    user_id    TEXT REFERENCES public.users(id) ON DELETE SET NULL,
    user_name  TEXT NOT NULL,
    avatar_url TEXT,
    rating     INT NOT NULL DEFAULT 5,
    date       TEXT,
    game       TEXT,
    comment    TEXT NOT NULL,
    verified   BOOLEAN DEFAULT true,
    status     TEXT DEFAULT 'PENDING',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure columns exist
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS user_name TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS rating INT DEFAULT 5;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS date TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS game TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS comment TEXT;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT true;
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'PENDING';
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();

-- Enable Row Level Security
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- 1. Anyone can view approved reviews (and users can view their own reviews)
DROP POLICY IF EXISTS "Public read approved reviews" ON public.reviews;
CREATE POLICY "Public read approved reviews" ON public.reviews FOR SELECT USING (
  status = 'APPROVED' OR (user_id IS NOT NULL AND user_id = auth.uid()::text)
);

-- 2. Users and guests can insert reviews (tagged with authenticated uid or null for guests)
DROP POLICY IF EXISTS "Users insert own reviews" ON public.reviews;
CREATE POLICY "Users insert own reviews" ON public.reviews FOR INSERT WITH CHECK (
  (auth.uid() IS NOT NULL AND user_id = auth.uid()::text)
  OR (auth.uid() IS NULL AND user_id IS NULL)
);

-- 3. Users can update their own reviews
DROP POLICY IF EXISTS "Users update own reviews" ON public.reviews;
CREATE POLICY "Users update own reviews" ON public.reviews FOR UPDATE USING (
  user_id = auth.uid()::text
);

-- 4. Users can delete their own reviews
DROP POLICY IF EXISTS "Users delete own reviews" ON public.reviews;
CREATE POLICY "Users delete own reviews" ON public.reviews FOR DELETE USING (
  user_id = auth.uid()::text
);

-- Realtime Publication for reviews table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'reviews'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.reviews;
  END IF;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;
