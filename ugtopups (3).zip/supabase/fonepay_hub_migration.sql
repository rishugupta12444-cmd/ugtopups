-- Run once in Supabase SQL Editor before deploying the Fonepay Hub functions.
-- These values contain only the Hub payment UUID, QR payload and expiry. Secrets
-- remain exclusively in Supabase Edge Function secrets.
alter table public.orders add column if not exists "qrPayload" text;
alter table public.orders add column if not exists "qrExpiresAt" timestamptz;

create index if not exists orders_transaction_ref_idx
  on public.orders ("transactionRef")
  where "transactionRef" is not null;

-- Atomically claims a verified Hub payment, changes the order state and credits
-- wallet loads. Row locks and the SUCCESS guard prevent webhook/status races from
-- ever crediting the same payment twice.
create or replace function public.confirm_fonepay_hub_payment(
  p_order_id text,
  p_payment_id text,
  p_amount numeric
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order public.orders%rowtype;
  v_user public.users%rowtype;
  v_is_wallet boolean;
  v_is_voucher boolean := false;
  v_previous numeric := 0;
  v_new numeric := 0;
begin
  select * into v_order from public.orders where "orderId" = p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if abs(coalesce(v_order."totalPriceNpr", 0) - p_amount) > 0.009 then
    raise exception 'Payment amount mismatch';
  end if;
  if coalesce(v_order."transactionRef", '') <> p_payment_id then
    raise exception 'Payment reference mismatch';
  end if;
  if upper(coalesce(v_order."paymentStatus", '')) = 'SUCCESS' then
    return jsonb_build_object('transitioned', false, 'order', to_jsonb(v_order));
  end if;
  if upper(coalesce(v_order."paymentStatus", '')) in ('FAILED', 'CANCELLED', 'REJECTED')
    or upper(coalesce(v_order."topUpStatus", '')) in ('CANCELLED', 'REJECTED')
    or upper(coalesce(v_order.status, '')) in ('CANCELLED', 'REJECTED', 'PAYMENT FAILED') then
    raise exception 'Payment is no longer pending';
  end if;

  v_is_wallet := v_order."gameId" = 'wallet-load'
    or v_order."packageId" = 'wallet-recharge'
    or lower(coalesce(v_order."packageName", '')) like '%wallet%'
    or lower(coalesce(v_order."gameName", '')) like '%wallet%';
  begin
    select public.package_requires_redeem(v_order."gameId", v_order."packageId") into v_is_voucher;
  exception when undefined_function then
    v_is_voucher := false;
  end;

  update public.orders set
    "paymentStatus" = 'SUCCESS',
    "topUpStatus" = case when v_is_wallet or v_is_voucher then 'COMPLETED' else 'PENDING' end,
    status = case when v_is_wallet or v_is_voucher then 'Completed' else 'Payment Verified' end
  where "orderId" = p_order_id
  returning * into v_order;

  if v_is_wallet and v_order."userId" is not null then
    select * into v_user from public.users where id = v_order."userId" for update;
    if not found then raise exception 'Wallet user not found'; end if;
    v_previous := coalesce(v_user."walletBalanceNpr", 0);
    v_new := v_previous + p_amount;
    update public.users set
      "walletBalanceNpr" = v_new,
      "totalTopupsNpr" = coalesce("totalTopupsNpr", 0) + p_amount
    where id = v_order."userId";

    insert into public.transactions (
      id, "orderId", uid, "userId", username, "packageName", "gameName",
      amount, type, operation, "previousBalance", "newBalance",
      "paymentMethod", status, date, "createdAt", created_at
    ) values (
      'TXN-FONEPAY-' || p_order_id, p_order_id, v_order."userId", v_order."userId",
      coalesce(v_user.username, v_order."playerName", 'User'),
      'Instant Online Wallet Load', coalesce(v_order."gameName", 'UG Wallet'),
      p_amount, 'RECHARGE', 'increase', v_previous, v_new,
      'Fonepay Hub', 'SUCCESS', now()::text, now(), now()
    ) on conflict (id) do nothing;
  end if;

  return jsonb_build_object(
    'transitioned', true,
    'is_wallet', v_is_wallet,
    'is_voucher', v_is_voucher,
    'previous_balance', v_previous,
    'new_balance', v_new,
    'order', to_jsonb(v_order)
  );
end;
$$;

revoke all on function public.confirm_fonepay_hub_payment(text, text, numeric) from public, anon, authenticated;
grant execute on function public.confirm_fonepay_hub_payment(text, text, numeric) to service_role;
