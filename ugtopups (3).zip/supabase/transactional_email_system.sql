-- ============================================================================
-- UGTOPUPS — Transactional Email Delivery System Migration
-- Table, Indexes, RLS Policies, and Event Tracking
-- ============================================================================

-- 1. Create the transactional_email_deliveries tracking table
CREATE TABLE IF NOT EXISTS public.transactional_email_deliveries (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             TEXT,
    order_id            TEXT,
    transaction_id      TEXT,
    email               TEXT NOT NULL,
    email_type          TEXT NOT NULL, -- 'wallet_recharge_success', 'order_completed', 'voucher_delivered'
    event_key           TEXT NOT NULL UNIQUE, -- e.g. 'wallet_recharge:TXN123', 'order_completed:ORD456', 'voucher_delivered:ORD789'
    resend_message_id   TEXT,
    status              TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'sent', 'failed'
    error_message       TEXT,
    metadata            JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at             TIMESTAMPTZ
);

-- 2. Indexes for fast idempotency lookups and admin dashboard queries
CREATE INDEX IF NOT EXISTS idx_trans_email_event_key ON public.transactional_email_deliveries(event_key);
CREATE INDEX IF NOT EXISTS idx_trans_email_order_id ON public.transactional_email_deliveries(order_id);
CREATE INDEX IF NOT EXISTS idx_trans_email_user_id ON public.transactional_email_deliveries(user_id);
CREATE INDEX IF NOT EXISTS idx_trans_email_status ON public.transactional_email_deliveries(status);
CREATE INDEX IF NOT EXISTS idx_trans_email_created_at ON public.transactional_email_deliveries(created_at DESC);

-- 3. Row Level Security
ALTER TABLE public.transactional_email_deliveries ENABLE ROW LEVEL SECURITY;

-- Drop old policies if existing
DROP POLICY IF EXISTS "Admin view all email deliveries" ON public.transactional_email_deliveries;
DROP POLICY IF EXISTS "Service role full access email deliveries" ON public.transactional_email_deliveries;
DROP POLICY IF EXISTS "Users view own email delivery status" ON public.transactional_email_deliveries;

-- Allow admins to view delivery records in the admin panel
CREATE POLICY "Admin view all email deliveries"
    ON public.transactional_email_deliveries
    FOR SELECT
    USING (public.is_admin());

-- Allow users to view their own delivery records (excluding sensitive metadata)
CREATE POLICY "Users view own email delivery status"
    ON public.transactional_email_deliveries
    FOR SELECT
    USING (auth.uid()::text = user_id);

-- Permissions
REVOKE ALL ON public.transactional_email_deliveries FROM anon;
GRANT SELECT ON public.transactional_email_deliveries TO authenticated;
GRANT ALL ON public.transactional_email_deliveries TO service_role;

-- 4. Helper RPC for idempotent email logging
CREATE OR REPLACE FUNCTION public.record_email_delivery_attempt(
    p_event_key TEXT,
    p_email_type TEXT,
    p_user_id TEXT,
    p_order_id TEXT,
    p_transaction_id TEXT,
    p_email TEXT,
    p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS TABLE (
    already_sent BOOLEAN,
    delivery_id UUID,
    resend_id TEXT,
    current_status TEXT
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
    v_rec RECORD;
BEGIN
    SELECT * INTO v_rec FROM public.transactional_email_deliveries WHERE event_key = p_event_key;
    
    IF FOUND THEN
        IF v_rec.status = 'sent' THEN
            RETURN QUERY SELECT true, v_rec.id, v_rec.resend_message_id, v_rec.status;
            RETURN;
        ELSE
            -- Return existing non-sent record so caller can retry
            RETURN QUERY SELECT false, v_rec.id, v_rec.resend_message_id, v_rec.status;
            RETURN;
        END IF;
    END IF;

    -- Insert new pending record
    INSERT INTO public.transactional_email_deliveries (
        event_key, email_type, user_id, order_id, transaction_id, email, status, metadata, created_at
    ) VALUES (
        p_event_key, p_email_type, p_user_id, p_order_id, p_transaction_id, p_email, 'pending', p_metadata, NOW()
    ) RETURNING id, resend_message_id, status INTO v_rec;

    RETURN QUERY SELECT false, v_rec.id, v_rec.resend_message_id, v_rec.status;
END;
$$;

GRANT EXECUTE ON FUNCTION public.record_email_delivery_attempt(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, JSONB) TO service_role;
