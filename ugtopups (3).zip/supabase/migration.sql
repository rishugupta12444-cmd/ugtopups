-- ============================================================
-- UG TOP UP CENTER — SUPABASE PRODUCTION SCHEMA
-- Complete, idempotent migration (safe to re-run)
-- ============================================================

-- ── Extensions ───────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. CATEGORIES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.categories (
    id          TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    name        TEXT NOT NULL,
    enabled     BOOLEAN DEFAULT true,
    "order"     INT DEFAULT 0,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.categories
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 2. BANNERS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.banners (
    id           TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    "imageUrl"   TEXT,
    title        TEXT,
    subtitle     TEXT,
    badge        TEXT,
    "actionText" TEXT,
    "gameId"     TEXT,
    "linkUrl"    TEXT,
    active       BOOLEAN DEFAULT true,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.banners
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 3. GAMES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.games (
    id                 TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    name               TEXT NOT NULL,
    category           TEXT,
    "iconUrl"          TEXT,
    "bannerUrl"        TEXT,
    "requiresZoneId"   BOOLEAN DEFAULT false,
    "uidPlaceholder"   TEXT,
    packages           JSONB DEFAULT '[]'::jsonb,
    description        TEXT,
    publisher          TEXT,
    badge              TEXT,
    "zoneIdLabel"      TEXT,
    "userInstructions" TEXT,
    active             BOOLEAN DEFAULT true,
    featured           BOOLEAN DEFAULT false,
    trending           BOOLEAN DEFAULT false,
    popular            BOOLEAN DEFAULT false,
    hot                BOOLEAN DEFAULT false,
    created_at         TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.games
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 4. PRODUCTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.products (
    id                   TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    title                TEXT,
    name                 TEXT,
    code                 TEXT,
    category             TEXT,
    status               TEXT DEFAULT 'Active',
    availability         TEXT DEFAULT 'In Stock',
    "priceNpr"           NUMERIC DEFAULT 0,
    "originalPriceNpr"   NUMERIC,
    "stockCount"         INT DEFAULT 0,
    image                TEXT,
    "imageUrl"           TEXT,
    badge                TEXT,
    "inStock"            BOOLEAN DEFAULT true,
    description          TEXT,
    "gameId"             TEXT,
    "deliveryType"       TEXT DEFAULT 'MANUAL',
    packages             JSONB DEFAULT '[]'::jsonb,
    "createdAt"          TIMESTAMPTZ DEFAULT NOW(),
    "updatedAt"          TIMESTAMPTZ DEFAULT NOW(),
    created_at           TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.products
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 5. USERS
-- BUG FIX: id must reference auth.users(id) — do NOT gen_random_uuid() here.
-- The trigger inserts NEW.id (the auth UID) so this column must accept
-- the value coming from auth.  We keep the default only as a safety net.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.users (
    id                     TEXT PRIMARY KEY,
    "userCode"             TEXT,
    username               TEXT,
    email                  TEXT UNIQUE,
    "gameUid"              TEXT DEFAULT '',
    "avatarUrl"            TEXT DEFAULT '',
    "walletBalanceNpr"     NUMERIC DEFAULT 0,
    level                  TEXT DEFAULT 'Regular Member',
    "totalTopupsNpr"       NUMERIC DEFAULT 0,
    "completedOrdersCount" INT DEFAULT 0,
    "registrationDate"     TEXT,
    disabled               BOOLEAN DEFAULT false,
    role                   TEXT DEFAULT 'user',
    created_at             TIMESTAMPTZ DEFAULT NOW()
);
-- Do NOT set a random default for users.id — the trigger provides auth.users.id

-- ============================================================
-- 6. ADMINS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.admins (
    id         TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    email      TEXT UNIQUE NOT NULL,
    username   TEXT,
    role       TEXT DEFAULT 'admin',
    active     BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed admin
INSERT INTO public.admins (id, email, username, role, active)
VALUES ('admin-rishu', 'rishugupta12444@gmail.com', 'Rishu Gupta', 'admin', true)
ON CONFLICT (email) DO UPDATE SET active = true, role = 'admin';

-- ============================================================
-- 7. WALLET REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public."walletRequests" (
    id              TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    uid             TEXT NOT NULL,
    username        TEXT,
    email           TEXT,
    "amountNpr"     NUMERIC DEFAULT 0,
    "screenshotUrl" TEXT,
    "paymentMethod" TEXT DEFAULT 'eSewa / Khalti QR',
    status          TEXT DEFAULT 'PENDING',
    "rejectionReason" TEXT,
    "createdAt"     TIMESTAMPTZ DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public."walletRequests"
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 8. TRANSACTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.transactions (
    id                TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    "orderId"         TEXT,
    uid               TEXT,
    "userId"          TEXT,
    username          TEXT,
    "packageName"     TEXT,
    "gameName"        TEXT,
    amount            NUMERIC DEFAULT 0,
    type              TEXT DEFAULT 'DEDUCTION',
    operation         TEXT,
    "previousBalance" NUMERIC,
    "newBalance"      NUMERIC,
    "paymentMethod"   TEXT DEFAULT 'UG Wallet',
    status            TEXT DEFAULT 'SUCCESS',
    date              TEXT,
    "createdAt"       TIMESTAMPTZ DEFAULT NOW(),
    created_at        TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.transactions
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 9. ORDERS
-- BUG FIX: orderId is the PK and must have a default.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.orders (
    "orderId"          TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    id                 TEXT DEFAULT (gen_random_uuid()::text),
    "userId"           TEXT,
    "gameId"           TEXT,
    "gameName"         TEXT,
    "playerUid"        TEXT,
    "playerName"       TEXT,
    "zoneId"           TEXT DEFAULT '',
    "packageId"        TEXT,
    "packageName"      TEXT,
    diamonds           INT DEFAULT 0,
    quantity           INT DEFAULT 1,
    "totalPriceNpr"    NUMERIC DEFAULT 0,
    "walletDeductionNpr" NUMERIC DEFAULT 0,
    "paymentMethod"    TEXT,
    "transactionRef"   TEXT,
    "paymentStatus"    TEXT DEFAULT 'Pending',
    "topUpStatus"      TEXT DEFAULT 'PENDING',
    status             TEXT DEFAULT 'Pending',
    "rejectionReason"  TEXT,
    "createdAt"        TIMESTAMPTZ DEFAULT NOW(),
    "completedAt"      TEXT,
    "completedBy"      TEXT,
    "cancelledAt"      TEXT,
    "cancelledBy"      TEXT,
    created_at         TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.orders
    ALTER COLUMN "orderId" SET DEFAULT (gen_random_uuid()::text);
ALTER TABLE public.orders
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 10. SETTINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.settings (
    id         TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    facebook   TEXT,
    tiktok     TEXT,
    instagram  TEXT,
    youtube    TEXT,
    discord    TEXT,
    whatsapp   TEXT,
    email      TEXT,
    location   TEXT,
    data       JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.settings
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 11. EXPENSES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.expenses (
    id         TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    title      TEXT NOT NULL,
    amount     NUMERIC DEFAULT 0,
    category   TEXT,
    date       TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.expenses
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 12. NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.notifications (
    id         TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    title      TEXT NOT NULL,
    message    TEXT NOT NULL,
    date       TEXT,
    unread     BOOLEAN DEFAULT true,
    category   TEXT DEFAULT 'Announcement',
    "isPinned"  BOOLEAN DEFAULT false,
    "isExpired" BOOLEAN DEFAULT false,
    code       TEXT,
    "expiresIn" TEXT,
    "linkUrl"   TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.notifications
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 13. ANALYTICS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.analytics (
    id           TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    "pageViews"  INT DEFAULT 0,
    "totalSales" NUMERIC DEFAULT 0,
    data         JSONB,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.analytics
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- 14. SERVICES (was missing in previous migration)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.services (
    id          TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    name        TEXT NOT NULL,
    description TEXT,
    icon        TEXT,
    active      BOOLEAN DEFAULT true,
    "order"     INT DEFAULT 0,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.services
    ALTER COLUMN id SET DEFAULT (gen_random_uuid()::text);

-- ============================================================
-- REALTIME PUBLICATION
-- ============================================================
DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'categories','banners','games','products','users','orders',
    'admins','walletRequests','transactions','settings','notifications',
    'expenses','services','analytics'
  ] LOOP
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public'
        AND tablename = tbl
    ) THEN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', tbl);
    END IF;
  END LOOP;
END $$;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE public.categories    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.banners       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.games         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admins        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."walletRequests" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services      ENABLE ROW LEVEL SECURITY;

-- ── Drop old catch-all policies ──────────────────────────────
DO $$
DECLARE
  pol TEXT;
  tbl TEXT;
BEGIN
  FOR pol, tbl IN
    SELECT policyname, tablename
    FROM pg_policies
    WHERE schemaname = 'public'
      AND policyname LIKE 'Allow All%'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pol, tbl);
  END LOOP;
END $$;

-- ── Public read-only tables (anyone can read) ─────────────────
CREATE POLICY "Public read categories"    ON public.categories    FOR SELECT USING (true);
CREATE POLICY "Public read banners"       ON public.banners       FOR SELECT USING (true);
CREATE POLICY "Public read games"         ON public.games         FOR SELECT USING (true);
CREATE POLICY "Public read products"      ON public.products      FOR SELECT USING (true);
CREATE POLICY "Public read settings"      ON public.settings      FOR SELECT USING (true);
CREATE POLICY "Public read notifications" ON public.notifications FOR SELECT USING (true);
CREATE POLICY "Public read services"      ON public.services      FOR SELECT USING (true);

-- ── Users: own row only ───────────────────────────────────────
CREATE POLICY "Users: read own"   ON public.users FOR SELECT
    USING (auth.uid()::text = id);
CREATE POLICY "Users: update own" ON public.users FOR UPDATE
    USING (auth.uid()::text = id);
CREATE POLICY "Users: insert own" ON public.users FOR INSERT
    WITH CHECK (auth.uid()::text = id);

-- ── Orders: own rows only ─────────────────────────────────────
CREATE POLICY "Orders: read own"   ON public.orders FOR SELECT
    USING (auth.uid()::text = "userId");
CREATE POLICY "Orders: insert own" ON public.orders FOR INSERT
    WITH CHECK (auth.uid()::text = "userId");

-- ── Transactions: own rows ────────────────────────────────────
CREATE POLICY "Transactions: read own" ON public.transactions FOR SELECT
    USING (auth.uid()::text = "userId" OR auth.uid()::text = uid);

-- ── Wallet requests: own rows ─────────────────────────────────
CREATE POLICY "WalletReq: read own"   ON public."walletRequests" FOR SELECT
    USING (auth.uid()::text = uid);
CREATE POLICY "WalletReq: insert own" ON public."walletRequests" FOR INSERT
    WITH CHECK (auth.uid()::text = uid);

-- ── Admin full access (checks admins table or users.role='admin') ──
-- Helper function: is the current user an admin?
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admins
    WHERE id = auth.uid()::text AND active = true
  ) OR EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()::text AND role = 'admin'
  );
$$;

-- Admin bypass for all tables
CREATE POLICY "Admin full access categories"    ON public.categories    FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access banners"       ON public.banners       FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access games"         ON public.games         FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access products"      ON public.products      FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access users"         ON public.users         FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access admins"        ON public.admins        FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access walletReq"     ON public."walletRequests" FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access transactions"  ON public.transactions  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access orders"        ON public.orders        FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access settings"      ON public.settings      FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access expenses"      ON public.expenses      FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access notifications" ON public.notifications FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access analytics"     ON public.analytics     FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "Admin full access services"      ON public.services      FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true), ('screenshots', 'screenshots', true)
ON CONFLICT (id) DO UPDATE SET public = true;

DROP POLICY IF EXISTS "Public Storage Avatars" ON storage.objects;
DROP POLICY IF EXISTS "Public Storage Screenshots" ON storage.objects;
DROP POLICY IF EXISTS "Auth Storage Avatars Upload" ON storage.objects;

CREATE POLICY "Public Storage Avatars"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'avatars');

CREATE POLICY "Auth Storage Avatars Upload"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'avatars' AND auth.role() = 'authenticated');

CREATE POLICY "Public Storage Screenshots"
    ON storage.objects FOR ALL
    USING (bucket_id = 'screenshots')
    WITH CHECK (bucket_id = 'screenshots');

-- ============================================================
-- AUTO-CREATE USER PROFILE ON SIGN UP
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users (
    id,
    "userCode",
    username,
    email,
    "avatarUrl",
    "walletBalanceNpr",
    level,
    role,
    "registrationDate",
    created_at
  )
  VALUES (
    NEW.id::text,
    'UG-' || upper(substring(md5(random()::text), 1, 6)),
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'name',
      NEW.raw_user_meta_data->>'username',
      split_part(NEW.email, '@', 1),
      'User'
    ),
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', NEW.raw_user_meta_data->>'picture', ''),
    0,
    'Regular Member',
    CASE
      WHEN LOWER(TRIM(NEW.email)) = 'rishugupta12444@gmail.com' THEN 'admin'
      ELSE 'user'
    END,
    NOW()::text,
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email      = EXCLUDED.email,
    username   = COALESCE(EXCLUDED.username, public.users.username),
    "avatarUrl" = CASE
                    WHEN EXCLUDED."avatarUrl" != '' THEN EXCLUDED."avatarUrl"
                    ELSE public.users."avatarUrl"
                  END;

  -- Auto-add admin to admins table
  IF LOWER(TRIM(NEW.email)) = 'rishugupta12444@gmail.com' THEN
    INSERT INTO public.admins (id, email, username, role, active)
    VALUES (NEW.id::text, NEW.email, 'Rishu Gupta', 'admin', true)
    ON CONFLICT (email) DO UPDATE SET active = true, id = NEW.id::text;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- INDEXES for common query patterns
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_orders_userId    ON public.orders ("userId");
CREATE INDEX IF NOT EXISTS idx_orders_status    ON public.orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_createdAt ON public.orders ("createdAt" DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_userId ON public.transactions ("userId");
CREATE INDEX IF NOT EXISTS idx_transactions_uid    ON public.transactions (uid);
CREATE INDEX IF NOT EXISTS idx_walletreq_uid   ON public."walletRequests" (uid);
CREATE INDEX IF NOT EXISTS idx_walletreq_status ON public."walletRequests" (status);
CREATE INDEX IF NOT EXISTS idx_users_email     ON public.users (email);
CREATE INDEX IF NOT EXISTS idx_users_role      ON public.users (role);
-- UG TOP UP CENTER - Secure Redeem/Voucher Inventory
create table if not exists public.redeem_codes (
  id text primary key default gen_random_uuid()::text,
  product_id text not null,
  package_id text not null,
  code text not null,
  status text not null default 'available' check (status in ('available','reserved','delivered','redeemed','cancelled')),
  order_id text,
  user_id text,
  created_at timestamptz not null default now(),
  assigned_at timestamptz,
  delivered_at timestamptz,
  redeemed_at timestamptz,
  reservation_expires_at timestamptz
);

create unique index if not exists uq_redeem_codes_code_ci on public.redeem_codes ((lower(code)));
create index if not exists idx_redeem_codes_package_status on public.redeem_codes(product_id, package_id, status);
create index if not exists idx_redeem_codes_order on public.redeem_codes(order_id);
create index if not exists idx_redeem_codes_user on public.redeem_codes(user_id);

create table if not exists public.redeem_code_audit (
  id bigint generated always as identity primary key,
  redeem_code_id text not null references public.redeem_codes(id) on delete cascade,
  action text not null,
  order_id text,
  user_id text,
  created_at timestamptz not null default now()
);
create index if not exists idx_redeem_audit_code on public.redeem_code_audit(redeem_code_id, created_at desc);

alter table public.redeem_codes enable row level security;
alter table public.redeem_code_audit enable row level security;

drop policy if exists "redeem_codes_admin_all" on public.redeem_codes;
create policy "redeem_codes_admin_all" on public.redeem_codes for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "redeem_audit_admin_read" on public.redeem_code_audit;
create policy "redeem_audit_admin_read" on public.redeem_code_audit for select using (public.is_admin());

-- Never allow end users to query the inventory table directly.
revoke all on public.redeem_codes from anon, authenticated;
grant select, insert, update, delete on public.redeem_codes to authenticated;
-- RLS still limits those operations to admins.

create or replace function public.package_requires_redeem(p_product_id text, p_package_id text)
returns boolean
language sql stable security definer set search_path = public
as $$
  select coalesce((
    select bool_or(coalesce((pkg->>'requiresRedeemCode')::boolean, false))
    from public.products p
    cross join lateral jsonb_array_elements(coalesce(p.packages, '[]'::jsonb)) pkg
    where p.id = p_product_id and pkg->>'id' = p_package_id
  ), false);
$$;

grant execute on function public.package_requires_redeem(text,text) to anon, authenticated;

create or replace function public.get_redeem_stock(p_product_id text, p_package_id text)
returns integer
language plpgsql volatile security definer set search_path = public
as $$
begin
  update public.redeem_codes
     set status = 'available', order_id = null, user_id = null, assigned_at = null, reservation_expires_at = null
   where status = 'reserved' and reservation_expires_at is not null and reservation_expires_at < now();
  return (select count(*)::int from public.redeem_codes where product_id = p_product_id and package_id = p_package_id and status = 'available');
end;
$$;
grant execute on function public.get_redeem_stock(text,text) to anon, authenticated;

create or replace function public.reserve_redeem_codes(p_product_id text, p_package_id text, p_order_id text, p_user_id text, p_quantity integer)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  ids text[] := '{}';
  rec record;
  expires_at timestamptz := now() + interval '15 minutes';
  needed integer := greatest(coalesce(p_quantity,1),1);
  got integer := 0;
begin
  if not public.package_requires_redeem(p_product_id,p_package_id) then return jsonb_build_object('requires_redeem',false,'count',0,'ids',jsonb_build_array()); end if;
  if p_order_id is null or p_user_id is null then raise exception 'order/user is required'; end if;

  -- Release stale reservations first.
  update public.redeem_codes
     set status='available', order_id=null, user_id=null, assigned_at=null, reservation_expires_at=null
   where status='reserved' and reservation_expires_at is not null and reservation_expires_at < now();

  for rec in
    select id from public.redeem_codes
    where product_id=p_product_id and package_id=p_package_id and status='available'
    order by created_at asc
    for update skip locked
    limit needed
  loop
    update public.redeem_codes
       set status='reserved', order_id=p_order_id, user_id=p_user_id, assigned_at=now(), reservation_expires_at=expires_at
     where id=rec.id;
    insert into public.redeem_code_audit(redeem_code_id,action,order_id,user_id) values(rec.id,'reserved',p_order_id,p_user_id);
    ids := array_append(ids, rec.id);
    got := got + 1;
  end loop;

  if got <> needed then
    update public.redeem_codes set status='available', order_id=null, user_id=null, assigned_at=null, reservation_expires_at=null where id = any(ids);
    delete from public.redeem_code_audit where redeem_code_id = any(ids) and order_id=p_order_id and action='reserved';
    raise exception 'INSUFFICIENT_VOUCHER_STOCK';
  end if;

  return jsonb_build_object('requires_redeem',true,'count',got,'ids',to_jsonb(ids));
end;
$$;
grant execute on function public.reserve_redeem_codes(text,text,text,text,integer) to service_role;
grant execute on function public.reserve_redeem_codes(text,text,text,text,integer) to authenticated;

create or replace function public.deliver_reserved_redeem_codes(p_order_id text)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  result jsonb;
begin
  update public.redeem_codes
     set status='delivered', delivered_at=coalesce(delivered_at,now()), reservation_expires_at=null
   where order_id=p_order_id and status='reserved';

  insert into public.redeem_code_audit(redeem_code_id,action,order_id,user_id)
  select id,'delivered',order_id,user_id from public.redeem_codes
  where order_id=p_order_id and status='delivered'
    and not exists(select 1 from public.redeem_code_audit a where a.redeem_code_id=redeem_codes.id and a.action='delivered' and a.order_id=p_order_id);

  select coalesce(jsonb_agg(jsonb_build_object('id',id,'product_id',product_id,'package_id',package_id,'code',code,'status',status) order by created_at), '[]'::jsonb)
    into result
    from public.redeem_codes where order_id=p_order_id and status='delivered';
  return result;
end;
$$;
grant execute on function public.deliver_reserved_redeem_codes(text) to service_role;
grant execute on function public.deliver_reserved_redeem_codes(text) to authenticated;

create or replace function public.release_reserved_redeem_codes(p_order_id text)
returns integer
language plpgsql security definer set search_path = public
as $$
declare n integer;
begin
  with changed as (
    update public.redeem_codes
       set status='available', order_id=null, user_id=null, assigned_at=null, reservation_expires_at=null
     where order_id=p_order_id and status='reserved'
     returning id, order_id, user_id
  )
  insert into public.redeem_code_audit(redeem_code_id,action,order_id,user_id)
  select id,'cancelled',order_id,user_id from changed;
  get diagnostics n = row_count;
  return coalesce(n,0);
end;
$$;
grant execute on function public.release_reserved_redeem_codes(text) to service_role;
grant execute on function public.release_reserved_redeem_codes(text) to authenticated;

-- Secure customer-only read: the full code is returned only for the authenticated order owner.
create or replace function public.get_my_redeem_codes(p_order_id text)
returns table(id text, product_id text, package_id text, code text, status text, delivered_at timestamptz, order_id text)
language sql security definer set search_path = public
as $$
  select r.id,r.product_id,r.package_id,r.code,r.status,r.delivered_at,r.order_id
  from public.redeem_codes r
  join public.orders o on o."orderId" = r.order_id
  where r.order_id=p_order_id and o."userId"=auth.uid()::text and r.status in ('delivered','redeemed');
$$;
grant execute on function public.get_my_redeem_codes(text) to authenticated;

-- Realtime is safe because RLS blocks non-admin reads.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='redeem_codes') then
    alter publication supabase_realtime add table public.redeem_codes;
  end if;
end $$;

-- Notification hardening: user-specific rows, no public read of voucher data.
alter table public.notifications add column if not exists target_uid text;
alter table public.notifications add column if not exists target_email text;
alter table public.notifications add column if not exists order_id text;
alter table public.notifications add column if not exists product_id text;
alter table public.notifications add column if not exists package_id text;

drop policy if exists "Public read notifications" on public.notifications;
drop policy if exists "Users read own notifications" on public.notifications;
create policy "Users read own notifications" on public.notifications for select
using (target_uid = auth.uid()::text or coalesce(lower(target_email),'') = lower(coalesce((select email from public.users where id=auth.uid()::text),'')) or target_uid = 'ALL' or target_uid is null);

drop policy if exists "Admin full access notifications" on public.notifications;
create policy "Admin full access notifications" on public.notifications for all using (public.is_admin()) with check (public.is_admin());

-- Revoke direct client insert/update/delete on notifications; normal/admin notifications should use existing server-side admin routes.
revoke insert, update, delete on public.notifications from anon, authenticated;

-- Atomic wallet checkout for voucher packages. Uses auth.uid(), validates package price server-side,
-- locks wallet + voucher rows, creates the order and delivers the codes in one DB transaction.
create or replace function public.create_wallet_voucher_order(
  p_game_id text,
  p_game_name text,
  p_player_uid text,
  p_player_name text,
  p_zone_id text,
  p_package_id text,
  p_package_name text,
  p_quantity integer,
  p_diamonds integer,
  p_user_email text,
  p_user_password text,
  p_user_whatsapp text,
  p_user_field1 text,
  p_user_field2 text,
  p_client_order_id text
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  uid text := auth.uid()::text;
  qty integer := greatest(coalesce(p_quantity,1),1);
  pkg jsonb;
  unit_price numeric;
  total_price numeric;
  balance numeric;
  order_id text := coalesce(nullif(p_client_order_id,''), public.next_order_id());
  now_iso timestamptz := now();
  reservation jsonb;
  delivered jsonb;
  new_balance numeric;
begin
  if uid is null then raise exception 'AUTH_REQUIRED'; end if;
  select u."walletBalanceNpr" into balance from public.users u where u.id=uid for update;
  if balance is null then raise exception 'USER_NOT_FOUND'; end if;

  select pkg_item into pkg
  from public.products p
  cross join lateral jsonb_array_elements(coalesce(p.packages,'[]'::jsonb)) pkg_item
  where p.id=p_game_id and pkg_item->>'id'=p_package_id;
  if pkg is null then raise exception 'PACKAGE_NOT_FOUND'; end if;
  if coalesce((pkg->>'requiresRedeemCode')::boolean,false) is not true then raise exception 'PACKAGE_NOT_VOUCHER'; end if;

  unit_price := coalesce((pkg->>'priceNpr')::numeric,0);
  if unit_price <= 0 then raise exception 'INVALID_PACKAGE_PRICE'; end if;
  total_price := unit_price * qty;
  if balance < total_price then raise exception 'INSUFFICIENT_WALLET_BALANCE'; end if;

  reservation := public.reserve_redeem_codes(p_game_id,p_package_id,order_id,uid,qty);

  new_balance := balance - total_price;
  update public.users set "walletBalanceNpr"=new_balance where id=uid;

  insert into public.orders(
    "orderId","userId","gameId","gameName","playerUid","playerName","zoneId","packageId","packageName",
    diamonds,quantity,"totalPriceNpr","walletDeductionNpr","paymentMethod","transactionRef","paymentStatus","topUpStatus",status,
    "createdAt","completedAt","completedBy"
  ) values (
    order_id,uid,p_game_id,p_game_name,p_player_uid,p_player_name,coalesce(p_zone_id,''),p_package_id,
    p_package_name,coalesce(p_diamonds,0),qty,total_price,total_price,'UG Wallet','TXN-WLT-'||substr(md5(order_id||clock_timestamp()::text),1,12),
    'Paid','COMPLETED','Completed',to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),'AUTO_REDEEM_SYSTEM'
  );

  insert into public.transactions(id,"orderId",uid,"userId","packageName","gameName",amount,type,"paymentMethod",status,date,"createdAt", "previousBalance","newBalance")
  values (gen_random_uuid()::text,order_id,uid,uid,p_package_name,p_game_name,total_price,'DEDUCTION','UG Wallet','SUCCESS',to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),now_iso,balance,new_balance);

  delivered := public.deliver_reserved_redeem_codes(order_id);

  return jsonb_build_object(
    'orderId',order_id,'paymentStatus','Paid','topUpStatus','COMPLETED','status','Completed',
    'totalPriceNpr',total_price,'walletBalanceNpr',new_balance,
    'codes',delivered
  );
exception
  when others then
    raise;
end;
$$;
grant execute on function public.create_wallet_voucher_order(text,text,text,text,text,text,text,integer,integer,text,text,text,text,text,text) to authenticated;

-- Admin-only bulk import through Edge Function; direct table access remains admin-only by RLS.

-- Preserve the existing notification UI while restricting user writes to their own rows.
grant select, insert, update, delete on public.notifications to authenticated;
drop policy if exists "Users insert own notifications" on public.notifications;
create policy "Users insert own notifications" on public.notifications for insert with check (
  public.is_admin() or target_uid = auth.uid()::text
);
drop policy if exists "Users update own notifications" on public.notifications;
create policy "Users update own notifications" on public.notifications for update using (
  public.is_admin() or target_uid = auth.uid()::text
) with check (
  public.is_admin() or target_uid = auth.uid()::text
);
drop policy if exists "Users delete own notifications" on public.notifications;
create policy "Users delete own notifications" on public.notifications for delete using (
  public.is_admin() or target_uid = auth.uid()::text
);

-- Tighten privileged inventory mutations: end users never call these directly.
revoke execute on function public.reserve_redeem_codes(text,text,text,text,integer) from authenticated;
revoke execute on function public.deliver_reserved_redeem_codes(text) from authenticated;
revoke execute on function public.release_reserved_redeem_codes(text) from authenticated;


-- Redeem-code security patch
-- Run this AFTER redeem_codes_secure.sql in the existing Supabase project.

-- Never return raw voucher codes from the wallet checkout RPC.
create or replace function public.create_wallet_voucher_order(
  p_game_id text, p_game_name text, p_player_uid text, p_player_name text, p_zone_id text,
  p_package_id text, p_package_name text, p_quantity integer, p_diamonds integer,
  p_user_email text, p_user_password text, p_user_whatsapp text, p_user_field1 text,
  p_user_field2 text, p_client_order_id text
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  uid text := auth.uid()::text;
  qty integer := greatest(coalesce(p_quantity,1),1);
  pkg jsonb;
  unit_price numeric;
  total_price numeric;
  balance numeric;
  order_id text := coalesce(nullif(p_client_order_id,''), public.next_order_id());
  now_iso timestamptz := now();
  reservation jsonb;
  delivered jsonb;
  new_balance numeric;
begin
  if uid is null then raise exception 'AUTH_REQUIRED'; end if;
  select u."walletBalanceNpr" into balance from public.users u where u.id=uid for update;
  if balance is null then raise exception 'USER_NOT_FOUND'; end if;
  select pkg_item into pkg
  from public.products p
  cross join lateral jsonb_array_elements(coalesce(p.packages,'[]'::jsonb)) pkg_item
  where p.id=p_game_id and pkg_item->>'id'=p_package_id;
  if pkg is null then raise exception 'PACKAGE_NOT_FOUND'; end if;
  if coalesce((pkg->>'requiresRedeemCode')::boolean,false) is not true then raise exception 'PACKAGE_NOT_VOUCHER'; end if;
  unit_price := coalesce((pkg->>'priceNpr')::numeric,0);
  if unit_price <= 0 then raise exception 'INVALID_PACKAGE_PRICE'; end if;
  total_price := unit_price * qty;
  if balance < total_price then raise exception 'INSUFFICIENT_WALLET_BALANCE'; end if;
  reservation := public.reserve_redeem_codes(p_game_id,p_package_id,order_id,uid,qty);
  new_balance := balance - total_price;
  update public.users set "walletBalanceNpr"=new_balance where id=uid;
  insert into public.orders(
    "orderId","userId","gameId","gameName","playerUid","playerName","zoneId","packageId","packageName",
    diamonds,quantity,"totalPriceNpr","walletDeductionNpr","paymentMethod","transactionRef","paymentStatus","topUpStatus",status,
    "createdAt","completedAt","completedBy"
  ) values (
    order_id,uid,p_game_id,p_game_name,p_player_uid,p_player_name,coalesce(p_zone_id,''),p_package_id,p_package_name,
    coalesce(p_diamonds,0),qty,total_price,total_price,'UG Wallet','TXN-WLT-'||substr(md5(order_id||clock_timestamp()::text),1,12),
    'Paid','COMPLETED','Completed',to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),'AUTO_REDEEM_SYSTEM'
  );
  insert into public.transactions(id,"orderId",uid,"userId","packageName","gameName",amount,type,"paymentMethod",status,date,"createdAt","previousBalance","newBalance")
  values (gen_random_uuid()::text,order_id,uid,uid,p_package_name,p_game_name,total_price,'DEDUCTION','UG Wallet','SUCCESS',to_char(now_iso,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),now_iso,balance,new_balance);
  delivered := public.deliver_reserved_redeem_codes(order_id);
  return jsonb_build_object(
    'orderId',order_id,'paymentStatus','Paid','topUpStatus','COMPLETED','status','Completed',
    'totalPriceNpr',total_price,'walletBalanceNpr',new_balance,
    'deliveredCount',jsonb_array_length(coalesce(delivered,'[]'::jsonb))
  );
end;
$$;

-- Customers must never insert arbitrary notifications. Server/admin delivery paths insert them.
revoke insert on public.notifications from anon, authenticated;

-- ============================================================
-- AUTOMATIC WALLET REQUEST APPROVAL TRIGGER & RPC
-- ============================================================
CREATE OR REPLACE FUNCTION public.process_wallet_request_approval()
RETURNS TRIGGER AS $$
DECLARE
  v_user_id TEXT;
  v_amount NUMERIC;
  v_username TEXT;
BEGIN
  IF (NEW.status = 'APPROVED' AND (OLD.status IS NULL OR OLD.status != 'APPROVED')) THEN
    v_user_id := COALESCE(NEW.uid, NEW.user_id);
    v_amount := COALESCE(NEW."amountNpr", NEW.amount_npr, 0);
    v_username := COALESCE(NEW.username, 'User');

    IF v_amount > 0 THEN
      UPDATE public.users
      SET 
        "walletBalanceNpr" = COALESCE("walletBalanceNpr", 0) + v_amount,
        "totalTopupsNpr" = COALESCE("totalTopupsNpr", 0) + v_amount
      WHERE id = v_user_id OR (email IS NOT NULL AND LOWER(email) = LOWER(NEW.email));

      INSERT INTO public.transactions (
        id,
        "orderId",
        uid,
        "userId",
        username,
        amount,
        type,
        "paymentMethod",
        status,
        date,
        "createdAt",
        created_at
      ) VALUES (
        'TXN-WLT-' || floor(extract(epoch from now()) * 1000)::text,
        NEW.id,
        v_user_id,
        v_user_id,
        v_username,
        v_amount,
        'RECHARGE',
        COALESCE(NEW."paymentMethod", NEW.payment_method, 'Manual QR Verification'),
        'SUCCESS',
        to_char(now(), 'YYYY-MM-DD HH24:MI:SS'),
        now(),
        now()
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_approve_wallet_request ON public."walletRequests";
CREATE TRIGGER trg_approve_wallet_request
  AFTER UPDATE OF status ON public."walletRequests"
  FOR EACH ROW
  EXECUTE FUNCTION public.process_wallet_request_approval();

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='wallet_requests') THEN
    EXECUTE 'DROP TRIGGER IF EXISTS trg_approve_wallet_request_snake ON public.wallet_requests';
    EXECUTE 'CREATE TRIGGER trg_approve_wallet_request_snake AFTER UPDATE OF status ON public.wallet_requests FOR EACH ROW EXECUTE FUNCTION public.process_wallet_request_approval()';
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.approve_wallet_request(p_request_id TEXT)
RETURNS JSONB AS $$
DECLARE
  v_req RECORD;
  v_found BOOLEAN := false;
BEGIN
  SELECT * INTO v_req FROM public."walletRequests" WHERE id = p_request_id;
  IF FOUND THEN
    UPDATE public."walletRequests" SET status = 'APPROVED' WHERE id = p_request_id;
    v_found := true;
  END IF;

  IF NOT v_found THEN
    SELECT * INTO v_req FROM public.wallet_requests WHERE id = p_request_id;
    IF FOUND THEN
      UPDATE public.wallet_requests SET status = 'APPROVED' WHERE id = p_request_id;
      v_found := true;
    END IF;
  END IF;

  IF NOT v_found THEN
    RETURN jsonb_build_object('success', false, 'message', 'Wallet request not found');
  END IF;

  RETURN jsonb_build_object('success', true, 'message', 'Wallet request approved and user balance updated.');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.approve_wallet_request(TEXT) TO anon, authenticated;



-- VOUCHER EMAIL DELIVERY TRACKING
-- Voucher email delivery tracking. This replaces automatic voucher notifications.
create table if not exists public.voucher_email_deliveries (
  order_id text primary key,
  user_id text,
  recipient_email text not null,
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  code_count integer not null default 0,
  message_id text,
  error_message text,
  sent_at timestamptz,
  updated_at timestamptz not null default now()
);

create index if not exists voucher_email_deliveries_user_id_idx
  on public.voucher_email_deliveries(user_id);

alter table public.voucher_email_deliveries enable row level security;

drop policy if exists "No customer access to voucher email delivery records" on public.voucher_email_deliveries;
create policy "No customer access to voucher email delivery records"
  on public.voucher_email_deliveries
  for all
  using (false)
  with check (false);

revoke all on public.voucher_email_deliveries from anon, authenticated;
grant all on public.voucher_email_deliveries to service_role;

-- ============================================================
-- CHECKOUT & DATABASE LATENCY OPTIMIZATION INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_orders_orderid_lookup ON public.orders ("orderId");
CREATE INDEX IF NOT EXISTS idx_orders_user_created_desc ON public.orders ("userId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS idx_orders_user_status ON public.orders ("userId", status, "createdAt" DESC);
CREATE INDEX IF NOT EXISTS idx_orders_payment_lookup ON public.orders ("paymentStatus", "topUpStatus", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS idx_orders_game_package ON public.orders ("gameId", "packageId");

CREATE INDEX IF NOT EXISTS idx_users_wallet_balance ON public.users (id, "walletBalanceNpr");
CREATE INDEX IF NOT EXISTS idx_users_email_wallet ON public.users (email, "walletBalanceNpr");

CREATE INDEX IF NOT EXISTS idx_transactions_user_created_desc ON public.transactions (uid, "createdAt" DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_userId_created_desc ON public.transactions ("userId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_orderid_lookup ON public.transactions ("orderId");
CREATE INDEX IF NOT EXISTS idx_transactions_type_status ON public.transactions (type, status, "createdAt" DESC);

CREATE INDEX IF NOT EXISTS idx_redeem_codes_avail_fifo ON public.redeem_codes (product_id, package_id, status, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_redeem_codes_order_status ON public.redeem_codes (order_id, status);
CREATE INDEX IF NOT EXISTS idx_redeem_codes_user_delivered ON public.redeem_codes (user_id, status, delivered_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_requests_uid_status ON public."walletRequests" (uid, status, "createdAt" DESC);

