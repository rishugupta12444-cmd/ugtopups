-- ============================================================
-- UGTOPUPS NOTIFICATIONS: FINAL UID-ONLY SYSTEM
-- Every notification row:
--   target_uid   = real Supabase Auth UID
--   target_email = NULL
-- No ALL/null recipient rows are used.
-- Broadcasts are expanded into one row per user by the Edge Function.
-- Safe to re-run.
-- ============================================================

BEGIN;

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS target_uid TEXT,
  ADD COLUMN IF NOT EXISTS target_email TEXT,
  ADD COLUMN IF NOT EXISTS order_id TEXT,
  ADD COLUMN IF NOT EXISTS product_id TEXT,
  ADD COLUMN IF NOT EXISTS package_id TEXT;

-- Remove every older notification policy that can expose ALL/null rows or
-- cause duplicate-policy errors when this migration is re-run.
DROP POLICY IF EXISTS "Public read notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users read scoped notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users read own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users update own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users delete own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users insert own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Admin full access notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users insert notifications" ON public.notifications;

-- Remove the old trigger that raised:
-- "Private Order notification requires order_id and target user".
DROP TRIGGER IF EXISTS trg_normalize_private_notification_target ON public.notifications;
DROP FUNCTION IF EXISTS public.normalize_private_notification_target();

DROP TRIGGER IF EXISTS trg_force_notification_target_email_null ON public.notifications;
DROP TRIGGER IF EXISTS trg_normalize_notification_target ON public.notifications;
DROP TRIGGER IF EXISTS trg_validate_notification_target ON public.notifications;
DROP FUNCTION IF EXISTS public.force_notification_target_email_null();
DROP FUNCTION IF EXISTS public.normalize_notification_target();
DROP FUNCTION IF EXISTS public.validate_notification_target();

-- target_email is never used by this system.
UPDATE public.notifications SET target_email = NULL;

-- Repair existing order/wallet rows when an order owner is known.
UPDATE public.notifications n
SET target_uid = o."userId",
    target_email = NULL
FROM public.orders o
WHERE n.order_id = o."orderId"
  AND n.category IN ('Order','Wallet')
  AND o."userId" IS NOT NULL
  AND (n.target_uid IS NULL OR btrim(n.target_uid) = '' OR upper(btrim(n.target_uid)) = 'ALL');

-- Old global order/wallet rows whose owner cannot be determined are not safe
-- to expose to customers. Keep them admin-visible only by assigning a special
-- non-user target; the app never queries it. They can be deleted later.
UPDATE public.notifications
SET target_uid = 'ORPHANED_ADMIN_ONLY', target_email = NULL
WHERE category IN ('Order','Wallet')
  AND (target_uid IS NULL OR btrim(target_uid) = '' OR upper(btrim(target_uid)) = 'ALL');

CREATE INDEX IF NOT EXISTS idx_notifications_target_uid_created
  ON public.notifications(target_uid, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_order_id
  ON public.notifications(order_id);

-- Customers can read/update/delete only their own rows.
CREATE POLICY "Users read own notifications"
ON public.notifications
FOR SELECT TO authenticated
USING (target_uid = auth.uid()::text);

CREATE POLICY "Users update own notifications"
ON public.notifications
FOR UPDATE TO authenticated
USING (target_uid = auth.uid()::text)
WITH CHECK (target_uid = auth.uid()::text);

CREATE POLICY "Users delete own notifications"
ON public.notifications
FOR DELETE TO authenticated
USING (target_uid = auth.uid()::text);

-- Only admins may write notifications directly through the client. Automatic
-- customer-originated notifications are written by trusted Edge Functions.
CREATE POLICY "Admin full access notifications"
ON public.notifications
FOR ALL TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Defense-in-depth: always NULL the legacy email field.
CREATE OR REPLACE FUNCTION public.force_notification_email_null()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.target_email := NULL;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_force_notification_email_null
BEFORE INSERT OR UPDATE ON public.notifications
FOR EACH ROW EXECUTE FUNCTION public.force_notification_email_null();

COMMIT;

SELECT id, title, category, target_uid, target_email, order_id, created_at
FROM public.notifications
ORDER BY created_at DESC
LIMIT 30;
