-- UG TOP UP CENTER: UID Verification Enforcement & Voucher Bypass Fix
-- Run this in Supabase SQL Editor.

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS "uidVerified" BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS "uidVerifiedAt" TIMESTAMPTZ;

-- Function to check if a product package requires a redeem code / voucher
CREATE OR REPLACE FUNCTION public.package_requires_redeem(p_product_id text, p_package_id text)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_req boolean := false;
BEGIN
  -- 1. Check products table
  SELECT COALESCE(bool_or(
    COALESCE((pkg->>'requiresRedeemCode')::boolean, false)
    OR COALESCE((pkg->>'isRedeemCode')::boolean, false)
  ), false) INTO is_req
  FROM public.products p
  CROSS JOIN LATERAL jsonb_array_elements(COALESCE(p.packages, '[]'::jsonb)) pkg
  WHERE (p.id = p_product_id OR p."gameId" = p_product_id OR p.code = p_product_id)
    AND (p_package_id IS NULL OR p_package_id = '' OR pkg->>'id' = p_package_id);

  IF is_req THEN RETURN true; END IF;

  -- 2. Check games table
  SELECT COALESCE(bool_or(
    COALESCE((pkg->>'requiresRedeemCode')::boolean, false)
    OR COALESCE((pkg->>'isRedeemCode')::boolean, false)
  ), false) INTO is_req
  FROM public.games g
  CROSS JOIN LATERAL jsonb_array_elements(COALESCE(g.packages, '[]'::jsonb)) pkg
  WHERE g.id = p_product_id
    AND (p_package_id IS NULL OR p_package_id = '' OR pkg->>'id' = p_package_id);

  IF is_req THEN RETURN true; END IF;

  -- 3. Check deliveryType or category or name
  IF EXISTS (
    SELECT 1 FROM public.products p
    WHERE (p.id = p_product_id OR p."gameId" = p_product_id OR p.code = p_product_id)
      AND (
        p."deliveryType" IN ('INSTANT_CODE', 'AUTO_REDEEM', 'VOUCHER')
        OR p.category ~* '(voucher|redeem|gift[\s_-]?card|digital_code)'
        OR p.name ~* '(voucher|redeem|gift[\s_-]?card|unipin)'
        OR p.title ~* '(voucher|redeem|gift[\s_-]?card|unipin)'
      )
  ) THEN
    RETURN true;
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.games g
    WHERE g.id = p_product_id
      AND (
        g.category ~* '(voucher|redeem|gift[\s_-]?card|digital_code)'
        OR g.name ~* '(voucher|redeem|gift[\s_-]?card|unipin)'
      )
  ) THEN
    RETURN true;
  END IF;

  RETURN false;
END;
$$;

-- Trigger to prevent normal game orders from completing without verified UID,
-- while automatically allowing voucher and digital code products to complete.
CREATE OR REPLACE FUNCTION public.prevent_unverified_order_completion()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.status = 'Completed' AND COALESCE(NEW."uidVerified", FALSE) = FALSE THEN
    -- Check if this order is for a voucher or redeem-code product
    IF COALESCE(NEW."requiresRedeemCode", FALSE) = TRUE
       OR public.package_requires_redeem(NEW."gameId", NEW."packageId") = TRUE
       OR LOWER(COALESCE(NEW."gameName", '') || ' ' || COALESCE(NEW."packageName", '')) ~* '(voucher|redeem|gift[\s_-]?card|unipin)' THEN
      NEW."uidVerified" := TRUE;
      NEW."uidVerifiedAt" := COALESCE(NEW."uidVerifiedAt", NOW());
      RETURN NEW;
    END IF;

    RAISE EXCEPTION 'ORDER_UID_NOT_VERIFIED: This order cannot be completed until the player UID is successfully verified.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prevent_unverified_order_completion ON public.orders;

CREATE TRIGGER trg_prevent_unverified_order_completion
BEFORE INSERT OR UPDATE OF status, "uidVerified" ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.prevent_unverified_order_completion();
