-- ============================================================
-- MOBILE LEGENDS (LIANA) AUTOMATED DELIVERY — MIGRATION
-- ============================================================
-- Run this in the Supabase SQL Editor for the existing UG Top Up
-- Center project. It only adds new tables + policies; it does not
-- touch any existing table, data, or auth setup.
--
-- Requires: public.is_admin() (already created by supabase/migration.sql).
-- If you have not run supabase/migration.sql on this project yet,
-- run that first — this file depends on the is_admin() helper it defines.
-- ============================================================

-- ------------------------------------------------------------
-- 1. liana_orders — tracks every Liana verify/order API call
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.liana_orders (
    id                     TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    order_id               TEXT NOT NULL,               -- our internal orders."orderId"
    liana_product_id       INTEGER,                      -- Liana variation_id used
    user_id                TEXT,                         -- MLBB player UID entered by customer
    zone_id                TEXT,
    ign                    TEXT,                         -- verified in-game name
    status                 TEXT NOT NULL DEFAULT 'pending'
                             CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    error_message          TEXT,
    verification_response  JSONB,
    order_response         JSONB,
    api_transaction_id     TEXT,                         -- Liana's transaction_id / order_id
    retry_count            INTEGER NOT NULL DEFAULT 0,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_liana_orders_order_id ON public.liana_orders (order_id);
CREATE INDEX IF NOT EXISTS idx_liana_orders_status   ON public.liana_orders (status);
CREATE INDEX IF NOT EXISTS idx_liana_orders_created  ON public.liana_orders (created_at DESC);

CREATE OR REPLACE FUNCTION public.set_liana_orders_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_liana_orders_updated_at ON public.liana_orders;
CREATE TRIGGER trg_liana_orders_updated_at
  BEFORE UPDATE ON public.liana_orders
  FOR EACH ROW EXECUTE FUNCTION public.set_liana_orders_updated_at();

-- ------------------------------------------------------------
-- 2. wallet_activity_logs — merchant (Liana) wallet activity trail
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.wallet_activity_logs (
    id               TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    order_id         TEXT,                     -- liana_orders.id (or our internal order id)
    order_number     TEXT,                     -- our internal orders."orderId"
    action           TEXT NOT NULL,            -- e.g. verify_attempt, order_completed, order_failed
    api_status       TEXT,                     -- success | verification_failed | api_error | insufficient_funds | connection_error | error
    error_message    TEXT,
    coins_used       NUMERIC,
    balance_before    NUMERIC,
    balance_after     NUMERIC,
    api_response     JSONB,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wallet_logs_created ON public.wallet_activity_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_logs_order    ON public.wallet_activity_logs (order_number);

-- ------------------------------------------------------------
-- 3. system_settings — key/value config (daily cap, rate limit, etc.)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.system_settings (
    setting_key    TEXT PRIMARY KEY,
    setting_value  TEXT NOT NULL,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.system_settings (setting_key, setting_value) VALUES
  ('liana_daily_spending_cap', '5000'),
  ('liana_rate_limit_per_minute', '10'),
  ('liana_low_balance_threshold', '2000')
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE public.liana_orders        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings      ENABLE ROW LEVEL SECURITY;

-- liana_orders: only admins can read/write from the client. The edge
-- function itself uses the service-role key and bypasses RLS entirely.
DROP POLICY IF EXISTS "Admin full access liana_orders" ON public.liana_orders;
CREATE POLICY "Admin full access liana_orders"
  ON public.liana_orders
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- wallet_activity_logs: admin-only, same reasoning.
DROP POLICY IF EXISTS "Admin full access wallet_activity_logs" ON public.wallet_activity_logs;
CREATE POLICY "Admin full access wallet_activity_logs"
  ON public.wallet_activity_logs
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- system_settings: admin-only.
DROP POLICY IF EXISTS "Admin full access system_settings" ON public.system_settings;
CREATE POLICY "Admin full access system_settings"
  ON public.system_settings
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Enable realtime for live admin monitoring dashboard (safe to re-run)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'liana_orders'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.liana_orders;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'wallet_activity_logs'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.wallet_activity_logs;
  END IF;
EXCEPTION WHEN OTHERS THEN
  -- Publication may not exist on some project tiers; ignore if so.
  NULL;
END $$;
