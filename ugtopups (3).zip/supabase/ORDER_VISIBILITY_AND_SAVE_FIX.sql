-- ============================================================
-- ORDER VISIBILITY + PERSISTENCE RELIABILITY FIX
-- Run once in Supabase SQL Editor.
-- ============================================================

-- Admin-only authoritative order reader. RLS can otherwise return [] without an
-- error, which makes existing database rows look missing in the admin panel.
CREATE OR REPLACE FUNCTION public.admin_get_all_orders()
RETURNS SETOF public.orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  IF NOT (
    public.is_admin()
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
  ) THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  RETURN QUERY
  SELECT *
  FROM public.orders
  ORDER BY coalesce("createdAt", created_at) DESC NULLS LAST;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_get_all_orders() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_get_all_orders() TO authenticated;

-- Customer-owned server-side upsert. This is a fallback for direct writes that
-- are blocked by stale/misaligned RLS policies. It NEVER allows writing an order
-- for another user.
CREATE OR REPLACE FUNCTION public.customer_persist_order(p_order jsonb)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order public.orders;
  v_uid text;
  v_existing_user text;
BEGIN
  v_uid := auth.uid()::text;
  IF v_uid IS NULL OR v_uid = '' THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  IF nullif(trim(coalesce(p_order ->> 'orderId', '')), '') IS NULL THEN
    RAISE EXCEPTION 'orderId is required';
  END IF;

  IF coalesce(p_order ->> 'userId', '') <> v_uid THEN
    RAISE EXCEPTION 'Order userId does not match authenticated user';
  END IF;

  -- If this is only a retry after a successful insert, return success without
  -- allowing the customer to modify status/payment fields of an existing row.
  SELECT "userId" INTO v_existing_user
  FROM public.orders
  WHERE "orderId" = p_order ->> 'orderId';

  IF FOUND THEN
    IF v_existing_user <> v_uid THEN
      RAISE EXCEPTION 'Order belongs to another user';
    END IF;
    RETURN true;
  END IF;

  SELECT * INTO v_order
  FROM jsonb_populate_record(NULL::public.orders, p_order);

  INSERT INTO public.orders
  SELECT v_order.*;

  RETURN EXISTS (
    SELECT 1 FROM public.orders
    WHERE "orderId" = p_order ->> 'orderId'
      AND "userId" = v_uid
  );
END;
$$;

REVOKE ALL ON FUNCTION public.customer_persist_order(jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.customer_persist_order(jsonb) TO authenticated;

-- Keep normal RLS paths healthy as well.
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Orders: read own" ON public.orders;
CREATE POLICY "Orders: read own" ON public.orders
FOR SELECT TO authenticated
USING (auth.uid()::text = "userId");

DROP POLICY IF EXISTS "Orders: insert own" ON public.orders;
CREATE POLICY "Orders: insert own" ON public.orders
FOR INSERT TO authenticated
WITH CHECK (auth.uid()::text = "userId");

DROP POLICY IF EXISTS "Orders: select admin" ON public.orders;
CREATE POLICY "Orders: select admin" ON public.orders
FOR SELECT TO authenticated
USING (
  public.is_admin()
  OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
);
