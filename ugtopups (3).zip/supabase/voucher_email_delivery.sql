-- Voucher email delivery tracking. This replaces automatic voucher notifications.
create table if not exists public.voucher_email_deliveries (
  order_id text primary key,
  user_id text,
  recipient_email text not null,
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  code_count integer not null default 0,
  message_id text,
  error_message text,
  sent_at timestamptz,
  updated_at timestamptz not null default now()
);

create index if not exists voucher_email_deliveries_user_id_idx
  on public.voucher_email_deliveries(user_id);

alter table public.voucher_email_deliveries enable row level security;

drop policy if exists "No customer access to voucher email delivery records" on public.voucher_email_deliveries;
create policy "No customer access to voucher email delivery records"
  on public.voucher_email_deliveries
  for all
  using (false)
  with check (false);

revoke all on public.voucher_email_deliveries from anon, authenticated;
grant all on public.voucher_email_deliveries to service_role;
