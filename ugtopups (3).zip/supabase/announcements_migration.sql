-- ============================================================
-- ANNOUNCEMENT MANAGEMENT SYSTEM — MIGRATION
-- ============================================================
-- Run this in the Supabase SQL Editor for the existing UG Top Up
-- Center project. It only adds a new table + policies; it does not
-- touch any existing table, data, or auth setup.
--
-- Requires: public.is_admin() (already created by supabase/migration.sql).
-- If you have not run supabase/migration.sql on this project yet,
-- run that first — this file depends on the is_admin() helper it defines.
-- ============================================================

CREATE TABLE IF NOT EXISTS public.announcements (
    id                     TEXT PRIMARY KEY DEFAULT (gen_random_uuid()::text),
    title                  TEXT NOT NULL,
    description            TEXT NOT NULL,
    icon                   TEXT,
    status                 TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive')),
    "buttonEnabled"        BOOLEAN NOT NULL DEFAULT false,
    "buttonText"           TEXT,
    "buttonUrl"            TEXT,
    "buttonIcon"           TEXT,
    "openInNewTab"         BOOLEAN NOT NULL DEFAULT true,
    "startAt"              TIMESTAMPTZ,
    "endAt"                TIMESTAMPTZ,
    priority               INTEGER NOT NULL DEFAULT 0,
    "autoDisplay"          BOOLEAN NOT NULL DEFAULT true,
    "allowDontShowAgain"   BOOLEAN NOT NULL DEFAULT true,
    "createdAt"            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updatedAt"            TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Guard against unsafe button URL protocols at the database layer too
    -- (defense in depth — the frontend also validates/sanitizes this).
    CONSTRAINT announcements_button_url_safe CHECK (
        "buttonUrl" IS NULL
        OR "buttonUrl" ~* '^https?://'
        OR "buttonUrl" ~* '^/'
    ),
    CONSTRAINT announcements_end_after_start CHECK (
        "startAt" IS NULL OR "endAt" IS NULL OR "endAt" >= "startAt"
    )
);

-- Keep updatedAt fresh on every write
CREATE OR REPLACE FUNCTION public.set_announcements_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
  NEW."updatedAt" = NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_announcements_updated_at ON public.announcements;
CREATE TRIGGER trg_announcements_updated_at
  BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.set_announcements_updated_at();

-- Indexes for the lookups the app actually performs
CREATE INDEX IF NOT EXISTS idx_announcements_status    ON public.announcements (status);
CREATE INDEX IF NOT EXISTS idx_announcements_start_at   ON public.announcements ("startAt");
CREATE INDEX IF NOT EXISTS idx_announcements_end_at     ON public.announcements ("endAt");
CREATE INDEX IF NOT EXISTS idx_announcements_priority   ON public.announcements (priority DESC);
CREATE INDEX IF NOT EXISTS idx_announcements_active_window
  ON public.announcements (status, priority DESC, "startAt", "endAt");

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- Public (including anonymous/logged-out) visitors may only ever read
-- announcements that are marked Active. Time-window + auto-display
-- filtering happens in the app on top of this, but the DB never leaks
-- draft/inactive announcement content to non-admins.
DROP POLICY IF EXISTS "Public read active announcements" ON public.announcements;
CREATE POLICY "Public read active announcements"
  ON public.announcements
  FOR SELECT
  USING (status = 'active');

-- Admins (via the existing is_admin() helper — checks the admins table
-- or users.role = 'admin') get full read/write/delete access, including
-- to inactive/scheduled/expired announcements for management purposes.
DROP POLICY IF EXISTS "Admin full access announcements" ON public.announcements;
CREATE POLICY "Admin full access announcements"
  ON public.announcements
  FOR ALL
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Enable realtime updates for live admin/frontend sync (safe to re-run)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'announcements'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.announcements;
  END IF;
EXCEPTION WHEN OTHERS THEN
  -- Publication may not exist on some project tiers; ignore if so.
  NULL;
END $$;
