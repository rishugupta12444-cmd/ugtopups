-- ============================================================
-- ADMIN ORDER STATUS RELIABILITY FIX
-- Fixes orders disappearing / not updating when Admin clicks
-- Complete or Cancel. Keeps the existing frontend refund and
-- notification flow unchanged.
-- ============================================================

CREATE OR REPLACE FUNCTION public.admin_update_order_status(
  p_order_id text,
  p_new_status text,
  p_admin_uid text DEFAULT NULL,
  p_rejection_reason text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_admin boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;

  v_is_admin := public.is_admin()
    OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com';
  IF NOT v_is_admin THEN RETURN false; END IF;

  IF nullif(trim(coalesce(p_order_id, '')), '') IS NULL THEN RETURN false; END IF;
  IF upper(coalesce(p_new_status, '')) NOT IN ('COMPLETED','CANCELLED','PENDING') THEN RETURN false; END IF;

  IF upper(p_new_status) = 'COMPLETED' THEN
    UPDATE public.orders
    SET
      status = 'Completed',
      "topUpStatus" = 'COMPLETED',
      "paymentStatus" = 'Paid',
      "completedAt" = now()::text,
      "completedBy" = coalesce(nullif(trim(p_admin_uid), ''), auth.uid()::text),
      "uidVerified" = true
    WHERE "orderId" = trim(p_order_id);
  ELSIF upper(p_new_status) = 'CANCELLED' THEN
    UPDATE public.orders
    SET
      status = 'Cancelled',
      "topUpStatus" = 'CANCELLED',
      "cancelledAt" = now()::text,
      "cancelledBy" = coalesce(nullif(trim(p_admin_uid), ''), auth.uid()::text),
      "rejectionReason" = CASE
        WHEN nullif(trim(coalesce(p_rejection_reason, '')), '') IS NOT NULL THEN p_rejection_reason
        ELSE "rejectionReason"
      END
    WHERE "orderId" = trim(p_order_id);
  ELSE
    UPDATE public.orders
    SET
      status = 'Pending',
      "topUpStatus" = 'PENDING'
    WHERE "orderId" = trim(p_order_id);
  END IF;

  RETURN FOUND;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_update_order_status(text,text,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_update_order_status(text,text,text,text) TO authenticated;

-- Make sure the admin can still read/update orders through normal Supabase
-- queries as a fallback to the RPC path.
DROP POLICY IF EXISTS "Orders: update admin" ON public.orders;
CREATE POLICY "Orders: update admin" ON public.orders
FOR UPDATE
USING (
  public.is_admin()
  OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
)
WITH CHECK (
  public.is_admin()
  OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
);

DROP POLICY IF EXISTS "Orders: select admin" ON public.orders;
CREATE POLICY "Orders: select admin" ON public.orders
FOR SELECT
USING (
  public.is_admin()
  OR lower(coalesce(auth.jwt() ->> 'email', '')) = 'rishugupta12444@gmail.com'
);
