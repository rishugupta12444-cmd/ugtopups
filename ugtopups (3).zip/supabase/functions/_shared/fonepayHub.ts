const encoder = new TextEncoder();

const hex = (bytes: Uint8Array) =>
  Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('');

async function sha256(value: string): Promise<string> {
  return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(value))));
}

async function hmac(value: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  );
  return hex(new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(value))));
}

function baseUrl(): string {
  const value = (Deno.env.get('FONEPAY_HUB_BASE_URL') || '').trim().replace(/\/+$/, '');
  if (!/^https:\/\//i.test(value)) throw new Error('FONEPAY_HUB_BASE_URL must be a valid HTTPS URL.');
  return value;
}

export async function hubRequest(
  method: 'GET' | 'POST',
  path: string,
  payload?: Record<string, unknown>,
): Promise<{ response: Response; result: any }> {
  const clientId = (Deno.env.get('FONEPAY_HUB_CLIENT_ID') || '').trim();
  const clientSecret = (Deno.env.get('FONEPAY_HUB_CLIENT_SECRET') || '').trim();
  if (!clientId || !clientSecret) throw new Error('Fonepay Hub client credentials are not configured.');
  if (!path.startsWith('/api/v1/')) throw new Error('Invalid Fonepay Hub API path.');

  const body = payload === undefined ? '' : JSON.stringify(payload);
  const timestamp = String(Math.floor(Date.now() / 1000));
  const nonceBytes = crypto.getRandomValues(new Uint8Array(24));
  const nonce = hex(nonceBytes);
  const canonical = `${method}\n${path}\n${timestamp}\n${nonce}\n${await sha256(body)}`;
  const signature = await hmac(canonical, clientSecret);

  const response = await fetch(`${baseUrl()}${path}`, {
    method,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'X-Client-Id': clientId,
      'X-Timestamp': timestamp,
      'X-Nonce': nonce,
      'X-Signature': signature,
    },
    body: body || undefined,
  });
  const result = await response.json().catch(() => null);
  return { response, result };
}

export function hubData(result: any): any {
  return result?.data && typeof result.data === 'object' ? result.data : result;
}

export function hubError(result: any, fallback: string): string {
  return String(result?.error?.message || result?.message || fallback);
}

export async function verifyHubWebhook(rawBody: string, headers: Headers): Promise<boolean> {
  const secret = (Deno.env.get('FONEPAY_HUB_WEBHOOK_SECRET') || '').trim();
  const timestamp = (headers.get('X-Webhook-Timestamp') || '').trim();
  const supplied = (headers.get('X-Webhook-Signature') || '').trim().replace(/^v1=/i, '').toLowerCase();
  if (!secret || !/^\d+$/.test(timestamp) || !/^[a-f0-9]{64}$/.test(supplied)) return false;
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp)) > 300) return false;
  const expected = await hmac(`${timestamp}.${rawBody}`, secret);
  if (expected.length !== supplied.length) return false;
  let mismatch = 0;
  for (let i = 0; i < expected.length; i += 1) mismatch |= expected.charCodeAt(i) ^ supplied.charCodeAt(i);
  return mismatch === 0;
}
