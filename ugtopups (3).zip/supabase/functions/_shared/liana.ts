// supabase/functions/_shared/liana.ts
//
// Single source of truth for talking to the Liana reseller API
// (https://server.lianastore.in/api/v1). Both `check-uid` (customer-facing
// IGN verification) and `process-ml-order` (verify-ign / check-balance /
// order pipeline) import from here so the response-parsing logic can never
// drift apart between the two functions again.
//
// Auth: single header — X-API-Key: <key>
// There is NO separate API secret — the old X-API-KEY + X-API-SECRET pair
// is gone. Only LIANA_API_KEY is needed. Remove LIANA_API_SECRET if present.
//
// Required secret (Supabase Edge Function secret — never in frontend code):
//   LIANA_API_KEY   — the sk_live_... key from the Liana dashboard
//
// Pro/Elite-plan-only endpoints: /verify/mlbb, /verify/bgmi, /verify-ign,
// /check-region, /check-bonus. If the account isn't on Pro/Elite, these
// will return a plan-related error — surfaced distinctly (see below).

export const LIANA_BASE = 'https://server.lianastore.in/api/v1';

export function lianaHeaders(apiKey: string): Record<string, string> {
  return {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-API-Key': apiKey,
  };
}

/** Fetch with a hard timeout so a hung Liana connection can't hang the whole edge function. */
export async function lianaFetch(url: string, options: RequestInit, timeoutMs = 8000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/** Retries idempotent Liana calls on network errors / 5xx only — never on 4xx. */
export async function lianaFetchWithRetry(url: string, options: RequestInit, maxRetries = 2, delayMs = 1000): Promise<Response> {
  let lastErr: unknown = null;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const res = await lianaFetch(url, options);
      if (res.status < 500) return res;
      lastErr = new Error(`Liana server error ${res.status}`);
    } catch (e) {
      lastErr = e;
    }
    if (attempt < maxRetries) await new Promise((r) => setTimeout(r, delayMs));
  }
  throw lastErr instanceof Error ? lastErr : new Error('Liana request failed after retries.');
}

/** Loosely coerce Liana's `verified`-style fields — sometimes boolean, sometimes "true"/"1"/"yes" strings. */
function truthy(value: unknown): boolean {
  if (value === true) return true;
  if (typeof value === 'string') return ['true', '1', 'yes', 'verified', 'success'].includes(value.trim().toLowerCase());
  if (typeof value === 'number') return value === 1;
  return false;
}

/**
 * When Liana's response body isn't valid JSON, figure out WHY so the admin
 * doesn't just see a dead-end "invalid response" message. This is the
 * difference between "credentials are wrong" and "we're being firewalled"
 * and "the endpoint URL itself is wrong" — three very different fixes.
 */
function diagnoseNonJsonResponse(status: number, contentType: string, text: string): string {
  const t = text.trim();
  const lower = t.toLowerCase();

  if (!t) {
    return `Liana returned an empty response (HTTP ${status}). The endpoint may be down, or the request is being silently blocked before it reaches Liana's server.`;
  }
  if (lower.includes('cloudflare') || lower.includes('attention required') || lower.includes('checking your browser') || status === 403 && lower.startsWith('<')) {
    return `Liana's server blocked this request behind Cloudflare/a firewall (HTTP ${status}) instead of returning API data. This usually means the server's outgoing IP isn't allow-listed on Liana's side, or too many requests triggered a challenge page.`;
  }
  if (lower.includes('<title>login') || lower.includes('wp-login') || lower.includes('name="log"') ) {
    return `Liana returned a login page (HTTP ${status}) instead of API data — this points to invalid/expired API credentials.`;
  }
  if (status === 404) {
    return `Liana returned "not found" (HTTP 404) for this API endpoint. The API URL may have changed on Liana's side.`;
  }
  if (status === 429) {
    return `Liana rate-limited this request (HTTP 429). Too many requests were sent in a short time — wait a moment and retry.`;
  }
  if (status >= 500) {
    return `Liana's server returned an error (HTTP ${status}) instead of API data. This is on Liana's side — try again shortly.`;
  }
  if (t.startsWith('<')) {
    return `Liana returned an HTML page instead of JSON (HTTP ${status}, content-type: ${contentType || 'unknown'}). Check the Supabase function logs for the full response to see exactly what page was returned.`;
  }
  return `Liana returned a response that isn't valid JSON (HTTP ${status}, content-type: ${contentType || 'unknown'}). Check the Supabase function logs for the raw response.`;
}

export interface LianaVerifyOutcome {
  verified: boolean;
  display: string | null;
  /** True only when Liana explicitly reported the account as verified but gave no usable name — kept distinct from a hard "not found" so callers can decide whether to fall back. */
  verifiedWithoutName: boolean;
  error: string | null;
  /** True when the failure is an infra/connectivity problem (blocked, rate-limited, 5xx, malformed response) rather than a genuine "this account doesn't exist" — callers should show customers a generic retry message for these, not the technical detail, and may want to try a fallback network path. */
  blocked: boolean;
  httpStatus: number;
  raw: any;
}

/**
 * Parses a Liana `/verify/mlbb` response.
 * Confirmed shape: { "status": true, "ign": "PlayerName", "region": "..." }
 * Also tolerates nesting under `data` in case the API evolves.
 * Logs the raw shape the first time an unexpected nesting is seen so it
 * can be locked down precisely once the live response is observed.
 */
export function parseLianaVerifyResponse(raw: any): { verified: boolean; display: string | null; region: string | null; verifiedWithoutName: boolean } {
  if (!raw || typeof raw !== 'object') return { verified: false, display: null, region: null, verifiedWithoutName: false };

  const d = raw.data || {};

  // ign and region may live at top level OR under data — be tolerant of both.
  const ign = raw.ign ?? d.ign ?? raw.display ?? d.display ??
    raw.playerName ?? d.playerName ?? raw.player_name ?? d.player_name ??
    raw.username ?? d.username ?? raw.name ?? d.name ?? raw.nickname ?? d.nickname;

  const region = raw.region ?? d.region ?? null;

  const display = String(ign ?? '').trim();

  // status:true or verified:true (boolean or truthy string) counts as verified.
  const verified =
    truthy(raw.status) ||
    truthy(d.verified) ||
    truthy(raw.verified);

  return {
    verified,
    display: display || null,
    region: region ? String(region).trim() || null : null,
    verifiedWithoutName: verified && !display,
  };
}

/**
 * Calls Liana's MLBB IGN verification endpoint (POST /verify/mlbb) and
 * returns a clean outcome. Requires only customer_id + zone_id — no
 * product_id is needed for MLBB verification.
 *
 * This endpoint requires a Pro/Elite plan on the Liana account. If the
 * account is on a lower plan, Liana will return a plan-related error that
 * is surfaced distinctly (planError: true) so it isn't confused with a
 * bad Game ID / Zone ID.
 *
 * If Liana confirms the account is verified but returns no cached nickname,
 * we fall back to a generated placeholder instead of hard-rejecting a real
 * valid account.
 */
export async function verifyMlbbIgn(apiKey: string, _productId: number, customerId: string, zoneId: string): Promise<LianaVerifyOutcome> {
  // _productId is accepted for call-site compatibility but NOT sent to /verify/mlbb —
  // the confirmed contract only requires customer_id and zone_id.
  const cleanCustomerId = String(customerId).trim();
  const cleanZone = String(zoneId).trim();

  try {
    const res = await lianaFetchWithRetry(`${LIANA_BASE}/verify/mlbb`, {
      method: 'POST',
      headers: lianaHeaders(apiKey),
      body: JSON.stringify({ customer_id: cleanCustomerId, zone_id: cleanZone }),
    });

    const rawText = await res.text();
    const contentType = res.headers.get('content-type') || '';
    let raw: any = null;
    try {
      raw = rawText ? JSON.parse(rawText) : null;
    } catch {
      const diagnosis = diagnoseNonJsonResponse(res.status, contentType, rawText);
      console.error(`[liana] verify: non-JSON response — HTTP ${res.status}, content-type=${contentType}. Body (first 500 chars): ${rawText.slice(0, 500)}`);
      return { verified: false, display: null, verifiedWithoutName: false, error: diagnosis, blocked: true, httpStatus: res.status, raw: null };
    }

    // Pro/Elite plan check — 402 or a message containing "plan", "upgrade",
    // "subscription" suggests the account isn't on a qualifying plan.
    const rawTextForPlanCheck = ''; // captured below after full parse
    if (res.status === 402) {
      console.error(`[liana] verify: plan restriction — HTTP 402. The Liana account may not be on Pro/Elite plan.`);
      return { verified: false, display: null, verifiedWithoutName: false, error: 'This verification feature requires a Pro or Elite plan on the Liana account. Please upgrade the merchant plan.', blocked: true, httpStatus: res.status, raw: null };
    }

    if (res.status === 401 || res.status === 403) {
      console.error(`[liana] verify: auth rejected — HTTP ${res.status}. Check that LIANA_API_KEY is correct (single key, no secret needed).`);
      return { verified: false, display: null, verifiedWithoutName: false, error: 'Liana rejected the merchant credentials. Please contact support.', blocked: true, httpStatus: res.status, raw };
    }

    // Detect plan-restriction errors that come back as JSON (e.g. 200 with an error message).
    if (raw && !truthy(raw.status)) {
      const msg = String(raw.message || raw.error || '').toLowerCase();
      if (msg.includes('plan') || msg.includes('upgrade') || msg.includes('subscription') || msg.includes('elite') || msg.includes('pro ')) {
        console.error(`[liana] verify: plan restriction detected in JSON response — ${raw.message || raw.error}`);
        return { verified: false, display: null, verifiedWithoutName: false, error: 'This verification feature requires a Pro or Elite plan on the Liana account. Please upgrade the merchant plan.', blocked: true, httpStatus: res.status, raw };
      }
    }

    // Log the raw nesting shape the first time so unexpected layouts can be locked down.
    const hasTopLevelIgn = raw && ('ign' in raw || 'region' in raw);
    const hasNestedIgn = raw?.data && ('ign' in raw.data || 'region' in raw.data);
    if (!hasTopLevelIgn && !hasNestedIgn && raw) {
      console.warn(`[liana] verify: unexpected response shape (no top-level ign/region, no data.ign/region). Raw keys: ${Object.keys(raw).join(', ')}`);
    }

    const { verified, display, verifiedWithoutName } = parseLianaVerifyResponse(raw);

    console.log(`[liana] verify uid=${cleanCustomerId} zone=${cleanZone} → HTTP ${res.status}, verified=${verified}, hasDisplay=${!!display}`);

    if (verified && display) {
      return { verified: true, display, verifiedWithoutName: false, error: null, blocked: false, httpStatus: res.status, raw };
    }

    if (verifiedWithoutName) {
      // Liana confirmed the account exists but returned no cached nickname —
      // don't reject a real account for this; use a stable placeholder.
      const fallback = `Player_${cleanCustomerId}`;
      console.warn(`[liana] verify: account verified but no display name — using fallback "${fallback}"`);
      return { verified: true, display: fallback, verifiedWithoutName: true, error: null, blocked: false, httpStatus: res.status, raw };
    }

    const errorMsg = raw?.message || raw?.error || raw?.data?.message || raw?.provider?.message ||
      "We couldn't verify this Mobile Legends account. Please check your Game ID and Zone ID.";
    return { verified: false, display: null, verifiedWithoutName: false, error: errorMsg, blocked: false, httpStatus: res.status, raw };
  } catch (e: any) {
    const timedOut = e?.name === 'AbortError';
    console.error(`[liana] verify: request failed — ${timedOut ? 'timeout' : (e?.message || 'unknown error')}`);
    return {
      verified: false, display: null, verifiedWithoutName: false,
      error: timedOut ? 'Verification request timed out. Please try again.' : 'Verification service is temporarily unavailable. Please try again in a moment.',
      blocked: true, httpStatus: 0, raw: null,
    };
  }
}

export interface LianaBalanceOutcome {
  ok: boolean;
  balance: number | null;
  error: string | null;
  blocked: boolean;
  httpStatus: number;
  credentialsExpired: boolean;
  raw: any;
}

/** Pulls a numeric balance out of the Liana Official response — documented as `data.balance`, but stays tolerant of top-level/alternate field names too. */
export function parseLianaBalanceResponse(raw: any): number | null {
  if (raw == null) return null;
  if (typeof raw === 'number') return Number.isFinite(raw) ? raw : null;

  const d = raw.data || {};
  const candidate =
    d.balance ?? d.wallet_balance ?? d.amount ?? d.coins ??
    raw.balance ?? raw.wallet_balance ?? raw.amount ?? raw.coins;

  if (candidate === undefined || candidate === null) return null;
  const num = Number(candidate);
  return Number.isFinite(num) ? num : null;
}

export async function checkMlbbBalance(apiKey: string): Promise<LianaBalanceOutcome> {
  try {
    const res = await lianaFetchWithRetry(`${LIANA_BASE}/balance`, {
      method: 'GET',
      headers: lianaHeaders(apiKey),
    });

    const rawText = await res.text();
    const contentType = res.headers.get('content-type') || '';
    let raw: any = null;
    try {
      raw = rawText ? JSON.parse(rawText) : null;
    } catch {
      const diagnosis = diagnoseNonJsonResponse(res.status, contentType, rawText);
      console.error(`[liana] balance: non-JSON response — HTTP ${res.status}, content-type=${contentType}. Body (first 500 chars): ${rawText.slice(0, 500)}`);
      return { ok: false, balance: null, error: diagnosis, blocked: true, httpStatus: res.status, credentialsExpired: false, raw: null };
    }

    if (res.status === 401 || res.status === 403) {
      console.error(`[liana] balance: auth rejected — HTTP ${res.status}. Check that LIANA_API_KEY is correct (single key, no secret needed).`);
      return { ok: false, balance: null, error: 'Liana rejected the merchant credentials. Please contact support.', blocked: true, httpStatus: res.status, credentialsExpired: true, raw };
    }

    const balance = parseLianaBalanceResponse(raw);
    console.log(`[liana] balance: HTTP ${res.status}, parsedBalance=${balance}`);

    if (balance !== null) {
      return { ok: true, balance, error: null, blocked: false, httpStatus: res.status, credentialsExpired: false, raw };
    }

    const errorMsg = raw?.message || raw?.error || raw?.data?.message || 'Failed to fetch merchant wallet balance.';
    return { ok: false, balance: null, error: errorMsg, blocked: false, httpStatus: res.status, credentialsExpired: false, raw };
  } catch (e: any) {
    const timedOut = e?.name === 'AbortError';
    console.error(`[liana] balance: request failed — ${timedOut ? 'timeout' : (e?.message || 'unknown error')}`);
    return {
      ok: false, balance: null,
      error: timedOut ? 'Balance request timed out. Please try again.' : 'Balance service is temporarily unavailable.',
      blocked: true, httpStatus: 0, credentialsExpired: false, raw: null,
    };
  }
}
