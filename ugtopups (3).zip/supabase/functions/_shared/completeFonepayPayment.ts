export async function completeFonepayPayment(admin: any, order: any, hubPayment: any) {
  const orderId = String(order.orderId || '');
  const amount = Number(hubPayment?.amount);
  if (!orderId || String(hubPayment?.merchant_reference || '') !== orderId) {
    throw new Error('Fonepay Hub merchant reference does not match this order.');
  }
  if (!Number.isFinite(amount) || Math.abs(amount - Number(order.totalPriceNpr || 0)) > 0.009) {
    throw new Error('Fonepay Hub amount does not match this order.');
  }
  if (String(hubPayment?.status || '').toLowerCase() !== 'paid') {
    return { verified: false, order };
  }

  if (String(order.paymentStatus || '').toUpperCase() === 'SUCCESS') {
    return { verified: true, order };
  }

  const transactionRef = String(hubPayment?.id || order.transactionRef || orderId);
  const paidAmount = Number(order.totalPriceNpr || 0);
  const { data: confirmation, error: confirmationError } = await admin.rpc('confirm_fonepay_hub_payment', {
    p_order_id: orderId, p_payment_id: transactionRef, p_amount: paidAmount,
  });
  if (confirmationError) throw new Error(`Could not confirm Fonepay payment: ${confirmationError.message}`);
  const updated = confirmation?.order || order;
  if (confirmation?.transitioned !== true) {
    return { verified: String(updated?.paymentStatus || '').toUpperCase() === 'SUCCESS', order: updated };
  }
  const isWalletLoad = confirmation?.is_wallet === true;
  const voucherRequired = confirmation?.is_voucher === true;

  const nowStr = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }) + ' · ' +
    new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  if (voucherRequired) {
    const { data: deliveredData } = await admin.rpc('deliver_reserved_redeem_codes', { p_order_id: orderId });
    const codes = (Array.isArray(deliveredData) ? deliveredData : []).map((row: any) => String(row?.code || '').trim()).filter(Boolean);
    await admin.from('notifications').upsert({
      id: `voucher-${orderId}`, target_uid: updated.userId || null, target_email: null,
      title: 'Voucher Delivered 🎟️',
      message: codes.length ? `Your voucher code for ${order.packageName || order.gameName} is: ${codes.join(', ')}` : `Your voucher is ready in order ${orderId}.`,
      category: 'Order', code: codes[0] || null, order_id: orderId,
      product_id: order.gameId || null, package_id: order.packageId || null,
      unread: true, date: nowStr, created_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  } else if (isWalletLoad) {
    await admin.from('notifications').upsert({
      id: `wallet-load-${orderId}`, target_uid: updated.userId || null, target_email: null,
      title: 'Wallet Recharge Successful 💰', message: `NPR ${paidAmount} has been added to your UG Wallet!`,
      category: 'Wallet', order_id: orderId, unread: true, date: nowStr, created_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  } else {
    if (updated.userId) await admin.rpc('increment_user_coins', { p_uid: updated.userId, p_amount: 3 }).catch(() => null);
    await admin.from('notifications').upsert({
      id: `order-paid-${orderId}`, target_uid: updated.userId || null, target_email: null,
      title: 'Payment Successful 💳',
      message: `Your Fonepay payment of NPR ${paidAmount} for ${order.packageName || order.gameName} was received.`,
      category: 'Order', order_id: orderId, product_id: order.gameId || null,
      package_id: order.packageId || null, unread: true, date: nowStr, created_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  }

  return { verified: true, order: updated };
}
