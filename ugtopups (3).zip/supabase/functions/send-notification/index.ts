import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
const serviceKey = () =>
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ||
  (() => {
    try {
      return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '';
    } catch {
      return '';
    }
  })();

// This function is the ONLY place (besides trusted DB triggers/RPCs) that is
// allowed to create a notification row. Customers never get direct INSERT
// access to `notifications` (see notifications_reviews_security_fix.sql), so
// this closes the "fake Voucher Delivered notification" attack surface and
// gives admin broadcasts a path that actually writes to Supabase.
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = serviceKey();
    if (!key) return json({ success: false, message: 'Server key not configured.' }, 500);
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, key);

    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    if (!token) return json({ success: false, message: 'Authentication required.' }, 401);
    const { data: authData } = await admin.auth.getUser(token);
    const caller = authData?.user;
    if (!caller) return json({ success: false, message: 'Invalid authentication token.' }, 401);

    // Admins can send any notification. A normal signed-in user may only
    // create the automatic private Order/Wallet notification for their OWN
    // order. This is needed because checkout runs from the customer session,
    // while the actual row is still written with the service role.
    const { data: adminRow } = await admin.from('admins').select('id').eq('id', caller.id).eq('active', true).maybeSingle();
    let isAdmin = !!adminRow;
    if (!isAdmin) {
      const { data: userRow } = await admin.from('users').select('role').eq('id', caller.id).maybeSingle();
      isAdmin = ['admin', 'super_admin'].includes(String(userRow?.role || '').toLowerCase());
    }

    const body = await req.json().catch(() => ({}));
    const title = String(body.title || '').trim();
    const message = String(body.message || '').trim();
    if (!title || !message) return json({ success: false, message: 'Title and message are required.' }, 400);

    const category = String(body.category || 'System').trim();
    const requestedTargetEmail = String(body.targetEmail || '').trim();
    let requestedTargetUid = String(body.targetUid || '').trim();

    // The database contract is UID-only. target_email is always stored NULL.
    // Email is accepted only as an admin input to resolve a user's Auth UID.
    const privateEvent = category === 'Order' || category === 'Wallet';
    const orderId = String(body.orderId || '').trim();

    if (privateEvent) {
      if (!orderId) {
        return json({ success: false, message: 'Order/Wallet notifications require orderId.' }, 400);
      }

      const { data: orderRow } = await admin
        .from('orders')
        .select('orderId, userId')
        .eq('orderId', orderId)
        .maybeSingle();

      if (!orderRow?.userId) {
        return json({ success: false, message: 'Order owner could not be resolved.' }, 404);
      }

      const ownerUid = String(orderRow.userId).trim();
      if (!isAdmin && caller.id !== ownerUid) {
        return json({ success: false, message: 'Not authorized for this order.' }, 403);
      }

      // Order/Wallet events always belong to the order owner.
      requestedTargetUid = ownerUid;
    } else if (!isAdmin) {
      return json({ success: false, message: 'Not authorized.' }, 403);
    }

    const nowIso = new Date().toISOString();
    const nowStr =
      new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }) +
      ' · ' +
      new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    // Admin broadcast: expand to one notification row per registered user.
    // This keeps the database UID-only: there is never target_uid = ALL.
    const isBroadcast = !privateEvent &&
      (requestedTargetEmail.toUpperCase() === 'ALL' || requestedTargetUid.toUpperCase() === 'ALL');

    let targetUids: string[] = [];

    if (isBroadcast) {
      const { data: users, error: usersError } = await admin
        .from('users')
        .select('id')
        .not('id', 'is', null);
      if (usersError) return json({ success: false, message: usersError.message }, 400);
      targetUids = (users || [])
        .map((u: any) => String(u.id || '').trim())
        .filter(Boolean);
    } else {
      if (!requestedTargetUid && requestedTargetEmail) {
        const { data: userRow } = await admin
          .from('users')
          .select('id')
          .ilike('email', requestedTargetEmail)
          .maybeSingle();
        if (!userRow?.id) return json({ success: false, message: 'No user found with that email.' }, 404);
        requestedTargetUid = String(userRow.id).trim();
      }

      if (!requestedTargetUid || requestedTargetUid.toUpperCase() === 'ALL') {
        return json({ success: false, message: 'A valid target user UID is required.' }, 400);
      }
      targetUids = [requestedTargetUid];
    }

    if (targetUids.length === 0) {
      return json({ success: false, message: 'No users found for this notification.' }, 404);
    }

    const baseId = String(body.id || `notif-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`);
    const rows = targetUids.map((uid, index) => ({
      id: targetUids.length === 1 ? baseId : `${baseId}-${index + 1}`,
      target_uid: uid,
      target_email: null,
      order_id: privateEvent ? orderId : null,
      title,
      message,
      category,
      expiresIn: body.expiresIn || null,
      isPinned: !!body.isPinned,
      unread: true,
      date: nowStr,
      created_at: nowIso,
    }));

    console.log('[NOTIFICATION] creating', rows.length, 'notification row(s)');
    console.log('[NOTIFICATION] category:', category, 'broadcast:', isBroadcast);

    const { error } = await admin.from('notifications').insert(rows);
    if (error) {
      console.warn('[NOTIFICATION] insert failed', error.message);
      return json({ success: false, message: error.message }, 400);
    }

    console.log('[NOTIFICATION] insert success');
    return json({ success: true, id: baseId, count: rows.length });
  } catch (e) {
    return json({ success: false, message: e instanceof Error ? e.message : 'Notification service failed.' }, 500);
  }
});
