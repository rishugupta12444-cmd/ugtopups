import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
const serviceKey = () => Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || (() => { try { return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || ''; } catch { return ''; } })();

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = serviceKey(); if (!key) return json({ success:false, message:'Server key not configured.' },500);
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, key);
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace(/^Bearer\s+/i,'').trim();
    const { data: authUser } = token ? await admin.auth.getUser(token) : { data: { user: null } };
    const body = await req.json().catch(() => ({}));
    const action = String(body.action || '').trim();

    if (action === 'get_my_codes') {
      if (!authUser?.user?.id) return json({ success:false, message:'Authentication required.' },401);
      const orderId = String(body.orderId || '').trim();
      if (!orderId) return json({ success:false, message:'Order ID is required.' },400);
      const { data, error } = await admin.rpc('get_my_redeem_codes', { p_order_id: orderId });
      if (error) return json({ success:false, message:error.message },400);
      return json({ success:true, codes:data || [] });
    }

    if (!authUser?.user?.id) return json({ success:false, message:'Authentication required.' },401);
    const userId = authUser.user.id;
    const orderId = String(body.orderId || '').trim();
    const productId = String(body.productId || '').trim();
    const packageId = String(body.packageId || '').trim();
    const quantity = Math.max(1, Number(body.quantity || 1));
    if (!orderId || !productId || !packageId) return json({ success:false, message:'Missing order details.' },400);

    if (action === 'stock') {
      const { data: stock, error } = await admin.rpc('get_redeem_stock', { p_product_id:productId, p_package_id:packageId });
      if (error) return json({ success:false, message:error.message },400);
      return json({ success:true, stock:Number(stock || 0) });
    }

    if (action === 'reserve') {
      const { data, error } = await admin.rpc('reserve_redeem_codes', { p_product_id:productId, p_package_id:packageId, p_order_id:orderId, p_user_id:userId, p_quantity:quantity });
      if (error) return json({ success:false, message:error.message.includes('INSUFFICIENT_VOUCHER_STOCK') ? 'Currently Out of Stock' : error.message },409);
      return json({ success:true, reservation:data });
    }

    if (action === 'deliver') {
      const { data: order, error: orderError } = await admin.from('orders').select('orderId,userId,paymentStatus,gameId,packageId,packageName,gameName,quantity').eq('orderId',orderId).single();
      if (orderError || !order) return json({ success:false, message:'Order not found.' },404);
      if (order.userId !== userId) {
        const { data: adminRow } = await admin.from('admins').select('id').eq('id',userId).eq('active',true).maybeSingle();
        if (!adminRow) return json({ success:false, message:'Not authorized.' },403);
      }
      if (!['SUCCESS','Paid','Completed'].includes(String(order.paymentStatus))) return json({ success:false, message:'Payment not verified.' },409);
      const { data: codes, error } = await admin.rpc('deliver_reserved_redeem_codes', { p_order_id:orderId });
      if (error) return json({ success:false, message:error.message },400);
      const list = Array.isArray(codes) ? codes : [];
      let emailSent = false;
      if (list.length) {
        const emailFunctionUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/send-voucher-email`;
        const emailResponse = await fetch(emailFunctionUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${key}`,
          },
          body: JSON.stringify({ orderId }),
        });
        const emailResult = await emailResponse.json().catch(() => ({}));
        emailSent = emailResponse.ok && emailResult?.success === true;
        if (!emailSent) console.warn('[EMAIL] voucher delivery email failed:', emailResult?.message || emailResponse.status);
      }
      return json({ success:true, delivered:list.length, emailSent });
    }

    if (action === 'release') {
      const { error } = await admin.rpc('release_reserved_redeem_codes', { p_order_id:orderId });
      if (error) return json({ success:false, message:error.message },400);
      return json({ success:true });
    }

    return json({ success:false, message:'Unknown action.' },400);
  } catch (e) {
    return json({ success:false, message:e instanceof Error ? e.message : 'Redeem code service failed.' },500);
  }
});
