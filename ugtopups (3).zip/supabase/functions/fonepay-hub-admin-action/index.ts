import { createClient } from 'npm:@supabase/supabase-js@2';
import { completeFonepayPayment } from '../_shared/completeFonepayPayment.ts';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { ...cors, 'Content-Type': 'application/json' },
});

function serviceKey() {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (legacy) return legacy;
  try {
    return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '';
  } catch {
    return '';
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });

  try {
    const key = serviceKey();
    if (!key) return json({ success: false, message: 'Server key is not configured.' }, 500);

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, key);
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '').trim();
    const { data: authData } = token
      ? await admin.auth.getUser(token)
      : { data: { user: null } };
    const caller = authData?.user;
    if (!caller?.id) return json({ success: false, message: 'Authentication required.' }, 401);

    const { data: adminRow } = await admin
      .from('admins')
      .select('id')
      .eq('id', caller.id)
      .eq('active', true)
      .maybeSingle();

    let isAdmin = !!adminRow;
    if (!isAdmin) {
      const { data: userRow } = await admin
        .from('users')
        .select('role')
        .eq('id', caller.id)
        .maybeSingle();
      isAdmin = ['admin', 'super_admin'].includes(String(userRow?.role || '').toLowerCase());
    }
    if (!isAdmin) return json({ success: false, message: 'Admin access required.' }, 403);

    const input = await req.json().catch(() => ({}));
    const orderId = String(input.orderId || '').trim();
    const action = String(input.action || '').trim().toLowerCase();
    if (!orderId || !['confirm', 'reject'].includes(action)) {
      return json({ success: false, message: 'A valid order ID and action are required.' }, 400);
    }

    const { data: order, error: orderError } = await admin
      .from('orders')
      .select('*')
      .eq('orderId', orderId)
      .maybeSingle();
    if (orderError || !order) return json({ success: false, message: 'Payment record not found.' }, 404);

    const method = String(order.paymentMethod || '').toLowerCase();
    if (!method.includes('fonepay')) {
      return json({ success: false, message: 'Only Fonepay Hub payments can be managed here.' }, 400);
    }

    const paymentStatus = String(order.paymentStatus || '').toUpperCase();
    const orderStatus = String(order.status || '').toUpperCase();
    if (paymentStatus === 'SUCCESS' || paymentStatus === 'PAID') {
      return json({ success: false, message: 'This payment is already confirmed.' }, 409);
    }
    if (['FAILED', 'CANCELLED', 'REJECTED'].includes(paymentStatus) || ['CANCELLED', 'REJECTED'].includes(orderStatus)) {
      return json({ success: false, message: 'This payment is no longer pending.' }, 409);
    }

    if (action === 'reject') {
      await admin.rpc('release_reserved_redeem_codes', { p_order_id: orderId });
      const reason = String(input.reason || 'Rejected manually by admin.').trim().slice(0, 500);
      const now = new Date().toISOString();
      const { data: rejected, error: rejectError } = await admin
        .from('orders')
        .update({
          paymentStatus: 'FAILED',
          topUpStatus: 'CANCELLED',
          status: 'Cancelled',
          rejectionReason: reason,
          cancelledAt: now,
          cancelledBy: caller.id,
        })
        .eq('orderId', orderId)
        .neq('paymentStatus', 'SUCCESS')
        .neq('paymentStatus', 'PAID')
        .neq('paymentStatus', 'Paid')
        .select()
        .maybeSingle();
      if (rejectError) throw new Error(`Could not reject payment: ${rejectError.message}`);
      if (!rejected) {
        return json({ success: false, message: 'This payment was already confirmed and cannot be rejected.' }, 409);
      }
      return json({ success: true, action: 'rejected', order: rejected });
    }

    const transactionRef = String(order.transactionRef || '').trim();
    if (!transactionRef) {
      return json({ success: false, message: 'This payment has no Fonepay Hub transaction reference.' }, 400);
    }

    // This is an explicit, authenticated admin override. Reuse the same atomic
    // completion flow used by the Fonepay webhook so wallet credits, voucher
    // delivery, notifications and order activation stay idempotent.
    const completed = await completeFonepayPayment(admin, order, {
      id: transactionRef,
      merchant_reference: orderId,
      amount: Number(order.totalPriceNpr || 0),
      status: 'paid',
    });

    return json({ success: true, action: 'confirmed', ...completed });
  } catch (error) {
    return json({
      success: false,
      message: error instanceof Error ? error.message : 'Could not update the Fonepay Hub payment.',
    }, 500);
  }
});
