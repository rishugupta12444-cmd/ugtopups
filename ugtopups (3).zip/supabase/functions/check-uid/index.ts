// supabase/functions/check-uid/index.ts
// Supabase Edge Function — Free Fire/PUBG UID Verification via Ez2Topup
// Deploy: supabase functions deploy check-uid
// Secrets required: EZ2TOPUP_API_KEY, EZ2TOPUP_SECRET_KEY

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { verifyMlbbIgn } from "../_shared/liana.ts";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

function jsonResponse(
  body: unknown,
  status = 200,
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

/**
 * HMAC-SHA256 Signature Generation — matches Ez2Topup spec exactly.
 *
 * Algorithm:
 *  1. Gather all parameters except 'sign'.
 *  2. Sort keys alphabetically.
 *  3. Build a URLSearchParams query string.
 *  4. HMAC-SHA256 the query string with the Secret Key.
 *  5. Hex-encode the result.
 */
async function generateSignature(
  params: Record<string, string>,
  secretKey: string,
): Promise<{ queryString: string; signature: string }> {
  // 1. Exclude 'sign', strip whitespace
  const clean: Record<string, string> = {};
  for (const [k, v] of Object.entries(params)) {
    if (k !== "sign" && v !== undefined && v !== null) {
      clean[k] = String(v).trim();
    }
  }

  // 2. Sort alphabetically
  const sortedKeys = Object.keys(clean).sort();
  const sorted: Record<string, string> = {};
  for (const k of sortedKeys) sorted[k] = clean[k];

  // 3. Build query string
  const queryString = new URLSearchParams(sorted).toString();

  // 4 & 5. HMAC-SHA256 → hex
  const encoder = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secretKey),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sigBuf = await crypto.subtle.sign(
    "HMAC",
    cryptoKey,
    encoder.encode(queryString),
  );
  const signature = Array.from(new Uint8Array(sigBuf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  return { queryString, signature };
}

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: CORS_HEADERS });
  }

  try {
    // ── Parse input ──────────────────────────────────────────────────────
    let uid = "";
    let zoneId = "";
    let variationId = "";
    let gameId = "free-fire";
    let gameName = "";

    if (req.method === "GET") {
      const url = new URL(req.url);
      uid = (url.searchParams.get("uid") ||
        url.searchParams.get("player_id") ||
        url.searchParams.get("user_id") || "").trim();
      zoneId = (url.searchParams.get("zone_id") || url.searchParams.get("zoneId") || "").trim();
      variationId = (url.searchParams.get("product_id") || url.searchParams.get("productId") || url.searchParams.get("variation_id") || url.searchParams.get("variationId") || "").trim();
      gameId = url.searchParams.get("gameId") || "free-fire";
      gameName = url.searchParams.get("gameName") || "";
    } else if (req.method === "POST") {
      try {
        const body = await req.json();
        uid = String(body.uid || body.player_id || body.user_id || "").trim();
        zoneId = String(body.zone_id || body.zoneId || "").trim();
        variationId = String(body.product_id || body.productId || body.variation_id || body.variationId || "").trim();
        gameId = String(body.gameId || body.game_id || "free-fire").trim();
        gameName = String(body.gameName || body.game_name || "").trim();
      } catch {
        return jsonResponse(
          { success: false, error: "Invalid JSON body" },
          400,
        );
      }
    }

    // IMPORTANT: detect MLBB only by gameId — NOT by variationId
    // Using variationId here would cause Free Fire requests to be routed to Liana MLBB API
    const isMlbb =
      gameId.toLowerCase().includes('mlbb') ||
      gameId.toLowerCase().includes('mobilelegend') ||
      gameId.toLowerCase().includes('mobile-legend') ||
      gameId.toLowerCase().includes('mobile_legend') ||
      gameId.toLowerCase() === 'mlbb';

    // ── Handle MLBB Brazil Verification via Liana ───────────────────────
    if (isMlbb) {
      if (!uid || !zoneId) {
        return jsonResponse(
          { success: false, verified: false, error: "Missing required Game ID or Zone ID for Mobile Legends" },
          200,
        );
      }

      const lianaApiKey = (Deno.env.get("LIANA_API_KEY") || "").trim();

      if (!lianaApiKey) {
        console.error("[check-uid] Missing LIANA_API_KEY secret");
        return jsonResponse({
          success: false,
          verified: false,
          error: "Mobile Legends verification is not configured on the server.",
        }, 200);
      }

      console.log(`[check-uid] Verifying MLBB uid=${uid} zone=${zoneId} product_id=${variationId || "not-required-for-verification"}`);

      const outcome = await verifyMlbbIgn(lianaApiKey, Number(variationId) || 4, uid, zoneId);

      if (outcome.verified && outcome.display) {
        return jsonResponse({
          success: true,
          verified: true,
          playerName: outcome.display,
          display: outcome.display,
          provider: outcome.raw,
        }, 200);
      }

      // Infra-level failures (blocked/rate-limited/malformed response) get a
      // generic, friendly message for the customer — the technical detail
      // (Cloudflare block, HTTP status, etc.) is logged server-side only and
      // is not something a customer can act on.
      return jsonResponse({
        success: false,
        verified: false,
        blocked: outcome.blocked,
        error: outcome.blocked
          ? "Verification service is temporarily unavailable. Please try again in a few minutes."
          : (outcome.error || "We couldn't verify this Mobile Legends account. Please check your Game ID and Zone ID."),
      }, 200);
    }

    if (!uid) {
      return jsonResponse(
        { success: false, error: "Missing required parameter: uid / player_id" },
        400,
      );
    }

    // ── Load secrets ─────────────────────────────────────────────────────
    const apiKey = (Deno.env.get("EZ2TOPUP_API_KEY") || Deno.env.get("FREEFIRE_API_KEY") || "").trim();
    const secretKey = (Deno.env.get("EZ2TOPUP_SECRET_KEY") || Deno.env.get("FREEFIRE_SECRET_KEY") || "").trim();

    if (!apiKey || !secretKey) {
      console.error("[check-uid] Missing EZ2TOPUP_API_KEY or EZ2TOPUP_SECRET_KEY secrets");
      return jsonResponse(
        { success: false, error: "Free Fire verification is not configured on the server. Add EZ2TOPUP_API_KEY and EZ2TOPUP_SECRET_KEY to Supabase Edge Function secrets." },
        200,
      );
    }

    // ── Build signed request per Ez2Topup spec ───────────────────────────
    // Params for signature: api_key + player_id (no sign in the hash input)
    const params: Record<string, string> = {
      api_key: apiKey,
      player_id: uid,
    };

    const { queryString, signature } = await generateSignature(params, secretKey);

    // Free Fire and PUBG use the same credentials/signature scheme; only the endpoint changes.
    const isPubg = /pubg|bgmi/i.test(`${gameId} ${gameName}`);
    const endpoint = isPubg ? 'pubg.php' : 'freefire.php';
    const targetUrl =
      `https://ez2topup.com/api/v1/verify/${endpoint}?${queryString}&sign=${signature}`;

    console.log(`[check-uid] Verifying UID: ${uid} | gameId: ${gameId}`);

    // ── Call Ez2Topup API with retry + timeout ───────────────────────────
    const MAX_ATTEMPTS = 2;
    const TIMEOUT_MS = 8000;
    let lastError = "Player not found or verification failed";

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

      try {
        const response = await fetch(targetUrl, {
          method: "GET",
          headers: {
            Accept: "application/json",
            // Pass credentials both as headers (recommended) AND in query string (already done above)
            "X-API-Key": apiKey,
            "X-Signature": signature,
          },
          signal: controller.signal,
        });
        clearTimeout(timer);

        const rawText = await response.text();
        console.log(`[check-uid] Attempt ${attempt} — HTTP ${response.status}: ${rawText.slice(0, 200)}`);

        let json: any = null;
        try {
          json = JSON.parse(rawText);
        } catch {
          lastError = "Invalid response from verification server";
          continue;
        }

        if (!json) continue;

        // Free Fire and PUBG do not necessarily return the same response shape.
        // Accept both nested `data` responses and PUBG-style top-level responses.
        const payload = (json?.data && typeof json.data === 'object') ? json.data : json;
        const playerName =
          payload?.username || payload?.nickname || payload?.player_name || payload?.playerName ||
          payload?.name || payload?.ign || payload?.character_name || payload?.characterName ||
          json?.playerName || json?.username || json?.nickname || json?.name || json?.ign || '';
        const explicitSuccess =
          json?.success === true || json?.status === true || json?.api_status === true ||
          json?.verified === true || json?.valid === true ||
          String(json?.status || '').toLowerCase() === 'success';

        // A returned player name is sufficient proof of a successful verification even
        // when the PUBG endpoint omits `success: true`.
        if (playerName && (response.ok || explicitSuccess)) {
          return jsonResponse({
            success: true,
            verified: true,
            playerName: String(playerName),
            gameId,
            uid: payload?.player_id || payload?.playerId || payload?.uid || payload?.user_id || uid,
            region: payload?.region || payload?.server || json?.region || null,
            data: payload,
          });
        }

        // Ez2Topup endpoints use different error envelopes; normalize all common fields.
        lastError =
          json?.error || json?.message || json?.msg || json?.detail ||
          payload?.error || payload?.message ||
          "Player not found or invalid format";
        // Don't retry on known player-not-found errors
        if (
          lastError.toLowerCase().includes("not found") ||
          lastError.toLowerCase().includes("invalid")
        ) {
          break;
        }
      } catch (err: unknown) {
        clearTimeout(timer);
        const e = err as Error;
        if (e.name === "AbortError") {
          lastError = "Verification request timed out. Please try again.";
          console.warn(`[check-uid] Attempt ${attempt} timed out`);
        } else {
          lastError = e.message || "Network error during verification";
          console.error(`[check-uid] Attempt ${attempt} error:`, e.message);
        }
      }
    }

    return jsonResponse({ success: false, error: lastError });
  } catch (err: unknown) {
    const e = err as Error;
    console.error("[check-uid] Unhandled error:", e.message);
    return jsonResponse(
      { success: false, error: "Internal server error" },
      200,
    );
  }
});
