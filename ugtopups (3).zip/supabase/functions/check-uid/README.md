# Free Fire UID verification

This function keeps Ez2Topup credentials server-side and returns a JSON `success: false` response with HTTP 200 for expected verification/configuration failures. This prevents the Supabase client from replacing the useful API error with the generic `Edge Function returned a non-2xx status code` message.

## Deploy

```bash
supabase secrets set EZ2TOPUP_API_KEY="YOUR_API_KEY"
supabase secrets set EZ2TOPUP_SECRET_KEY="YOUR_SECRET_KEY"
supabase functions deploy check-uid
```

`config.toml` has `verify_jwt = false` because the storefront verifies UIDs before login.
