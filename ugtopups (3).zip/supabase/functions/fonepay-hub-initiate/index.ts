import { createClient } from 'npm:@supabase/supabase-js@2';
import { hubData, hubError, hubRequest } from '../_shared/fonepayHub.ts';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (data: unknown) => new Response(JSON.stringify(data), {
  status: 200, headers: { ...cors, 'Content-Type': 'application/json' },
});
function serviceKey() {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (legacy) return legacy;
  try { return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || ''; } catch { return ''; }
}

async function verifyPlayer(uid: string, gameName: string) {
  const apiKey = (Deno.env.get('EZ2TOPUP_API_KEY') || Deno.env.get('FREEFIRE_API_KEY') || '').trim();
  const secret = (Deno.env.get('EZ2TOPUP_SECRET_KEY') || Deno.env.get('FREEFIRE_SECRET_KEY') || '').trim();
  if (!apiKey || !secret) return { ok: false, message: 'Player verification is not configured.' };
  const params = new URLSearchParams({ api_key: apiKey, player_id: uid });
  const sorted = new URLSearchParams();
  [...params.entries()].sort(([a], [b]) => a.localeCompare(b)).forEach(([key, value]) => sorted.set(key, value));
  const cryptoKey = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = Array.from(new Uint8Array(await crypto.subtle.sign('HMAC', cryptoKey, new TextEncoder().encode(sorted.toString()))))
    .map((byte) => byte.toString(16).padStart(2, '0')).join('');
  try {
    const endpoint = /pubg|bgmi/i.test(gameName) ? 'pubg.php' : 'freefire.php';
    const response = await fetch(`https://ez2topup.com/api/v1/verify/${endpoint}?${sorted}&sign=${signature}`, {
      headers: { Accept: 'application/json', 'X-API-Key': apiKey, 'X-Signature': signature },
    });
    const body = await response.json().catch(() => null);
    const payload = body?.data && typeof body.data === 'object' ? body.data : body;
    const name = payload?.username || payload?.nickname || payload?.player_name || payload?.playerName || payload?.name || payload?.ign || payload?.character_name || body?.playerName;
    const explicitSuccess = body?.success === true || body?.status === true || body?.api_status === true || body?.verified === true || body?.valid === true || String(body?.status || '').toLowerCase() === 'success';
    return name && (response.ok || explicitSuccess)
      ? { ok: true, name: String(name) }
      : { ok: false, message: String(body?.error || body?.message || body?.msg || payload?.error || payload?.message || `Invalid ${/pubg|bgmi/i.test(gameName) ? 'PUBG' : 'Free Fire'} UID.`) };
  } catch { return { ok: false, message: 'Player verification service is unavailable.' }; }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = serviceKey();
    if (!key) return json({ success: false, message: 'Supabase server secret is not configured.' });
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, key);
    const body = await req.json().catch(() => ({}));

    let userId = '';
    const jwt = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    if (jwt) {
      const { data } = await admin.auth.getUser(jwt).catch(() => ({ data: { user: null } }));
      userId = data?.user?.id || '';
    }
    if (!userId) return json({ success: false, message: 'Please sign in before starting payment.' });

    const gameName = String(body.gameName || '').trim();
    const playerUid = String(body.playerUid || '').trim();
    const amount = Number(body.totalPriceNpr || 0);
    if (!gameName || !playerUid || !Number.isFinite(amount) || amount < 1) {
      return json({ success: false, message: 'Invalid order details or amount.' });
    }

    let playerName = String(body.playerName || '').trim();
    if (/free\s*fire|pubg|bgmi/i.test(gameName)) {
      const verified = await verifyPlayer(playerUid, gameName);
      if (!verified.ok) return json({ success: false, message: verified.message });
      playerName = verified.name || playerName;
    }

    // Public order IDs intentionally use the same short format everywhere:
    // ODR12345. Reuse the requested ID only when it belongs to this user;
    // otherwise generate another unused 5-digit ID to avoid cross-user collisions.
    const requested = String(body.orderId || '').trim();
    let orderId = /^ODR\d{5}$/.test(requested) ? requested : '';
    if (orderId) {
      const { data: existing } = await admin.from('orders').select('*').eq('orderId', orderId).maybeSingle();
      if (existing) {
        if (String(existing.userId || '') === userId) {
          return json({
            success: true, alreadyExists: true, order: existing,
            qrPayload: existing.qrPayload || null, qrImage: null,
            qrExpiresAt: existing.qrExpiresAt || null, hubPaymentId: existing.transactionRef || null,
            message: String(existing.paymentStatus).toUpperCase() === 'SUCCESS'
              ? 'This payment has already been completed.' : 'Reusing the existing payment session.',
          });
        }
        orderId = '';
      }
    }

    // Generate a unique short ID when the client did not provide a reusable one.
    // The database primary key remains the final uniqueness guard.
    for (let attempt = 0; !orderId && attempt < 25; attempt++) {
      const candidate = `ODR${Math.floor(10000 + Math.random() * 90000)}`;
      const { data: taken } = await admin.from('orders').select('orderId').eq('orderId', candidate).maybeSingle();
      if (!taken) orderId = candidate;
    }
    if (!orderId) return json({ success: false, message: 'Could not generate a unique order ID. Please try again.' }, 503);

    const { data: requiresRedeem } = await admin.rpc('package_requires_redeem', {
      p_product_id: String(body.gameId || ''), p_package_id: String(body.packageId || ''),
    });
    if (requiresRedeem === true) {
      const { data: stock } = await admin.rpc('get_redeem_stock', {
        p_product_id: String(body.gameId || ''), p_package_id: String(body.packageId || ''),
      });
      if (Number(stock || 0) < Number(body.quantity || 1)) return json({ success: false, message: 'Currently Out of Stock' });
    }

    const { data: order, error: orderError } = await admin.from('orders').insert({
      orderId, userId, gameId: body.gameId || 'wallet-load', gameName, playerUid, playerName,
      zoneId: body.zoneId || '', packageId: body.packageId || 'wallet-recharge',
      packageName: body.packageName || `UG Wallet Load NPR ${amount}`,
      diamonds: Number(body.diamonds || 0), quantity: Number(body.quantity || 1),
      totalPriceNpr: amount, walletDeductionNpr: 0, paymentMethod: 'Fonepay Hub',
      paymentStatus: 'Pending', topUpStatus: 'PENDING_PAYMENT', status: 'Payment Pending',
    }).select().single();
    if (orderError) return json({ success: false, message: `Could not create order: ${orderError.message}` });

    if (requiresRedeem === true) {
      const { error } = await admin.rpc('reserve_redeem_codes', {
        p_product_id: String(body.gameId || ''), p_package_id: String(body.packageId || ''),
        p_order_id: orderId, p_user_id: userId, p_quantity: Number(body.quantity || 1),
      });
      if (error) {
        await admin.from('orders').update({ paymentStatus: 'Failed', status: 'Payment Failed', rejectionReason: 'Voucher stock was exhausted.' }).eq('orderId', orderId);
        return json({ success: false, message: 'Currently Out of Stock' });
      }
    }

    const { response, result } = await hubRequest('POST', '/api/v1/payments', {
      merchant_reference: orderId,
      amount: Number(amount.toFixed(2)),
      currency: 'NPR',
      metadata: { local_order_id: orderId, user_id: userId },
    });
    const payment = hubData(result);
    if (!response.ok || result?.ok === false || !payment?.id || !payment?.qr_payload) {
      const message = hubError(result, 'Fonepay Hub could not generate a QR code.');
      await admin.from('orders').update({ paymentStatus: 'Failed', status: 'Payment Failed', rejectionReason: message }).eq('orderId', orderId);
      await admin.rpc('release_reserved_redeem_codes', { p_order_id: orderId });
      return json({ success: false, message, orderId });
    }

    // merchant_reference becomes Fonepay billId, so the payment remarks are the exact order ID.
    const qrExpiresAt = String(payment.expires_at || new Date(Date.now() + 5 * 60_000).toISOString());
    const { data: saved } = await admin.from('orders').update({
      transactionRef: String(payment.id), qrPayload: String(payment.qr_payload), qrExpiresAt,
    }).eq('orderId', orderId).select().single();

    return json({
      success: true, order: saved || { ...order, transactionRef: payment.id, qrPayload: payment.qr_payload, qrExpiresAt },
      hubPaymentId: String(payment.id), qrPayload: String(payment.qr_payload), qrImage: null,
      qrExpiresAt, checkoutUrl: payment.checkout_url || null,
    });
  } catch (error) {
    return json({ success: false, message: error instanceof Error ? error.message : 'Fonepay Hub payment initiation failed.' });
  }
});
