import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });

function getServiceKey() {
  return (
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ||
    Deno.env.get('SERVICE_ROLE_KEY') ||
    (() => {
      try {
        return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '';
      } catch {
        return '';
      }
    })()
  );
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
    const serviceKey = getServiceKey();

    if (!supabaseUrl || !anonKey) {
      console.error('[CHECKOUT] Missing SUPABASE_URL or SUPABASE_ANON_KEY');
      return json({ success: false, code: 'CONFIG_ERROR', message: 'Supabase configuration missing on server.' }, 500);
    }

    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    if (!token) {
      return json({ success: false, code: 'AUTH_REQUIRED', message: 'Authentication required. Please log in.' }, 401);
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const adminClient = serviceKey ? createClient(supabaseUrl, serviceKey) : userClient;

    // ── STEP 1: AUTHENTICATION ──
    const { data: authData, error: authError } = await userClient.auth.getUser(token);
    const authUser = authData?.user;
    if (authError || !authUser?.id) {
      console.warn('[CHECKOUT] Invalid auth token:', authError?.message);
      return json({ success: false, code: 'INVALID_TOKEN', message: 'Invalid or expired authentication session.' }, 401);
    }
    console.log('[CHECKOUT] STEP 1 AUTH OK - user_id:', authUser.id);

    const body = await req.json().catch(() => ({}));
    const gameId = String(body.gameId || body.productId || '').trim();
    const gameName = String(body.gameName || body.productName || '').trim();
    const packageId = String(body.packageId || '').trim();
    const packageName = String(body.packageName || '').trim();
    const playerUid = String(body.playerUid || body.uid || '').trim();
    const playerName = String(body.playerName || '').trim();
    const zoneId = String(body.zoneId || '').trim();
    const quantity = Math.max(1, Math.floor(Number(body.quantity || 1)));
    const diamonds = Number(body.diamonds || 0);
    const userEmailInput = String(body.userEmail || '').trim();
    const userWhatsapp = String(body.userWhatsapp || '').trim();
    const userPassword = String(body.userPassword || '').trim();
    const userField1 = String(body.userField1Val || '').trim();
    const userField2 = String(body.userField2Val || '').trim();
    const clientOrderId = String(body.orderId || '').trim();

    if (!gameId && !gameName) {
      return json({ success: false, code: 'INVALID_INPUT', message: 'Product or Game ID is required.' }, 400);
    }
    if (!packageId && !packageName) {
      return json({ success: false, code: 'INVALID_INPUT', message: 'Package ID or Package Name is required.' }, 400);
    }

    // ── STEP 2: PRODUCT LOOKUP ──
    let product: any = null;
    let pkg: any = null;

    if (gameId) {
      const { data: pData } = await adminClient
        .from('products')
        .select('*')
        .or(`id.eq.${gameId},gameId.eq.${gameId},code.eq.${gameId}`)
        .maybeSingle();
      product = pData;

      if (!product) {
        const { data: gData } = await adminClient
          .from('games')
          .select('*')
          .eq('id', gameId)
          .maybeSingle();
        product = gData;
      }
    }
    console.log('[CHECKOUT] STEP 2 PRODUCT OK - productId:', product?.id || gameId);

    // ── STEP 3: PACKAGE LOOKUP ──
    if (product && Array.isArray(product.packages)) {
      pkg = product.packages.find((p: any) => String(p?.id || '') === packageId || (packageName && String(p?.name || '') === packageName));
    }
    console.log('[CHECKOUT] STEP 3 PACKAGE OK - packageId:', pkg?.id || packageId);

    // ── STEP 4: VOUCHER DETECTION ──
    const isVoucher = Boolean(
      body.requiresRedeemCode === true ||
      body.isRedeemCode === true ||
      body.isVoucher === true ||
      body.deliveryType === 'VOUCHER' ||
      pkg?.requiresRedeemCode === true ||
      pkg?.isRedeemCode === true ||
      ['INSTANT_CODE', 'AUTO_REDEEM', 'VOUCHER'].includes(String(product?.deliveryType || '').toUpperCase()) ||
      /voucher|redeem|gift[\s_-]?card|digital_code|unipin/i.test(
        `${product?.category || ''} ${product?.name || ''} ${product?.title || ''} ${gameName} ${packageName} ${pkg?.name || ''}`
      )
    );
    console.log('[CHECKOUT] STEP 4 VOUCHER DETECTED:', isVoucher);

    if (!isVoucher && !body.uidVerified) {
      if (!playerUid) {
        return json(
          {
            success: false,
            code: 'ORDER_UID_NOT_VERIFIED',
            message: 'ORDER_UID_NOT_VERIFIED: This order cannot be completed until the player UID is successfully verified.',
          },
          400
        );
      }

      const isUidValid = (playerUid.length >= 3 && !/test/i.test(playerUid)) || Boolean(playerName && playerName !== 'Test User');
      if (!isUidValid) {
        return json(
          {
            success: false,
            code: 'ORDER_UID_NOT_VERIFIED',
            message: 'ORDER_UID_NOT_VERIFIED: This order cannot be completed until the player UID is successfully verified.',
          },
          400
        );
      }
    }

    const nowIso = new Date().toISOString();
    // Keep the existing order ID format. The frontend normally supplies the
    // stable ID; only older clients need the original ODR fallback.
    const effectiveOrderId = clientOrderId || `ODR${Date.now()}${Math.floor(1000 + Math.random() * 9000)}`;
    const effectiveGameName = gameName || product?.name || product?.title || 'Gaming Voucher';
    const effectivePackageName = packageName || pkg?.name || 'Voucher Package';
    const unitPrice = Number(pkg?.priceNpr ?? body.priceNpr ?? body.totalPriceNpr ?? 0);
    const totalPriceNpr = unitPrice > 0 ? unitPrice * quantity : Number(body.totalPriceNpr || 0);
    const txnRef = `TXN-WLT-${effectiveOrderId}`;

    // ── STEP 5: FETCH USER BALANCE & AVAILABLE CODES CONCURRENTLY ──
    const candidateProductIds = Array.from(new Set([gameId, product?.id, product?.gameId, product?.code].filter(Boolean)));
    const candidatePackageIds = Array.from(new Set([packageId, pkg?.id].filter(Boolean)));

    const [userRes, stockRes] = await Promise.all([
      adminClient.from('users').select('id, walletBalanceNpr, username, email').eq('id', authUser.id).single(),
      adminClient
        .from('redeem_codes')
        .select('id, product_id, package_id, status')
        .in('product_id', candidateProductIds)
        .in('package_id', candidatePackageIds)
        .eq('status', 'available')
        .order('created_at', { ascending: true })
        .limit(quantity),
    ]);

    const userRow = userRes.data;
    if (userRes.error || !userRow) {
      return json({ success: false, code: 'USER_NOT_FOUND', message: 'User wallet account not found.' }, 404);
    }

    const currentBalance = Number(userRow.walletBalanceNpr || 0);
    if (totalPriceNpr > 0 && currentBalance < totalPriceNpr) {
      return json({ success: false, code: 'INSUFFICIENT_WALLET_BALANCE', message: 'Insufficient wallet balance.' }, 409);
    }

    const availableCodes = stockRes.data;
    if (!availableCodes || availableCodes.length < quantity) {
      console.log('[CHECKOUT] STEP 5 FAILED: Insufficient available codes for product/package.', {
        available: availableCodes?.length || 0,
        requested: quantity,
        candidateProductIds,
        candidatePackageIds,
      });
      return json({
        success: false,
        code: 'NO_AVAILABLE_CODE',
        message: 'No redeem code is currently available for this package.',
      }, 409);
    }

    const assignedCodeIds = availableCodes.map((c: any) => c.id);
    const newBalance = Math.max(0, currentBalance - totalPriceNpr);

    // ── STEP 6: ATOMIC CODE ASSIGNMENT, WALLET DEDUCTION, ORDER & TXN INSERTION ──
    // 1) Atomically assign codes to delivered
    const { error: codeDeliverErr } = await adminClient
      .from('redeem_codes')
      .update({
        status: 'delivered',
        order_id: effectiveOrderId,
        user_id: authUser.id,
        assigned_at: nowIso,
        delivered_at: nowIso,
        reservation_expires_at: null,
      })
      .in('id', assignedCodeIds)
      .eq('status', 'available');

    if (codeDeliverErr) {
      console.error('[CHECKOUT] Code assignment error:', codeDeliverErr.message);
      return json({
        success: false,
        code: 'CODE_ASSIGNMENT_FAILED',
        message: 'Failed to assign voucher code. Please try again.',
      }, 500);
    }

    // 2) Deduct wallet balance
    const { error: balErr } = await adminClient
      .from('users')
      .update({ walletBalanceNpr: newBalance })
      .eq('id', authUser.id);

    if (balErr) {
      console.error('[CHECKOUT] Balance deduction error:', balErr.message);
      // Rollback code assignment
      await adminClient.from('redeem_codes').update({ status: 'available', order_id: null, user_id: null, assigned_at: null, delivered_at: null }).in('id', assignedCodeIds);
      return json({ success: false, code: 'WALLET_DEDUCTION_FAILED', message: 'Failed to deduct wallet balance.' }, 500);
    }

    // 3) Insert Order & Transaction in parallel
    const [orderInsertRes, txnInsertRes] = await Promise.all([
      adminClient.from('orders').insert({
        orderId: effectiveOrderId,
        id: effectiveOrderId,
        userId: authUser.id,
        gameId,
        gameName: effectiveGameName,
        playerUid: playerUid || 'VOUCHER_PURCHASE',
        playerName: playerName || 'Voucher Customer',
        zoneId: zoneId || '',
        packageId,
        packageName: effectivePackageName,
        diamonds,
        quantity,
        totalPriceNpr,
        walletDeductionNpr: totalPriceNpr,
        paymentMethod: 'UG Wallet',
        transactionRef: txnRef,
        paymentStatus: 'Paid',
        topUpStatus: 'COMPLETED',
        status: 'Completed',
        uidVerified: true,
        uidVerifiedAt: nowIso,
        createdAt: nowIso,
        created_at: nowIso,
        completedAt: nowIso,
        completedBy: 'AUTO_REDEEM_SYSTEM',
      }),
      adminClient.from('transactions').insert({
        id: `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        orderId: effectiveOrderId,
        uid: authUser.id,
        userId: authUser.id,
        username: userRow.username || 'User',
        packageName: effectivePackageName,
        gameName: effectiveGameName,
        amount: totalPriceNpr,
        type: 'DEDUCTION',
        paymentMethod: 'UG Wallet',
        status: 'SUCCESS',
        date: nowIso,
        createdAt: nowIso,
        created_at: nowIso,
        previousBalance: currentBalance,
        newBalance,
      }),
    ]);

    if (orderInsertRes.error) {
      console.error('[CHECKOUT] Order insertion error:', orderInsertRes.error.message);
      // Rollback balance & codes
      await adminClient.from('users').update({ walletBalanceNpr: currentBalance }).eq('id', authUser.id);
      await adminClient.from('redeem_codes').update({ status: 'available', order_id: null, user_id: null, assigned_at: null, delivered_at: null }).in('id', assignedCodeIds);
      return json({ success: false, code: 'ORDER_CREATION_FAILED', message: `Order creation failed: ${orderInsertRes.error.message}` }, 500);
    }

    // 3b) Reward UG Coins for the successful order (best-effort, never blocks checkout)
    try {
      await adminClient.rpc('increment_user_coins', { p_uid: authUser.id, p_amount: 3 });
    } catch (coinErr) {
      console.warn('[CHECKOUT] Failed to award UG Coins:', coinErr);
    }

    // ── STEP 9: EMAIL PROCESSING (fire-and-forget — does not block response) ──
    console.log('[CHECKOUT] STEP 9 EMAIL QUEUED (background)');
    if (serviceKey) {
      const emailFunctionUrl = `${supabaseUrl}/functions/v1/send-voucher-email`;
      const emailPromise = fetch(emailFunctionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${serviceKey}`,
        },
        body: JSON.stringify({ orderId: effectiveOrderId }),
      }).then((r) => {
        if (!r.ok) console.warn('[EMAIL] voucher email background delivery failed:', r.status);
        else console.log('[EMAIL] voucher email delivered in background for order:', effectiveOrderId);
      }).catch((err: any) => {
        console.warn('[EMAIL] voucher email background error:', err?.message);
      });
      // Use EdgeRuntime.waitUntil if available so Deno keeps the promise alive
      // after the response is sent; fall back silently if not supported.
      try {
        (EdgeRuntime as any).waitUntil(emailPromise);
      } catch {
        // EdgeRuntime.waitUntil not available in this environment — promise runs
        // as best-effort fire-and-forget (still completes in practice).
      }
    }

    // ── STEP 10: CHECKOUT COMPLETE ──
    console.log('[CHECKOUT] STEP 10 CHECKOUT COMPLETE - orderId:', effectiveOrderId);

    const baseOrder = {
      orderId: effectiveOrderId,
      userId: authUser.id,
      gameId,
      gameName: effectiveGameName,
      playerUid,
      playerName,
      zoneId: zoneId || '',
      packageId,
      packageName: effectivePackageName,
      diamonds,
      quantity,
      totalPriceNpr,
      walletDeductionNpr: totalPriceNpr,
      paymentMethod: 'UG Wallet',
      transactionRef: txnRef,
      paymentStatus: 'Paid',
      topUpStatus: 'COMPLETED',
      status: 'Completed',
      uidVerified: true,
      uidVerifiedAt: nowIso,
      createdAt: nowIso,
      completedAt: nowIso,
      completedBy: 'AUTO_REDEEM_SYSTEM',
      redeemDelivered: true,
      emailDelivered: true, // dispatched in background via fire-and-forget
    };

    return json({
      success: true,
      orderId: effectiveOrderId,
      message: 'Voucher purchased successfully',
      order: baseOrder,
      walletBalanceNpr: newBalance,
    });
  } catch (e: any) {
    console.error('[CHECKOUT] Unhandled server exception:', e?.message || e);
    return json(
      {
        success: false,
        code: 'CHECKOUT_INTERNAL_ERROR',
        message: 'Internal checkout error',
      },
      500
    );
  }
});


