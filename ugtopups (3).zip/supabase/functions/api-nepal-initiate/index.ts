import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(data: unknown, _status = 200) {
  // Always return HTTP 200 so Supabase JS client SDK parses `data` body cleanly
  // rather than throwing generic "Edge Function returned a non-2xx status code"
  return new Response(JSON.stringify(data), { status: 200, headers: { ...cors, 'Content-Type': 'application/json' } });
}

function getServiceKey() {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (legacy) return legacy;
  const map = Deno.env.get('SUPABASE_SECRET_KEYS');
  if (map) {
    try { return JSON.parse(map).default; } catch {}
  }
  return '';
}

async function verifyPlayer(uid: string, gameName: string) {
  const apiKey = (Deno.env.get('EZ2TOPUP_API_KEY') || Deno.env.get('FREEFIRE_API_KEY') || '').trim();
  const secretKey = (Deno.env.get('EZ2TOPUP_SECRET_KEY') || Deno.env.get('FREEFIRE_SECRET_KEY') || '').trim();
  if (!apiKey || !secretKey) return { ok: false, message: 'Player verification is not configured on the server.' };
  const params = new URLSearchParams({ api_key: apiKey, player_id: uid });
  const sorted = new URLSearchParams();
  [...params.entries()].sort(([a],[b]) => a.localeCompare(b)).forEach(([k,v]) => sorted.set(k,v));
  const data = new TextEncoder().encode(sorted.toString());
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secretKey), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = [...new Uint8Array(await crypto.subtle.sign('HMAC', key, data))].map(b => b.toString(16).padStart(2,'0')).join('');
  const endpoint = /pubg|bgmi/i.test(gameName) ? 'pubg.php' : 'freefire.php';
  const url = `https://ez2topup.com/api/v1/verify/${endpoint}?${sorted.toString()}&sign=${sig}`;
  try {
    const r = await fetch(url, { headers: { Accept: 'application/json', 'X-API-Key': apiKey, 'X-Signature': sig } });
    const body = await r.json().catch(() => null);
    const payload = body?.data && typeof body.data === 'object' ? body.data : body;
    const name = payload?.username || payload?.nickname || payload?.player_name || payload?.playerName || payload?.name || payload?.ign || payload?.character_name || body?.playerName;
    const explicitSuccess = body?.success === true || body?.status === true || body?.api_status === true || body?.verified === true || body?.valid === true || String(body?.status || '').toLowerCase() === 'success';
    if (name && (r.ok || explicitSuccess)) return { ok: true, name: String(name), region: payload?.region || payload?.server || '' };
    return { ok: false, message: body?.error || body?.message || body?.msg || payload?.error || payload?.message || `Invalid ${/pubg|bgmi/i.test(gameName) ? 'PUBG' : 'Free Fire'} UID.` };
  } catch (e) { return { ok: false, message: 'Player verification service is unavailable.' }; }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    let userId = '';
    const auth = req.headers.get('Authorization') || '';
    const jwt = auth.replace(/^Bearer\s+/i, '');
    const serviceKey = getServiceKey();
    if (!serviceKey) return json({ success:false, message:'Supabase server secret is not configured.' });
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, serviceKey);

    if (jwt) {
      const { data: userData } = await admin.auth.getUser(jwt).catch(() => ({ data: { user: null } }));
      if (userData?.user) {
        userId = userData.user.id;
      }
    }

    const p = await req.json().catch(() => ({}));
    if (!userId) {
      userId = String(p.userId || p.playerUid || 'GUEST_USER').trim();
    }

    const gameName = String(p.gameName || '').trim();
    const playerUid = String(p.playerUid || '').trim();
    const amount = Number(p.totalPriceNpr || 0);
    if (!gameName || !playerUid || !Number.isFinite(amount) || amount <= 0) return json({ success:false, message:'Invalid order details or amount.' });

    let verifiedPlayerName = String(p.playerName || '').trim();
    if (/free\s*fire|pubg|bgmi/i.test(gameName)) {
      const check = await verifyPlayer(playerUid, gameName);
      if (!check.ok) return json({ success:false, message: check.message });
      verifiedPlayerName = check.name;
    }

    // Keep the existing order ID format. Do not migrate or renumber existing IDs.
    // If the browser retries the same checkout, honor its stable order ID instead
    // of silently creating another order.
    const requestedOrderId = String(p.orderId || '').trim();
    const orderId = /^ODR\d{8,}$/.test(requestedOrderId)
      ? requestedOrderId
      : `ODR${Date.now()}${Math.floor(1000 + Math.random() * 9000)}`;

    // Idempotency guard: if this exact order ID already exists, never insert a
    // second row. This protects against network retries/double invocation.
    const { data: existingOrder } = await admin
      .from('orders')
      .select('*')
      .eq('orderId', orderId)
      .maybeSingle();
    if (existingOrder) {
      // Hand back the QR we stored on the first initiate so a retry or a page
      // refresh repaints the same code instead of losing the payment session.
      return json({
        success: true,
        alreadyExists: true,
        order: existingOrder,
        paymentUrl: null,
        qrPayload: existingOrder.qrPayload || null,
        qrImage: null,
        trxNumber: existingOrder.transactionRef || null,
        message: existingOrder.paymentStatus === 'SUCCESS'
          ? 'This payment has already been completed.'
          : 'This payment session already exists. Reusing the existing order.'
      });
    }
    const { data: requiresRedeem } = await admin.rpc('package_requires_redeem', { p_product_id: String(p.gameId || ''), p_package_id: String(p.packageId || '') });
    if (requiresRedeem === true) { const { data: stock } = await admin.rpc('get_redeem_stock', { p_product_id: String(p.gameId || ''), p_package_id: String(p.packageId || '') }); if (Number(stock || 0) < Number(p.quantity || 1)) return json({ success:false, message:'Currently Out of Stock' }); }
    const { data: order, error: orderError } = await admin.from('orders').insert({
      orderId,
      userId,
      gameId: p.gameId || 'wallet-load',
      gameName,
      playerUid,
      playerName: verifiedPlayerName,
      zoneId: p.zoneId || '',
      packageId: p.packageId || 'wallet-recharge',
      packageName: p.packageName || `UG Wallet Load NPR ${amount}`,
      diamonds: Number(p.diamonds || 0),
      quantity: Number(p.quantity || 1),
      totalPriceNpr: amount,
      walletDeductionNpr: 0,
      paymentMethod: 'API Nepal QR',
      paymentStatus: 'Pending',
      topUpStatus: 'PENDING_PAYMENT',
      status: 'Payment Pending',
    }).select().single();
    if (orderError) return json({ success:false, message:`Could not create order: ${orderError.message}` });

    if (requiresRedeem === true) {
      const { error: reserveError } = await admin.rpc('reserve_redeem_codes', { p_product_id:String(p.gameId||''), p_package_id:String(p.packageId||''), p_order_id:orderId, p_user_id:userId, p_quantity:Number(p.quantity||1) });
      if (reserveError) { await admin.from('orders').update({ paymentStatus:'Failed', status:'Payment Failed', rejectionReason:'Voucher stock was exhausted.' }).eq('orderId',orderId); return json({ success:false, message:'Currently Out of Stock' }); }
    }

    const publicKey = (Deno.env.get('API_NEPAL_PUBLIC_KEY') || '').trim();
    const secretKey = (Deno.env.get('API_NEPAL_SECRET_KEY') || '').trim();
    if (!publicKey || !secretKey) { await admin.rpc('release_reserved_redeem_codes', { p_order_id: orderId }); return json({ success:false, message:'API Nepal gateway keys are not configured on the server.', orderId }); }
    const siteUrl = (Deno.env.get('SITE_URL') || req.headers.get('origin') || req.headers.get('referer') || 'https://ugtopup.com').replace(/\/$/, '');
    const ipnUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/api-nepal-ipn`;
    const successUrl = `${siteUrl}/?orderId=${encodeURIComponent(orderId)}&payment=success`;
    const cancelUrl = `${siteUrl}/?orderId=${encodeURIComponent(orderId)}&payment=cancel`;

    const amountStr = amount % 1 === 0 ? String(Math.round(amount)) : amount.toFixed(2);
    const form = new URLSearchParams({
      public_key: publicKey,
      secret_key: secretKey,
      identifier: orderId,
      currency: 'NPR',
      amount: amountStr,
      // Remark shown on the payer's bank/Fonepay statement. Defaults to the bare
      // order ID so a payment can always be matched back to an order.
      details: (Deno.env.get('API_NEPAL_REMARK_TEMPLATE') || '{orderId}')
        .replace('{orderId}', orderId)
        .replace('{gameName}', gameName)
        .replace('{amount}', amountStr)
        .slice(0, 50),
      ipn_url: ipnUrl,
      success_url: successUrl,
      cancel_url: cancelUrl,
      site_name: 'UG Top Up Center',
      checkout_theme: 'light',
    });
    const gateway = await fetch('https://apinepal.com/payment/initiate', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:form });
    const result = await gateway.json().catch(() => null);
    if (!gateway.ok || result?.status !== 'success') {
      console.error('[API Nepal Gateway Error]', gateway.status, result);
      await admin.from('orders').update({ paymentStatus:'Failed', status:'Payment Failed', rejectionReason: result?.message || 'API Nepal initiation failed' }).eq('orderId', orderId);
      await admin.rpc('release_reserved_redeem_codes', { p_order_id: orderId });
      const errDetail = Array.isArray(result?.message) ? result.message.join(', ') : (result?.message || result?.error || 'API Nepal payment initiation failed.');
      return json({ success:false, message: errDetail }, 200);
    }

    const qrPayload = result?.qr?.qr_string || null;
    const expiryMinutes = Math.min(60, Math.max(1, Number(Deno.env.get('QR_EXPIRY_MINUTES') || 5)));
    const qrExpiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000).toISOString();

    // qrPayload is stored so /billing can rebuild the QR after a refresh.
    // Only the short EMV string is kept — never the base64 image.
    await admin.from('orders').update({
      transactionRef: result.trx_number || null,
      qrPayload,
      qrExpiresAt,
    }).eq('orderId', orderId);

    const qrImage = result?.qr?.qr_image_base64 ? (String(result.qr.qr_image_base64).startsWith('data:') ? result.qr.qr_image_base64 : `data:image/png;base64,${result.qr.qr_image_base64}`) : null;
    return json({
      success: true,
      order: { ...order, transactionRef: result.trx_number || null, playerName: verifiedPlayerName, qrPayload, qrExpiresAt },
      trxNumber: result.trx_number || null,
      qrPayload,
      qrImage,
      qrExpiresAt,
      // Kept for reference only — the storefront no longer redirects here.
      paymentUrl: result?.redirect_url || result?.payment_url || result?.url || null,
    });
  } catch (e) {
    return json({ success:false, message:e instanceof Error ? e.message : 'Payment initiation failed.' }, 500);
  }
});