// supabase/functions/process-ml-order/index.ts
// Supabase Edge Function — Mobile Legends (Liana Store) automated diamond delivery.
// Deploy: supabase functions deploy process-ml-order
// Secrets required: LIANA_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
// (LIANA_API_SECRET is no longer used — the Liana Official API at
// api.lianaofficial.in authenticates with a single X-API-Key, not a
// key+secret pair. You can remove the old secret once this is redeployed.)
//
// Modes (all via POST body):
//   { action: 'verify-ign', user_id, zone_id, product_id? }           -> verify player, return IGN
//   { action: 'check-balance' }                                       -> merchant wallet balance
//   { order_id }                                                      -> full pipeline: verify -> place order -> deliver -> track

import { createClient } from 'npm:@supabase/supabase-js@2';
import { verifyMlbbIgn, checkMlbbBalance, LIANA_BASE, lianaHeaders, lianaFetchWithRetry } from '../_shared/liana.ts';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(data: unknown) {
  // Always return HTTP 200 so supabase.functions.invoke() parses `data` cleanly
  // instead of throwing a generic "non-2xx status code" error client-side.
  return new Response(JSON.stringify(data), { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } });
}

function getServiceKey(): string {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (legacy) return legacy;
  const map = Deno.env.get('SUPABASE_SECRET_KEYS');
  if (map) {
    try { return JSON.parse(map).default; } catch { /* ignore */ }
  }
  return '';
}

// Liana `/order` uses PRODUCT IDs. Do not keep a hard-coded variation/product
// table here: product IDs are account-specific and can change. If the admin
// has not configured product_id on a package, resolve it from Liana's live
// `/products` endpoint by matching the package name.

function normalisePackageName(name: string): string {
  return String(name || '')
    .replace(/\s*\(x\d+\)\s*$/i, '')
    .trim()
    .toLowerCase();
}

function productArray(raw: any): any[] {
  if (Array.isArray(raw)) return raw;
  if (Array.isArray(raw?.products)) return raw.products;
  if (Array.isArray(raw?.data)) return raw.data;
  if (Array.isArray(raw?.data?.products)) return raw.data.products;
  if (Array.isArray(raw?.results)) return raw.results;
  return [];
}

function productName(p: any): string {
  return String(p?.name ?? p?.product_name ?? p?.title ?? p?.product?.name ?? '').trim();
}

function productIdFrom(p: any): number | undefined {
  const raw = p?.product_id ?? p?.productId ?? p?.id ?? p?.product?.id;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

async function resolveLianaProductId(apiKey: string, packageName: string, gameId: string, preferredProductId?: number): Promise<{ productId?: number; error?: string }> {
  const target = normalisePackageName(packageName);
  if (!target) return { error: 'MLBB package name is missing; cannot resolve Liana product_id.' };

  // Prefer the configured game's slug, then the common MLBB slugs documented by Liana.
  const slugs = Array.from(new Set([
    String(gameId || '').trim(),
    'mobile_legends_pro',
    'mobile_legends',
    'mlbb',
  ].filter(Boolean)));

  for (const slug of slugs) {
    try {
      const url = `${LIANA_BASE}/products?game=${encodeURIComponent(slug)}`;
      const res = await lianaFetchWithRetry(url, { method: 'GET', headers: lianaHeaders(apiKey) });
      const text = await res.text().catch(() => '');
      let raw: any = null;
      try { raw = text ? JSON.parse(text) : null; } catch { raw = null; }
      if (!res.ok || !raw) continue;

      const products = productArray(raw);
      // If an admin configured a product_id, accept it only when that ID
      // exists in Liana's live product catalog for this account. This also
      // repairs old packages that accidentally stored a stale variation ID.
      if (preferredProductId) {
        const configured = products.find((p) => productIdFrom(p) === preferredProductId);
        if (configured) return { productId: preferredProductId };
      }

      const exact = products.filter((p) => normalisePackageName(productName(p)) === target);
      if (exact.length === 1) {
        const id = productIdFrom(exact[0]);
        if (id) return { productId: id };
      }

      // A tolerant match is allowed only when it produces exactly one candidate.
      const partial = products.filter((p) => {
        const n = normalisePackageName(productName(p));
        return n && (n.includes(target) || target.includes(n));
      });
      if (partial.length === 1) {
        const id = productIdFrom(partial[0]);
        if (id) return { productId: id };
      }
    } catch (e) {
      console.warn(`[process-ml-order] /products lookup failed for game=${slug}:`, e);
    }
  }

  return { error: `Liana product_id could not be resolved for package "${packageName}". Set the exact product_id from Liana /products in the Admin Panel.` };
}

// verifyIgn() and checkBalance() used to be re-implemented here with their own
// (narrower, stricter) response parsing than check-uid's — that drift is what
// let the two functions silently fall out of sync with Liana's real response
// shape. Both now use the shared, single-source-of-truth parser in
// ../_shared/liana.ts instead.
//
// placeLianaOrder — confirmed contract:
//   POST /order  { product_id, customer_id, zone_id }
//   (No qty, no reference_id — those were WooCommerce-era fields.)
//   product_id must come from the real /products endpoint for this account;
//   the MLBB_BRAZIL_VARIATIONS table below may have stale IDs — rebuild from
//   a live GET /products?game=<slug> call if orders start returning
//   "product not found" errors.
//
// Note: /order also requires Pro/Elite plan on some configurations.
async function placeLianaOrder(apiKey: string, productId: number, uid: string, zoneId: string, _referenceId: string) {
  // _referenceId accepted for call-site compatibility but not sent — not part of the confirmed API contract.
  try {
    const res = await lianaFetchWithRetry(`${LIANA_BASE}/order`, {
      method: 'POST',
      headers: lianaHeaders(apiKey),
      body: JSON.stringify({ product_id: productId, customer_id: String(uid).trim(), zone_id: String(zoneId).trim() }),
    });

    const rawText = await res.text().catch(() => '');
    let raw: any = null;
    try { raw = rawText ? JSON.parse(rawText) : null; } catch { /* fall through */ }

    if (!raw) return { ok: false, error: 'Invalid response from order server.' };

    // Plan restriction check (402 or message-based)
    if (res.status === 402) {
      return { ok: false, code: 'plan_error', error: 'Placing orders requires a Pro or Elite plan on the Liana account. Please upgrade the merchant plan.', raw };
    }
    if (res.status === 401 || res.status === 403) {
      return { ok: false, code: 'auth_error', error: 'Liana rejected the merchant credentials. Check LIANA_API_KEY.', raw };
    }
    const msg = String(raw.message || raw.error || '').toLowerCase();
    if (!truthy(raw.status) && (msg.includes('plan') || msg.includes('upgrade') || msg.includes('subscription') || msg.includes('elite') || msg.includes('pro '))) {
      return { ok: false, code: 'plan_error', error: 'Placing orders requires a Pro or Elite plan on the Liana account. Please upgrade the merchant plan.', raw };
    }

    // Success: status === true (boolean) or status === 'success' (string)
    const isSuccess = raw.status === true || raw.status === 'success' || raw.status === 1;
    if (isSuccess) {
      const d = raw.data || raw;
      const orderId = d.order_id ?? raw.order_id;
      const transactionId = d.transaction_id ?? raw.transaction_id;
      const balanceAfterNum = Number(d.balance_after ?? raw.balance_after);
      return {
        ok: true,
        orderId,
        transactionId,
        balanceAfter: Number.isFinite(balanceAfterNum) ? balanceAfterNum : undefined,
        raw,
      };
    }

    return {
      ok: false,
      code: raw.code,
      error: raw.error || raw.message || 'Order placement failed.',
      raw,
    };
  } catch (e: any) {
    return { ok: false, code: 'connection_error', error: e?.message || 'Order service is temporarily unavailable.' };
  }
}

// Local truthy helper (mirrors _shared/liana.ts) so placeLianaOrder can use it
// without an extra import.
function truthy(value: unknown): boolean {
  if (value === true) return true;
  if (typeof value === 'string') return ['true', '1', 'yes', 'verified', 'success'].includes(value.trim().toLowerCase());
  if (typeof value === 'number') return value === 1;
  return false;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });

  try {
    const serviceKey = getServiceKey();
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    if (!serviceKey || !supabaseUrl) return json({ success: false, error: 'Supabase server secret is not configured.' });

    const apiKey = (Deno.env.get('LIANA_API_KEY') || '').trim();
    if (!apiKey) return json({ success: false, error: 'Liana API credentials are not configured on the server.', credentials_expired: true });

    const admin = createClient(supabaseUrl, serviceKey);
    const body = await req.json().catch(() => ({}));

    // ── Mode: check-balance ────────────────────────────────────────────
    if (body?.action === 'check-balance') {
      const bal = await checkMlbbBalance(apiKey);
      if (!bal.ok || bal.balance === null) {
        return json({ success: false, error: bal.error, blocked: bal.blocked, credentials_expired: bal.credentialsExpired });
      }
      // Clean numeric contract for the frontend; `raw` kept for admin debugging only.
      return json({ success: true, balance: bal.balance, raw: bal.raw, timestamp: new Date().toISOString() });
    }

    // ── Mode: verify-ign ────────────────────────────────────────────────
    if (body?.action === 'verify-ign') {
      const userId = String(body.user_id || body.uid || '').trim();
      const zoneId = String(body.zone_id || '').trim();
      if (!userId || !zoneId) return json({ success: false, error: 'Player ID and Zone ID are required.' });

      const productId = Number(body.product_id ?? body.productId ?? body.variation_id ?? body.variationId);
      const result = await verifyMlbbIgn(apiKey, Number.isFinite(productId) ? productId : 0, userId, zoneId);
      if (!result.verified || !result.display) return json({ success: false, verified: false, error: result.error, stage: 'verification' });
      return json({ success: true, verified: true, ign: result.display, product_id: Number.isFinite(productId) && productId > 0 ? productId : undefined, playerName: result.display, display: result.display });
    }

    // ── Mode: full order pipeline ──────────────────────────────────────
    const orderId = String(body.order_id || '').trim();
    if (!orderId) return json({ success: false, error: 'order_id is required.' });

    const { data: order, error: orderFetchErr } = await admin.from('orders').select('*').eq('orderId', orderId).single();
    if (orderFetchErr || !order) return json({ success: false, error: 'Order not found.' });

    // Idempotency guard — don't re-deliver an already-completed order.
    if (order.topUpStatus === 'COMPLETED' || order.status === 'Completed') {
      return json({ success: true, message: 'Order was already completed.', ign: order.playerName, alreadyCompleted: true });
    }

    // Find (or create) the tracking row for this order.
    const { data: existingRow } = await admin.from('liana_orders').select('*').eq('order_id', orderId).maybeSingle();
    let trackingId: string;
    if (existingRow) {
      trackingId = existingRow.id;
      await admin.from('liana_orders').update({
        status: 'processing',
        error_message: null,
        retry_count: (existingRow.retry_count || 0) + (body.is_retry ? 1 : 0),
      }).eq('id', trackingId);
    } else {
      const { data: inserted, error: insertErr } = await admin.from('liana_orders').insert({
        order_id: orderId,
        user_id: order.playerUid || '',
        zone_id: order.zoneId || '',
        status: 'processing',
      }).select().single();
      if (insertErr || !inserted) return json({ success: false, error: 'Could not create order tracking record.' });
      trackingId = inserted.id;
    }

    // ── Safeguards: daily spending cap + per-minute rate limit ─────────
    const { data: settingsRows } = await admin.from('system_settings').select('setting_key, setting_value')
      .in('setting_key', ['liana_daily_spending_cap', 'liana_rate_limit_per_minute', 'liana_low_balance_threshold']);
    const settings: Record<string, number> = {};
    (settingsRows || []).forEach((r: any) => { settings[r.setting_key] = Number(r.setting_value) || 0; });

    const dailyCap = settings.liana_daily_spending_cap || 5000;
    const rateLimit = settings.liana_rate_limit_per_minute || 10;
    const lowBalanceThreshold = settings.liana_low_balance_threshold || 2000;

    const oneMinuteAgo = new Date(Date.now() - 60_000).toISOString();
    const { count: recentCount } = await admin.from('liana_orders').select('id', { count: 'exact', head: true })
      .gte('created_at', oneMinuteAgo).in('status', ['processing', 'completed']);
    if ((recentCount || 0) > rateLimit) {
      await admin.from('liana_orders').update({ status: 'failed', error_message: 'Rate limit exceeded.' }).eq('id', trackingId);
      await admin.from('wallet_activity_logs').insert({ order_id: trackingId, order_number: orderId, action: 'order_failed', api_status: 'error', error_message: 'Rate limit exceeded.' });
      return json({ success: false, error: 'Too many orders right now, please try again in a minute.', rate_limited: true });
    }

    const todayStart = new Date(); todayStart.setUTCHours(0, 0, 0, 0);
    const { data: todaysSpend } = await admin.from('wallet_activity_logs').select('coins_used')
      .eq('api_status', 'success').gte('created_at', todayStart.toISOString());
    const spentToday = (todaysSpend || []).reduce((sum: number, r: any) => sum + (Number(r.coins_used) || 0), 0);
    if (spentToday >= dailyCap) {
      await admin.from('liana_orders').update({ status: 'failed', error_message: 'Daily spending cap reached.' }).eq('id', trackingId);
      await admin.from('wallet_activity_logs').insert({ order_id: trackingId, order_number: orderId, action: 'order_failed', api_status: 'error', error_message: 'Daily spending cap reached.' });
      return json({ success: false, error: 'Daily automated delivery limit reached. Our team will process this order manually shortly.', spending_cap_reached: true });
    }

    // ── Resolve Liana PRODUCT ID — priority order: configured order field, package field, live /products lookup.
    // Never use the old hard-coded variation IDs: Liana /order expects product_id.
    let productId = Number(order.productId || order.product_id || 0);
    if (!productId) {
      const { data: gameRow } = await admin.from('products').select('packages').eq('id', String(order.gameId || '')).maybeSingle();
      const packages = Array.isArray(gameRow?.packages) ? gameRow.packages : [];
      const pkg = packages.find((p: any) => String(p?.id || '') === String(order.packageId || ''));
      productId = Number(pkg?.product_id || pkg?.productId || pkg?.variation_id || pkg?.variationId || 0);
      if (productId) console.log(`[process-ml-order] product_id from product package: ${productId}`);
    }
    // Validate the configured ID against Liana's live catalog. If it is an old
    // variation/stale ID, resolve the correct account-specific product_id by name.
    const resolved = await resolveLianaProductId(
      apiKey,
      String(order.packageName || ''),
      String(order.gameId || ''),
      productId || undefined,
    );
    if (resolved.productId) {
      if (productId && productId !== resolved.productId) {
        console.warn(`[process-ml-order] Replaced stale configured product_id ${productId} with live product_id ${resolved.productId}`);
      }
      productId = resolved.productId;
    } else if (!productId) {
      const msg = resolved.error || 'Liana product_id is missing.';
      await admin.from('liana_orders').update({ status: 'failed', error_message: msg }).eq('id', trackingId);
      await admin.from('orders').update({ topUpStatus: 'PENDING', deliveryStatus: 'pending' }).eq('orderId', orderId);
      return json({ success: false, error: msg, stage: 'product_resolution' });
    }

    console.log(`[process-ml-order] Final Liana product_id: ${productId} for order: ${orderId}`);
    await admin.from('liana_orders').update({ liana_product_id: productId }).eq('id', trackingId);

    // ── Step 1: Verify IGN ───────────────────────────────────────────────
    const verify = await verifyMlbbIgn(apiKey, productId, order.playerUid, order.zoneId);
    await admin.from('liana_orders').update({ verification_response: verify.raw || null, ign: verify.display || null }).eq('id', trackingId);

    if (!verify.verified || !verify.display) {
      await admin.from('liana_orders').update({ status: 'failed', error_message: verify.error }).eq('id', trackingId);
      await admin.from('wallet_activity_logs').insert({ order_id: trackingId, order_number: orderId, action: 'verify_attempt', api_status: 'verification_failed', error_message: verify.error, api_response: verify.raw || null });
      await admin.from('orders').update({ rejectionReason: verify.error }).eq('orderId', orderId);
      return json({ success: false, error: verify.error, stage: 'verification' });
    }

    // ── Step 2: Check merchant wallet balance (advisory) ────────────────
    const bal = await checkMlbbBalance(apiKey);
    const balanceBefore = bal.ok ? bal.balance ?? undefined : undefined;
    if (bal.ok && typeof balanceBefore === 'number' && balanceBefore < lowBalanceThreshold) {
      console.warn(`[process-ml-order] Liana merchant wallet balance is low: ${balanceBefore}`);
    }

    // ── Step 3: Place the order ──────────────────────────────────────────
    const placed = await placeLianaOrder(apiKey, productId, order.playerUid, order.zoneId, orderId);
    await admin.from('liana_orders').update({ order_response: placed.raw || null }).eq('id', trackingId);

    if (!placed.ok) {
      const isInsufficient = placed.code === 'insufficient_funds';
      const isExpired = placed.raw?.data?.status === 403 || placed.code === 'expired' || placed.code === 'auth_error';
      const isPlanError = placed.code === 'plan_error';
      await admin.from('liana_orders').update({ status: 'failed', error_message: placed.error }).eq('id', trackingId);
      await admin.from('wallet_activity_logs').insert({
        order_id: trackingId, order_number: orderId, action: 'order_failed',
        api_status: isInsufficient ? 'insufficient_funds' : isPlanError ? 'plan_error' : (placed.code === 'connection_error' ? 'connection_error' : 'api_error'),
        error_message: placed.error, balance_before: balanceBefore ?? null, api_response: placed.raw || null,
      });
      await admin.from('orders').update({ rejectionReason: placed.error }).eq('orderId', orderId);
      return json({
        success: false,
        error: placed.error,
        stage: 'order',
        insufficient_funds: isInsufficient,
        credentials_expired: isExpired,
        // plan_error: true means the Liana account isn't on Pro/Elite plan —
        // distinct from auth errors or invalid Game/Zone IDs.
        plan_error: isPlanError,
      });
    }

    // ── Step 4: Success — update tracking + deliver ─────────────────────
    const coinsUsed = typeof balanceBefore === 'number' && typeof placed.balanceAfter === 'number'
      ? Math.max(0, balanceBefore - placed.balanceAfter)
      : undefined;

    await admin.from('liana_orders').update({
      status: 'completed',
      api_transaction_id: placed.transactionId || placed.orderId || null,
    }).eq('id', trackingId);

    await admin.from('wallet_activity_logs').insert({
      order_id: trackingId, order_number: orderId, action: 'order_completed', api_status: 'success',
      coins_used: coinsUsed ?? null, balance_before: balanceBefore ?? null, balance_after: placed.balanceAfter ?? null,
      api_response: placed.raw || null,
    });

    const nowIso = new Date().toISOString();
    await admin.from('orders').update({
      topUpStatus: 'COMPLETED',
      status: 'Completed',
      playerName: verify.display,
      uidVerified: true,
      uidVerifiedAt: nowIso,
      completedAt: nowIso,
      completedBy: 'LIANA_AUTO_DELIVERY',
    }).eq('orderId', orderId);

    return json({
      success: true,
      message: 'Diamonds delivered successfully!',
      ign: verify.display,
      transaction_id: placed.transactionId || placed.orderId,
      wallet_balance_after: placed.balanceAfter,
      coins_used: coinsUsed,
    });
  } catch (e: any) {
    console.error('[process-ml-order] Unhandled error:', e);
    return json({ success: false, error: e?.message || 'Mobile Legends order processing failed.' });
  }
});
