import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });

function getServiceKey() {
  return (
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ||
    Deno.env.get('SERVICE_ROLE_KEY') ||
    (() => {
      try {
        return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '';
      } catch {
        return '';
      }
    })()
  );
}

function escapeHtml(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return '';
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function formatNpr(amount: number | string | null | undefined): string {
  const num = Number(amount || 0);
  return 'NPR ' + num.toLocaleString('en-IN');
}

function formatDisplayDate(dateInput?: string | null): string {
  try {
    const d = dateInput ? new Date(dateInput) : new Date();
    if (isNaN(d.getTime())) return String(dateInput || new Date().toUTCString());
    return (
      d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }) +
      ', ' +
      d.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      })
    );
  } catch {
    return new Date().toISOString();
  }
}

// ────────────────────────────────────────────────────────────────────────────
// EMAIL TEMPLATES (Modern, responsive, gaming marketplace branding)
// ────────────────────────────────────────────────────────────────────────────

function baseEmailLayout(contentHtml: string, previewText: string): string {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="color-scheme" content="light">
  <title>${escapeHtml(previewText)}</title>
</head>
<body style="margin:0;padding:0;background-color:#0b0d14;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#18181b;-webkit-font-smoothing:antialiased;">
  
  <!-- Outer Wrapper -->
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#0b0d14;min-width:100%;margin:0;padding:32px 12px 48px;">
    <tr>
      <td align="center">
        
        <!-- Main Card Container -->
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:580px;background-color:#ffffff;border-radius:20px;overflow:hidden;border:1px solid #27272a;box-shadow:0 20px 40px rgba(0,0,0,0.5);">
          
          <!-- Header Banner -->
          <tr>
            <td style="background-color:#09090b;padding:26px 32px;border-bottom:1px solid #27272a;">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td align="left">
                    <div style="font-size:24px;line-height:1;font-weight:900;letter-spacing:-0.03em;color:#ffffff;">
                      <span style="color:#ef4444;">UG</span>TOPUPS
                    </div>
                    <div style="font-size:11px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:#71717a;margin-top:6px;">
                      Instant Gaming Top-Up &amp; Digital Store
                    </div>
                  </td>
                  <td align="right">
                    <span style="display:inline-block;padding:5px 11px;border-radius:20px;background-color:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);color:#ef4444;font-size:10px;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;">
                      Nepal
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Main Content Slot -->
          <tr>
            <td style="padding:32px 32px 28px;">
              ${contentHtml}
            </td>
          </tr>

          <!-- Support & Info Box -->
          <tr>
            <td style="padding:0 32px 28px;">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f4f4f5;border-radius:14px;border:1px solid #e4e4e7;">
                <tr>
                  <td style="padding:16px 20px;">
                    <div style="font-size:12px;font-weight:700;color:#18181b;margin-bottom:4px;">Need assistance? We're here 24/7</div>
                    <div style="font-size:11px;line-height:1.6;color:#71717a;">
                      WhatsApp: <a href="https://wa.me/9779708562001" style="color:#ef4444;text-decoration:none;font-weight:700;">+977 9708562001</a> &bull;
                      Email: <a href="mailto:support@ugtopups.com" style="color:#ef4444;text-decoration:none;font-weight:700;">support@ugtopups.com</a>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color:#f9fafb;padding:24px 32px;border-top:1px solid #f4f4f5;text-align:center;">
              <div style="font-size:12px;color:#71717a;line-height:1.6;">
                &copy; ${new Date().getFullYear()} <strong style="color:#18181b;">UGTOPUPS</strong>. All rights reserved.<br>
                Official fast &amp; secure gaming marketplace in Nepal.
              </div>
              <div style="font-size:10px;color:#a1a1aa;margin-top:10px;line-height:1.4;">
                This is an automated transactional receipt. Please do not reply directly to this email.
              </div>
            </td>
          </tr>

        </table>

      </td>
    </tr>
  </table>

</body>
</html>`;
}

// 1. Wallet Recharge Template
function buildWalletRechargeEmail(params: {
  customerName: string;
  amountNpr: number;
  paymentMethod: string;
  transactionId: string;
  previousBalanceNpr: number;
  newBalanceNpr: number;
  dateTime: string;
}): { subject: string; html: string } {
  const name = escapeHtml(params.customerName || 'Gamer');
  const amountStr = escapeHtml(formatNpr(params.amountNpr));
  const prevStr = escapeHtml(formatNpr(params.previousBalanceNpr));
  const newStr = escapeHtml(formatNpr(params.newBalanceNpr));
  const method = escapeHtml(params.paymentMethod || 'eSewa / Khalti / Mobile Banking');
  const txnId = escapeHtml(params.transactionId || 'N/A');
  const dateStr = escapeHtml(formatDisplayDate(params.dateTime));

  const content = `
    <!-- Success Badge & Title -->
    <div style="text-align:center;margin-bottom:28px;">
      <div style="display:inline-block;width:56px;height:56px;line-height:56px;border-radius:28px;background-color:#dcfce7;color:#16a34a;font-size:28px;text-align:center;margin-bottom:14px;box-shadow:0 4px 12px rgba(22,163,74,0.15);">
        &#10003;
      </div>
      <h1 style="margin:0 0 8px;font-size:22px;font-weight:900;color:#09090b;letter-spacing:-0.02em;">
        Wallet Recharge Successful
      </h1>
      <p style="margin:0;font-size:13px;color:#71717a;line-height:1.5;">
        Hi <strong style="color:#18181b;">${name}</strong>, your UG Wallet has been successfully credited with <strong style="color:#16a34a;">${amountStr}</strong>.
      </p>
    </div>

    <!-- Balance Summary Card -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#09090b;border-radius:14px;margin-bottom:24px;overflow:hidden;">
      <tr>
        <td style="padding:22px 24px;text-align:center;">
          <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#a1a1aa;margin-bottom:6px;">
            NEW WALLET BALANCE
          </div>
          <div style="font-size:32px;font-weight:900;color:#22c55e;letter-spacing:-0.02em;">
            ${newStr}
          </div>
          <div style="font-size:11px;color:#71717a;margin-top:6px;">
            Previous Balance: <span style="color:#d4d4d8;">${prevStr}</span> &bull; Credited: <span style="color:#4ade80;">+${amountStr}</span>
          </div>
        </td>
      </tr>
    </table>

    <!-- Transaction Details List -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#fafafa;border:1px solid #e4e4e7;border-radius:14px;margin-bottom:28px;">
      <tr>
        <td style="padding:18px 20px;">
          
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Recharge Amount:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:800;text-align:right;">${amountStr}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Payment Method:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:700;text-align:right;">${method}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Transaction ID:</td>
              <td style="padding:6px 0;font-size:11px;color:#3f3f46;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-weight:700;text-align:right;">${txnId}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Date &amp; Time:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:600;text-align:right;">${dateStr}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Status:</td>
              <td style="padding:6px 0;font-size:11px;font-weight:800;color:#16a34a;text-align:right;text-transform:uppercase;">
                &#9679; Completed
              </td>
            </tr>
          </table>

        </td>
      </tr>
    </table>

    <!-- Call to action button -->
    <div style="text-align:center;margin-bottom:8px;">
      <a href="https://ugtopups.com/account/wallet" style="display:inline-block;background-color:#ef4444;color:#ffffff;font-size:13px;font-weight:800;letter-spacing:0.04em;text-transform:uppercase;text-decoration:none;padding:14px 32px;border-radius:12px;box-shadow:0 4px 14px rgba(239,68,68,0.35);">
        VIEW UG WALLET
      </a>
    </div>
  `;

  return {
    subject: `Wallet Recharge Successful — UGTOPUPS`,
    html: baseEmailLayout(content, 'Wallet Recharge Successful — UGTOPUPS'),
  };
}

// 2. Order Completed Template (Normal Gaming Products)
function buildOrderCompletedEmail(params: {
  customerName: string;
  orderId: string;
  gameName: string;
  packageName: string;
  amountNpr: number;
  paymentMethod: string;
  orderDate: string;
  completedDate: string;
  playerUid?: string;
  playerName?: string;
}): { subject: string; html: string } {
  const name = escapeHtml(params.customerName || 'Gamer');
  const orderId = escapeHtml(params.orderId);
  const game = escapeHtml(params.gameName || 'Gaming Package');
  const pkg = escapeHtml(params.packageName || 'Top-Up Item');
  const amountStr = escapeHtml(formatNpr(params.amountNpr));
  const method = escapeHtml(params.paymentMethod || 'UG Wallet');
  const orderDateStr = escapeHtml(formatDisplayDate(params.orderDate));
  const compDateStr = escapeHtml(formatDisplayDate(params.completedDate));
  const playerUid = escapeHtml(params.playerUid || '');

  const content = `
    <!-- Success Banner -->
    <div style="text-align:center;margin-bottom:28px;">
      <div style="display:inline-block;width:56px;height:56px;line-height:56px;border-radius:28px;background-color:#dcfce7;color:#16a34a;font-size:28px;text-align:center;margin-bottom:14px;box-shadow:0 4px 12px rgba(22,163,74,0.15);">
        &#10003;
      </div>
      <h1 style="margin:0 0 8px;font-size:22px;font-weight:900;color:#09090b;letter-spacing:-0.02em;">
        Order Completed Successfully
      </h1>
      <p style="margin:0;font-size:13px;color:#71717a;line-height:1.5;">
        Hi <strong style="color:#18181b;">${name}</strong>, your order <strong style="color:#ef4444;">#${orderId}</strong> has been fulfilled and delivered to your gaming account.
      </p>
    </div>

    <!-- Order Item Card -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#09090b;border-radius:14px;margin-bottom:24px;overflow:hidden;">
      <tr>
        <td style="padding:22px 24px;">
          <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#ef4444;margin-bottom:6px;">
            ${game}
          </div>
          <div style="font-size:22px;font-weight:900;color:#ffffff;margin-bottom:8px;letter-spacing:-0.01em;">
            ${pkg}
          </div>
          <div style="font-size:12px;color:#a1a1aa;">
            Amount Paid: <strong style="color:#22c55e;">${amountStr}</strong> &bull; Paid via <strong style="color:#ffffff;">${method}</strong>
          </div>
          ${playerUid ? `<div style="font-size:11px;color:#71717a;margin-top:6px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;">Player UID: ${playerUid}</div>` : ''}
        </td>
      </tr>
    </table>

    <!-- Order Meta Details -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#fafafa;border:1px solid #e4e4e7;border-radius:14px;margin-bottom:28px;">
      <tr>
        <td style="padding:18px 20px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Order ID:</td>
              <td style="padding:6px 0;font-size:11px;color:#18181b;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-weight:800;text-align:right;">#${orderId}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Product:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:700;text-align:right;">${game}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Package:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:700;text-align:right;">${pkg}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Order Placed:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:600;text-align:right;">${orderDateStr}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Completed At:</td>
              <td style="padding:6px 0;font-size:12px;color:#18181b;font-weight:600;text-align:right;">${compDateStr}</td>
            </tr>
            <tr>
              <td style="padding:6px 0;font-size:12px;color:#71717a;font-weight:600;">Status:</td>
              <td style="padding:6px 0;font-size:11px;font-weight:800;color:#16a34a;text-align:right;text-transform:uppercase;">
                &#9679; Completed
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- Call to action button -->
    <div style="text-align:center;margin-bottom:8px;">
      <a href="https://ugtopups.com/orders?orderId=${encodeURIComponent(params.orderId)}" style="display:inline-block;background-color:#ef4444;color:#ffffff;font-size:13px;font-weight:800;letter-spacing:0.04em;text-transform:uppercase;text-decoration:none;padding:14px 32px;border-radius:12px;box-shadow:0 4px 14px rgba(239,68,68,0.35);">
        VIEW ORDER HISTORY
      </a>
    </div>
  `;

  return {
    subject: `Order Completed — UGTOPUPS`,
    html: baseEmailLayout(content, 'Order Completed — UGTOPUPS'),
  };
}

// 3. Voucher Delivered Template (CRITICAL: NEVER INCLUDES VOUCHER CODES!)
function buildVoucherDeliveredEmail(params: {
  customerName: string;
  orderId: string;
  gameName: string;
  packageName: string;
  amountNpr: number;
  orderDate: string;
}): { subject: string; html: string } {
  const name = escapeHtml(params.customerName || 'Customer');
  const orderId = escapeHtml(params.orderId);
  const game = escapeHtml(params.gameName || 'Gaming Voucher');
  const pkg = escapeHtml(params.packageName || 'Digital Voucher');
  const amountStr = escapeHtml(formatNpr(params.amountNpr));
  const dateStr = escapeHtml(formatDisplayDate(params.orderDate));

  const content = `
    <!-- Success Banner -->
    <div style="text-align:center;margin-bottom:28px;">
      <div style="display:inline-block;width:56px;height:56px;line-height:56px;border-radius:28px;background-color:#fef2f2;color:#ef4444;font-size:28px;text-align:center;margin-bottom:14px;box-shadow:0 4px 12px rgba(239,68,68,0.15);">
        &#127871;
      </div>
      <h1 style="margin:0 0 8px;font-size:22px;font-weight:900;color:#09090b;letter-spacing:-0.02em;">
        Voucher Delivered Successfully
      </h1>
      <p style="margin:0;font-size:13px;color:#71717a;line-height:1.5;">
        Hi <strong style="color:#18181b;">${name}</strong>, your digital voucher order has been delivered and is ready in your account.
      </p>
    </div>

    <!-- Voucher Details Card -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#09090b;border-radius:14px;margin-bottom:24px;overflow:hidden;">
      <tr>
        <td style="padding:22px 24px;">
          <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#ef4444;margin-bottom:6px;">
            ${game}
          </div>
          <div style="font-size:22px;font-weight:900;color:#ffffff;margin-bottom:8px;letter-spacing:-0.01em;">
            ${pkg}
          </div>
          <div style="font-size:12px;color:#a1a1aa;">
            Order ID: <strong style="color:#ffffff;font-family:ui-monospace,monospace;">#${orderId}</strong> &bull; Amount: <strong style="color:#22c55e;">${amountStr}</strong>
          </div>
        </td>
      </tr>
    </table>

    <!-- Notice Box: Voucher is inside account -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f0fdf4;border:1px solid #bbf7d0;border-radius:14px;margin-bottom:24px;">
      <tr>
        <td style="padding:18px 20px;text-align:center;">
          <div style="font-size:13px;font-weight:800;color:#166534;margin-bottom:4px;">
            Your voucher is securely available inside your UGTOPUPS account.
          </div>
          <div style="font-size:12px;color:#15803d;line-height:1.5;">
            Click the button below to sign in and view your redeem code securely.
          </div>
        </td>
      </tr>
    </table>

    <!-- Primary CTA: VIEW VOUCHER -->
    <div style="text-align:center;margin-bottom:24px;">
      <a href="https://ugtopups.com/orders?orderId=${encodeURIComponent(params.orderId)}" style="display:inline-block;background-color:#ef4444;color:#ffffff;font-size:14px;font-weight:900;letter-spacing:0.04em;text-transform:uppercase;text-decoration:none;padding:16px 36px;border-radius:12px;box-shadow:0 4px 16px rgba(239,68,68,0.4);">
        VIEW VOUCHER
      </a>
    </div>

    <!-- Security Warning (MANDATORY) -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#fffbeb;border:1px solid #fde68a;border-radius:12px;margin-bottom:28px;">
      <tr>
        <td style="padding:14px 18px;">
          <div style="font-size:11px;line-height:1.6;color:#92400e;">
            <strong style="color:#78350f;">Security Notice:</strong> For your security, the voucher code is not included in this email. Your voucher credentials can only be viewed after authenticating on the official UGTOPUPS website.
          </div>
        </td>
      </tr>
    </table>

    <!-- Order Meta Details -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#fafafa;border:1px solid #e4e4e7;border-radius:14px;margin-bottom:20px;">
      <tr>
        <td style="padding:16px 20px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td style="padding:5px 0;font-size:12px;color:#71717a;font-weight:600;">Order ID:</td>
              <td style="padding:5px 0;font-size:11px;color:#18181b;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-weight:800;text-align:right;">#${orderId}</td>
            </tr>
            <tr>
              <td style="padding:5px 0;font-size:12px;color:#71717a;font-weight:600;">Product:</td>
              <td style="padding:5px 0;font-size:12px;color:#18181b;font-weight:700;text-align:right;">${game}</td>
            </tr>
            <tr>
              <td style="padding:5px 0;font-size:12px;color:#71717a;font-weight:600;">Package:</td>
              <td style="padding:5px 0;font-size:12px;color:#18181b;font-weight:700;text-align:right;">${pkg}</td>
            </tr>
            <tr>
              <td style="padding:5px 0;font-size:12px;color:#71717a;font-weight:600;">Amount:</td>
              <td style="padding:5px 0;font-size:12px;color:#18181b;font-weight:700;text-align:right;">${amountStr}</td>
            </tr>
            <tr>
              <td style="padding:5px 0;font-size:12px;color:#71717a;font-weight:600;">Order Date:</td>
              <td style="padding:5px 0;font-size:12px;color:#18181b;font-weight:600;text-align:right;">${dateStr}</td>
            </tr>
            <tr>
              <td style="padding:5px 0;font-size:12px;color:#71717a;font-weight:600;">Status:</td>
              <td style="padding:5px 0;font-size:11px;font-weight:800;color:#16a34a;text-align:right;text-transform:uppercase;">
                &#9679; Delivered
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `;

  return {
    subject: `Voucher Delivered Successfully — UGTOPUPS`,
    html: baseEmailLayout(content, 'Voucher Delivered Successfully — UGTOPUPS'),
  };
}

// ────────────────────────────────────────────────────────────────────────────
// MAIN DISPATCHER & HTTP HANDLER
// ────────────────────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });

  try {
    const serviceKey = getServiceKey();
    const supabaseUrl = Deno.env.get('SUPABASE_URL');

    if (!serviceKey || !supabaseUrl) {
      console.error('[EMAIL] Missing SUPABASE_URL or SERVICE_ROLE_KEY');
      return json({ success: false, message: 'Server configuration error.' }, 500);
    }

    const admin = createClient(supabaseUrl, serviceKey);
    const body = await req.json().catch(() => ({}));
    const type = String(body.type || body.email_type || '').trim();

    if (!type) {
      return json({ success: false, message: 'email_type is required.' }, 400);
    }

    // Supported email types only
    const allowedTypes = ['wallet_recharge_success', 'order_completed', 'voucher_delivered'];
    if (!allowedTypes.includes(type)) {
      return json({
        success: false,
        message: `Unsupported email type: ${type}. Allowed: ${allowedTypes.join(', ')}`,
      }, 400);
    }

    const resendKey = (Deno.env.get('RESEND_API_KEY') || '').trim();
    const senderFrom = (
      Deno.env.get('VOUCHER_EMAIL_FROM') ||
      Deno.env.get('EMAIL_FROM') ||
      'UGTOPUPS <noreply@ugtopups.com>'
    ).trim();

    // ────────────────────────────────────────────────────────────────────────
    // CASE 1: WALLET RECHARGE SUCCESS
    // ────────────────────────────────────────────────────────────────────────
    if (type === 'wallet_recharge_success') {
      const txnId = String(body.transactionId || body.orderId || body.requestId || '').trim();
      const userId = String(body.userId || body.uid || '').trim();
      const rawAmount = Number(body.amount ?? body.amountNpr ?? 0);
      const paymentMethod = String(body.paymentMethod || 'eSewa / Khalti / Mobile Banking').trim();

      if (!txnId && !userId) {
        return json({ success: false, message: 'transactionId or userId is required.' }, 400);
      }

      const eventKey = `wallet_recharge:${txnId || userId + '_' + Date.now()}`;

      // Duplicate Check
      const { data: existing } = await admin
        .from('transactional_email_deliveries')
        .select('*')
        .eq('event_key', eventKey)
        .maybeSingle();

      if (existing && existing.status === 'sent') {
        console.log('[EMAIL] Wallet recharge email already sent for event:', eventKey);
        return json({
          success: true,
          alreadySent: true,
          messageId: existing.resend_message_id,
          message: 'Wallet recharge email already sent.',
        });
      }

      // Fetch user profile and actual auth email
      let recipientEmail = '';
      let customerName = '';
      let currentBal = 0;
      let prevBal = 0;

      if (userId) {
        const { data: authUser } = await admin.auth.admin.getUserById(userId).catch(() => ({ data: { user: null } }));
        recipientEmail = String(authUser?.user?.email || '').trim();

        const { data: userProfile } = await admin.from('users').select('*').eq('id', userId).maybeSingle();
        if (userProfile) {
          customerName = userProfile.username || userProfile.fullName || '';
          currentBal = Number(userProfile.walletBalanceNpr ?? 0);
          if (!recipientEmail && userProfile.email) recipientEmail = String(userProfile.email).trim();
        }
      }

      // If previous balance not passed, compute from newBalance - amount
      if (body.newBalance !== undefined && Number.isFinite(Number(body.newBalance))) {
        currentBal = Number(body.newBalance);
      }
      if (body.previousBalance !== undefined && Number.isFinite(Number(body.previousBalance))) {
        prevBal = Number(body.previousBalance);
      } else {
        prevBal = Math.max(0, currentBal - rawAmount);
      }

      if (!recipientEmail) {
        console.warn('[EMAIL] No recipient email found for wallet recharge user:', userId);
        return json({ success: false, message: 'Recipient email not found for user.' }, 404);
      }

      const { subject, html } = buildWalletRechargeEmail({
        customerName: customerName || 'Gamer',
        amountNpr: rawAmount,
        paymentMethod,
        transactionId: txnId || `TXN-${Date.now()}`,
        previousBalanceNpr: prevBal,
        newBalanceNpr: currentBal,
        dateTime: new Date().toISOString(),
      });

      // Upsert pending delivery record
      await admin.from('transactional_email_deliveries').upsert(
        {
          event_key: eventKey,
          email_type: 'wallet_recharge_success',
          user_id: userId || null,
          transaction_id: txnId || null,
          email: recipientEmail,
          status: 'pending',
          metadata: { amount: rawAmount, paymentMethod, newBalance: currentBal },
          created_at: new Date().toISOString(),
        },
        { onConflict: 'event_key' }
      );

      if (!resendKey) {
        console.warn('[EMAIL] RESEND_API_KEY is not configured in environment.');
        return json({
          success: false,
          code: 'NO_RESEND_KEY',
          message: 'RESEND_API_KEY is not configured in Supabase Secrets.',
        }, 500);
      }

      const resendRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: senderFrom,
          to: [recipientEmail],
          subject,
          html,
          tags: [
            { name: 'type', value: 'wallet-recharge-success' },
            { name: 'txn_id', value: String(txnId).slice(0, 40) },
          ],
        }),
      });

      const resendData = await resendRes.json().catch(() => ({}));

      if (!resendRes.ok) {
        const errMsg = String(resendData?.message || resendData?.error || 'Resend rejected request');
        console.error('[EMAIL] Resend send error for wallet recharge:', errMsg);
        await admin
          .from('transactional_email_deliveries')
          .update({ status: 'failed', error_message: errMsg })
          .eq('event_key', eventKey);

        return json({ success: false, message: errMsg }, 502);
      }

      const messageId = String(resendData?.id || '');
      await admin
        .from('transactional_email_deliveries')
        .update({
          status: 'sent',
          resend_message_id: messageId,
          sent_at: new Date().toISOString(),
          error_message: null,
        })
        .eq('event_key', eventKey);

      return json({
        success: true,
        sent: true,
        eventKey,
        recipient: recipientEmail,
        messageId,
      });
    }

    // ────────────────────────────────────────────────────────────────────────
    // CASE 2: ORDER COMPLETED (NORMAL PRODUCTS)
    // ────────────────────────────────────────────────────────────────────────
    if (type === 'order_completed') {
      const orderId = String(body.orderId || '').trim();
      if (!orderId) {
        return json({ success: false, message: 'orderId is required.' }, 400);
      }

      const eventKey = `order_completed:${orderId}`;

      // Duplicate Check
      const { data: existing } = await admin
        .from('transactional_email_deliveries')
        .select('*')
        .eq('event_key', eventKey)
        .maybeSingle();

      if (existing && existing.status === 'sent') {
        // Keep additive order-level tracking in sync with the canonical event log.
        await admin.from('orders').update({ completion_email_sent: true, completion_email_sent_at: existing.sent_at || new Date().toISOString(), completion_email_error: null }).eq('orderId', orderId);
        console.log('[EMAIL] Order completed email already sent for event:', eventKey);
        return json({
          success: true,
          alreadySent: true,
          messageId: existing.resend_message_id,
          message: 'Order completed email already sent.',
        });
      }

      // Fetch order
      const { data: order, error: orderError } = await admin
        .from('orders')
        .select('*')
        .eq('orderId', orderId)
        .maybeSingle();

      if (orderError || !order) {
        console.warn('[EMAIL] Order lookup failed:', orderId);
        return json({ success: false, message: 'Order not found.' }, 404);
      }

      // Fetch customer email strictly from auth.users
      let recipientEmail = '';
      let customerName = String(order.playerName || '').trim();

      if (order.userId) {
        const { data: authUser } = await admin.auth.admin.getUserById(String(order.userId)).catch(() => ({ data: { user: null } }));
        recipientEmail = String(authUser?.user?.email || '').trim();

        const { data: userProfile } = await admin.from('users').select('username,fullName,email').eq('id', order.userId).maybeSingle();
        if (userProfile) {
          if (userProfile.username || userProfile.fullName) {
            customerName = userProfile.username || userProfile.fullName;
          }
          if (!recipientEmail && userProfile.email) recipientEmail = String(userProfile.email).trim();
        }
      }

      if (!recipientEmail && order.userEmail) {
        recipientEmail = String(order.userEmail).trim();
      }

      const emailLooksValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail);
      if (!emailLooksValid) {
        const msg = 'Recipient email not found or invalid.';
        console.warn('[EMAIL]', msg, orderId);
        await admin.from('orders').update({ completion_email_error: msg }).eq('orderId', orderId);
        return json({ success: false, message: msg }, 404);
      }

      const { subject, html } = buildOrderCompletedEmail({
        customerName: customerName || 'Valued Customer',
        orderId,
        gameName: String(order.gameName || 'Gaming Top-Up'),
        packageName: String(order.packageName || 'Package Item'),
        amountNpr: Number(order.totalPriceNpr || 0),
        paymentMethod: String(order.paymentMethod || 'UG Wallet'),
        orderDate: String(order.createdAt || order.created_at || new Date().toISOString()),
        completedDate: String(order.completedAt || new Date().toISOString()),
        playerUid: String(order.playerUid || ''),
        playerName: String(order.playerName || ''),
      });

      // Upsert pending delivery record
      await admin.from('transactional_email_deliveries').upsert(
        {
          event_key: eventKey,
          email_type: 'order_completed',
          user_id: order.userId || null,
          order_id: orderId,
          email: recipientEmail,
          status: 'pending',
          metadata: {
            gameName: order.gameName,
            packageName: order.packageName,
            amount: order.totalPriceNpr,
          },
          created_at: new Date().toISOString(),
        },
        { onConflict: 'event_key' }
      );

      if (!resendKey) {
        console.warn('[EMAIL] RESEND_API_KEY is not configured in environment.');
        return json({
          success: false,
          code: 'NO_RESEND_KEY',
          message: 'RESEND_API_KEY is not configured in Supabase Secrets.',
        }, 500);
      }

      const resendRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: senderFrom,
          to: [recipientEmail],
          subject,
          html,
          tags: [
            { name: 'type', value: 'order-completed' },
            { name: 'order_id', value: String(orderId).slice(0, 40) },
          ],
        }),
      });

      const resendData = await resendRes.json().catch(() => ({}));

      if (!resendRes.ok) {
        const errMsg = String(resendData?.message || resendData?.error || 'Resend rejected request');
        console.error('[EMAIL] Resend send error for order completed:', errMsg);
        await admin.from('transactional_email_deliveries').update({ status: 'failed', error_message: errMsg }).eq('event_key', eventKey);
        await admin.from('orders').update({ completion_email_error: errMsg }).eq('orderId', orderId);
        return json({ success: false, message: errMsg }, 502);
      }

      const messageId = String(resendData?.id || '');
      await admin
        .from('transactional_email_deliveries')
        .update({
          status: 'sent',
          resend_message_id: messageId,
          sent_at: new Date().toISOString(),
          error_message: null,
        })
        .eq('event_key', eventKey);
      await admin.from('orders').update({ completion_email_sent: true, completion_email_sent_at: new Date().toISOString(), completion_email_error: null }).eq('orderId', orderId);

      return json({ success: true, sent: true, eventKey, recipient: recipientEmail, messageId });
    }

    // ────────────────────────────────────────────────────────────────────────
    // CASE 3: VOUCHER DELIVERED (CRITICAL: NEVER INCLUDES VOUCHER CODES!)
    // ────────────────────────────────────────────────────────────────────────
    if (type === 'voucher_delivered') {
      const orderId = String(body.orderId || '').trim();
      if (!orderId) {
        return json({ success: false, message: 'orderId is required.' }, 400);
      }

      const eventKey = `voucher_delivered:${orderId}`;

      // Duplicate Check
      const { data: existing } = await admin
        .from('transactional_email_deliveries')
        .select('*')
        .eq('event_key', eventKey)
        .maybeSingle();

      if (existing && existing.status === 'sent') {
        console.log('[EMAIL] Voucher delivered email already sent for event:', eventKey);
        return json({
          success: true,
          alreadySent: true,
          messageId: existing.resend_message_id,
          message: 'Voucher delivered email already sent.',
        });
      }

      // Fetch order
      const { data: order, error: orderError } = await admin
        .from('orders')
        .select('*')
        .eq('orderId', orderId)
        .maybeSingle();

      if (orderError || !order) {
        console.warn('[EMAIL] Voucher order lookup failed:', orderId);
        return json({ success: false, message: 'Order not found.' }, 404);
      }

      // Fetch customer email strictly from auth.users
      let recipientEmail = '';
      let customerName = String(order.playerName || '').trim();

      if (order.userId) {
        const { data: authUser } = await admin.auth.admin.getUserById(String(order.userId)).catch(() => ({ data: { user: null } }));
        recipientEmail = String(authUser?.user?.email || '').trim();

        const { data: userProfile } = await admin.from('users').select('username,fullName,email').eq('id', order.userId).maybeSingle();
        if (userProfile) {
          if (userProfile.username || userProfile.fullName) {
            customerName = userProfile.username || userProfile.fullName;
          }
          if (!recipientEmail && userProfile.email) recipientEmail = String(userProfile.email).trim();
        }
      }

      if (!recipientEmail && order.userEmail) {
        recipientEmail = String(order.userEmail).trim();
      }

      if (!recipientEmail) {
        console.warn('[EMAIL] No valid recipient email found for voucher order:', orderId);
        return json({ success: false, message: 'Recipient email not found for voucher order.' }, 404);
      }

      // Build secure voucher email (NO VOUCHER CODE INSIDE!)
      const { subject, html } = buildVoucherDeliveredEmail({
        customerName: customerName || 'Valued Customer',
        orderId,
        gameName: String(order.gameName || 'Gaming Voucher'),
        packageName: String(order.packageName || 'Digital Voucher'),
        amountNpr: Number(order.totalPriceNpr || 0),
        orderDate: String(order.createdAt || order.created_at || new Date().toISOString()),
      });

      // Upsert pending delivery record
      await admin.from('transactional_email_deliveries').upsert(
        {
          event_key: eventKey,
          email_type: 'voucher_delivered',
          user_id: order.userId || null,
          order_id: orderId,
          email: recipientEmail,
          status: 'pending',
          metadata: {
            gameName: order.gameName,
            packageName: order.packageName,
            amount: order.totalPriceNpr,
          },
          created_at: new Date().toISOString(),
        },
        { onConflict: 'event_key' }
      );

      if (!resendKey) {
        console.warn('[EMAIL] RESEND_API_KEY is not configured in environment.');
        return json({
          success: false,
          code: 'NO_RESEND_KEY',
          message: 'RESEND_API_KEY is not configured in Supabase Secrets.',
        }, 500);
      }

      const resendRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: senderFrom,
          to: [recipientEmail],
          subject,
          html,
          tags: [
            { name: 'type', value: 'voucher-delivered' },
            { name: 'order_id', value: String(orderId).slice(0, 40) },
          ],
        }),
      });

      const resendData = await resendRes.json().catch(() => ({}));

      if (!resendRes.ok) {
        const errMsg = String(resendData?.message || resendData?.error || 'Resend rejected request');
        console.error('[EMAIL] Resend send error for voucher delivered:', errMsg);
        await admin
          .from('transactional_email_deliveries')
          .update({ status: 'failed', error_message: errMsg })
          .eq('event_key', eventKey);

        return json({ success: false, message: errMsg }, 502);
      }

      const messageId = String(resendData?.id || '');
      await admin
        .from('transactional_email_deliveries')
        .update({
          status: 'sent',
          resend_message_id: messageId,
          sent_at: new Date().toISOString(),
          error_message: null,
        })
        .eq('event_key', eventKey);

      return json({
        success: true,
        sent: true,
        eventKey,
        recipient: recipientEmail,
        messageId,
      });
    }

    return json({ success: false, message: 'Invalid request.' }, 400);
  } catch (error: any) {
    console.error('[EMAIL] Unhandled error in send-transactional-email:', error?.message || error);
    return json({
      success: false,
      message: error instanceof Error ? error.message : 'Transactional email service failed.',
    }, 500);
  }
});
