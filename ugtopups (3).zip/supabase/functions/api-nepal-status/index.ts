import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(d: unknown, _status = 200) {
  return new Response(JSON.stringify(d), {
    status: 200,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });
}

function key() {
  const l = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (l) return l;
  try {
    return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '';
  } catch {
    return '';
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });

  try {
    const serviceKey = key();
    if (!serviceKey) return json({ success: false, message: 'Server key not configured.' });
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, serviceKey);

    const p = await req.json().catch(() => ({}));
    const orderId = String(p.orderId || '').trim();

    if (!orderId) {
      return json({ success: false, message: 'Order ID is required.' });
    }

    const { data: order, error } = await admin
      .from('orders')
      .select('*')
      .eq('orderId', orderId)
      .maybeSingle();

    if (error || !order) {
      return json({ success: false, message: 'Order not found.' });
    }

    // Release any pre-payment voucher reservation when the payment is explicitly cancelled/failed.
    if (order.paymentStatus !== 'SUCCESS' && (String(p.payment || '').toLowerCase() === 'cancel' || String(p.payment || '').toLowerCase() === 'failed' || String(p.status || '').toLowerCase() === 'cancelled')) {
      await admin.rpc('release_reserved_redeem_codes', { p_order_id: orderId });
      await admin.from('orders').update({ paymentStatus: 'FAILED', topUpStatus: 'CANCELLED', status: 'Cancelled' }).eq('orderId', orderId);
      return json({ success: true, verified: false, order: { ...order, paymentStatus: 'FAILED', topUpStatus: 'CANCELLED', status: 'Cancelled' }, message: 'Payment was cancelled.' });
    }

    // 1. A SUCCESS value written by a valid IPN is normally trusted. However,
    // when the client explicitly asks for a gateway check we re-verify it too.
    // This is important for repairing orders that were incorrectly marked SUCCESS
    // by the old status checker, which treated the API response's outer `status:
    // success` (request accepted) as a paid payment.
    const forceGatewayCheck = p.checkGateway === true;
    if (order.paymentStatus === 'SUCCESS' && !forceGatewayCheck) {
      return json({ success: true, verified: true, order });
    }

    // 2. If checkGateway is false and not returning from gateway success redirect
    if (!p.checkGateway && !p.isSuccessReturn && p.payment !== 'success') {
      return json({ success: true, verified: false, order, message: 'Payment is still pending.' });
    }

    // 3. Perform Gateway Verification via API Nepal.
    const publicKey = (Deno.env.get('API_NEPAL_PUBLIC_KEY') || '').trim();
    const secretKey = (Deno.env.get('API_NEPAL_SECRET_KEY') || '').trim();
    // API Nepal legacy status verification must use the real gateway transaction
    // number. The outer API response may contain status=success simply because the
    // status request itself succeeded; that does NOT mean the payment was paid.
    // The actual payment state is result.data.status.
    const trx = String(p.transactionRef || order.transactionRef || p.trx || p.trx_number || '').trim();

    let gatewayVerified = false;
    let finalTrx = trx;

    if (publicKey && secretKey && trx) {
      try {
        const form = new URLSearchParams({
          public_key: publicKey,
          secret_key: secretKey,
          trx_number: trx,
        });

        const r = await fetch('https://apinepal.com/payment/status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: form,
        });

        const result = await r.json().catch(() => null);
        // IMPORTANT: result.status === 'success' only means the API request was
        // accepted. Payment state lives in result.data.status.
        const actualStatus = String(
          result?.data?.status ||
          result?.data?.payment_status ||
          result?.payment_status ||
          ''
        ).toLowerCase().trim();

        const gatewayAmount = Number(result?.data?.amount ?? result?.amount);
        const amountMatches = !Number.isFinite(gatewayAmount) || Math.abs(gatewayAmount - Number(order.totalPriceNpr || 0)) <= 0.009;

        const paymentIsSuccessful =
          actualStatus === 'success' ||
          actualStatus === 'successful' ||
          actualStatus === 'paid' ||
          actualStatus === 'completed' ||
          actualStatus === 'succeeded';

        if (paymentIsSuccessful && amountMatches) {
          gatewayVerified = true;
          finalTrx = String(
            result?.data?.trx_number ||
            result?.data?.transaction_id ||
            result?.trx_number ||
            trx
          ).trim();
        } else if (!amountMatches) {
          console.warn('[API Nepal Gateway Status] Amount mismatch for order:', orderId);
        } else {
          console.log('[API Nepal Gateway Status] Payment not successful yet:', actualStatus || 'unknown');
        }
      } catch (e) {
        console.error('[API Nepal Gateway Status Error]', e);
      }
    } else {
      console.error('[API Nepal Gateway Status Error] API_NEPAL_PUBLIC_KEY/SECRET_KEY not configured; cannot verify payment server-side.');
    }

    // Only a real, server-side gateway confirmation proceeds from here.
    if (gatewayVerified) {
      const isWalletLoad =
        order.gameId === 'wallet-load' ||
        order.packageId === 'wallet-recharge' ||
        String(order.packageName || '').toLowerCase().includes('wallet') ||
        String(order.gameName || '').toLowerCase().includes('wallet');

      const newTopUpStatus = isWalletLoad ? 'COMPLETED' : 'PENDING';
      const newStatus = isWalletLoad ? 'Completed' : 'Payment Verified';

      const { data: updated } = await admin
        .from('orders')
        .update({
          paymentStatus: 'SUCCESS',
          transactionRef: finalTrx,
          topUpStatus: newTopUpStatus,
          status: newStatus,
        })
        .eq('orderId', orderId)
        .neq('paymentStatus', 'SUCCESS')
        .select()
        .maybeSingle();

      let currentBal = 0;
      let newBalance = 0;
      const depositAmt = Number(order.totalPriceNpr || 0);

      if (isWalletLoad && updated && order.userId) {
        const { data: userProfile } = await admin
          .from('users')
          .select('walletBalanceNpr, totalTopupsNpr, username, email')
          .eq('id', order.userId)
          .maybeSingle();

        currentBal = Number(userProfile?.walletBalanceNpr || 0);
        newBalance = currentBal + depositAmt;

        const { error: walletErr } = await admin
          .from('users')
          .update({
            walletBalanceNpr: newBalance,
            totalTopupsNpr: Number(userProfile?.totalTopupsNpr || 0) + depositAmt,
          })
          .eq('id', order.userId);

        if (walletErr) {
          console.error('[API Nepal Wallet Credit Error]', walletErr);
        } else {
          const txnId = `TXN-API-${orderId}`;
          const nowIso = new Date().toISOString();
          const { error: txnErr } = await admin.from('transactions').upsert({
            id: txnId,
            orderId,
            uid: order.userId,
            userId: order.userId,
            username: userProfile?.username || order.username || order.playerName || 'User',
            packageName: 'Instant Online Wallet Load',
            gameName: order.gameName || 'UG Wallet',
            amount: depositAmt,
            type: 'RECHARGE',
            operation: 'increase',
            previousBalance: currentBal,
            newBalance,
            paymentMethod: 'API Nepal',
            status: 'SUCCESS',
            date: nowIso,
            createdAt: nowIso,
          }, { onConflict: 'id' });

          if (txnErr) {
            console.error('[API Nepal Transaction Ledger Error]', txnErr);
          }
        }
      }

      const nowStr = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }) + ' · ' +
        new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      const { data: voucherRequired } = await admin.rpc('package_requires_redeem', { p_product_id:String(order.gameId||''), p_package_id:String(order.packageId||'') });
      if (voucherRequired === true) {
        const { data: deliveredData } = await admin.rpc('deliver_reserved_redeem_codes', { p_order_id: orderId });
        const deliveredCodes = (Array.isArray(deliveredData) ? deliveredData : [])
          .map((row: any) => String(row?.code || '').trim())
          .filter(Boolean);

        const codeStr = deliveredCodes.join(', ');
        await admin.from('notifications').upsert({
          id: `voucher-${orderId}`,
          target_uid: order.userId || null,
          target_email: null,
          title: 'Voucher Delivered 🎟️',
          message: deliveredCodes.length > 0
            ? `Your voucher code for ${order.packageName || order.gameName} is: ${codeStr}`
            : `Your voucher code for ${order.packageName || order.gameName} is ready in your order receipt!`,
          category: 'Order',
          code: deliveredCodes[0] || null,
          order_id: orderId,
          product_id: order.gameId || null,
          package_id: order.packageId || null,
          unread: true,
          date: nowStr,
          created_at: new Date().toISOString(),
        }, { onConflict: 'id' });

        const emailFunctionUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/send-transactional-email`;
        const emailPromise2 = fetch(emailFunctionUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${serviceKey}` },
          body: JSON.stringify({
            type: 'voucher_delivered',
            orderId,
          }),
        }).then((r) => {
          if (!r.ok) console.warn('[EMAIL] voucher delivery email failed (background):', r.status);
          else console.log('[EMAIL] gateway-verified voucher email delivered in background for order:', orderId);
        }).catch((err: any) => console.warn('[EMAIL] gateway email background error:', err?.message));
        try { (EdgeRuntime as any).waitUntil(emailPromise2); } catch { /* best-effort */ }
      } else if (isWalletLoad) {
        await admin.from('notifications').upsert({
          id: `wallet-load-${orderId}`,
          target_uid: order.userId || null,
          target_email: null,
          title: 'Wallet Recharge Successful 💰',
          message: `NPR ${order.totalPriceNpr} has been added to your UG Wallet!`,
          category: 'Wallet',
          order_id: orderId,
          unread: true,
          date: nowStr,
          created_at: new Date().toISOString(),
        }, { onConflict: 'id' });

        // Trigger Transactional Email for Wallet Recharge
        const emailFunctionUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/send-transactional-email`;
        const emailPromiseWallet = fetch(emailFunctionUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${serviceKey}` },
          body: JSON.stringify({
            type: 'wallet_recharge_success',
            userId: order.userId,
            amount: depositAmt,
            paymentMethod: 'Online Payment (API Nepal)',
            transactionId: finalTrx || `TXN-${orderId}`,
            previousBalance: currentBal,
            newBalance,
          }),
        }).then((r) => {
          if (!r.ok) console.warn('[EMAIL] wallet recharge email failed (background):', r.status);
          else console.log('[EMAIL] status-check wallet recharge email delivered for order:', orderId);
        }).catch((err: any) => console.warn('[EMAIL] wallet email background error:', err?.message));
        try { (EdgeRuntime as any).waitUntil(emailPromiseWallet); } catch { /* best-effort */ }
      } else {
        await admin.from('notifications').upsert({
          id: `order-paid-${orderId}`,
          target_uid: order.userId || null,
          target_email: null,
          title: 'Payment Successful 💳',
          message: `Your payment of NPR ${order.totalPriceNpr} for ${order.packageName || order.gameName} was received successfully! Top-up is being processed.`,
          category: 'Order',
          order_id: orderId,
          product_id: order.gameId || null,
          package_id: order.packageId || null,
          unread: true,
          date: nowStr,
          created_at: new Date().toISOString(),
        }, { onConflict: 'id' });
      }

      const completedOrder = updated || {
        ...order,
        paymentStatus: 'SUCCESS',
        transactionRef: finalTrx,
        topUpStatus: newTopUpStatus,
        status: newStatus,
      };

      return json({ success: true, verified: true, order: completedOrder });
    }

    if (order.paymentStatus === 'SUCCESS' && forceGatewayCheck) {
      const { data: reverted } = await admin
        .from('orders')
        .update({
          paymentStatus: 'Pending',
          topUpStatus: 'PENDING_PAYMENT',
          status: 'Payment Pending',
        })
        .eq('orderId', orderId)
        .select()
        .maybeSingle();

      return json({
        success: true,
        verified: false,
        order: reverted || { ...order, paymentStatus: 'Pending', topUpStatus: 'PENDING_PAYMENT', status: 'Payment Pending' },
        message: 'Payment is not confirmed by API Nepal yet. The order remains pending.',
      });
    }

    return json({
      success: true,
      verified: false,
      order,
      message: 'Payment is still pending. Please complete the QR payment first.',
    });
  } catch (e) {
    return json({
      success: false,
      message: e instanceof Error ? e.message : 'Payment status check failed.',
    }, 500);
  }
});
