import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });

function serviceKey() {
  return (
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ||
    Deno.env.get('SERVICE_ROLE_KEY') ||
    (() => {
      try {
        return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '';
      } catch {
        return '';
      }
    })()
  );
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });

  try {
    const key = serviceKey();
    const supabaseUrl = Deno.env.get('SUPABASE_URL');

    if (!key || !supabaseUrl) {
      return json({ success: false, message: 'Server key not configured.' }, 500);
    }

    const body = await req.json().catch(() => ({}));
    const orderId = String(body.orderId || '').trim();

    if (!orderId) {
      return json({ success: false, message: 'orderId is required.' }, 400);
    }

    // Forward to unified send-transactional-email function for duplicate protection & secure no-code template
    const functionUrl = `${supabaseUrl}/functions/v1/send-transactional-email`;
    const response = await fetch(functionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        type: 'voucher_delivered',
        orderId,
      }),
    });

    const result = await response.json().catch(() => ({}));
    return json(result, response.status);
  } catch (err: any) {
    console.error('[send-voucher-email wrapper error]:', err?.message || err);
    return json(
      {
        success: false,
        message: err instanceof Error ? err.message : 'Voucher email dispatch failed.',
      },
      500
    );
  }
});
