import { createClient } from 'npm:@supabase/supabase-js@2';
const cors={
 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'
};
const json=(d:unknown,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{...cors,'Content-Type':'application/json'}});
const key=()=>Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||(()=>{try{return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}').default||''}catch{return ''}})();
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
 try{
  const sk=key(); if(!sk) return json({success:false,message:'Server key not configured.'},500);
  const admin=createClient(Deno.env.get('SUPABASE_URL')!,sk);
  const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'').trim();
  const {data:u}=token?await admin.auth.getUser(token):{data:{user:null}};
  if(!u?.user?.id) return json({success:false,message:'Authentication required.'},401);
  const {data:a}=await admin.from('admins').select('id').eq('id',u.user.id).eq('active',true).maybeSingle();
  let isAdmin = !!a;
  if (!isAdmin) { const {data:ur} = await admin.from('users').select('role').eq('id',u.user.id).maybeSingle(); isAdmin = ur?.role === 'admin'; }
  if(!isAdmin) return json({success:false,message:'Admin access required.'},403);
  const body=await req.json().catch(()=>({}));
  const productId=String(body.productId||'').trim(), packageId=String(body.packageId||'').trim();
  const codes=Array.isArray(body.codes)?body.codes.map((x:any)=>String(x).trim()).filter(Boolean):[];
  if(!productId||!packageId||!codes.length) return json({success:false,message:'Product, package and at least one code are required.'},400);
  const {data:product,error:pe}=await admin.from('products').select('id,name,packages').eq('id',productId).single();
  if(pe||!product) return json({success:false,message:'Product not found.'},400);
  const pkg=(Array.isArray(product.packages)?product.packages:[]).find((p:any)=>String(p?.id)===packageId);
  if(!pkg) return json({success:false,message:'Package does not belong to this product.'},400);

  const normalized=[]; const seen=new Set<string>();
  for(const code of codes){ const n=code.trim(); const k=n.toLowerCase(); if(!seen.has(k)){seen.add(k);normalized.push(n);} }
  let added=0,duplicates=codes.length-normalized.length;
  for(const code of normalized){
    const {error}=await admin.from('redeem_codes').insert({product_id:productId,package_id:packageId,code,status:'available'});
    if(!error) added++;
    else if(String(error.code)==='23505'||String(error.message).toLowerCase().includes('duplicate')) duplicates++;
    else return json({success:false,message:error.message,added,duplicates},400);
  }
  return json({success:true,added,duplicates,total:codes.length});
 }catch(e){return json({success:false,message:e instanceof Error?e.message:'Import failed.'},500)}
});
