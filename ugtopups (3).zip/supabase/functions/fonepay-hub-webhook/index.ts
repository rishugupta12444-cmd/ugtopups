import { createClient } from 'npm:@supabase/supabase-js@2';
import { completeFonepayPayment } from '../_shared/completeFonepayPayment.ts';
import { verifyHubWebhook } from '../_shared/fonepayHub.ts';

function serviceKey() {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (legacy) return legacy;
  try { return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || ''; } catch { return ''; }
}
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { 'Content-Type': 'application/json' },
});

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ ok: false, message: 'Method not allowed.' }, 405);
  const rawBody = await req.text();
  if (!await verifyHubWebhook(rawBody, req.headers)) return json({ ok: false, message: 'Invalid webhook signature.' }, 401);
  if ((req.headers.get('X-Webhook-Event') || '') !== 'payment.paid') return json({ ok: true, ignored: true });

  try {
    const payload = JSON.parse(rawBody);
    const payment = payload?.payment;
    const orderId = String(payment?.merchant_reference || '').trim();
    if (!orderId || String(payment?.status || '').toLowerCase() !== 'paid') return json({ ok: false, message: 'Invalid payment event.' }, 422);
    const key = serviceKey();
    if (!key) return json({ ok: false, message: 'Server is not configured.' }, 500);
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, key);
    const { data: order } = await admin.from('orders').select('*').eq('orderId', orderId).maybeSingle();
    if (!order) return json({ ok: false, message: 'Order not found.' }, 404);
    const completed = await completeFonepayPayment(admin, order, payment);
    return json({ ok: true, verified: completed.verified });
  } catch (error) {
    return json({ ok: false, message: error instanceof Error ? error.message : 'Webhook processing failed.' }, 500);
  }
});
