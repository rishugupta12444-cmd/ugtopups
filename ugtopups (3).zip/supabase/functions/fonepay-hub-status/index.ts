import { createClient } from 'npm:@supabase/supabase-js@2';
import { completeFonepayPayment } from '../_shared/completeFonepayPayment.ts';
import { hubData, hubError, hubRequest } from '../_shared/fonepayHub.ts';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (data: unknown) => new Response(JSON.stringify(data), {
  status: 200, headers: { ...cors, 'Content-Type': 'application/json' },
});
function serviceKey() {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (legacy) return legacy;
  try { return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || ''; } catch { return ''; }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const key = serviceKey();
    if (!key) return json({ success: false, message: 'Supabase server secret is not configured.' });
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, key);
    const input = await req.json().catch(() => ({}));
    const orderId = String(input.orderId || '').trim();
    if (!orderId) return json({ success: false, message: 'Order ID is required.' });

    const jwt = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    const { data: authData } = jwt
      ? await admin.auth.getUser(jwt).catch(() => ({ data: { user: null } }))
      : { data: { user: null } };
    const callerId = authData?.user?.id || '';
    if (!callerId) return json({ success: false, message: 'Please sign in to check this payment.' });

    const { data: order, error } = await admin.from('orders').select('*').eq('orderId', orderId).maybeSingle();
    if (error || !order) return json({ success: false, message: 'Order not found.' });
    if (String(order.userId || '') !== callerId) return json({ success: false, message: 'You cannot access this payment.' });

    if (String(input.payment || '').toLowerCase() === 'cancel' && String(order.paymentStatus).toUpperCase() !== 'SUCCESS') {
      await admin.rpc('release_reserved_redeem_codes', { p_order_id: orderId });
      const { data: cancelled } = await admin.from('orders').update({
        paymentStatus: 'FAILED', topUpStatus: 'CANCELLED', status: 'Cancelled',
      }).eq('orderId', orderId).select().maybeSingle();
      return json({ success: true, verified: false, order: cancelled || order, message: 'Payment was cancelled.' });
    }

    if (String(order.paymentStatus).toUpperCase() === 'SUCCESS') {
      return json({ success: true, verified: true, order });
    }

    const paymentId = String(order.transactionRef || input.hubPaymentId || '').trim();
    if (!/^[0-9a-f-]{36}$/i.test(paymentId)) {
      return json({ success: false, verified: false, order, message: 'This order has no valid Fonepay Hub payment ID.' });
    }

    const verifyNow = input.checkGateway === true || input.manual === true;
    const path = `/api/v1/payments/${encodeURIComponent(paymentId)}${verifyNow ? '/verify' : ''}`;
    const { response, result } = await hubRequest(verifyNow ? 'POST' : 'GET', path, verifyNow ? {} : undefined);
    if (!response.ok || result?.ok === false) {
      return json({ success: false, verified: false, order, message: hubError(result, 'Could not check Fonepay Hub right now.') });
    }

    const payment = hubData(result);
    if (String(payment?.merchant_reference || '') !== orderId) {
      return json({ success: false, verified: false, order, message: 'Gateway reference mismatch. Payment was not accepted.' });
    }
    if (String(payment?.status || '').toLowerCase() !== 'paid') {
      return json({
        success: true, verified: false, order,
        gatewayStatus: String(payment?.status || 'pending'),
        message: String(payment?.status || '').toLowerCase() === 'expired'
          ? 'This Fonepay QR has expired.' : 'Payment is still pending. Complete the Fonepay QR payment first.',
      });
    }

    const completed = await completeFonepayPayment(admin, order, payment);
    return json({ success: true, ...completed });
  } catch (error) {
    return json({ success: false, verified: false, message: error instanceof Error ? error.message : 'Payment status check failed.' });
  }
});
