import { createClient } from 'npm:@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Headers':'content-type', 'Access-Control-Allow-Methods':'POST, OPTIONS' };
function json(data:unknown,status=200){return new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json'}})}
function key(){const l=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'); if(l)return l; try{return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}').default||''}catch{return ''}}
async function hmac(message:string, secret:string){const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']); const b=new Uint8Array(await crypto.subtle.sign('HMAC',k,new TextEncoder().encode(message))); return [...b].map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase()}
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 try{
  const body=await req.text(); const form=new URLSearchParams(body); const status=form.get('status')||''; const identifier=form.get('identifier')||''; const signature=form.get('signature')||''; const rawData=form.get('data')||'{}';
  let data:any={}; try{data=JSON.parse(rawData)}catch{}
  const secret=(Deno.env.get('API_NEPAL_SECRET_KEY')||'').trim(); if(!secret)return json({success:false,message:'Gateway secret not configured.'},500);
  const amount=String(data?.amount ?? ''); const expected=await hmac(amount+identifier,secret);
  if(status!=='success' || !identifier || !signature || signature.toUpperCase()!==expected)return json({success:false,message:'Invalid payment notification.'},400);
  const admin=createClient(Deno.env.get('SUPABASE_URL')!,key());
  const {data:order,error}=await admin.from('orders').select('*').eq('orderId',identifier).maybeSingle();
  if(error || !order)return json({success:false,message:'Order not found.'},404);
  const gatewayAmount=Number(amount); const orderAmount=Number(order.totalPriceNpr);
  if(!Number.isFinite(gatewayAmount) || Math.abs(gatewayAmount-orderAmount)>0.009)return json({success:false,message:'Payment amount mismatch.'},400);
  if(order.paymentStatus!=='SUCCESS'){
    const isWalletLoad = order.gameId === 'wallet-load' || order.packageId === 'wallet-recharge' || String(order.packageName || '').toLowerCase().includes('wallet') || String(order.gameName || '').toLowerCase().includes('wallet');
    const { data: voucherRequired } = await admin.rpc('package_requires_redeem', { p_product_id:String(order.gameId||''), p_package_id:String(order.packageId||'') });

    const newTopUpStatus = isWalletLoad || voucherRequired ? 'COMPLETED' : 'PENDING';
    const newStatus = isWalletLoad || voucherRequired ? 'Completed' : 'Payment Verified';

    // Reward UG Coins for real order purchases (never for wallet top-ups) — best-effort.
    if (!isWalletLoad && order.userId) {
      try {
        await admin.rpc('increment_user_coins', { p_uid: order.userId, p_amount: 3 });
      } catch (coinErr) {
        console.warn('[IPN] Failed to award UG Coins:', coinErr);
      }
    }

    const txnRef = data?.transaction_id || order.transactionRef || identifier;

    await admin.from('orders').update({
      paymentStatus: 'SUCCESS',
      transactionRef: txnRef,
      topUpStatus: newTopUpStatus,
      status: newStatus,
    }).eq('orderId', identifier);

    const nowStr = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }) + ' · ' +
      new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    if (voucherRequired === true) {
      const { data: deliveredData } = await admin.rpc('deliver_reserved_redeem_codes', { p_order_id: identifier });
      const deliveredCodes = (Array.isArray(deliveredData) ? deliveredData : [])
        .map((row: any) => String(row?.code || '').trim())
        .filter(Boolean);

      const codeStr = deliveredCodes.join(', ');
      await admin.from('notifications').upsert({
        id: `voucher-${identifier}`,
        target_uid: order.userId || null,
        target_email: null,
        title: 'Voucher Delivered 🎟️',
        message: deliveredCodes.length > 0
          ? `Your voucher code for ${order.packageName || order.gameName} is: ${codeStr}`
          : `Your voucher code for ${order.packageName || order.gameName} is ready in your order receipt!`,
        category: 'Order',
        code: deliveredCodes[0] || null,
        order_id: identifier,
        product_id: order.gameId || null,
        package_id: order.packageId || null,
        unread: true,
        date: nowStr,
        created_at: new Date().toISOString(),
      }, { onConflict: 'id' });

      // Transactional Email for Voucher Delivery (code is NEVER in the email)
      const emailFunctionUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/send-transactional-email`;
      const emailPromise = fetch(emailFunctionUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key()}` },
        body: JSON.stringify({
          type: 'voucher_delivered',
          orderId: identifier,
        }),
      }).then((r) => {
        if (!r.ok) console.warn('[EMAIL] voucher delivery email failed from IPN:', r.status);
        else console.log('[EMAIL] IPN voucher email delivered in background for order:', identifier);
      }).catch((err: any) => console.warn('[EMAIL] IPN email background error:', err?.message));
      try { (EdgeRuntime as any).waitUntil(emailPromise); } catch { /* best-effort */ }
    } else if (isWalletLoad) {
      const { data: userProfile } = await admin.from('users').select('walletBalanceNpr, totalTopupsNpr').eq('id', order.userId).maybeSingle();
      const currentBal = Number(userProfile?.walletBalanceNpr || 0);
      const depositAmt = Number(order.totalPriceNpr || 0);
      const newBal = currentBal + depositAmt;

      await admin.from('users').update({
        walletBalanceNpr: newBal,
        totalTopupsNpr: Number(userProfile?.totalTopupsNpr || 0) + depositAmt,
      }).eq('id', order.userId);

      await admin.from('notifications').upsert({
        id: `wallet-load-${identifier}`,
        target_uid: order.userId || null,
        target_email: null,
        title: 'Wallet Recharge Successful 💰',
        message: `NPR ${order.totalPriceNpr} has been added to your UG Wallet!`,
        category: 'Wallet',
        order_id: identifier,
        unread: true,
        date: nowStr,
        created_at: new Date().toISOString(),
      }, { onConflict: 'id' });

      // Transactional Email for Wallet Recharge Success
      const emailFunctionUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/send-transactional-email`;
      const emailPromise = fetch(emailFunctionUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key()}` },
        body: JSON.stringify({
          type: 'wallet_recharge_success',
          userId: order.userId,
          amount: depositAmt,
          paymentMethod: 'Online Payment (API Nepal)',
          transactionId: txnRef || `TXN-${identifier}`,
          previousBalance: currentBal,
          newBalance: newBal,
        }),
      }).then((r) => {
        if (!r.ok) console.warn('[EMAIL] wallet recharge email failed from IPN:', r.status);
        else console.log('[EMAIL] IPN wallet recharge email delivered in background for order:', identifier);
      }).catch((err: any) => console.warn('[EMAIL] IPN wallet recharge email background error:', err?.message));
      try { (EdgeRuntime as any).waitUntil(emailPromise); } catch { /* best-effort */ }
    } else {
      await admin.from('notifications').upsert({
        id: `order-paid-${identifier}`,
        target_uid: order.userId || null,
        target_email: null,
        title: 'Payment Successful 💳',
        message: `Your payment of NPR ${order.totalPriceNpr} for ${order.packageName || order.gameName} was received successfully! Top-up is being processed.`,
        category: 'Order',
        order_id: identifier,
        product_id: order.gameId || null,
        package_id: order.packageId || null,
        unread: true,
        date: nowStr,
        created_at: new Date().toISOString(),
      }, { onConflict: 'id' });
    }
  }
  return json({success:true,received:true});
 }catch(e){return json({success:false,message:e instanceof Error?e.message:'Webhook error'},500)}
});
