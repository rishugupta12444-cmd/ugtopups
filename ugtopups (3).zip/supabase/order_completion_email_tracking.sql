-- Safe additive tracking for automatic order-completion receipts.
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS completion_email_sent BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS completion_email_sent_at TIMESTAMPTZ;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS completion_email_error TEXT;
CREATE INDEX IF NOT EXISTS idx_orders_completion_email_sent ON public.orders(completion_email_sent);
