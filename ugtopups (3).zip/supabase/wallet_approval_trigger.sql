-- UG TOP UP CENTER: Automatic Wallet Balance Credit Trigger & RPC Function
-- Place or run this file in Supabase SQL Editor.

-- 1. Create function to automatically credit user wallet balance when request is APPROVED
CREATE OR REPLACE FUNCTION public.process_wallet_request_approval()
RETURNS TRIGGER AS $$
DECLARE
  v_user_id TEXT;
  v_amount NUMERIC;
  v_username TEXT;
BEGIN
  -- Only execute when status is set to 'APPROVED'
  IF (NEW.status = 'APPROVED' AND (OLD.status IS NULL OR OLD.status != 'APPROVED')) THEN
    v_user_id := COALESCE(NEW.uid, NEW.user_id);
    v_amount := COALESCE(NEW."amountNpr", NEW.amount_npr, 0);
    v_username := COALESCE(NEW.username, 'User');

    IF v_amount > 0 THEN
      -- Find user by ID or Email and credit balance
      UPDATE public.users
      SET 
        "walletBalanceNpr" = COALESCE("walletBalanceNpr", 0) + v_amount,
        "totalTopupsNpr" = COALESCE("totalTopupsNpr", 0) + v_amount
      WHERE id = v_user_id OR (email IS NOT NULL AND LOWER(email) = LOWER(NEW.email));

      -- Log transaction entry
      INSERT INTO public.transactions (
        id,
        "orderId",
        uid,
        "userId",
        username,
        amount,
        type,
        "paymentMethod",
        status,
        date,
        "createdAt",
        created_at
      ) VALUES (
        'TXN-WLT-' || floor(extract(epoch from now()) * 1000)::text,
        NEW.id,
        v_user_id,
        v_user_id,
        v_username,
        v_amount,
        'RECHARGE',
        COALESCE(NEW."paymentMethod", NEW.payment_method, 'Manual QR Verification'),
        'SUCCESS',
        to_char(now(), 'YYYY-MM-DD HH24:MI:SS'),
        now(),
        now()
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Attach trigger to public."walletRequests"
DROP TRIGGER IF EXISTS trg_approve_wallet_request ON public."walletRequests";
CREATE TRIGGER trg_approve_wallet_request
  AFTER UPDATE OF status ON public."walletRequests"
  FOR EACH ROW
  EXECUTE FUNCTION public.process_wallet_request_approval();

-- 3. Attach trigger to public.wallet_requests if present
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='wallet_requests') THEN
    EXECUTE 'DROP TRIGGER IF EXISTS trg_approve_wallet_request_snake ON public.wallet_requests';
    EXECUTE 'CREATE TRIGGER trg_approve_wallet_request_snake AFTER UPDATE OF status ON public.wallet_requests FOR EACH ROW EXECUTE FUNCTION public.process_wallet_request_approval()';
  END IF;
END $$;

-- 4. RPC function for explicit atomic wallet approval
CREATE OR REPLACE FUNCTION public.approve_wallet_request(p_request_id TEXT)
RETURNS JSONB AS $$
DECLARE
  v_req RECORD;
  v_found BOOLEAN := false;
BEGIN
  -- Search in walletRequests
  SELECT * INTO v_req FROM public."walletRequests" WHERE id = p_request_id;
  IF FOUND THEN
    UPDATE public."walletRequests" SET status = 'APPROVED' WHERE id = p_request_id;
    v_found := true;
  END IF;

  -- Search in wallet_requests
  IF NOT v_found THEN
    SELECT * INTO v_req FROM public.wallet_requests WHERE id = p_request_id;
    IF FOUND THEN
      UPDATE public.wallet_requests SET status = 'APPROVED' WHERE id = p_request_id;
      v_found := true;
    END IF;
  END IF;

  IF NOT v_found THEN
    RETURN jsonb_build_object('success', false, 'message', 'Wallet request not found');
  END IF;

  RETURN jsonb_build_object('success', true, 'message', 'Wallet request approved and user balance updated.');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.approve_wallet_request(TEXT) TO anon, authenticated;
