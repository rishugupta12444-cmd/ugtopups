-- UG TOP UP CENTER: permanent admin persistence + RLS fix
-- Safe to run on the existing project. It does NOT drop games/products or recreate tables.

-- 1) Make the admin row follow the real Supabase Auth user when the email exists.
DO $$
DECLARE
  auth_admin_id text;
BEGIN
  SELECT id::text INTO auth_admin_id
  FROM auth.users
  WHERE lower(email) = lower('rishugupta12444@gmail.com')
  LIMIT 1;

  IF auth_admin_id IS NOT NULL THEN
    -- Remove the old placeholder row only when it is a different ID.
    DELETE FROM public.admins
    WHERE lower(email) = lower('rishugupta12444@gmail.com')
      AND id <> auth_admin_id;

    INSERT INTO public.admins (id, email, username, role, active)
    VALUES (auth_admin_id, 'rishugupta12444@gmail.com', 'Rishu Gupta', 'admin', true)
    ON CONFLICT (id) DO UPDATE
      SET email = EXCLUDED.email,
          username = EXCLUDED.username,
          role = 'admin',
          active = true;
  END IF;
END $$;

-- 2) Robust admin test. It accepts the authenticated user's UID, email,
--    or an existing users.role='admin' record.
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    EXISTS (
      SELECT 1
      FROM public.admins a
      WHERE a.active = true
        AND (
          a.id = auth.uid()::text
          OR lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
        )
    )
    OR EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()::text
        AND (
          u.role = 'admin'
          OR lower(coalesce(u.email, '')) = lower(coalesce(auth.jwt() ->> 'email', ''))
        )
    );
$$;

GRANT EXECUTE ON FUNCTION public.is_admin() TO anon, authenticated;

-- 3) Explicitly guarantee admin write policies for the two tables that caused
--    the disappearing game/product issue. Existing rows are untouched.
DROP POLICY IF EXISTS "Admin full access games" ON public.games;
CREATE POLICY "Admin full access games"
ON public.games
FOR ALL
USING (public.is_admin())
WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Admin full access products" ON public.products;
CREATE POLICY "Admin full access products"
ON public.products
FOR ALL
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- 4) Public reads remain enabled so the storefront can load the catalog.
DROP POLICY IF EXISTS "Public read games" ON public.games;
CREATE POLICY "Public read games"
ON public.games
FOR SELECT
USING (true);

DROP POLICY IF EXISTS "Public read products" ON public.products;
CREATE POLICY "Public read products"
ON public.products
FOR SELECT
USING (true);

-- 5) Ensure RLS is on.
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- 6) Helpful indexes for the catalog.
CREATE INDEX IF NOT EXISTS games_active_idx ON public.games (active);
CREATE INDEX IF NOT EXISTS products_status_idx ON public.products (status);
