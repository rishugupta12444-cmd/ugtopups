# MLBB Liana Product ID Fix

## What changed
- Liana `/order` now uses `product_id`, not the old `variation_id` naming.
- Admin package editor now shows **Liana Product ID (MLBB Auto-Delivery)**.
- Existing `variation_id` package values remain readable as a legacy alias, but are treated as product IDs only for backward compatibility.
- Before placing an order, the `process-ml-order` Edge Function checks Liana's live `/products` catalog. If a saved ID is stale/not found, it attempts to resolve the correct product ID by the package name.
- No hard-coded old MLBB variation IDs are used as an automatic fallback anymore.
- MLBB verification still uses `/verify/mlbb` with only `customer_id` and `zone_id`, as required by the supplied API documentation.
- Liana order body is exactly `{ product_id, customer_id, zone_id }`.

## Required deployment
Deploy the updated Supabase Edge Function:

`supabase functions deploy process-ml-order`

Also deploy the updated frontend normally.

## Important
The Liana API key must be configured as the Supabase secret `LIANA_API_KEY`.

If automatic product lookup cannot find a package by name, enter the exact `product_id` from Liana's `GET /products?game=...` response in the Admin Panel for that package.
