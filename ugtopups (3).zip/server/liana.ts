/**
 * Server-side (Vercel serverless) helper to call the Liana reseller API.
 * Base: https://server.lianastore.in/api/v1
 *   POST /verify/mlbb { customer_id, zone_id } -> { status, ign, region }
 *   GET  /balance                              -> { status, data: { balance } }
 *   POST /order       { product_id, customer_id, zone_id } -> order result
 *
 * Auth: single X-API-Key header — no separate secret.
 *
 * This runs on Vercel's serverless infrastructure — a different outbound IP
 * range than the Supabase Edge Functions (supabase/functions/_shared/liana.ts).
 * It exists as a fallback network path: if Liana's WAF ever blocks Supabase's
 * egress IPs specifically, requests here may still get through.
 * Keep this in sync with _shared/liana.ts if Liana's response shape changes.
 *
 * Pro/Elite-plan-only endpoints: /verify/mlbb, /verify-ign, /check-region,
 * /check-bonus. Plan errors are surfaced distinctly (see planError below).
 */

const LIANA_BASE = 'https://server.lianastore.in/api/v1';

function lianaHeaders(apiKey: string): Record<string, string> {
  return {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-API-Key': apiKey,
  };
}

function truthy(value: unknown): boolean {
  if (value === true) return true;
  if (typeof value === 'string') return ['true', '1', 'yes', 'verified', 'success'].includes(value.trim().toLowerCase());
  if (typeof value === 'number') return value === 1;
  return false;
}

function diagnoseNonJson(status: number, text: string): string {
  const t = text.trim();
  const lower = t.toLowerCase();
  if (!t) return `Liana returned an empty response (HTTP ${status}).`;
  if (lower.includes('cloudflare') || lower.includes('attention required') || lower.includes('checking your browser')) {
    return `Liana's server blocked this request behind Cloudflare/a firewall (HTTP ${status}).`;
  }
  if (lower.includes('wp-login') || lower.includes('name="log"')) {
    return `Liana returned a login page (HTTP ${status}) — credentials may be invalid.`;
  }
  if (status === 404) return `Liana API endpoint not found (HTTP 404).`;
  if (status === 429) return `Liana rate-limited this request (HTTP 429).`;
  if (status >= 500) return `Liana's server returned an error (HTTP ${status}).`;
  return `Liana returned a non-JSON response (HTTP ${status}).`;
}

export interface LianaVerifyParams {
  variation_id: number | string; // mapped to product_id
  uid: string;                   // mapped to customer_id
  zone_id: string;
}

export interface LianaVerifyResult {
  success: boolean;
  verified: boolean;
  playerName?: string;
  display?: string;
  region?: string | null;
  error?: string;
  blocked?: boolean;
  /** True when Liana rejected due to plan tier (Pro/Elite required). Distinct from auth errors or bad Game/Zone ID. */
  planError?: boolean;
  provider?: any;
}

/**
 * Calls POST /verify/mlbb — confirmed MLBB verification endpoint.
 * Body: { customer_id, zone_id } only (no product_id needed for MLBB).
 * Response: { status: true, ign: "PlayerName", region: "..." }
 *   (also tolerates nesting under data in case the API evolves)
 */
export async function verifyMlbbPlayerLiana(params: LianaVerifyParams): Promise<LianaVerifyResult> {
  const apiKey = (process.env.LIANA_API_KEY || '').trim();

  if (!apiKey) {
    return { success: false, verified: false, error: 'Mobile Legends verification is not configured on the server.' };
  }

  // Only customer_id and zone_id are sent — product_id is NOT part of the
  // /verify/mlbb contract. variation_id is accepted in params for backward
  // compatibility but is not forwarded.
  const bodyData = {
    customer_id: String(params.uid).trim(),
    zone_id: String(params.zone_id).trim(),
  };

  try {
    console.log(`[liana] (vercel) verifying MLBB customer_id=${bodyData.customer_id} zone=${bodyData.zone_id}`);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    let response: Response;
    try {
      response = await fetch(LIANA_BASE + '/verify/mlbb', {
        method: 'POST',
        headers: lianaHeaders(apiKey),
        body: JSON.stringify(bodyData),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timer);
    }

    const rawText = await response.text();

    let json: any = null;
    try {
      json = rawText ? JSON.parse(rawText) : null;
    } catch {
      console.error(`[liana] (vercel) non-JSON response — HTTP ${response.status}: ${rawText.slice(0, 500)}`);
      return { success: false, verified: false, error: diagnoseNonJson(response.status, rawText), blocked: true };
    }

    // Plan restriction: 402 HTTP or message-based
    if (response.status === 402) {
      console.error(`[liana] (vercel) plan restriction — HTTP 402`);
      return { success: false, verified: false, error: 'This verification feature requires a Pro or Elite plan on the Liana account. Please upgrade the merchant plan.', blocked: true, planError: true };
    }

    if (response.status === 401 || response.status === 403) {
      console.error(`[liana] (vercel) auth rejected — HTTP ${response.status}. Check LIANA_API_KEY (single key, no secret needed).`);
      return { success: false, verified: false, error: 'Liana rejected the merchant credentials.', blocked: true };
    }

    if (!json) {
      return { success: false, verified: false, error: 'Empty response from verification server.', blocked: true };
    }

    // Plan error in JSON body (200 with error message)
    const rawMsg = String(json.message || json.error || '').toLowerCase();
    if (!truthy(json.status) && (rawMsg.includes('plan') || rawMsg.includes('upgrade') || rawMsg.includes('subscription') || rawMsg.includes('elite') || rawMsg.includes('pro '))) {
      console.error(`[liana] (vercel) plan restriction in JSON: ${json.message || json.error}`);
      return { success: false, verified: false, error: 'This verification feature requires a Pro or Elite plan on the Liana account. Please upgrade the merchant plan.', blocked: true, planError: true };
    }

    const d = json.data || {};

    // ign/region may be at top level OR under data — tolerate both.
    const ign = json.ign ?? d.ign ?? json.display ?? d.display ??
      json.playerName ?? d.playerName ?? json.player_name ?? d.player_name ??
      json.username ?? d.username ?? json.name ?? d.name ?? json.nickname ?? d.nickname;
    const region = json.region ?? d.region ?? null;

    const isVerified = truthy(json.status) || truthy(d.verified) || truthy(json.verified);
    const display = String(ign ?? '').trim();

    // Log unexpected nesting shapes for future lockdown.
    const hasTopLevel = 'ign' in json || 'region' in json;
    const hasNested = d && ('ign' in d || 'region' in d);
    if (!hasTopLevel && !hasNested && json) {
      console.warn(`[liana] (vercel) unexpected response shape. Keys: ${Object.keys(json).join(', ')}`);
    }

    console.log(`[liana] (vercel) HTTP ${response.status}, verified=${isVerified}, hasDisplay=${!!display}, region=${region}`);

    if (isVerified && display) {
      return { success: true, verified: true, playerName: display, display, region: region ? String(region) : null, provider: json };
    }
    if (isVerified) {
      // Verified but Liana gave no cached nickname — use a stable placeholder.
      const fallbackName = `Player_${bodyData.customer_id}`;
      return { success: true, verified: true, playerName: fallbackName, display: fallbackName, region: region ? String(region) : null, provider: json };
    }

    const errorMsg =
      json.message ||
      json.error ||
      "We couldn't verify this Mobile Legends account. Please check your Game ID and Zone ID and try again.";

    return { success: false, verified: false, error: errorMsg, provider: json };
  } catch (err: any) {
    const timedOut = err?.name === 'AbortError';
    console.error('[liana] (vercel) request failed:', timedOut ? 'timeout' : (err?.message || err));
    return {
      success: false,
      verified: false,
      blocked: true,
      error: timedOut ? 'Verification request timed out. Please try again.' : (err?.message || 'Verification service is temporarily unavailable. Please try again in a moment.'),
    };
  }
}

export interface LianaBalanceResult {
  success: boolean;
  balance?: number;
  error?: string;
  blocked?: boolean;
}

export async function checkMlbbBalanceLiana(): Promise<LianaBalanceResult> {
  const apiKey = (process.env.LIANA_API_KEY || '').trim();

  if (!apiKey) {
    return { success: false, error: 'Liana API credentials are not configured on the server.' };
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    let response: Response;
    try {
      response = await fetch(LIANA_BASE + '/balance', {
        method: 'GET',
        headers: lianaHeaders(apiKey),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timer);
    }

    const rawText = await response.text();
    let json: any = null;
    try {
      json = rawText ? JSON.parse(rawText) : null;
    } catch {
      console.error(`[liana] (vercel) balance non-JSON — HTTP ${response.status}: ${rawText.slice(0, 500)}`);
      return { success: false, error: diagnoseNonJson(response.status, rawText), blocked: true };
    }

    if (response.status === 401 || response.status === 403) {
      return { success: false, error: 'Liana rejected the merchant credentials.', blocked: true };
    }

    const d = json?.data || {};
    const candidate = d.balance ?? d.wallet_balance ?? d.amount ?? d.coins ??
      json?.balance ?? json?.wallet_balance;
    const num = Number(candidate);

    if (Number.isFinite(num)) {
      return { success: true, balance: num };
    }

    return { success: false, error: json?.message || json?.error || 'Failed to fetch merchant wallet balance.' };
  } catch (err: any) {
    const timedOut = err?.name === 'AbortError';
    return {
      success: false,
      blocked: true,
      error: timedOut ? 'Balance request timed out. Please try again.' : (err?.message || 'Balance service is temporarily unavailable.'),
    };
  }
}
