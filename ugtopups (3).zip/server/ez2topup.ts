import crypto from 'crypto';

/**
 * Ez2Topup API Data Types based on Official Specification PDF
 */
export interface Ez2TopupFreeFireData {
  username: string;
  region: string;
  open_id: string;
  player_id: string;
  game: string;
}

export interface Ez2TopupSuccessResponse {
  success: true;
  data: Ez2TopupFreeFireData;
}

export interface Ez2TopupErrorResponse {
  success: false;
  error: string;
  api_status?: boolean;
}

export type Ez2TopupResponse = Ez2TopupSuccessResponse | Ez2TopupErrorResponse;

/**
 * Step-by-Step HMAC-SHA256 Signature Generation Algorithm
 * 
 * 1. Gather all parameters passed in the request (excluding the `sign` parameter itself).
 * 2. Sort the parameters alphabetically by key.
 * 3. Build a query string from the sorted parameters (e.g. key1=value1&key2=value2).
 * 4. Compute the HMAC-SHA256 signature of this query string using your Secret Key.
 * 5. Return both query string and calculated hex signature.
 */
export function generateHmacSignature(
  params: Record<string, string>,
  secretKey: string
): { queryString: string; signature: string } {
  // 1. Gather parameters excluding 'sign'
  const cleanParams: Record<string, string> = {};
  for (const key of Object.keys(params)) {
    if (key !== 'sign' && params[key] !== undefined && params[key] !== null) {
      cleanParams[key] = String(params[key]).trim();
    }
  }

  // 2. Sort parameters alphabetically by key
  const sortedKeys = Object.keys(cleanParams).sort();
  const sortedParams: Record<string, string> = {};
  sortedKeys.forEach((key) => {
    sortedParams[key] = cleanParams[key];
  });

  // 3. Build query string
  const queryString = new URLSearchParams(sortedParams).toString();

  // 4. Compute HMAC-SHA256 signature
  const signature = crypto
    .createHmac('sha256', secretKey)
    .update(queryString)
    .digest('hex');

  return { queryString, signature };
}

/**
 * Production-ready Free Fire Player Verification calling official Ez2Topup API.
 * Uses secure HMAC signature, timeout protection, and retry logic.
 */
export async function verifyFreeFirePlayerEz2Topup(
  playerId: string,
  customApiKey?: string,
  customSecretKey?: string
): Promise<Ez2TopupResponse> {
  const apiKey = (customApiKey || process.env.EZ2TOPUP_API_KEY || process.env.FREEFIRE_API_KEY || '').trim();
  const secretKey = (customSecretKey || process.env.EZ2TOPUP_SECRET_KEY || process.env.FREEFIRE_SECRET_KEY || '').trim();

  const cleanPlayerId = (playerId || '').trim();
  if (!apiKey || !secretKey) {
    return { success: false, error: 'Free Fire verification is not configured on the server.', api_status: false };
  }
  if (!cleanPlayerId) {
    return {
      success: false,
      error: 'Player ID / UID is required for verification',
      api_status: false,
    };
  }

  // Parameter collection
  const params: Record<string, string> = {
    api_key: apiKey,
    player_id: cleanPlayerId,
  };

  // Generate signature if secret key exists
  const { queryString, signature } = generateHmacSignature(params, secretKey);
  const targetUrl = `https://ez2topup.com/api/v1/verify/freefire.php?${queryString}&sign=${signature}`;

  // Retry logic (up to 2 attempts) with 6s timeout each
  const maxAttempts = 2;
  let lastError: string = 'Player not found or invalid format';

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    try {
      const response = await fetch(targetUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'X-API-Key': apiKey,
          'X-Signature': signature,
        },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        const json = (await response.json()) as any;
        if (json && json.success && json.data) {
          const playerName = json.data.username || json.data.nickname || json.data.player_name;
          if (playerName) {
            return { success: true, data: { ...json.data, username: playerName, region: json.data.region || '', open_id: json.data.open_id || '', player_id: json.data.player_id || cleanPlayerId, game: json.data.game || 'free-fire' } };
          }
        }
        if (json && json.success === false) {
          return { success: false, error: json.error || json.message || 'Player not found or invalid format', api_status: false };
        }
      } else {
        const errJson = await response.json().catch(() => null);
        if (errJson && errJson.error) {
          return {
            success: false,
            error: errJson.error,
            api_status: false,
          };
        }
      }
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        lastError = 'Verification request timed out. Please check your connection.';
      } else if (err.message) {
        lastError = err.message;
      }
    }
  }

  return {
    success: false,
    error: lastError || 'Player ID not found or verification failed',
    api_status: false,
  };
}


/**
 * Generic Ez2Topup player verification for supported game endpoints.
 * The API/Secret credentials are shared; only the verification endpoint changes.
 */
export async function verifyEz2TopupPlayer(
  playerId: string,
  game: 'free-fire' | 'pubg',
  customApiKey?: string,
  customSecretKey?: string,
): Promise<Ez2TopupResponse> {
  const apiKey = (customApiKey || process.env.EZ2TOPUP_API_KEY || process.env.FREEFIRE_API_KEY || '').trim();
  const secretKey = (customSecretKey || process.env.EZ2TOPUP_SECRET_KEY || process.env.FREEFIRE_SECRET_KEY || '').trim();
  const cleanPlayerId = (playerId || '').trim();

  if (!apiKey || !secretKey) {
    return { success: false, error: 'Player verification is not configured on the server.', api_status: false };
  }
  if (!cleanPlayerId) {
    return { success: false, error: 'Player ID / UID is required for verification', api_status: false };
  }

  const params: Record<string, string> = { api_key: apiKey, player_id: cleanPlayerId };
  const { queryString, signature } = generateHmacSignature(params, secretKey);
  const endpoint = game === 'pubg' ? 'pubg.php' : 'freefire.php';
  const targetUrl = `https://ez2topup.com/api/v1/verify/${endpoint}?${queryString}&sign=${signature}`;

  let lastError = 'Player not found or invalid format';
  for (let attempt = 1; attempt <= 2; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(targetUrl, {
        method: 'GET',
        headers: { Accept: 'application/json', 'X-API-Key': apiKey, 'X-Signature': signature },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      const raw = await response.text();
      let json: any = null;
      try { json = JSON.parse(raw); } catch { lastError = 'Invalid response from verification server'; continue; }

      const payload = (json?.data && typeof json.data === 'object') ? json.data : json;
      const playerName =
        payload?.username || payload?.nickname || payload?.player_name || payload?.playerName ||
        payload?.name || payload?.ign || payload?.character_name || payload?.characterName ||
        json?.playerName || json?.username || json?.nickname || json?.name || json?.ign || '';
      const explicitSuccess =
        json?.success === true || json?.status === true || json?.api_status === true ||
        json?.verified === true || json?.valid === true ||
        String(json?.status || '').toLowerCase() === 'success';

      if (playerName && (response.ok || explicitSuccess)) {
        return {
          success: true,
          data: {
            ...payload,
            username: String(playerName),
            region: payload?.region || payload?.server || json?.region || '',
            open_id: payload?.open_id || payload?.openId || '',
            player_id: payload?.player_id || payload?.playerId || payload?.uid || payload?.user_id || cleanPlayerId,
            game: payload?.game || game,
          },
        };
      }

      lastError = json?.error || json?.message || json?.msg || json?.detail || payload?.error || payload?.message || 'Player not found or invalid format';
      const lower = String(lastError).toLowerCase();
      if (lower.includes('not found') || lower.includes('invalid')) break;
    } catch (err: any) {
      clearTimeout(timeoutId);
      lastError = err?.name === 'AbortError' ? 'Verification request timed out. Please try again.' : (err?.message || 'Network error during verification');
    }
  }
  return { success: false, error: lastError, api_status: false };
}
