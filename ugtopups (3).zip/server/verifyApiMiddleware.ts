import type { IncomingMessage, ServerResponse } from 'http';
import { verifyFreeFirePlayerEz2Topup, verifyEz2TopupPlayer } from './ez2topup';
import { verifyMlbbPlayerLiana } from './liana';

/**
 * Helper to parse body from IncomingMessage
 */
async function parseJsonBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        resolve({});
      }
    });
  });
}

/**
 * Server Middleware to securely handle player verification requests.
 * Keeps secret keys completely hidden from the frontend client.
 */
export async function handleFreeFireVerification(req: IncomingMessage, res: ServerResponse): Promise<void> {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-API-Key, X-Signature');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  try {
    const reqUrl = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
    let postBody: any = {};
    if (req.method === 'POST') {
      postBody = await parseJsonBody(req);
    }

    const gameId = String(postBody.gameId || reqUrl.searchParams.get('gameId') || 'free-fire').trim();
    const gameName = String(postBody.gameName || reqUrl.searchParams.get('gameName') || '').trim();
    const uid = postBody.uid || postBody.player_id || postBody.user_id || reqUrl.searchParams.get('uid') || reqUrl.searchParams.get('player_id') || reqUrl.searchParams.get('user_id') || '';
    const zoneId = postBody.zone_id || postBody.zoneId || reqUrl.searchParams.get('zone_id') || reqUrl.searchParams.get('zoneId') || '';
    const variationId = postBody.variation_id || postBody.variationId || reqUrl.searchParams.get('variation_id') || reqUrl.searchParams.get('variationId') || '';

    // IMPORTANT: detect MLBB by gameId ONLY — NOT by variationId alone.
    // Using variationId here would cause Free Fire requests (which also
    // pass a variationId) to be incorrectly routed to the Liana MLBB API.
    const gameIdLower = gameId.toLowerCase();
    const isMlbb = Boolean(
      gameIdLower.includes('mlbb') ||
      gameIdLower.includes('mobilelegend') ||
      gameIdLower.includes('mobile-legend') ||
      gameIdLower.includes('mobile_legend')
    );

    if (isMlbb) {
      if (!uid || !zoneId) {
        res.statusCode = 200;
        res.end(JSON.stringify({
          success: false,
          verified: false,
          error: 'Missing required Game ID or Zone ID for Mobile Legends',
        }));
        return;
      }

      const mlbbResult = await verifyMlbbPlayerLiana({
        variation_id: variationId || 5657,
        uid,
        zone_id: zoneId,
      });

      res.statusCode = 200;
      res.end(JSON.stringify(mlbbResult));
      return;
    }

    if (!uid) {
      res.statusCode = 400;
      res.end(JSON.stringify({
        success: false,
        error: 'Missing required parameter: player_id / uid',
        api_status: false,
      }));
      return;
    }

    // Call the same Ez2Topup credentials for the selected supported game.
    const isPubg = /pubg|bgmi/i.test(`${gameId} ${gameName}`);
    const result = isPubg
      ? await verifyEz2TopupPlayer(uid, 'pubg')
      : await verifyFreeFirePlayerEz2Topup(uid);

    if (result.success) {
      res.statusCode = 200;
      res.end(JSON.stringify({
        success: true,
        playerName: result.data.username,
        gameId,
        uid: result.data.player_id,
        region: result.data.region,
        data: result.data,
      }));
    } else {
      res.statusCode = 200; // Return 200 so client can gracefully read error message
      res.end(JSON.stringify({
        success: false,
        error: result.error || 'Player not found or invalid format',
        api_status: false,
      }));
    }
  } catch (err: any) {
    res.statusCode = 200;
    res.end(JSON.stringify({
      success: false,
      error: err?.message || 'Internal server error during verification',
      api_status: false,
    }));
  }
}

